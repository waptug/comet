--
--  Create the Courses database for course scheduling and curriculum
--  planning workflow management.
--

CREATE DATABASE courses;
USE courses;


CREATE TABLE course
(
	courseid SERIAL NOT NULL,
	curriculum CHAR(6) NOT NULL,
	courseno SMALLINT UNSIGNED NOT NULL,
	title VARCHAR(255),
	shorttitle VARCHAR(100),
	wildcardtitle VARCHAR(255),
	creditcontrol CHAR(10),
	creditmin SMALLINT,
	creditmax SMALLINT,
	creditrepeatmax SMALLINT,
	creditestimate SMALLINT,
	general_education TEXT,
	rouid BIGINT UNSIGNED,
	firstquarter CHAR(6),
	lastquarter CHAR(6),
	swslastupdate DATETIME,
	CONSTRAINT pk_courses PRIMARY KEY(courseid)
);

ALTER TABLE course ADD COLUMN wildcardcode VARCHAR(50) AFTER wildcardtitle;
ALTER TABLE course DROP COLUMN selfsustaining;

CREATE TABLE offering
(
	offeringid SERIAL NOT NULL,
	courseid BIGINT UNSIGNED NOT NULL,
	year YEAR NOT NULL,
	quarter TINYINT UNSIGNED NOT NULL,
	section CHAR(1) NOT NULL DEFAULT 'A',
	summerterm CHAR(1),
	sectiontype CHAR(2),
	institution CHAR(10) NOT NULL DEFAULT 'state',
	funding CHAR(2) NOT NULL DEFAULT 'St',
	sln BIGINT UNSIGNED,
	creditcontrol CHAR(10),
	creditmin SMALLINT,
	creditmax SMALLINT,
	enrollmentcurrent SMALLINT UNSIGNED,
	enrollmentestimate SMALLINT UNSIGNED,
	enrollmentlimit SMALLINT UNSIGNED,
	studentcredithours SMALLINT UNSIGNED,
	studentcredithoursestimate SMALLINT UNSIGNED,
	gradingsystem SMALLINT UNSIGNED,
	syllabusid BIGINT UNSIGNED,
	meetingsummary VARCHAR(100),
	status CHAR(10),
	repetitionid BIGINT UNSIGNED,
	uwtsstatus TINYINT UNSIGNED NOT NULL DEFAULT 0,
	roomstatus TINYINT UNSIGNED NOT NULL DEFAULT 0,
	sectionstatus CHAR(1) NOT NULL DEFAULT 'P',
	instructorapproval TINYINT UNSIGNED NOT NULL DEFAULT 0,
	instructorapproval_logid BIGINT UNSIGNED,
	CONSTRAINT pk_offering PRIMARY KEY(offeringid)
);

ALTER TABLE offering ADD COLUMN status CHAR(10) AFTER meetingsummary;
ALTER TABLE offering MODIFY COLUMN sln BIGINT UNSIGNED;
ALTER TABLE offering ADD COLUMN estcredithours SMALLINT UNSIGNED AFTER credithours;
ALTER TABLE offering ADD COLUMN selfsustaining TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER type;

UPDATE offering SET selfsustaining = 1 WHERE courseid IN (SELECT courseid FROM course WHERE selfsustaining = 1);

CREATE TABLE offeringrule
(
	ruleid SERIAL NOT NULL,
	courseid BIGINT UNSIGNED NOT NULL,
	firstyear YEAR NOT NULL,
	yearfreq TINYINT UNSIGNED NOT NULL DEFAULT 1,
	quarter TINYINT UNSIGNED NOT NULL,
	sections TINYINT UNSIGNED NOT NULL DEFAULT 1,
	sectionpref VARCHAR(100),
	CONSTRAINT pk_offeringrule PRIMARY KEY(ruleid)
);

ALTER TABLE offeringrule ADD COLUMN sectionpref VARCHAR(100) AFTER sections;

CREATE TABLE orgunit
(
	orgunitid SERIAL NOT NULL,
	name VARCHAR(50) NOT NULL,
	description TEXT,
	CONSTRAINT pk_orgunit PRIMARY KEY(orgunitid)
);

ALTER TABLE orgunit AUTO_INCREMENT = 1000;


CREATE TABLE person
(
	personid SERIAL NOT NULL,
	firstname VARCHAR(50),
	lastname VARCHAR(50),
	uwnetid CHAR(8),
	ein CHAR(10),
	email VARCHAR(255),
	phone VARCHAR(25),
	source CHAR(10),
	area CHAR(6),
	faculty_rouid BIGINT UNSIGNED,
	isfaculty TINYINT UNSIGNED NOT NULL DEFAULT 0,
	isadjunct TINYINT UNSIGNED NOT NULL DEFAULT 0,
	isstudentstaff TINYINT UNSIGNED NOT NULL DEFAULT 0,
	isssupport TINYINT UNSIGNED NOT NULL DEFAULT 0,
	workflow TINYINT UNSIGNED NOT NULL DEFAULT 0,
	CONSTRAINT pk_person PRIMARY KEY(personid)
);

ALTER TABLE person ADD COLUMN isfaculty TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER source;
ALTER TABLE person ADD COLUMN isadjunct TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER isfaculty;
ALTER TABLE person ADD COLUMN isstudentstaff TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER isadjunct;
ALTER TABLE person ADD COLUMN issupport TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER isstudentstaff;


ALTER TABLE person AUTO_INCREMENT = 1000;

INSERT INTO person VALUES(1, '', 'To be determined', 'tbd', NULL, NULL, NULL, 'system', 0, 0, 0);

CREATE TABLE uwperson
(
	ein CHAR(10),
	firstname VARCHAR(50),
	lastname VARCHAR(50),
	uwnetid CHAR(8),
	CONSTRAINT pk_uwperson PRIMARY KEY(ein)
);


INSERT INTO orgunit VALUES(10, 'EDC&I', null);
INSERT INTO orgunit VALUES(11, 'EDC&I Chair', null);
INSERT INTO orgunit VALUES(12, 'EDC&I Area Administrator', null);
INSERT INTO orgunit VALUES(19, 'EDC&I Faculty & Staff', null);
INSERT INTO orgunit VALUES(20, 'EDPSY', null);
INSERT INTO orgunit VALUES(21, 'EDPSY Chair', null);
INSERT INTO orgunit VALUES(22, 'EDPSY Area Administrator', null);
INSERT INTO orgunit VALUES(29, 'EDPSY Faculty & Staff', null);
INSERT INTO orgunit VALUES(30, 'EDLPS', null);
INSERT INTO orgunit VALUES(31, 'EDLPS Chair', null);
INSERT INTO orgunit VALUES(32, 'EDLPS Area Administrator', null);
INSERT INTO orgunit VALUES(39, 'EDLPS Faculty & Staff', null);
INSERT INTO orgunit VALUES(40, 'EDSPE', null);
INSERT INTO orgunit VALUES(41, 'EDSPE Chair', null);
INSERT INTO orgunit VALUES(42, 'EDSPE Area Administrator', null);
INSERT INTO orgunit VALUES(49, 'EDSPE Faculty & Staff', null);
INSERT INTO orgunit VALUES(70, 'ECFS', null);
INSERT INTO orgunit VALUES(71, 'ECFS Chair', null);
INSERT INTO orgunit VALUES(72, 'ECFS Area Administrator', null);
INSERT INTO orgunit VALUES(79, 'ECFS Faculty & Staff', null);
INSERT INTO orgunit VALUES(80, 'TEP', null);
INSERT INTO orgunit VALUES(81, 'TEP Chair', null);
INSERT INTO orgunit VALUES(82, 'TEP Area Administrator', null);
INSERT INTO orgunit VALUES(89, 'TEP Faculty & Staff', null);
INSERT INTO orgunit VALUES(90, 'EDUC General College', null);
INSERT INTO orgunit VALUES(91, 'EDUC Chair', null);
INSERT INTO orgunit VALUES(92, 'EDUC Area Administrator', null);
INSERT INTO orgunit VALUES(99, 'EDUC Faculty & Staff', null);

INSERT INTO orgunit VALUES(101, 'Dean', null);
INSERT INTO orgunit VALUES(102, 'Academic Review', null);
INSERT INTO orgunit VALUES(103, 'Fiscal Review', null);
INSERT INTO orgunit VALUES(104, 'Room Scheduling', null);

CREATE TABLE personorgunit
(
	orgunitid BIGINT UNSIGNED NOT NULL,
	personid BIGINT UNSIGNED NOT NULL,
	CONSTRAINT pk_personorgunit PRIMARY KEY(orgunitid, personid)
);

CREATE TABLE staff
(
	staffid SERIAL NOT NULL,
	offeringid BIGINT UNSIGNED NOT NULL,
	meetingnumber TINYINT UNSIGNED NOT NULL DEFAULT 1,
	personid BIGINT UNSIGNED NOT NULL,
	role CHAR(10) NOT NULL,
	timesched TINYINT UNSIGNED NOT NULL DEFAULT 0,
	reason INTEGER,
	buyoutfor BIGINT UNSIGNED,
	CONSTRAINT pk_personorgunit PRIMARY KEY(staffid)
);

CREATE TABLE comment 

CREATE TABLE eventlog
(
	eventid SERIAL NOT NULL,
	type CHAR(10) NOT NULL,
	actor CHAR(8),
	offeringid BIGINT UNSIGNED NOT NULL,
	sentto VARCHAR(255),
	orgunitid BIGINT UNSIGNED NOT NULL,
	created DATETIME,
	description VARCHAR(100),
	CONSTRAINT pk_eventlog PRIMARY KEY(eventid)
);

CREATE TABLE meeting
(
	meetingid SERIAL NOT NULL,
	offeringid BIGINT UNSIGNED NOT NULL,
	dow TINYINT UNSIGNED NOT NULL,
	start TIME NOT NULL,
	end TIME NOT NULL,
	CONSTRAINT pk_meeting PRIMARY KEY(meetingid)
);

CREATE TABLE workflowstep
(
	stepid SERIAL NOT NULL,
	offeringid BIGINT UNSIGNED NOT NULL,
	workflowtype ENUM('offering') DEFAULT 'offering',
	steptype CHAR(10) NOT NULL,
	started DATETIME NOT NULL,
	responsible BIGINT UNSIGNED NOT NULL,
	result TINYINT UNSIGNED DEFAULT 0,
	completed DATETIME,
	completedby CHAR(8),
	revisit TINYINT UNSIGNED DEFAULT 0,
	CONSTRAINT pk_workflowstep PRIMARY KEY(stepid)
);

CREATE TABLE workflowmessage
(
	messageid SERIAL NOT NULL,
	stepid  BIGINT UNSIGNED NOT NULL,
	uwnetid CHAR(8) NOT NULL,
	created DATETIME NOT NULL,
	message TEXT,
	CONSTRAINT pk_workflowmessage PRIMARY KEY(messageid)
);

--
--  NOT SURE IF WE NEED THIS. MIGHT IMPLEMENT AS AN E-MAIL LOG INSTEAD
--
CREATE TABLE wfnotification
(
	notificationid SERIAL NOT NULL,
	wftype CHAR(10) NOT NULL,
	steptype CHAR(10) NOT NULL,
	status CHAR(10) NOT NULL,
	createdby CHAR(8) NOT NULL,
	created DATETIME NOT NULL,
	CONSTRAINT pk_wfnotification PRIMARY KEY(notificationid)
);

CREATE TABLE syllabus
(
	syllabusid SERIAL NOT NULL,
	url VARCHAR(255),
	filename VARCHAR(255),
	CONSTRAINT pk_syllabus PRIMARY KEY(syllabusid)
);

CREATE TABLE quarter
(
    year SMALLINT UNSIGNED NOT NULL,
    quarter TINYINT UNSIGNED NOT NULL,
    description VARCHAR(100),
    start DATE,
    end DATE,
    CONSTRAINT pk_quarter PRIMARY KEY(year, quarter)
) ENGINE = InnoDB;

INSERT INTO quarter SELECT * FROM step.quarter;
DELETE FROM quarter WHERE quarter = 0;
update quarter set description = 'Autumn 2013' where year = '2013' and quarter = 4;


CREATE TABLE c_error
(
    errorid SERIAL NOT NULL,
    url VARCHAR(300),
    httpcode SMALLINT UNSIGNED,
    response TEXT,
    attempted TIMESTAMP,
    CONSTRAINT pk_c_error PRIMARY KEY(errorid)
);

CREATE TABLE phpsession
(
    sessionid CHAR(32),
    data TEXT,
    accessed DATETIME,
    CONSTRAINT pk_phpsession PRIMARY KEY(sessionid)
);

CREATE TABLE auth
(
	uwnetid CHAR(8) NOT NULL,
	role CHAR(10) NOT NULL,
	CONSTRAINT pk_auth PRIMARY KEY(uwnetid)
);

INSERT INTO auth VALUES
('kemath', 'super'),
('hanisko', 'super'),
('mthowell', 'super');

CREATE TABLE appsettings
(
	setting VARCHAR(50) NOT NULL,
	value VARCHAR(255),
	CONSTRAINT pk_appsettings PRIMARY KEY(setting)
);


update course set orgunitid = 10 where department = 'EDC&I';
update course set orgunitid = 20 where department = 'EDPSY';
update course set orgunitid = 30 where department = 'EDLPS';
update course set orgunitid = 40 where department = 'EDSPE';
update course set orgunitid = 70 where department = 'ECFS';
update course set orgunitid = 80 where department = 'TEP';
update course set orgunitid = 90 where department = 'EDUC';

		10 => 'EDC&I',
		20 => 'EDPSY',
		30 => 'EDLPS',
		40 => 'EDSPE',
		70 => 'ECFS',
		80 => 'TEP',
		90 => 'EDUC'
		
--
-- rename department to curriculum
-- dev 10/27/2011
-- prod 10/28/2011
ALTER TABLE course ADD COLUMN curriculum CHAR(6) NOT NULL DEFAULT 'EDUC' AFTER department;
UPDATE course SET curriculum = department;
ALTER TABLE course DROP COLUMN department;


--
-- tag tables 
-- development 10/31/2011
-- production 11/17/2011
CREATE TABLE tag 
(
	tagid SERIAL NOT NULL,
	name VARCHAR(200) NOT NULL,
	owner CHAR(8) NOT NULL,
	CONSTRAINT pk_tag PRIMARY KEY(tagid)
);

CREATE TABLE tagpermission
(
	tagid BIGINT UNSIGNED NOT NULL,
	uwnetid CHAR(8) NOT NULL,
	CONSTRAINT pk_tagpermission PRIMARY KEY(tagid, uwnetid)
);

CREATE TABLE offeringtag
(
	offeringid BIGINT UNSIGNED NOT NULL,
	tagid BIGINT UNSIGNED NOT NULL,
	CONSTRAINT pk_offeringtag PRIMARY KEY(offeringid, tagid)
);

CREATE TABLE coursetag
(
	courseid BIGINT UNSIGNED NOT NULL,
	tagid BIGINT UNSIGNED NOT NULL,
	CONSTRAINT pk_coursetag PRIMARY KEY(courseid, tagid)
);

CREATE TABLE confirmation
(
    code CHAR(32) NOT NULL,
	uwnetid CHAR(8) NOT NULL,
    created DATETIME,
    CONSTRAINT pk_confirmation PRIMARY KEY(code, uwnetid)
);

--
-- Logging
--  on production 12/20/2011
CREATE TABLE activitylog
(
	logid SERIAL NOT NULL,
	uwnetid CHAR(8) NOT NULL,
	entered DATETIME NOT NULL,
	action CHAR(12) NOT NULL,
	courseid BIGINT UNSIGNED,
	offeringid BIGINT UNSIGNED,
	metadata TEXT,
	CONSTRAINT pk_activitylog PRIMARY KEY(logid)
);


--
-- Discussion & yellow cards v2
--  on development 1/3/2012
--  on production 1/3/2012
--
CREATE TABLE discussion
(
	discussionid SERIAL NOT NULL,
	uwnetid CHAR(8) NOT NULL,
	created DATETIME NOT NULL,
	courseid BIGINT UNSIGNED,
	offeringid BIGINT UNSIGNED,
	comment TEXT,
	thread BIGINT UNSIGNED,
	CONSTRAINT pk_discussion PRIMARY KEY(discussionid)
);

ALTER TABLE discussion DROP COLUMN yellowcard;
ALTER TABLE discussion DROP COLUMN ycresolved;
ALTER TABLE discussion DROP COLUMN yctype;

CREATE TABLE adcabnote
(
	adcabnoteid SERIAL NOT NULL,
	uwnetid CHAR(8) NOT NULL,
	created DATETIME NOT NULL,
	offeringid BIGINT UNSIGNED NOT NULL,
	replyto BIGINT UNSIGNED,
	comment TEXT,
	resolved TINYINT UNSIGNED NOT NULL DEFAULT 0,
	notetype CHAR(10),
	CONSTRAINT pk_adcabnote PRIMARY KEY(adcabnoteid)
);

--
-- Add area to person records
--  on dev and production 12/19/2011
ALTER TABLE person ADD COLUMN area CHAR(6) AFTER source;

--
-- Fixed credits fields, default value on course, actual value
-- goes in offering

ALTER TABLE offering ADD COLUMN creditsfixed

--
-- Get tags into a single table
-- changed on dev and production 1/23/12

RENAME TABLE offeringtag TO offeringtag_old;

CREATE TABLE offeringtag
(
	tagid BIGINT UNSIGNED NOT NULL,
	offeringid BIGINT UNSIGNED,
	courseid BIGINT UNSIGNED,
	CONSTRAINT pk_offeringtag PRIMARY KEY(tagid, offeringid, courseid)
);

INSERT INTO offeringtag(tagid, offeringid) SELECT tagid, offeringid FROM offeringtag_old;
INSERT INTO offeringtag(tagid, courseid) SELECT tagid, courseid FROM coursetag;

RENAME TABLE coursetag TO coursetag_old;

-- only deleted on dev 1/23/12
-- still needs deleted on production
DROP TABLE coursetag;
DROP TABLE offeringtag_old;

-- add fixed credits fields
-- 1/31/2012 development and production
ALTER TABLE course ADD COLUMN defaultfixedcredits TINYINT UNSIGNED AFTER orgunitid;
ALTER TABLE offering ADD COLUMN fixedcredits TINYINT UNSIGNED AFTER estenrolled;

-- add status flags for Time Schedule and room
-- on development 1/31/2012
-- on production 2/3/2012
ALTER TABLE offering ADD COLUMN uwtsstatus TINYINT UNSIGNED DEFAULT 0 AFTER status;
ALTER TABLE offering ADD COLUMN roomstatus TINYINT UNSIGNED DEFAULT 0 AFTER uwtsstatus;

ALTER TABLE offering DROP COLUMN uwtsstatus;
ALTER TABLE offering DROP COLUMN roomstatus;


-- add status flags for Time Schedule and room
-- on development 2/7/2012
-- on production 2/7/2012
ALTER TABLE offering ADD COLUMN varcredits VARCHAR(100) AFTER fixedcredits;
ALTER TABLE offering ADD COLUMN varcredits VARCHAR(100) AFTER fixedcredits;


-- clean up some unused tables and fields
-- on development and production 2/7/2012
ALTER TABLE course DROP COLUMN selfsustaining;
ALTER TABLE offering DROP COLUMN deleted;
DROP TABLE eventlog;
DROP TABLE old_staff;
DROP TABLE workflowmessage;
DROP TABLE workflowstep;

-- add status flags for Time Schedule and room
-- on development 2/7/2012
-- on production 2/8/2012
CREATE TABLE roomneed
(
	offeringid BIGINT UNSIGNED NOT NULL,
	roompref1 VARCHAR(50),
	roompref2 VARCHAR(50),
	roompref3 VARCHAR(50),
	features VARCHAR(100),
	CONSTRAINT pk_roomneed PRIMARY KEY(offeringid)
);

CREATE TABLE roomcomment
(
	roomcommentid SERIAL NOT NULL,
	offeringid BIGINT UNSIGNED NOT NULL,
	uwnetid CHAR(8) NOT NULL,
	created DATETIME NOT NULL,
	comment TEXT,
	CONSTRAINT pk_roomcomment PRIMARY KEY(roomcommentid)
);

--
-- create space for replaced faculty on staff table
--
ALTER TABLE staff ADD COLUMN buyoutfor BIGINT UNSIGNED AFTER role;


-- add grading system flag
-- 6126194
ALTER TABLE offering ADD COLUMN gradingsystem SMALLINT UNSIGNED AFTER estcredithours;


ALTER TABLE course MODIFY COLUMN defaultfixedcredits VARCHAR(100);

--
-- Lookup tables for Karen reporting
--

CREATE TABLE l_staff_reason
(
	code INT NOT NULL,
	description VARCHAR(200),
	CONSTRAINT pk_l_staff_reason PRIMARY KEY(code)
);
INSERT INTO l_staff_reason VALUES
(0, '(reason unknown)'),
(1, 'Administrative buy out'),
(2, 'Grant buy out'),
(3, 'Retired faculty rehire'),
(4, 'Sabbatical'),
(5, 'Self-sustaining'),
(6, 'Tenure-track vacancy'),
(9, 'Tradition'),
(10, 'No faculty expertise');

CREATE TABLE l_staff_role
(
	code CHAR(10),
	description VARCHAR(200),
	CONSTRAINT pk_l_staff_role PRIMARY KEY(code)
);

INSERT INTO l_staff_role VALUES
('faculty', 'Faculty'),
('adjunct', 'Adjunct'),
('grader', 'Grader'),
('ta', 'Teaching Assistant');

CREATE TABLE l_offering_gradingsystem
(
	code INT UNSIGNED,
	description VARCHAR(200),
	CONSTRAINT pk_l_offering_gradingsystem PRIMARY KEY(code)
);

INSERT INTO l_offering_gradingsystem VALUES
(1, 'Standard grading'),
(5, 'Credit/No-credit');	


CREATE TABLE l_offering_status
(
	code INT UNSIGNED,
	description VARCHAR(200),
	CONSTRAINT pk_l_offering_status PRIMARY KEY(code)
);

INSERT INTO l_offering_status VALUES
(0, 'Not entered'),
(1, 'Modified'),
(2, 'Up to date');

--
--  Rooms - add place to store rooms and to differentiate between meetings
--  completed on production 3/20/2012

ALTER TABLE staff ADD COLUMN meetingnumber TINYINT UNSIGNED NOT NULL DEFAULT 1 AFTER offeringid;

RENAME TABLE meeting TO meeting_old;

CREATE TABLE meeting
(
	meetingid SERIAL NOT NULL,
	offeringid BIGINT UNSIGNED NOT NULL,
	meetingnumber TINYINT UNSIGNED NOT NULL DEFAULT 1,
	start TIME,
	end TIME,
	dows CHAR(7),
	building VARCHAR(50),
	room VARCHAR(50),
	CONSTRAINT pk_meeting PRIMARY KEY(meetingid)
);

ALTER TABLE meeting MODIFY start TIME;
ALTER TABLE meeting MODIFY end TIME;

CREATE TABLE meetingday
(
	meetingid BIGINT UNSIGNED NOT NULL,
	dow TINYINT UNSIGNED NOT NULL,
	CONSTRAINT pk_meetingday PRIMARY KEY(meetingid, dow)
);

--
-- Repetition rules version 2
-- dev 3/21/2012
-- prod 4/5/2012
--

ALTER TABLE offering CHANGE COLUMN type sectiontype CHAR(2);
ALTER TABLE offering ADD COLUMN funding CHAR(2) NOT NULL DEFAULT 'St' AFTER selfsustaining;
UPDATE offering SET funding = 'SS' WHERE selfsustaining = 1;
SELECT offeringid, selfsustaining, funding FROM offering;
ALTER TABLE offering DROP COLUMN selfsustaining;
ALTER TABLE offering ADD COLUMN repetitionid BIGINT UNSIGNED AFTER status;

CREATE TABLE repetition
(
	repetitionid SERIAL NOT NULL,
	courseid BIGINT UNSIGNED NOT NULL,
	firstyear YEAR NOT NULL,
	yearfreq TINYINT UNSIGNED NOT NULL DEFAULT 1,
	quarter TINYINT UNSIGNED NOT NULL,
	sections TINYINT UNSIGNED NOT NULL DEFAULT 1,
	sectionpref VARCHAR(100),
	sectiontype CHAR(2),
	funding CHAR(2),
	gradingsystem SMALLINT UNSIGNED,
	staffjson TEXT,
	meetingsjson TEXT,
	CONSTRAINT pk_repetition PRIMARY KEY(repetitionid)
);

INSERT INTO repetition(courseid, firstyear, yearfreq, quarter, sections, sectionpref) 
SELECT courseid, firstyear, yearfreq, quarter, sections, sectionpref 
FROM offeringrule;

ALTER TABLE staff ADD COLUMN repetitionindex SMALLINT UNSIGNED;

-- temp table for fixing extra partial meeting records
-- supports utility/meeting_dedupe.php
-- dev & prod 4/5/2012
CREATE TABLE t_meetingdupe
(
	offeringid BIGINT UNSIGNED NOT NULL,
	meetingnumber INTEGER UNSIGNED,
	quantity INTEGER UNSIGNED,
	CONSTRAINT pk_t_meetingdupe PRIMARY KEY(offeringid, meetingnumber)
);

--
-- Add term field to course offering
-- dev & prod 4/6/2012
ALTER TABLE offering ADD COLUMN summerterm CHAR(1) AFTER section;
ALTER TABLE repetition ADD COLUMN summerterm CHAR(1) AFTER sectionpref;


--
--  Add UWTS Version
--  changed in DEV: beginning 4/15/2012
--  changed in PROD: 6/19/2012
--

-- prep remove all quiz sections
-- php -f delete_quiz_sections.php

ALTER TABLE person ADD COLUMN regid VARCHAR(40) AFTER ein;

ALTER TABLE activitylog MODIFY action VARCHAR(25) NOT NULL;

ALTER TABLE course DROP COLUMN description;
ALTER TABLE course DROP COLUMN facultydescription;
ALTER TABLE course DROP COLUMN defaultfixedcredits;
--ALTER TABLE course DROP COLUMN gradingsystem;

ALTER TABLE course ADD COLUMN creditcontrol CHAR(10) AFTER wildcardtitle;
ALTER TABLE course ADD COLUMN creditfixed SMALLINT AFTER creditcontrol;
ALTER TABLE course ADD COLUMN creditmin SMALLINT AFTER creditfixed;
ALTER TABLE course ADD COLUMN creditmax SMALLINT AFTER creditmin;
ALTER TABLE course ADD COLUMN creditrepeatmax SMALLINT AFTER creditmax;
ALTER TABLE course ADD COLUMN creditestimate SMALLINT AFTER creditrepeatmax;
ALTER TABLE course ADD COLUMN firstquarter CHAR(6) AFTER orgunitid;
ALTER TABLE course ADD COLUMN lastquarter CHAR(6) AFTER firstquarter;
ALTER TABLE course ADD COLUMN swslastupdate DATETIME AFTER lastquarter;

CREATE TABLE coursedetail
(
	courseid BIGINT UNSIGNED NOT NULL,
	detailkey VARCHAR(100) NOT NULL,
	detailvalue TEXT,
	CONSTRAINT pk_coursedetail PRIMARY KEY(courseid, detailkey)
);

ALTER TABLE offering MODIFY COLUMN section CHAR(2) NOT NULL DEFAULT 'A';
ALTER TABLE offering ADD COLUMN enrollmentcurrent SMALLINT AFTER sln;
ALTER TABLE offering ADD COLUMN enrollmentestimate SMALLINT AFTER enrollmentcurrent;
ALTER TABLE offering ADD COLUMN enrollmentlimit SMALLINT AFTER enrollmentestimate;
ALTER TABLE offering ADD COLUMN studentcredithours SMALLINT AFTER enrollmentlimit;
ALTER TABLE offering ADD COLUMN studentcredithoursestimate SMALLINT AFTER studentcredithours;
ALTER TABLE offering ADD COLUMN sectionstatus CHAR(1) NOT NULL DEFAULT 'P' AFTER roomstatus;

UPDATE offering SET enrollmentcurrent = enrolled;
UPDATE offering SET enrollmentestimate = estenrolled;
UPDATE offering SET studentcredithours = credithours;
UPDATE offering SET studentcredithoursestimate = estcredithours;

ALTER TABLE offering DROP COLUMN enrolled;
ALTER TABLE offering DROP COLUMN estenrolled;
ALTER TABLE offering DROP COLUMN credithours;
ALTER TABLE offering DROP COLUMN estcredithours;
ALTER TABLE offering DROP COLUMN fixedcredits;
ALTER TABLE offering DROP COLUMN varcredits;


CREATE TABLE uwtsoffering
(
	uwtsofferingid SERIAL NOT NULL,
	courseid BIGINT UNSIGNED NOT NULL,
	offeringid BIGINT UNSIGNED,
	sln BIGINT UNSIGNED,
	year YEAR NOT NULL,
	quarter TINYINT UNSIGNED NOT NULL,
	section CHAR(2) NOT NULL DEFAULT 'A',
	summerterm CHAR(1),
	sectiontype CHAR(2),
	creditcontrol CHAR(10),
	creditmin SMALLINT,
	creditmax SMALLINT,
	enrollmentcurrent SMALLINT,
	enrollmentestimate SMALLINT,
	enrollmentlimit SMALLINT,
	gradingsystem CHAR(10),
	deleteflag CHAR(10),
	swspath VARCHAR(255),
	swslastupdate DATETIME,
	importdate DATETIME,
	CONSTRAINT pk_uwtsoffering PRIMARY KEY(uwtsofferingid)
);

CREATE TABLE uwtsmeeting
(
	uwtsofferingid BIGINT UNSIGNED NOT NULL,
	meetingnumber TINYINT UNSIGNED NOT NULL DEFAULT 1,
	meetingid BIGINT UNSIGNED,
	meetingtype CHAR(2),
	dows CHAR(7),
	start TIME,
	end TIME,
	building VARCHAR(50),
	room VARCHAR(50),
	CONSTRAINT pk_uwtsmeeting PRIMARY KEY(uwtsofferingid, meetingnumber)
);

CREATE TABLE uwtsstaff
(
	uwtsstaffid SERIAL NOT NULL,
	uwtsofferingid BIGINT UNSIGNED NOT NULL,
	meetingnumber TINYINT UNSIGNED NOT NULL DEFAULT 1,
	regid VARCHAR(40) NOT NULL,
	staffid BIGINT UNSIGNED,
	personid BIGINT UNSIGNED,
	CONSTRAINT pk_uwtsstaff PRIMARY KEY(uwtsstaffid)
);

DROP TABLE comment;

CREATE TABLE comment
(
	commentid SERIAL NOT NULL,
	courseid BIGINT UNSIGNED,
	offeringid BIGINT UNSIGNED,
	commenttype CHAR(10) NOT NULL,
	createdby BIGINT UNSIGNED,
	createdon DATETIME,
	editedon DATETIME,
	commenttext TEXT,
	CONSTRAINT pk_comment PRIMARY KEY(commentid)
);

--
-- change grading system coding from int to string
ALTER TABLE offering CHANGE gradingsystem old_gradingsystem SMALLINT UNSIGNED;
ALTER TABLE offering ADD COLUMN gradingsystem CHAR(10) AFTER old_gradingsystem;
UPDATE offering SET gradingsystem = 'standard' WHERE old_gradingsystem = 1;
UPDATE offering SET gradingsystem = 'credit' WHERE old_gradingsystem = 5;
-- spot check
SELECT offeringid, gradingsystem, old_gradingsystem FROM offering;
ALTER TABLE offering DROP COLUMN old_gradingsystem;


-- change grading system coding from int to string for repetition
ALTER TABLE repetition CHANGE gradingsystem old_gradingsystem SMALLINT UNSIGNED;
ALTER TABLE repetition ADD COLUMN gradingsystem CHAR(10) AFTER old_gradingsystem;
UPDATE repetition SET gradingsystem = 'standard' WHERE gradingsystem = 0;
UPDATE repetition SET gradingsystem = 'standard' WHERE old_gradingsystem = 1;
UPDATE repetition SET gradingsystem = 'credit' WHERE old_gradingsystem = 5;
-- spot check
SELECT repetitionid, gradingsystem, old_gradingsystem FROM repetition;
ALTER TABLE repetition DROP COLUMN old_gradingsystem;

--
-- Table to log the matching process
--
CREATE TABLE uwtsmatchinglog
(
	id SERIAL NOT NULL,
	processed DATETIME NOT NULL,
	uwtsofferingid BIGINT UNSIGNED,
	offeringid BIGINT UNSIGNED,
	linkcreated TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
	error TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
	resultcode TINYINT UNSIGNED NOT NULL,
	matchingscore SMALLINT UNSIGNED,
	uwnetid CHAR(8),
	CONSTRAINT pk_uwtsmatchinglog PRIMARY KEY(id)
);

CREATE TABLE l_uwtsmatchinglog_result
(
	resultcode TINYINT UNSIGNED NOT NULL,
	description VARCHAR(200),
	CONSTRAINT pk_l_uwtsmatchinglog_result PRIMARY KEY(resultcode)
);

INSERT INTO l_uwtsmatchinglog_result VALUES
(1, 'not able to link, matching score too low'),
(2, 'not able to link, multiple possible sections'),
(3, 'not able to link on SLN or verified section'),
(21, 'linked on SLN'),
(22, 'linked on verified section'),
(23, 'linked on section match and matching score'),
(24, 'created new plan offering'),
(75, 'linked UWTS to plan manually'),
(76, 'created new plan offering manually'),
(86, 'removed link between UWTS and plan'),
(91, 'found SLN match with different section ids'),
(92, 'found SLN match already linked to different record'),
(93, 'found verified section match already linked to different record');

--
-- give tbd record a uwnetid that will not match in SWS
--
UPDATE person SET 
	firstname = null, 
	lastname = 'To be determined',
	uwnetid = '(TBD)',
	regid = 'TBD', 
	email = null, 
	isfaculty = 1, 
	isadjunct = 1, 
	isstudentstaff = 1 
WHERE personid = 1;

--
--  Change summer full term indicator from empty to F
--
UPDATE offering SET summerterm = 'F' WHERE quarter = 3 AND summerterm IS NULL OR summerterm = '';

--
--  Buy out records now implemented as separate staff record, not a property of adjunct
--

-- add better named reason column
ALTER TABLE staff ADD COLUMN buyoutreason INTEGER UNSIGNED AFTER timesched;

-- look at status of table before
SELECT offeringid, buyoutfor, reason FROM staff WHERE buyoutfor IS NOT NULL ORDER BY offeringid;

-- convert buyoutfor fields to new staff records
INSERT INTO staff (offeringid, meetingnumber, personid, role, timesched, buyoutreason)
SELECT offeringid, 1, buyoutfor, 'buyout', 0, reason
FROM staff 
WHERE buyoutfor IS NOT NULL;

-- compare this to the before query, make sure results are the same
SELECT offeringid, personid, buyoutreason FROM staff WHERE role = 'buyout' ORDER BY offeringid;

-- if the above check matches the before status query, delete the old columns
ALTER TABLE staff DROP COLUMN buyoutfor;
ALTER TABLE staff DROP COLUMN reason;

--
--  New logging format for staff records, rename old records
--
UPDATE activitylog SET action = 'staffchange' WHERE action = 'staff';

--
--  UWTS update configuration
--
CREATE TABLE uwtsdashboard
(
	environment CHAR(10) NOT NULL,
	updatetoyear YEAR,
	updatetoquarter TINYINT UNSIGNED,
	lastupdate DATETIME,
	lastupdateduration BIGINT UNSIGNED,
	CONSTRAINT pk_uwtsdashboard PRIMARY KEY(environment)
);

INSERT INTO uwtsdashboard VALUES('PROD', '2012', 4, null, null);

CREATE INDEX idx_uwtsoffering_offeringid ON uwtsoffering(offeringid);
CREATE INDEX idx_uwtsoffering_courseid ON uwtsoffering(courseid);

CREATE INDEX idx_course_curriculum ON course(curriculum);
CREATE INDEX idx_course_courseno ON course(courseno);

CREATE INDEX idx_offering_courseid ON offering(courseid);
CREATE INDEX idx_offering_year ON offering(year);
CREATE INDEX idx_offering_quarter ON offering(quarter);
CREATE INDEX idx_offering_sln ON offering(sln);

CREATE INDEX idx_meeting_offeringid ON meeting(offeringid);
CREATE INDEX idx_meeting_meetingnumber ON meeting(meetingnumber);

CREATE INDEX idx_staff_offeringid ON staff(offeringid);
CREATE INDEX idx_staff_meetingnumber ON staff(meetingnumber);
CREATE INDEX idx_staff_personid ON staff(personid);

--
--  Fix cancel log records
--

UPDATE activitylog SET action = 'cancel', metadata = '{"action":2}' WHERE action = 'cancelimplied';
UPDATE activitylog SET action = 'cancel', metadata = '{"action":5}' WHERE action = 'notcancelimplied';
UPDATE activitylog SET action = 'cancel', metadata = '{"action":3}' WHERE action = 'uwtscanceled';


-- 
-- Syllabus 
-- on dev, this is test mode building out attachment infrastrucure
-- on production

CREATE TABLE syllabus
(
	syllabusid SERIAL NOT NULL,
	url VARCHAR(255),
	clientfilename VARCHAR(255),
	storagefilename VARCHAR(255),
	uploadedon DATETIME,
	uploadedby CHAR(8),
	mimetype VARCHAR(60),
	extension VARCHAR(60),
	CONSTRAINT pk_syllabus PRIMARY KEY(syllabusid)
);

--
--  Change request tables
--

CREATE TABLE rou
(
	rouid SERIAL NOT NULL,
	rou_name VARCHAR(100),
	approver_personid BIGINT UNSIGNED,
	parent_rouid BIGINT UNSIGNED,
	CONSTRAINT pk_rou PRIMARY KEY(rouid)
);

INSERT INTO rou VALUES
(1, 'Undergraduate divison', 1046, 0),
(2, 'Professional division', 1019, 0),
(3, 'Graduate division', 1053, 0),
(999, 'unknown', 1245, 0);

ALTER TABLE rou AUTO_INCREMENT = 1000;

ALTER TABLE course ADD COLUMN rouid BIGINT(20) UNSIGNED NOT NULL DEFAULT 999 AFTER indivsociety;

CREATE TABLE rouperson
(
	rouid BIGINT UNSIGNED NOT NULL,
	personid BIGINT UNSIGNED NOT NULL,
	rou_role CHAR(12),
	CONSTRAINT pk_rouperson PRIMARY KEY(rouid, personid)
);

CREATE TABLE changes
(
	changeid SERIAL NOT NULL,
	offeringid BIGINT UNSIGNED NOT NULL,
	parent_changeid BIGINT UNSIGNED,
	author_personid BIGINT UNSIGNED NOT NULL,
	entered_date DATETIME NOT NULL,
	entered_personid BIGINT UNSIGNED,
	ask_personid BIGINT UNSIGNED,
	ask_response_changeid BIGINT UNSIGNED,
	response CHAR(12),
	resolution CHAR(12),
	resolution_changeid BIGINT UNSIGNED,
	message TEXT,
	message_edit_personid BIGINT UNSIGNED,
	message_edit_date DATETIME,
	CONSTRAINT pk_changes PRIMARY KEY(changeid)
);

ALTER TABLE changes AUTO_INCREMENT = 1000;

UPDATE auth SET role = 'admin' WHERE role = 'adcab';
UPDATE auth SET role = 'faculty' WHERE role IN('user','staff'); 

CREATE TABLE constraints
(
	constraintid SERIAL NOT NULL,
	courseid BIGINT UNSIGNED,
	offeringid BIGINT UNSIGNED,
	contact_personid BIGINT UNSIGNED NOT NULL,
	entered_date DATETIME NOT NULL,
	entered_personid BIGINT UNSIGNED NOT NULL,
	message TEXT,
	message_edit_personid BIGINT UNSIGNED,
	message_edit_date DATETIME,
	CONSTRAINT pk_constraints PRIMARY KEY(constraintid)
);

-- Plan A didnt work not using jointlocal table
--CREATE TABLE jointlocal
--(
--	offeringid BIGINT UNSIGNED NOT NULL,
--	joint_offeringid BIGINT UNSIGNED NOT NULL,
--	CONSTRAINT pk_jointlocal PRIMARY KEY(offeringid, joint_offeringid)
--);

CREATE TABLE jointexternal
(
	jointexternalid SERIAL NOT NULL,
	year YEAR NOT NULL,
	quarter TINYINT UNSIGNED NOT NULL,
	curriculum CHAR(6) NOT NULL,
	courseno SMALLINT UNSIGNED NOT NULL,
	section CHAR(1) NOT NULL DEFAULT 'A',
	uwts_curriculum_abbrev CHAR(6),
	enrollmentcurrent SMALLINT,
	enrollmentestimate SMALLINT,
	enrollmentlimit SMALLINT,
	CONSTRAINT pk_jointexternal PRIMARY KEY(jointexternalid)
);

CREATE TABLE jointgroup
(
	jointgroupid BIGINT UNSIGNED NOT NULL,
	jointexternalid BIGINT UNSIGNED,
	offeringid BIGINT UNSIGNED,
	CONSTRAINT pk_jointgroup PRIMARY KEY(jointgroupid, jointexternalid, offeringid)
);

CREATE TABLE uwtsjoint
(
	uwtsofferingid BIGINT UNSIGNED NOT NULL,
	jointlist_json TEXT,
	CONSTRAINT pk_uwtsjoint PRIMARY KEY(uwtsofferingid)
);

CREATE TABLE t_course_rou_draft
(
	courseid BIGINT UNSIGNED NOT NULL,
	curriculum CHAR(6) NOT NULL,
	courseno SMALLINT UNSIGNED NOT NULL,
	division VARCHAR(100),
	approver VARCHAR(100),
	program VARCHAR(100),
	CONSTRAINT pk_t_course_rou_draft PRIMARY KEY(courseid)
);

LOAD DATA LOCAL INFILE '/tmp/course_rou_draft_data.csv'
INTO TABLE t_course_rou_draft
FIELDS TERMINATED BY ','
OPTIONALLY ENCLOSED BY '\"'
LINES TERMINATED BY '\r\n'
(courseid, curriculum, courseno, division, approver, program);

--
--  Institution field to label UWEO records
--  dev: 11/26/2012
--  prod: 11/26/2012

ALTER TABLE offering ADD COLUMN institution CHAR(10) NOT NULL DEFAULT 'state' AFTER sectiontype;
UPDATE offering SET institution = 'uweo' WHERE funding = 'SS';

ALTER TABLE uwtsoffering ADD COLUMN institution CHAR(10) NOT NULL DEFAULT 'state' AFTER sectiontype;

ALTER TABLE repetition ADD COLUMN institution CHAR(10) NOT NULL DEFAULT 'state' AFTER sectiontype;
UPDATE repetition SET institution = 'uweo' WHERE funding = 'SS';

ALTER TABLE offering ADD COLUMN jointsummary VARCHAR(100) AFTER meetingsummary;

--
-- ROU Work
-- 12/4/2012

ALTER TABLE rou ADD COLUMN description TEXT AFTER parent_rouid;

ALTER TABLE offering ADD COLUMN creditcontrol CHAR(10) AFTER sln;
ALTER TABLE offering ADD COLUMN creditmin SMALLINT AFTER creditcontrol;
ALTER TABLE offering ADD COLUMN creditmax SMALLINT AFTER creditmin;

UPDATE course SET creditmin = creditfixed WHERE creditcontrol = 'fixed' AND creditfixed IS NOT NULL;
SELECT curriculum, courseno, creditcontrol, creditmin, creditfixed FROM course WHERE creditcontrol = 'fixed';
ALTER TABLE course DROP COLUMN creditfixed;

ALTER TABLE course CHANGE COLUMN creditcontrol coursecreditcontrol CHAR(10);
ALTER TABLE course CHANGE COLUMN creditmin coursecreditmin SMALLINT;
ALTER TABLE course CHANGE COLUMN creditmax coursecreditmax SMALLINT;

--
-- Total student credit hours available from SWS
-- dev: 1/4/13
-- prod: 1/4/13

ALTER TABLE uwtsoffering ADD COLUMN studentcredithours SMALLINT AFTER enrollmentlimit;

--
-- Faculty by ROU
-- dev & prod 1/8/13

ALTER TABLE person ADD COLUMN faculty_rouid BIGINT UNSIGNED AFTER area;


--
--  Tags version 2.0
--  dev 1/31/13
--  prod 2/4/13

DROP TABLE tagpermission;
ALTER TABLE tag DROP COLUMN owner;
CREATE TABLE tagcourse
(
	tagid BIGINT UNSIGNED NOT NULL,
	courseid BIGINT UNSIGNED,
	CONSTRAINT pk_tagcourse PRIMARY KEY(tagid, courseid)
);
INSERT INTO tagcourse SELECT tagid, courseid FROM offeringtag WHERE courseid <> 0;
-- DROP TABLE offeringtag;

--
-- Completed on dev and prod 4/2/2013
ALTER TABLE person DROP COLUMN facultysequence;
ALTER TABLE person ADD COLUMN facultysequence MEDIUMINT UNSIGNED AFTER ein;
SOURCE /www/courses/uploads/import/courses_facsequence_20130402.sql;


--
-- Add UWTS fields for updating section credits
-- dev 4/5/2013
--
ALTER TABLE uwtsoffering ADD COLUMN creditcontrol CHAR(10) AFTER sectiontype;
ALTER TABLE uwtsoffering ADD COLUMN creditmin SMALLINT AFTER creditcontrol;
ALTER TABLE uwtsoffering ADD COLUMN creditmax SMALLINT AFTER creditmin;

--
--  Instructor approvals
--  paul's wkstn 8/8/13
--  dev 9/17/13
ALTER TABLE offering ADD COLUMN instructorapproval TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER sectionstatus;
ALTER TABLE offering ADD COLUMN instructorapproval_logid BIGINT UNSIGNED AFTER instructorapproval;
ALTER TABLE person ADD COLUMN workflow TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER issupport;


DROP TABLE IF EXISTS comment;
CREATE TABLE comment
(
	commentid SERIAL NOT NULL,
	courseid BIGINT UNSIGNED,
	offeringid BIGINT UNSIGNED,
	created_on DATETIME NOT NULL,
	created_personid BIGINT UNSIGNED NOT NULL,
	edited_on DATETIME,
	edited_personid BIGINT UNSIGNED,
	commenttype TINYINT UNSIGNED NOT NULL DEFAULT 0,
	visibility TINYINT UNSIGNED NOT NULL DEFAULT 0,
	todoitem TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
	comment TEXT,
	CONSTRAINT pk_comment PRIMARY KEY(commentid)
);
