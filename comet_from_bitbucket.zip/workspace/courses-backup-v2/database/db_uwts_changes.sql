--
--  Add UWTS Version
--

-- prep remove all quiz sections
-- php -f delete_quiz_sections.php


ALTER TABLE person ADD COLUMN regid VARCHAR(40) AFTER ein;

ALTER TABLE activitylog MODIFY action VARCHAR(25) NOT NULL;

ALTER TABLE course DROP COLUMN description;
ALTER TABLE course DROP COLUMN facultydescription;
ALTER TABLE course DROP COLUMN defaultfixedcredits;
--ALTER TABLE course DROP COLUMN gradingsystem;

ALTER TABLE course ADD COLUMN creditcontrol CHAR(10) AFTER wildcardtitle;
ALTER TABLE course ADD COLUMN creditfixed SMALLINT AFTER creditcontrol;
ALTER TABLE course ADD COLUMN creditmin SMALLINT AFTER creditfixed;
ALTER TABLE course ADD COLUMN creditmax SMALLINT AFTER creditmin;
ALTER TABLE course ADD COLUMN creditrepeatmax SMALLINT AFTER creditmax;
ALTER TABLE course ADD COLUMN creditestimate SMALLINT AFTER creditrepeatmax;
ALTER TABLE course ADD COLUMN firstquarter CHAR(6) AFTER orgunitid;
ALTER TABLE course ADD COLUMN lastquarter CHAR(6) AFTER firstquarter;
ALTER TABLE course ADD COLUMN swslastupdate DATETIME AFTER lastquarter;

CREATE TABLE coursedetail
(
	courseid BIGINT UNSIGNED NOT NULL,
	detailkey VARCHAR(100) NOT NULL,
	detailvalue TEXT,
	CONSTRAINT pk_coursedetail PRIMARY KEY(courseid, detailkey)
);

ALTER TABLE offering MODIFY COLUMN section CHAR(2) NOT NULL DEFAULT 'A';
ALTER TABLE offering ADD COLUMN enrollmentcurrent SMALLINT AFTER sln;
ALTER TABLE offering ADD COLUMN enrollmentestimate SMALLINT AFTER enrollmentcurrent;
ALTER TABLE offering ADD COLUMN enrollmentlimit SMALLINT AFTER enrollmentestimate;
ALTER TABLE offering ADD COLUMN studentcredithours SMALLINT AFTER enrollmentlimit;
ALTER TABLE offering ADD COLUMN studentcredithoursestimate SMALLINT AFTER studentcredithours;
ALTER TABLE offering ADD COLUMN sectionstatus CHAR(1) NOT NULL DEFAULT 'P' AFTER roomstatus;

UPDATE offering SET enrollmentcurrent = enrolled;
UPDATE offering SET enrollmentestimate = estenrolled;
UPDATE offering SET studentcredithours = credithours;
UPDATE offering SET studentcredithoursestimate = estcredithours;

ALTER TABLE offering DROP COLUMN enrolled;
ALTER TABLE offering DROP COLUMN estenrolled;
ALTER TABLE offering DROP COLUMN credithours;
ALTER TABLE offering DROP COLUMN estcredithours;
ALTER TABLE offering DROP COLUMN fixedcredits;
ALTER TABLE offering DROP COLUMN varcredits;


CREATE TABLE uwtsoffering
(
	uwtsofferingid SERIAL NOT NULL,
	courseid BIGINT UNSIGNED NOT NULL,
	offeringid BIGINT UNSIGNED,
	sln BIGINT UNSIGNED,
	year YEAR NOT NULL,
	quarter TINYINT UNSIGNED NOT NULL,
	section CHAR(2) NOT NULL DEFAULT 'A',
	summerterm CHAR(1),
	sectiontype CHAR(2),
	enrollmentcurrent SMALLINT,
	enrollmentestimate SMALLINT,
	enrollmentlimit SMALLINT,
	gradingsystem CHAR(10),
	deleteflag CHAR(10),
	swspath VARCHAR(255),
	swslastupdate DATETIME,
	importdate DATETIME,
	CONSTRAINT pk_uwtsoffering PRIMARY KEY(uwtsofferingid)
);

CREATE TABLE uwtsmeeting
(
	uwtsofferingid BIGINT UNSIGNED NOT NULL,
	meetingnumber TINYINT UNSIGNED NOT NULL DEFAULT 1,
	meetingid BIGINT UNSIGNED,
	meetingtype CHAR(2),
	dows CHAR(7),
	start TIME,
	end TIME,
	building VARCHAR(50),
	room VARCHAR(50),
	CONSTRAINT pk_uwtsmeeting PRIMARY KEY(uwtsofferingid, meetingnumber)
);

CREATE TABLE uwtsstaff
(
	uwtsstaffid SERIAL NOT NULL,
	uwtsofferingid BIGINT UNSIGNED NOT NULL,
	meetingnumber TINYINT UNSIGNED NOT NULL DEFAULT 1,
	regid VARCHAR(40) NOT NULL,
	staffid BIGINT UNSIGNED,
	personid BIGINT UNSIGNED,
	CONSTRAINT pk_uwtsstaff PRIMARY KEY(uwtsstaffid)
);

DROP TABLE comment;

CREATE TABLE comment
(
	commentid SERIAL NOT NULL,
	courseid BIGINT UNSIGNED,
	offeringid BIGINT UNSIGNED,
	commenttype CHAR(10) NOT NULL,
	createdby BIGINT UNSIGNED,
	createdon DATETIME,
	editedon DATETIME,
	commenttext TEXT,
	CONSTRAINT pk_comment PRIMARY KEY(commentid)
);

--
-- change grading system coding from int to string
ALTER TABLE offering CHANGE gradingsystem old_gradingsystem SMALLINT UNSIGNED;
ALTER TABLE offering ADD COLUMN gradingsystem CHAR(10) AFTER old_gradingsystem;
UPDATE offering SET gradingsystem = 'standard' WHERE old_gradingsystem = 1;
UPDATE offering SET gradingsystem = 'credit' WHERE old_gradingsystem = 5;
-- spot check
SELECT offeringid, gradingsystem, old_gradingsystem FROM offering;
ALTER TABLE offering DROP COLUMN old_gradingsystem;

--
-- Table to log the matching process
--
CREATE TABLE uwtsmatchinglog
(
	id SERIAL NOT NULL,
	processed DATETIME NOT NULL,
	uwtsofferingid BIGINT UNSIGNED,
	offeringid BIGINT UNSIGNED,
	linkcreated TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
	error TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
	resultcode TINYINT UNSIGNED NOT NULL,
	matchingscore SMALLINT UNSIGNED,
	uwnetid CHAR(8),
	CONSTRAINT pk_uwtsmatchinglog PRIMARY KEY(id)
);

CREATE TABLE l_uwtsmatchinglog_result
(
	resultcode TINYINT UNSIGNED NOT NULL,
	description VARCHAR(200),
	CONSTRAINT pk_l_uwtsmatchinglog_result PRIMARY KEY(resultcode)
);

INSERT INTO l_uwtsmatchinglog_result VALUES
(1, 'not able to link, matching score too low'),
(2, 'not able to link, multiple possible sections'),
(3, 'not able to link on SLN or verified section'),
(21, 'linked on SLN'),
(22, 'linked on verified section'),
(23, 'linked on section match and matching score'),
(24, 'created new plan offering'),
(75, 'linked UWTS to plan manually'),
(76, 'created new plan offering manually'),
(86, 'removed link between UWTS and plan'),
(91, 'found SLN match with different section ids'),
(92, 'found SLN match already linked to different record'),
(93, 'found verified section match already linked to different record');

--
-- give tbd record a uwnetid that will not match in SWS
--
UPDATE person SET 
	firstname = null, 
	lastname = 'To be determined',
	uwnetid = '(TBD)',
	regid = 'TBD', 
	email = null, 
	isfaculty = 1, 
	isadjunct = 1, 
	isstudentstaff = 1 
WHERE personid = 1;

--
--  Change summer full term indicator from empty to F
--
UPDATE offering SET summerterm = 'F' WHERE quarter = 3 AND summerterm IS NULL OR summerterm = '';

--
--  Buy out records now implemented as separate staff record, not a property of adjunct
--

-- add better named reason column
ALTER TABLE staff ADD COLUMN buyoutreason INTEGER UNSIGNED AFTER timesched;

-- look at status of table before
SELECT offeringid, buyoutfor, reason FROM staff WHERE buyoutfor IS NOT NULL ORDER BY offeringid;

-- convert buyoutfor fields to new staff records
INSERT INTO staff (offeringid, meetingnumber, personid, role, timesched, buyoutreason)
SELECT offeringid, 1, buyoutfor, 'buyout', 0, reason
FROM staff 
WHERE buyoutfor IS NOT NULL;

-- compare this to the before query, make sure results are the same
SELECT offeringid, personid, buyoutreason FROM staff WHERE role = 'buyout' ORDER BY offeringid;

-- if the above check matches the before status query, delete the old columns
ALTER TABLE staff DROP COLUMN buyoutfor;
ALTER TABLE staff DROP COLUMN reason;

--
--  New logging format for staff records, rename old records
--
UPDATE activitylog SET action = 'staffchange' WHERE action = 'staff';

--
--  UWTS update configuration
--
CREATE TABLE uwtsdashboard
(
	environment CHAR(10) NOT NULL,
	updatetoyear YEAR,
	updatetoquarter TINYINT UNSIGNED,
	lastupdate DATETIME,
	lastupdateduration BIGINT UNSIGNED,
	CONSTRAINT pk_uwtsdashboard PRIMARY KEY(environment)
);

INSERT INTO uwtsdashboard VALUES('PROD', '2012', 4, null, null);

CREATE INDEX idx_uwtsoffering_offeringid ON uwtsoffering(offeringid);
CREATE INDEX idx_uwtsoffering_courseid ON uwtsoffering(courseid);

CREATE INDEX idx_course_curriculum ON course(curriculum);
CREATE INDEX idx_course_courseno ON course(courseno);

CREATE INDEX idx_offering_courseid ON offering(courseid);
CREATE INDEX idx_offering_year ON offering(year);
CREATE INDEX idx_offering_quarter ON offering(quarter);

CREATE INDEX idx_meeting_offeringid ON meeting(offeringid);
CREATE INDEX idx_meeting_meetingnumber ON meeting(meetingnumber);

CREATE INDEX idx_staff_offeringid ON staff(offeringid);
CREATE INDEX idx_staff_meetingnumber ON staff(meetingnumber);
CREATE INDEX idx_staff_personid ON staff(personid);


SELECT COUNT(o.offeringid) AS qty FROM offering o LEFT OUTER JOIN uwtsoffering u ON o.offeringid = u.offeringid WHERE u.offeringid IS NULL AND o.status <> 'canceled';
