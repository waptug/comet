

var SystemContextMenu = (function($){
    var sb = null;
    var width = 300;
    var getSidebar = function(){
        if (!sb) {
            sb = $('<div id="systems_menu"></div>');
            sb.css({
                display  : 'none',
                position : 'absolute',
                zIndex   : 51,
                width    : width + 'px',
                overflow : 'hidden'
            });
            $('body').append(sb);
        }
        return sb;
    };
    var hideMenu = function(){
        var bd = Pcore.Backdrop.getBackdrop();
        bd.off('.context_menu');
        bd.hide();
        var sidebar = getSidebar();
        sidebar.find('ul').animate({ marginLeft : width }, 200, function() {
            sidebar.hide();
        });
    };
    var requestMenu = function(){
        var sidebar = getSidebar();
        sidebar.load('/courseinfo/context_menu.html', showMenu);
    };
    var showMenu = function(){
        var sidebar = getSidebar();
        var viewportWidth = $( window ).outerWidth();
        var height = Math.max( $( window ).outerHeight(), $( document ).outerHeight() );
        sidebar.css({
            height : height + 'px',
            left   : (viewportWidth - width) + 'px',
            top    : '0px'
        });
        var content = $('#systems_menu ul');
        content.css({
            height : height + 'px',
            marginLeft : width+'px'
        });
        var bd = Pcore.Backdrop.getBackdrop();
        bd.on('click.context_menu', hideMenu);
        bd.show();
        sidebar.show();
        content.animate({ marginLeft : 6}, 200);
    };

    return {
        init : function(trigger)
        {
            $(trigger).on('click.context_menu', requestMenu);
        }
    };

})(jQuery);

$( document ).ready(function(){
    SystemContextMenu.init('#system_menu_trigger');
});
