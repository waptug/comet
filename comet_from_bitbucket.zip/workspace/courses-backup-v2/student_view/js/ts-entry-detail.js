
var TsEntryDetail = Class.create({

	backdrop : null,
	events   : {},
	pop      : null,

	initialize : function()
	{
		this.handlers = {
			'requestDetail' : this.requestDetail.bind(this),
			'highlight'     : this.highlight.bind(this),
			'highlightOff'  : this.highlightOff.bind(this),
			'hideDetail'    : this.hideDetail.bind(this),
		}
		this.attachHandlers();
		document.observe('report:refresh', this.attachHandlers.bind(this));
	},
	
	attachHandlers : function()
	{
		$$('table.compare-quarters div.offering-summary').each((function(e){
			var box = this.getParentBox(e);
			box.observe('click', this.handlers.requestDetail);
			box.observe('mouseover', this.handlers.highlight);
			box.observe('mouseout', this.handlers.highlightOff);
			box.style.cursor = 'pointer';
		}).bind(this));
	},
	
	getParentBox : function(e)
	{
		var out = $(e);
		if (out.tagName.toUpperCase() != 'TD') {
			out = out.up('td');
		}
		return out;
	},
	
	highlight : function(event)
	{
		var box = this.getParentBox(event.element());
		box.style.backgroundImage = 'url("/courses/images/detail-window-icon.png")';
	},
	
	highlightOff : function(event)
	{
		var box = this.getParentBox(event.element());
		box.style.backgroundImage = 'none';
	},
	
	requestDetail : function(event)
	{
		if (event.stopped) {
			return;
		}
		var box = this.getParentBox(event.element());
		var link = box.down('span.course-number a');
		var offeringid = Fw_GetParamValue(link, 'o');
		var url = '/courses/offering/ts-entry?ajax=1&o=' + offeringid;
		var options = {
			method    : 'get',
			onSuccess : this.showDetail.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(url, options);
	},
	
	showDetail : function(transport)
	{
		if (!this.pop) {
			this.pop = new Fw_Popupbox();
		}
		if (!this.backdrop) {
			this.backdrop = new Fw_Backdrop_Clear();
		}
		this.pop.update(transport.responseText);
		this.pop.show();
		this.backdrop.show();
		this.backdrop.observe('click', this.handlers.hideDetail);
		var closelink = this.pop.down('p.close_link');
		if (closelink) {
			closelink.style.cursor = 'pointer';
			closelink.observe('click', this.handlers.hideDetail);
		}
	},
	
	hideDetail : function(transport)
	{
		this.pop.hide();
		this.backdrop.hide();
	},
	
	showError : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);
	},
	
});

new TsEntryDetail(); 
