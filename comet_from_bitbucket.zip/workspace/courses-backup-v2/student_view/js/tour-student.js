
var TourStudent = Class.create({
	
	box        : null,
	index      : 0,
	navigation : null,
	pageMargin : 10,
	pointer    : null,
	text       : null,
	trigger    : null,
	config : [
	    {
	    	'text'    : 'Courses for state supported degree programs offered through the Seattle campus',
	    	'point'   : 'left',
	    	'subject' : function(){ return $$('div.menubar')[0].down().select('li')[0]; }
	    },
	    {
	    	'text'    : 'Courses for professional programs offered through the UW Professional &amp; Continuing Education',
	    	'point'   : 'left',
	    	'subject' : function(){ return $$('div.menubar')[0].down().select('li')[1]; }
	    },
	    {
	    	'text'    : 'Choose a quarter or academic year',
	    	'point'   : 'left',
	    	'subject' : function(){ return $('report-title').down().select('a')[0]; }
	    },
	    {
	    	'text'    : 'Choose a curriculum abbreviation',
	    	'point'   : 'left',
	    	'subject' : function(){ return $('report-title').down().select('a')[1]; }
	    },
	    {
	    	'text'    : 'Search for courses by year, quarter, course number, instructor, or title',
	    	'point'   : 'right',
	    	'subject' : function(){ return $$('div.search-form-small')[0].select('input')[0]; }
	    }
	],
	
	initialize : function(trigger)
	{
		this.trigger = $(trigger);
		this.box = $('tour_container');
		this.pointer = this.box.down('div.tour_pointer_box');
		this.text = this.box.down('div.tour_content');
		var nav = this.box.select('div.tour_navigation a');
		this.navigation = {
			'done' : nav[0],
			'prev' : nav[1],
			'next' : nav[2]
		}
		if (!this.box) console.log('No box');
		if (this.trigger && this.config[2].subject()) {
			this.trigger.show();
			this.trigger.style.cursor = 'pointer';
		} else {
			return;
		}
		this.trigger.observe('click', this.startTour.bind(this));
		this.navigation.next.observe('click', this.nextItem.bind(this));
		this.navigation.prev.observe('click', this.prevItem.bind(this));
		this.navigation.done.observe('click', this.done.bind(this));
		if (window.location.hash == '#tour') {
			this.startTour();
		}
	},
	
	startTour : function(event)
	{
		this.showItem(0);
	},
	
	nextItem : function(event)
	{
		this.showItem(this.index + 1);
	},
	
	prevItem : function(event)
	{
		this.showItem(this.index - 1);
	},
	
	showItem : function(index)
	{
		if (index < 0 || index >= this.config.length) {
			console.log('index out of range');
			return;
		}
		this.index = index;
		this.configTour(this.config[index]);
		if (index == 0) {
			this.navigation.prev.hide();
		} else {
			this.navigation.prev.show();
		}
		if (index == (this.config.length - 1)) {
			this.navigation.next.hide();
		} else {
			this.navigation.next.show();
		}
		this.box.show();
	},
	
	configTour : function(config) 
	{
		this.text.update(config.text);
		var subject = config.subject()
		if (!subject) {
			console.log('Couldn\'t locate subject');
			return;
		}
		var relPos = subject.cumulativeOffset();
		var setLeft = 10;
		var setTop = relPos.top + subject.getHeight() - 10;
		if (config.point == 'right') {
			this.pointer.style.textAlign = 'right';
			setLeft = relPos.left + subject.getWidth() - this.box.getWidth();
		} else {
			this.pointer.style.textAlign = 'left';
			setLeft = relPos.left + 10;
		}
		var html = $$('html')[0];
		var body = $$('body')[0];
		// if element got positioned outside of view port, move it back
		if (setLeft < this.pageMargin) {
			setLeft = this.pageMargin;
		}
		if ((setLeft + this.box.getWidth() + this.pageMargin) > body.getWidth()) {
			setLeft = body.getWidth() - this.box.getWidth() - this.pageMargin;
		}
		// if element got positioned outside of view port, move it back
		var contentHeight = Math.max(body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight, document.viewport.getHeight());
		if (setTop < this.pageMargin) {
			setTop = this.pageMargin;
		}
		if ((setTop + this.box.getHeight() + this.pageMargin) > contentHeight) {
			setTop = contentHeight - this.box.getHeight() - this.pageMargin;
			if (setTop < this.pageMargin) setTop = this.pageMargin;
		}
		this.box.style.left = setLeft + 'px';
		this.box.style.top = setTop + 'px';
	},
	
	done : function(event)
	{
		this.box.hide();
	}
	
});

Event.observe(window, 'load', function() {
	new TourStudent('tour_trigger');
});