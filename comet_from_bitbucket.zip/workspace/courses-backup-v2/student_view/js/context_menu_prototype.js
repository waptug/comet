

var SystemContextMenu = (function(){
    var bd = null;
    var sb = null;
    var width = 300;
    var getBackdrop = function(){
        if (!bd) {
            bd = new Fw_Backdrop_Clear();
        }
        return bd;
    };
    var getSidebar = function(){
        if (!sb) {
            sb = new Element('div', { "id" : "systems_menu" });
            sb.setStyle({
                position : 'absolute',
                zIndex   : 51,
                width    : width + 'px',
                overflow : 'hidden'
            });
            var body = $$('body')[0];
            body.insert(sb);
        }
        return sb;
    };
    var hideMenu = function(){
        var bd = getBackdrop();
        bd.stopObserving('click');
        bd.hide();
        var sidebar = getSidebar();
        sidebar.hide();
    };
    var requestMenu = function(){
        new Ajax.Request('/courseinfo/context_menu.html', {
            method    : 'get',
            onSuccess : showMenu
        });
    };
    var showMenu = function(transport){
        var sidebar = getSidebar();
        var viewportWidth = document.viewport.getWidth();
        var height = document.viewport.getHeight();
        sidebar.setStyle({
            height : height + 'px',
            left   : (viewportWidth - width) + 'px',
            top    : '0px'
        });
        sidebar.update(transport.responseText);
        sidebar.select('ul').each(function(item){
            $(item).setStyle({
                height : height+'px',
                marginLeft : '6px'
            });
        });
        var bd = getBackdrop();
        bd.show();
        bd.observe('click', hideMenu);
        sidebar.show();
    };

    return {
        init : function(trigger)
        {
            var clickme = $(trigger);
            if (clickme) {
                clickme.observe('click', requestMenu);
            }
        }
    };

})();

document.observe("dom:loaded", function() {
    SystemContextMenu.init('system_menu_trigger');
});
