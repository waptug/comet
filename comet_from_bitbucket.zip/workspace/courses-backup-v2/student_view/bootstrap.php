<?php
/**
 * Virtualize the client request so URIs do not have to be tightly
 * coupled with actual file system files. Allows for clean, 
 * descriptive, and RESTful URIs.
 * 
 * This script depends on apache mod_rewrite. mod_rewrite 
 * (generally configured through an .htaccess file) redirects any 
 * requests that do not match an actual file or directory to this 
 * script.
 * 
 * This script searches for a script file that matches some portion 
 * of the URI and passes the remaining elements of the URI to the 
 * script in the array $fw_request.
 */

// Set the error communication to strict and verbose
error_reporting(E_ALL | E_STRICT);
ini_set('display_startup_errors', 1); 
ini_set('display_errors', 1);

# This should be the application's URL base directory
# with no trailing slash e.g. '/basedir'
$fw_baseurl = rtrim($_SERVER['REDIRECT_BASE'], '/');
$relative_request = $_SERVER['REDIRECT_RELATIVE'];

# This bootstrap file should live in {Application Path}/pub
# the controller directory is {Application Path}/controllers
$fw_controllerdir = dirname(dirname(__FILE__)).'/controllers';

$controllers = array(
	''           => '/student_view/index.php',
	'about'      => '/student_view/about.php',	
	'detail'     => '/student_view/detail.php',
	'search'     => '/student_view/search.php',
	'uwpce'      => '/student_view/uwpce.php',
	'understand' => '/student_view/understand.php',
	'refresh'    => '/reports/refresh.php',
	'reports/setparam'  => '/reports/setparam.php',
	'reports/applyhash' => '/reports/applyhash.php',
	'offering/syllabus-download' => '/offering/syllabus-download.php',
);

if (isset($controllers[$relative_request])) {
	$script = $fw_controllerdir . $controllers[$relative_request];
} else {
	$script = $fw_controllerdir .'/error/filenotfound.php';
}

// Supports student view and records that they have clicked "I Understand" on
// the about page before allowing any other page views.
@session_start();
if ($relative_request != 'understand' && !isset($_SESSION['crs_i_understand'])) {
	$script = $fw_controllerdir . $controllers['about'];
}

// student view is public, no authorization
$GLOBALS['fw_noauth'] = true;

include $script;
