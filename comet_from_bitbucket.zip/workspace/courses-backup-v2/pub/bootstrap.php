<?php
/**
 * Virtualize the client request so URIs do not have to be tightly
 * coupled with actual file system files. Allows for clean, 
 * descriptive, and RESTful URIs.
 * 
 * This script depends on apache mod_rewrite. mod_rewrite 
 * (generally configured through an .htaccess file) redirects any 
 * requests that do not match an actual file or directory to this 
 * script.
 * 
 * This script searches for a script file that matches some portion 
 * of the URI and passes the remaining elements of the URI to the 
 * script in the array $fw_request.
 */

# This should be the application's URL base directory 
# with no trailing slash e.g. '/basedir'
$fw_baseurl = '/courses';

// Set the error communication to strict and verbose
error_reporting(E_ALL | E_STRICT);
ini_set('display_startup_errors', 1); 
ini_set('display_errors', 1);

# This bootstrap file should live in {Application Path}/pub
# the controller directory is {Application Path}/controllers
$fw_controllerdir = dirname(dirname(__FILE__)).'/controllers';

//strip off the query string
$query_start = strpos($_SERVER['REQUEST_URI'], '?');
if ($query_start === false) {
	$relative_request = $_SERVER['REQUEST_URI'];
} else {
	$relative_request = substr_replace($_SERVER['REQUEST_URI'], '', $query_start);
}

// Search for application root directory and strip it off the request
if (strpos($relative_request, $fw_baseurl) === 0) {
	// strip off the application base path
	$relative_request = substr_replace($relative_request, '', 0, strlen($fw_baseurl));
	// strip initial slash in relative path
	if (strpos($relative_request, '/') === 0) {
		$relative_request = substr_replace($relative_request, '', 0, 1);	
	}
}

// initalize our script search containers
$script = '';

// if a matching controller script exists use that
$try = $fw_controllerdir .'/'. $relative_request .'.php';
if (file_exists($try)) {
	$script = $try;
}	

// if there is a matching controller directory with an index.php file use that
$try = $fw_controllerdir .'/'. $relative_request .'/index.php';
if (file_exists($try)) {
	$script = $try;
}

// try to match the report viewer
if (!$script) {
	$fw_matches = array();
	if (preg_match('/report\/([a-zA-Z0-9_\-]+)/', $relative_request, $fw_matches)) {
		$_GET['rt'] = $fw_matches[1];
		$script = $fw_controllerdir.'/reports/viewer.php';
	}
}

// if we have not found a matching controller this is a 404 error
if (strlen($script) == 0) {
	include $fw_controllerdir .'/error/filenotfound.php';
	exit;
}

include $script;
