


var Staff_Input_By_Role = Class.create({
	
	events : null,
	roleInput : null,
	facultyBox : null,
	adjunctBox : null,
	studentBox : null,
	
	initialize : function(trigger)
	{
		this.roleInput = $(trigger);
		if (!this.roleInput) return;
		this.facultyBox = $('faculty').up().up();
		this.adjunctBox = $('adjunct').up().up();
		this.studentBox = $('student').up().up();
		this.buyoutReasonBox = $('buyoutreason').up().up();
		this.events = {};
		this.events.trigger = this.toggleBoxes.bindAsEventListener(this);
		this.roleInput.observe('change', this.events.trigger);
		this.toggleBoxes();
	},
	
	toggleBoxes : function()
	{
		if (this.roleInput.value == 'faculty') {
			this.facultyBox.show();
			this.buyoutReasonBox.hide();
			this.adjunctBox.hide();
			this.studentBox.hide();
		} else if (this.roleInput.value == 'adjunct') {
			this.facultyBox.hide();
			this.buyoutReasonBox.hide();
			this.adjunctBox.show();
			this.studentBox.hide();
		} else if (this.roleInput.value == 'buyout') {
			this.facultyBox.show();
			this.buyoutReasonBox.show();
			this.adjunctBox.hide();
			this.studentBox.hide();
		} else {
			this.facultyBox.hide();
			this.buyoutReasonBox.hide();
			this.adjunctBox.hide();
			this.studentBox.show();
		}
	}
	
});

if ($('role')) {
	new Staff_Input_By_Role('role');
}