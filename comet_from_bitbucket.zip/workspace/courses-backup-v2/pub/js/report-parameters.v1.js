


var Report_Parameter_Picker = Class.create({

	fullbox   : null,
	handlers  : null,
	trigger   : null,
	summary   : null,
	picker    : null,
	
	initialize : function(trigger)
	{
		this.trigger = $(trigger);
		if (!this.trigger) console.log('trigger does not exist');
		this.trigger.onclick = function(e){ return false; };
		this.fullbox = $('report-pickers');
		this.picker = this.fullbox.down('div.picker');
		this.summary = $('report-title');
		if (!this.summary) {
			console.log('No summary box');
		}
		this.handlers = {
			'changeParam'     : this.changeParam.bind(this),
			'requestPicker'   : this.requestPicker.bind(this),
			'showMoreOptions' : this.showMoreOptions.bind(this),
		}
		this.trigger.observe('click', this.handlers.requestPicker);
		//this.summary.observe('click', this.handlers.togglePicker);
	},
	
	requestPicker : function()
	{
		var options = {
			method    : 'get',
			onSuccess : this.showPicker.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(this.trigger.href, options);
	},
	
	requestSummary : function()
	{
		var options = {
			method    : 'get',
			onSuccess : this.showPicker.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(this.trigger.href, options);
	},
	
	showPicker : function(transport)
	{
		this.fullbox.select('div.sections li').each(function(item) {
			item.removeClassName('selected');
		});
		this.trigger.up().addClassName('selected');
		//this.summary.hide();
		console.log('fullbox height = '+this.fullbox.getHeight());
		console.log('picker height = '+this.picker.getHeight());
		this.picker.update(transport.responseText);
		this.setPickerHeight();
		var refresh = this.picker.down('div.summary-refresh');
		if (refresh) {
			this.summary.update(refresh.innerHTML);
			refresh.remove();
		}
		this.picker.select('a').each((function(anchor) {
			anchor.onclick = function(e){ return false; };
			if (anchor.hasClassName('show-more')) {
				anchor.observe('click', this.handlers.showMoreOptions);
			} else {
				anchor.observe('click', this.handlers.changeParam);
			}
		}).bind(this));
	},
	
	changeParam : function(event)
	{
		var options = {
			method    : 'get',
			onSuccess : this.updateAll.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(event.element().href, options);
	},
	
	updateAll : function(transport)
	{
		this.showPicker(transport);
		var options = {
			method    : 'get',
			onSuccess : this.refreshReport.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request($('refresh-report').href, options);
	},
	
	refreshReport : function(transport)
	{
		$('report-container').update(transport.responseText);
	},
	
	showMoreOptions : function(event)
	{
		var anchor = event.element();
		var list = anchor.up().up();
		list.select('a.more').each(function(e){
			e.toggle();
		});
		if (anchor.hasClassName('less')) {
			anchor.removeClassName('less');
			anchor.update('more');
		} else {
			anchor.addClassName('less');
			anchor.update('less');
		}
		this.setPickerHeight();
	},
	
	setPickerHeight : function()
	{
		this.picker.setStyle({height : 'auto'});
		if (this.picker.getHeight() < (this.fullbox.getHeight() - 40)) {
			this.picker.setStyle({height : (this.fullbox.getHeight() - 40) + 'px'});
		}
	},
	
	showError : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
	
});


$$('a.report-param-picker').each(function(e){
	new Report_Parameter_Picker(e);
});