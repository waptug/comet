


var TagsAdminCheckbox = Class.create({
	
	events : {},
	checkbox : null,
	
	initialize : function(checkbox)
	{
		this.checkbox = $(checkbox);
		if (!this.checkbox) {
			console.log('Checkbox not found');
			return;
		}
		this.checkbox.observe('click', this.toggleSection.bind(this));
	},
	
	toggleSection : function(e)
	{
		var section = this.checkbox.next('ul');
		if (section) {
			if (this.checkbox.checked) {
				section.show();
			} else {
				section.hide();
			}
		}
	},
	
});

$$('ul#admin-tags input[type="checkbox"]').each(function(e){
	new TagsAdminCheckbox(e);
});

var TagsAdminMerge = Class.create({
	
	events : {},
	link : null,
	selected : null,
	
	initialize : function(link)
	{
		this.link = $(link);
		if (!this.link) {
			console.log('Merge link not found');
			return;
		}
		this.link.observe('click', this.addSelected.bind(this));
	},
	
	addSelected : function(e)
	{
		this.selected = '';
		$$('ul#admin-tags input[type="checkbox"]').each(function(inpt){
			if (inpt.checked) {
				this.selected = this.selected + '+' + inpt.id.replace('tagid_', '');
			}
		}, this);
		this.link.href = this.link.href + '&merge=' + this.selected;
	},
	
});

$$('a.tag-merge-link').each(function(e){
	new TagsAdminMerge(e);
});