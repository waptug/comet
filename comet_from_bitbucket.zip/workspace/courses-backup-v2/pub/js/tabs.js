
var Offering_Tab = Class.create({
	
	contentbox  : null,
	tabname     : null,
	parentid    : 'tab_contents',

	initialize : function(trigger)
	{
		this.events = {};
		this.trigger = $(trigger);
		this.tabname = Fw_GetParamValue(trigger, 'tab');
		this.trigger.href = 'javascript:void(0);';
		this.observeTrigger(true);
	},
	
	showtab : function()
	{
		if (!this.contentbox) {
			this.requestcontent();
			return;
		}
		var tabbox = this.trigger.up().up();
		tabbox.select('a').each(function(anchor){
			$(anchor).removeClassName('current');
		});
		this.trigger.addClassName('current');
		$$("div#"+this.parentid+" div.tab_section").each(function(div){
			$(div).hide();
		});
		this.contentbox.show();
	},
	
	requestcontent : function()
	{
		var url = '/courses/offering/gettab?o='+$('ajax_offeringid').innerHTML+'&tab='+this.tabname;
		var options = {
			method    : 'get',
			onSuccess : this.displaycontent.bind(this),
			onFailure : this.showerror.bind(this)
		};
		new Ajax.Request(url, options);
	},
	
	displaycontent : function(transport)
	{
		var parent = $(this.parentid);
		parent.insert(transport.responseText);
		this.contentbox = parent.down('div#'+this.parentid+'_'+this.tabname);
		if (!this.contentbox) {
			alert ('Page has timed out. Try refreshing your browser window. If the problem persists contact COE Database Consultant (coedbase@uw.edu).');
			return;
		}
		if (this.tabname == 'changes') {
			$$('a.ajax_changedetails').each(function(e){
				new ChangeDetails(e);
			});
		}
		this.showtab();
	},
	
	observeTrigger : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.showtab = this.showtab.bindAsEventListener(this);
			this.trigger.observe('click', this.events.showtab);
		} else {
			this.trigger.stopObserving('click', this.events.showtab);
		}
	},
	
	showerror : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
	
});


$$('div.offering-tabs a').each(function(e){
	new Offering_Tab(e);
});



var ChangeDetails = Class.create({

	backdrop : null,
	box      : null,
	events   : null,
	parent   : null,
	trigger  : null,
		
	initialize : function(trigger)
	{
		this.trigger = $(trigger);
		if (!this.trigger) return;
		this.events = {};
		this.trigger.onclick = function() {return false;};
		this.parent = this.trigger.up().up();
		this.observeTrigger(true);
	},
	
	mouseOver : function()
	{
		this.parent.style.backgroundColor = '#f3f3f3';
	},
	
	mouseOut : function()
	{
		this.parent.style.backgroundColor = 'transparent';
	},
	
	observeTrigger : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.trigger = this.requestDetails.bindAsEventListener(this);
			this.events.mouseover = this.mouseOver.bindAsEventListener(this);
			this.events.mouseout = this.mouseOut.bindAsEventListener(this);
			this.parent.observe('mouseover', this.events.mouseover);
			this.parent.observe('mouseout', this.events.mouseout);
			this.parent.observe('click', this.events.trigger);
		} else {
			this.parent.stopObserving('click', this.events.trigger);
		}
	},

	requestDetails : function()
	{
		var url = this.trigger.href + '&ajax=1';
		var options = {
			method    : 'get',
			onSuccess : this.displayDetails.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(url, options);
	},
	
	displayDetails : function(transport)
	{
		this.box = new Fw_Popupbox({'maxWidth':500});
		this.backdrop = new Fw_Backdrop_Clear();
		this.backdrop.show();
		this.box.update(transport.responseText);
		this.box.positionBy(this.trigger, 'above');
		this.box.show();
		this.events.hide = this.hideDetails.bindAsEventListener(this);
		this.backdrop.observe('click', this.events.hide);
	},
	
	hideDetails : function(transport)
	{
		this.box.hide();
		this.backdrop.stopObserving('click', this.events.hide);
		this.backdrop.hide();
	},
	
	showError : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
	
});

$$('a.ajax_changedetails').each(function(e){
	new ChangeDetails(e);
});


