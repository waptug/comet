
var PopupWindow = Class.create({

	backdrop   : null,
	box        : null,
	closelink  : null,
	handlers   : null,
		
	initialize : function(selector)
	{
		this.handlers = {
			'requestContent' : this.requestContent.bind(this),
			'hideWindow'     : this.hideWindow.bind(this),
		};
		$$(selector).each((function(anchor) {
			anchor.onclick = function(e){ return false; };
			anchor.observe('click', this.handlers.requestContent);
		}).bind(this));
	},
	
	requestContent : function(event)
	{
		var anchor = event.element();
		var url = anchor.href
		if (url.indexOf('?') > -1) {
			url = url + '&ajax=1';
		} else {
			url = url + '?ajax=1';
		}
		var options = {
			method    : 'get',
			onSuccess : this.handleResponse.bind(this),
			onFailure : this.handleError.bind(this)
		};
		new Ajax.Request(url, options);
	},

	handleResponse : function(transport)
	{
		if (!this.box) {
			this.box = new Fw_Popupbox();
		}
		this.box.update(transport.responseText);
		this.box.show();
		if (!this.backdrop) {
			this.backdrop = new Fw_Backdrop_Dark();
			this.backdrop.observe('click', this.handlers.hideWindow);
		}
		this.backdrop.show();
		var closelink = Fw_CloseLink(this.box);
		closelink.observe('click', this.handlers.hideWindow);
	},
	
	hideWindow : function(event)
	{
		this.box.hide();
		this.backdrop.hide();
	},
	
	handleError : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
	
});

Event.observe(window, 'load', function() {
	new PopupWindow('a.popup-window');
});