
var Status_Menu = Class.create({
	
	backdrop  : null,
	closelink : null,
	popup     : null,
	events    : null,
	trigger   : null,
	href      : null,
	submitLinks : null,
		
	initialize : function(trigger)
	{
		this.trigger = $(trigger);
		if (!this.trigger) return;
		this.href = this.trigger.href;
		this.trigger.href = 'javascript:void(0);';
		this.events = {};
		this.observeTrigger(true);
	},
	
	observeTrigger : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.trigger = this.getMenu.bindAsEventListener(this);
			this.trigger.observe('click', this.events.trigger);
		} else {
			this.trigger.stopObserving('click', this.events.trigger);
		}
	},
	
	getMenu : function()
	{
		var options = {
			method    : 'get',
			onSuccess : this.showMenu.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(this.href + '&ajax=1', options);
	},
	
	showMenu : function(transport)
	{
		this.observeTrigger(false);
		this.popup = new Fw_Popupbox({ fixedWidth: 300 });
		this.popup.positionBy(this.trigger, 'below', 'right');
		this.popup.update(transport.responseText);
		this.popup.show();
		if (!this.backdrop) {
			this.backdrop = new Fw_Backdrop_Clear();	
		}
		this.backdrop.show();
		this.events.hidepopup = this.hideMenu.bindAsEventListener(this);
		this.trigger.observe('click', this.events.hidepopup);
		this.backdrop.observe('click', this.events.hidepopup);
		this.closelink = this.popup.down('p.close_link a');
		if (this.closelink) {
			this.closelink.href = 'javascript:void(0);'; 
			this.closelink.observe('click', this.events.hidepopup);
		}
		this.events.submitchange = this.submitChange.bindAsEventListener(this);
		this.submitLinks = this.popup.select('li a.status-change-trigger');
		for (var i = 0; i < this.submitLinks.length; i++) {
			this.submitLinks[i].observe('click', this.events.submitchange);
		}
	},
	
	submitChange : function(event)
	{
		var url = Event.element(event).href + '&ajax=1';
		var options = {
			method    : 'get',
			onSuccess : this.updateResult.bind(this),
			onFailure : this.showError.bind(this)
		};
		this.hideMenu();
		this.trigger.update('Processing...');
		new Ajax.Request(url, options);
	    Event.stop(event);
	},
	
	updateResult : function(transport)
	{
		this.trigger.update(transport.responseText);
		new Hover_Link(this.trigger);
		this.observeTrigger(true);
	},
	
	hideMenu : function()
	{
		this.trigger.stopObserving('click', this.events.hidepopup);
		this.backdrop.stopObserving('click', this.events.hidepopup);
		for (var i = 0; i < this.submitLinks.length; i++) {
			this.submitLinks[i].stopObserving('click', this.events.submitchange);
		}
		if (this.closelink) {
			this.closelink.stopObserving('click', this.events.hidepopup);
		}
		this.observeTrigger(true);
		this.backdrop.hide();
		this.popup.hide();
	},
	
	showError : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
	
});

$$('a.status-menu-trigger').each(function(e){
	new Status_Menu(e);
});

