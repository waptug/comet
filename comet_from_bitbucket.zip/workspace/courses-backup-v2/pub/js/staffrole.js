


var Toggle_Staff_Role = Class.create({
	
	trigger  : null,
	tablerow : null,
	events   : null,
	
	
	initialize : function(trigger)
	{
		this.trigger = $(trigger);
		this.trigger.onclick = function(e){ return false; };
		this.events = {};
		this.events.request = this.sendrequest.bindAsEventListener(this);
		this.trigger.observe('click', this.events.request);
	},
	
	sendrequest : function()
	{
		this.trigger.stopObserving('click', this.events.request);
		this.trigger.update('<img src="/courses/images/ajax-spinner-inline.gif" alt="Updating" />');
		this.tablerow = this.trigger.up().up();
		var query = this.trigger.id;
		var url = '/courses/admin/people/staffrole?q='+query;
		var options = {
			method    : 'get',
			onSuccess : this.showresult.bind(this),
			onFailure : this.showerror.bind(this)
		};
		new Ajax.Request(url, options);
	},
	
	showresult : function(transport)
	{
		this.tablerow.update(transport.responseText);
		this.tablerow.select('a.ajax-toggle-staff-role').each(function(e){
			new Toggle_Staff_Role(e);
		});
	},
	
	showerror : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
	
});

$$('a.ajax-toggle-staff-role').each(function(e){
	new Toggle_Staff_Role(e);
});
