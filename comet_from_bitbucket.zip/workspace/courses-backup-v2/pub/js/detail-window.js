


var Offering_Details = Class.create({

	backdrop   : null,
	closelink  : null,
	events     : null,
	trigger    : null,
	popup      : null,
	offeringid : null,
		
	initialize : function(trigger)
	{
		this.events = {};
		this.trigger = $(trigger);
		this.offeringid = Fw_GetParamValue(this.trigger, "o");
		this.trigger.href = 'javascript:void(0);';
		this.observeTrigger(true); 
	},
	
	observeTrigger : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.requestdetail = this.requestdetail.bindAsEventListener(this);
			this.trigger.observe('click', this.events.requestdetail);
		} else {
			this.trigger.stopObserving('click', this.events.requestdetail);
		}
	},

	requestdetail : function(activate)
	{
		var url = '/courses/week/details?o=' + this.offeringid;
		var options = {
			method    : 'get',
			onSuccess : this.showdetail.bind(this),
			onFailure : this.showerror.bind(this)
		};
		new Ajax.Request(url, options);
	},

	showdetail : function(transport)
	{
		this.popup = new Fw_Popupbox({ "topMargin" : 100, "padding" : 0});
		this.popup.update(transport.responseText);
		this.popup.show();
		this.backdrop = new Fw_Backdrop_Dark();
		this.backdrop.show();
		this.observeBackdrop(true);
		this.observeCloseLink(true);
	},
	
	hidedetail : function(transport)
	{
		this.popup.hide();
		this.observeBackdrop(false);
		this.observeCloseLink(false);
		this.backdrop.hide();
	},
	
	observeBackdrop : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.hidedetail = this.hidedetail.bindAsEventListener(this);
			this.backdrop.observe('click', this.events.hidedetail);
		} else {
			this.backdrop.stopObserving('click', this.events.hidedetail);
		}
	},
	
	observeCloseLink : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		this.closelink = this.popup.down('p.close_link a');
		if (this.closelink) {
			if (activate) {
				this.closelink.href = 'javascript:void(0);'; 
				this.closelink.observe('click', this.events.hidedetail);
			} else {
				this.closelink.stopObserving('click', this.events.hidedetail);
			}
		}
	},
	
	showerror : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
});


$$('a.ajax_get_detail').each(function(e){
	new Offering_Details(e);
});
