


var Summer_Term_Input = Class.create({
	
	events : null,
	quarterInput : null,
	termBox : null,
	
	initialize : function(trigger)
	{
		this.quarterInput = $(trigger);
		if (!this.quarterInput) return;
		this.termBox = $('summerterm').up().up();
		this.events = {};
		this.events.trigger = this.toggleBoxes.bindAsEventListener(this);
		this.quarterInput.observe('change', this.events.trigger);
		this.toggleBoxes();
	},
	
	toggleBoxes : function()
	{
		if (this.quarterInput.value == 3) {
			this.termBox.show();
		} else {
			this.termBox.hide();
		}
	}
	
});

if ($('quarter')) {
	new Summer_Term_Input('quarter');
}