

var Wildcard_Inputs = Class.create({
	
	actionmenu : null,
	titlebox   : null,
	choosebox  : null,
	events     : null,

	initialize : function(trigger)
	{
		this.actionmenu = $('action');
		if (!this.actionmenu) {
			console.log('couldnt find actionmenu');
		}
		this.titlebox = $('newtitle').up().up();
		if (!this.titlebox) {
			console.log('couldnt find titlebox');
		}
		this.choosebox = $('wildcard').up().up();
		if (!this.choosebox) {
			console.log('couldnt find choosebox');
		}
		if (!this.actionmenu || !this.titlebox || !this.choosebox) {
			return;
		}
		this.events = {};
		this.changeInput();
		this.observeTrigger(true);
	},
	
	observeTrigger : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.trigger = this.changeInput.bindAsEventListener(this);
			this.actionmenu.observe('change', this.events.trigger);
		} else {
			this.actionmenu.stopObserving('change', this.events.trigger);
		}
	},
	
	changeInput : function(activate)
	{
		if (this.actionmenu.value == 'create') {
			this.titlebox.show();
			this.choosebox.hide();
		} else if (this.actionmenu.value == 'choose') {
			this.titlebox.hide();
			this.choosebox.show();
		} else {
			this.titlebox.hide();
			this.choosebox.hide();
		}
	}
	
});

new Wildcard_Inputs();