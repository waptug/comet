


var Admin_Person_Area = Class.create({

	box      : null,
	backdrop : null,
	trigger  : null,
	events   : {},
	
	initialize : function(trigger)
	{
		this.trigger = $(trigger);
		if (!this.trigger) {
			console.log('trigger not found');
			return;
		}
		Fw_DeactivateLink(this.trigger);
		this.trigger.observe('click', this.getMenu.bind(this));
	},
	
	getMenu : function()
	{
		var url = this.trigger.href;
		var options = {
			method    : 'get',
			onSuccess : this.showResult.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(url, options);
	},
	
	submitMenu : function(event)
	{
		this.hideMenu();
		var element = event.element();
		var url = element.href;
		var options = {
			method    : 'get',
			onSuccess : this.showResult.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(url, options);
	},
	
	showResult : function(transport)
	{
		if (transport.responseJSON) {
			var result = transport.responseJSON;
			if (result.result == 'success') {
				this.showArea(result);
				return;
			}
		}
		this.showMenu(transport);
	},
	
	showMenu : function(transport)
	{
		if (!this.backdrop) {
			this.backdrop = new Fw_Backdrop_Clear();
		}
		if (!this.box) {
			this.box = new Fw_Popupbox({ maxWidth: 200 });
		}
		this.backdrop.show();
		this.events.reset = this.hideMenu.bind(this);
		this.backdrop.observe('click', this.events.reset);
		this.box.update(transport.responseText);
		this.box.positionBy(this.trigger);
		this.box.show();
		this.events.choose = this.submitMenu.bind(this);
		this.box.select('ul.popup-menu a').each(function(e){
			var choice = $(e);
			Fw_DeactivateLink(choice);
			choice.observe('click', this.events.choose);
		}, this);
	},
	
	showArea : function(result)
	{
		this.trigger.update(result.area);
	},
	
	hideMenu : function()
	{
		this.backdrop.stopObserving('click', this.events.reset);
		this.backdrop.hide();
		this.box.hide();
	},
	
	showError : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
	
});

$$('a.admin-person-area').each(function(e){
	new Admin_Person_Area(e);
});