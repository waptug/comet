


var CoursesMergePerson = (function(){

    var keepClass = 'merge_selected_keep';
    var mergeClass = 'merge_selected_merge';
    var keep = null;
    var merge = {};
    var working = false;

    var dumpState = function()
    {
        var log = '';
        if (keep) {
            log = 'keep:'+keep.id;
        } else {
            log = 'keep:empty';
        }
        log = log + ' merge';
        eachMerge(function(item) {
            log = log + ':' +item.id;
        });
        console.log(log);
    };

    var clearSelected = function()
    {
        if (keep !== null) {
            unselect(keep);
        }
        eachMerge(unselect);
        Event.stop(event);
    };

    var eachMerge = function(callback)
    {
        for (var key in merge) {
            if (typeof merge[key] != 'undefined' && typeof merge[key].id != 'undefined') {
                callback(merge[key]);
            }
        }
    };

    var tableClicked = function(event)
    {
        if (working) {
            console.log('merge-person request pending, state locked');
            return;
        }
        var clickedRow = event.findElement('tr');
        if (clickedRow) {
            rowClicked(clickedRow);
            Event.stop(event);
        }
    };

    var rowClicked = function(tr)
    {
        var row = {
            "id" : tr.readAttribute('data-personid'),
            "tr" : tr
        }
        if (!row.id) {
            return;
        }
        if (tr.hasClassName(keepClass)) {
            unselect(row);
            return;
        }
        if (tr.hasClassName(mergeClass)) {
            unselect(row);
            selectKeep(row);
            return;
        }
        if (keep === null) {
            selectKeep(row);
            return;
        }
        selectMerge(row);
    };

    var selectKeep = function(row)
    {
        if (keep) {
            keep.tr.removeClassName(keepClass);
            selectMerge(keep);
        }
        keep = row;
        keep.tr.removeClassName(mergeClass);
        keep.tr.addClassName(keepClass);
    };

    var selectMerge = function(row)
    {
        if (typeof merge[row.id] != 'undefined') { // already selected
            return;
        }
        merge[row.id] = row;
        row.tr.addClassName(mergeClass);
    };

    var unselect = function(row)
    {
        if (keep && (keep.id == row.id)) {
            keep.tr.removeClassName(keepClass);
            keep = null;
            return;
        }
        if (typeof merge[row.id] != 'undefined') {
            row.tr.removeClassName(mergeClass);
            merge[row.id] = undefined;
        }
    };

    var updateResults = function(transport)
    {
        var results = transport.responseText.evalJSON();
        var end = results.merged.length;
        for (var i = 0; i < end; i++) {
            var key = results.merged[i];
            if (typeof merge[key] != 'undefined' && typeof merge[key].id != 'undefined') {
                var row = merge[key];
                unselect(row);
                row.tr.remove();
            }
        }
        document.fire('merge:complete');
        clearSelected();
    };

    var readyToSubmit = function()
    {
        if (keep === null) {
            return false;
        }
        var ready = false;
        eachMerge(function(item) {
            ready = true;
        });
        return ready;
    };

    var showError = function(transport)
    {
        console.log('Error '+transport.responseText);
    };

    var submit = function(event)
    {
        Event.stop(event);
        if (!readyToSubmit()) {
            console.log('merge-person submit not ready');
            dumpState();
            return;
        }
        var mergeids = [];
        eachMerge(function(item) {
            mergeids.push(item.id);
        });
        var data = {
            "keep"    : keep.id,
            "merge[]" : mergeids
        };
        var options = {
            "method"     : 'post',
            "onSuccess"  : updateResults,
            "onFailure"  : showError,
            "parameters" : data
        };
        var href = event.findElement('form').readAttribute('action');
        new Ajax.Request(href, options);
    };

    var shutdown = function()
    {
        Event.stop(event);
        window.location.href = '/courses/admin/people';
    };

    return {
        init : function()
        {
            $$('table.mergable_records').each(function (e){
                $(e).observe('click', tableClicked);
            });
            $('merge_clear').observe('click', clearSelected);
            $('merge_shutdown').observe('click', shutdown);
            $('merge_submit').observe('click', submit);
        }
    };

})();

document.observe("dom:loaded", function() {
    CoursesMergePerson.init();
});
