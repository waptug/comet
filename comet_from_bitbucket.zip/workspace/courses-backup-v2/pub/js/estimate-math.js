


var Estimate_Updater = Class.create({

	events    : null,
	estenrolled    : null,
	fixedcredits   : null,
	estcredithours : null,
	
	initialize : function(trigger)
	{
		this.events = {};
		this.estenrolled = $('estenrolled');
		this.fixedcredits = $('fixedcredits');
		this.estcredithours = $('estcredithours');
		
		if (!this.estenrolled || !this.fixedcredits || !this.estcredithours) {
			return;
		}
		this.observeTrigger(true);
	},

	observeTrigger : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.keyEstenrolled = this.slowUpdate.bindAsEventListener(this);
			this.estenrolled.observe('keypress', this.events.keyEstenrolled);
			this.events.keyFixedcredits = this.slowUpdate.bindAsEventListener(this);
			this.fixedcredits.observe('keypress', this.events.keyFixedcredits);
		} else {
			this.estenrolled.stopObserving('keypress', this.events.keyEstenrolled);
			this.fixedcredits.stopObserving('keypress', this.events.keyFixedcredits);
		}
	},
	
	slowUpdate : function()
	{
		this.updateEstimate.delay(.1);
	},
	
	updateEstimate : function()
	{
		var f = parseInt($('fixedcredits').value);
		var e = parseInt($('estenrolled').value);
		if (f && e) {
			$('estcredithours').value = f * e;
		}
	}
	
});

var estimateDoMath = new Estimate_Updater();