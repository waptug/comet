/*
 * supports room scheduling tools
 */


var Change_RoomStatus = Class.create({
	
	events    : null,
	trigger   : null,
	triggerText : null,
		
	initialize : function(trigger)
	{
		this.trigger = $(trigger);
		if (!this.trigger) return;
		this.events = {};
		this.trigger.onclick = function() {return false;};
		this.observeTrigger(true);
	},
	
	observeTrigger : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.trigger = this.submitStatus.bindAsEventListener(this);
			this.trigger.observe('click', this.events.trigger);
		} else {
			this.trigger.stopObserving('click', this.events.trigger);
		}
	},
	
	submitStatus : function(event)
	{
		var url = this.trigger.href + '&ajax=1';
		var options = {
			method    : 'get',
			onSuccess : this.showResult.bind(this),
			onFailure : this.showError.bind(this)
		};
		this.triggerText = this.trigger.innerHTML;
		this.trigger.update('Processing...');
		new Ajax.Request(url, options);
	},
	
	showResult : function(transport)
	{
		this.trigger.update(this.triggerText);
		var r = transport.responseJSON;
		var fieldRoomStatus = null;
		var path = this.trigger.up('tr');
		if (path) {
			path = path.previous();
			if (path) {
				fieldRoomStatus = path.down('a.ajax_get_room_details');
			}
		}
		if (fieldRoomStatus) {
			fieldRoomStatus.update(r.statusText);
		} else {
			alert('Updated offering room status to "'+r.statusText+'"');
		}
	},
	
	showError : function(transport)
	{
		this.trigger.update(this.triggerText);
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
	
});

$$('a.ajax_roomstatus').each(function(e){
	new Change_RoomStatus(e);
});


var RoomScheduleDetails = Class.create({
	
	events    : null,
	href      : null,
	trigger   : null,
	detailBox : null,
	hasLoaded : false,
		
	initialize : function(trigger)
	{
		this.trigger = $(trigger);
		if (!this.trigger) return;
		this.events = {};
		this.trigger.onclick = function() {return false;};
		this.events.showDetails = this.requestDetails.bindAsEventListener(this);
		this.trigger.observe('click', this.events.showDetails);
	},
	
	requestDetails : function(event)
	{
		if (this.hasLoaded) {
			this.showDetails(null);
			return;
		}
		var url = this.trigger.href + '&ajax=1';
		var options = {
			method    : 'get',
			onSuccess : this.showDetails.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(url, options);
	},
	
	showDetails : function(transport)
	{
		var box = this.getDetailBox();
		if (!this.hasLoaded) {
			box.update(transport.responseText);
			// observe change room status links
			box.select('a.fw_menu_trigger').each(function(e){
				new Fw_Menu(e);
			});
			box.select('a.ajax_roomstatus').each(function(e){
				new Change_RoomStatus(e);
			});
			this.hasLoaded = true;
		}
		box.up().show();
		if (!this.events.hideDetails) {
			this.events.hideDetails = this.hideDetails.bindAsEventListener(this);
		}
		this.trigger.stopObserving('click', this.events.showDetails);
		this.trigger.observe('click', this.events.hideDetails);
	},
	
	getDetailBox : function()
	{
		// check if we already have a reference
		if (!this.detailBox) {
			// search by id
			var boxId = 'room_detail_tr_'+Fw_GetParamValue(this.trigger, 'o');
			this.detailBox = $(boxId);
		}
		// create the box
		if (!this.detailBox) {
			newrow = new Element('tr');
			// the <tr> element is two up from the trigger Anchor
			var triggerTableRow = this.trigger.up().up();
			triggerTableRow.insert({ after : newrow });
			this.detailBox = new Element('td', { id : boxId, 'colspan' : 6, 'class' : 'room_details' });
			newrow.insert(this.detailBox);
			//this.detailBox.style.padding = 0;
			this.detailBox.style.fontSize = '100%';
		}
		return this.detailBox;
	},
	
	hideDetails : function(transport)
	{
		// hide box
		this.getDetailBox().up().hide();
		this.trigger.stopObserving('click', this.events.hideDetails);
		this.trigger.observe('click', this.events.showDetails);
	},
	
	showError : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
	
});

$$('a.ajax_get_room_details').each(function(e){
	new RoomScheduleDetails(e);
});
