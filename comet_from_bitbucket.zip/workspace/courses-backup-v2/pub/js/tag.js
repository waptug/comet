



var Offering_Tag = Class.create({
	
	backdrop  : null,
	details   : null,
	events    : null,
	mask      : null,
	trigger   : null,
	
	settings : {
		detailZIndex : 52
	},
	
	initialize : function(trigger)
	{
		this.events = {};
		this.trigger = $(trigger);
		this.details = this.trigger.next();
		if (!this.details) {
			return;
		}
		this.details.hide();
		this.observeTrigger(true); 
	},
	
	showdetails : function()
	{
		this.observeTrigger(false);
		if (!this.backdrop) {
			this.backdrop = new Fw_Backdrop_Clear();	
		}
		//this.trigger.style.position = 'relative';
		//this.trigger.style.zIndex = this.settings.maskZIndex;
		if (!this.mask) {
			this.mask = new Fw_Mask({padding:2});
		}
		this.mask.wrapElement(this.trigger);
		this.mask.show();
		this.details.style.position = 'absolute';
		this.details.style.zIndex = this.settings.detailZIndex;
		this.details.show();
		this.positiondetails();
		this.backdrop.show();
		this.observeBackdrop(true);
	},
	
	positiondetails : function()
	{
		var pos = this.trigger.cumulativeOffset();
		this.details.style.top = (pos.top + this.trigger.getHeight()) + this.settings.margin + 'px';
		if (this.trigger.style.textAlign == 'right') {
			this.details.style.left = (pos.left + this.trigger.getWidth() - this.details.getWidth()) + 'px';
		} else {
			this.details.style.left = pos.left + 'px';
		}
	},
	
	hidedetails : function()
	{
		this.mask.hide();
		this.observeBackdrop(false);
		this.backdrop.hide();
		this.trigger.style.zIndex = 1;
		this.details.hide();
		this.observeTrigger(true);
	},
	
	observeBackdrop : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.backdrop = this.hidedetails.bindAsEventListener(this);
			this.backdrop.observe('mouseover', this.events.backdrop);
		} else {
			this.backdrop.stopObserving('mouseover', this.events.backdrop);
		}
	},
	
	observeTrigger : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.trigger = this.showdetails.bindAsEventListener(this);
			this.trigger.observe('mouseover', this.events.trigger);
		} else {
			this.trigger.stopObserving('mouseover', this.events.trigger);
		}
	}
	
});


var Menu_Choose_Tag = Class.create({
	
	backdrop  : null,
	closelink : null,
	menu      : null,
	events    : null,
	trigger   : null,
	
	settings : {
		margin  : 5,
		zIndex  : 52,
		menuId  : 'tag_menu_box'
	},
	
	initialize : function(trigger)
	{
		this.events = {};
		this.trigger = $(trigger);
		this.trigger.href = 'javascript:void(0);';
		this.observeTrigger(true); 
	},
	
	requestmenu : function()
	{
		var options = {
			method    : 'get',
			onSuccess : this.showmenu.bind(this),
			onFailure : this.showerror.bind(this)
		};
		new Ajax.Request(this.getmenuurl(), options);
	},
	
	getmenuurl : function()
	{
		return '/courses/tags/choose?ajax=1&o=' + $('ajax_offeringid').innerHTML;
	},
	
	showmenu : function(transport)
	{
		this.observeTrigger(false);
		if (!this.backdrop) {
			this.backdrop = new Fw_Backdrop_Dark();	
		}
		if (!this.menu) {
			this.createmenubox();	
		}
		this.menu.update(transport.responseText);
		this.positionmenu();
		this.menu.show();
		this.backdrop.show();
		this.observeBackdrop(true);
		
		this.closelink = this.menu.down('p.close_link a');
		if (this.closelink) {
			this.closelink.href = 'javascript:void(0);'; 
			this.closelink.observe('click', this.events.hidemenu);
		}
	},
	
	createmenubox : function()
	{
		this.menu = $(this.settings.menuId);
		if (!this.menu) {
			var body = $$('body')[0];
			this.menu = new Element('div', { id : this.settings.menuId });
			var styles = { 
				position: 'absolute',
				zIndex: this.settings.zIndex
			}
			this.menu.setStyle(styles);
			this.menu.addClassName('popup-window');
			body.insert(this.menu);
		}
	},
	
	positionmenu : function()
	{
		var menuwidth = this.menu.getWidth() + this.menu.style.paddingLeft + this.menu.style.paddingRight + this.menu.style.borderLeft + this.menu.style.borderRight;
		var body = $$('body')[0];
		var posLeft = (body.getWidth() - menuwidth ) / 2;
		var posTop = 100;
		this.menu.style.left = posLeft + 'px';
		this.menu.style.top = posTop + 'px';
	},
	
	hidemenu : function()
	{
		this.observeBackdrop(false);
		this.backdrop.hide();
		if (this.closelink) {
			this.closelink.stopObserving('click', this.events.hidemenu);
		}
		this.menu.hide();
		this.observeTrigger(true);
	},
	
	observeBackdrop : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.hidemenu = this.hidemenu.bindAsEventListener(this);
			this.backdrop.observe('click', this.events.hidemenu);
		} else {
			this.backdrop.stopObserving('click', this.events.hidemenu);
		}
	},
	
	observeTrigger : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.requestmenu = this.requestmenu.bindAsEventListener(this);
			this.trigger.observe('click', this.events.requestmenu);
		} else {
			this.trigger.stopObserving('click', this.events.requestmenu);
		}
	},
	
	showerror : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
	
});

$$('ul.taglist a').each(function(e){
	new Offering_Tag(e);
});

if ($('tag-add')) {
	new Menu_Choose_Tag('tag-add');
}