


var Report_Parameter_Picker = Class.create({

	basetime  : null,
	fullbox   : null,
	handlers  : null,
	summary   : null,
	picker    : null,
	clicked   : null,
	params    : {},
	
	initialize : function()
	{
		this.fullbox = $('report-pickers');
		this.picker = this.fullbox.down('div.picker');
		this.summary = $('report-title');
		this.handlers = {
			'changeParam'     : this.changeParam.bind(this),
			'externalTrigger' : this.externalTrigger.bind(this),
			'requestPicker'   : this.requestPicker.bind(this),
			'requestReset'   : this.requestReset.bind(this),
			'showMoreOptions' : this.showMoreOptions.bind(this),
		}
		$$('a.report-param-picker').each((function(anchor) {
			anchor.onclick = function(e){ return false; };
			anchor.observe('click', this.handlers.requestPicker);
			if (anchor.getAttribute('paramname')) {
				this.params[anchor.getAttribute('paramname')] = anchor;
			}
		}).bind(this));
		this.observeExternal();
		if ($('report-pickers-close')) {
			$('report-pickers-close').observe('click', this.closePickerWindow.bind(this));
		}
		this.fullbox.select('a.reset').each((function(anchor) {
			anchor.onclick = function(e){ return false; };
			anchor.observe('click', this.handlers.requestReset);
		}).bind(this));
		this.basetime = new Date().getTime() / 1000;
	},
	
	observeExternal : function()
	{
		$$('a.report-extra-picker').each((function(anchor) {
			anchor.onclick = function(e){ return false; };
			anchor.observe('click', this.handlers.externalTrigger);
		}).bind(this));
	},
	
	externalTrigger : function(event)
	{
		this.timeout();
		var anchor = event.element();
		var target = anchor.getAttribute('activates');
		if (target && typeof this.params[target] !== "undefined") {
			this.clicked = this.params[target];
			var options = {
				method    : 'get',
				onSuccess : this.showPicker.bind(this),
				onFailure : this.showError.bind(this)
			};
			new Ajax.Request(this.params[target].href, options);
		}
	},
	
	requestPicker : function(event)
	{
		this.timeout();
		this.clicked = event.element();
		var options = {
			method    : 'get',
			onSuccess : this.showPicker.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(event.element().href, options);
	},
	
	requestReset : function(event)
	{
		this.timeout();
		this.clicked = event.element();
		if (typeof this.params['curriculum'] !== "undefined") {
			this.clicked = this.params['curriculum'];
		}
		var options = {
			method    : 'get',
			onSuccess : this.updateAll.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(event.element().href, options);
	},
	
	showPicker : function(transport)
	{
		this.fullbox.show();
		this.fullbox.select('div.sections li').each((function(item) {
			item.removeClassName('selected');
		}).bind(this));
		this.clicked.up().addClassName('selected');
		this.picker.update(transport.responseText);
		this.setPickerHeight();
		var refresh = this.picker.down('div.summary-refresh');
		if (refresh) {
			this.summary.update(refresh.innerHTML);
			refresh.remove();
			this.observeExternal();
		}
		this.picker.select('a').each((function(anchor) {
			anchor.onclick = function(e){ return false; };
			if (anchor.hasClassName('show-more')) {
				anchor.observe('click', this.handlers.showMoreOptions);
			} else {
				anchor.observe('click', this.handlers.changeParam);
			}
		}).bind(this));
	},
	
	closePickerWindow : function()
	{
		this.fullbox.hide();
	},
	
	changeParam : function(event)
	{
		this.timeout();
		var options = {
			method    : 'get',
			onSuccess : this.updateAll.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(event.element().href, options);
	},
	
	updateAll : function(transport)
	{
		this.timeout();
		this.showPicker(transport);
		var options = {
			method    : 'get',
			onSuccess : this.refreshReport.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request($('refresh-report').href, options);
	},
	
	refreshReport : function(transport)
	{
		$('report-container').update(transport.responseText);
	},
	
	showMoreOptions : function(event)
	{
		var anchor = event.element();
		var list = anchor.up().up();
		list.select('a.more').each(function(e){
			e.toggle();
		});
		if (anchor.hasClassName('less')) {
			anchor.removeClassName('less');
			anchor.update('more');
		} else {
			anchor.addClassName('less');
			anchor.update('less');
		}
		this.setPickerHeight();
	},
	
	setPickerHeight : function()
	{
		this.picker.setStyle({height : 'auto'});
		if (this.picker.getHeight() < (this.fullbox.getHeight() - 40)) {
			this.picker.setStyle({height : (this.fullbox.getHeight() - 40) + 'px'});
		}
	},
	
	showError : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	},
	
	timeout : function()
	{
		var now = new Date().getTime() / 1000;
		// pubcookie hard inactive timeout is 30 minutes
		if ((now - this.basetime) > 1200) {
			location.reload(true);
		}
	}
	
});

if ($('report-pickers')) {
	new Report_Parameter_Picker();
}