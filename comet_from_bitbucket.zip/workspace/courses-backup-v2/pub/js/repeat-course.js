/**
 * Supports the plan/quarter view by adding Ajax functionality to 
 * the Repeat buttons.
 * @package UW_COE_Courses
 * @author hanisko
 */


var Repeat_Offering = Class.create({

	clicked   : null,
	
	initialize : function()
	{
		this.attachHandlers();
		document.observe('report:refresh', this.attachHandlers.bind(this));
	},
	
	attachHandlers :function()
	{
		$$('a.repeat-course-trigger').each((function(e){
			var trigger = $(e);
			trigger.onclick = function(e){ return false; };
			trigger.observe('click', this.requestNewOffering.bind(this));
		}).bind(this));
	},
	
	requestNewOffering : function(event)
	{
		this.clicked = event.element();
		var href = this.clicked.href.replace('/new-offering','/new-offering-ajax');
		var options = {
			method    : 'get',
			onSuccess : this.showResponse.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(href, options);
	},
	
	showResponse : function(transport)
	{
		this.clicked.up().previous().update(transport.responseText);
		this.clicked.up().update('&nbsp;');
	},
	
	showError : function(transport)
	{
		window.location.href = this.trigger.href;
	}
	
});

new Repeat_Offering();