
var Instructor_Approval = Class.create({
	
	backdrop : null,
	clicked  : null,
	formbox  : null,
	
	initialize : function()
	{
		$$('a.ajax-instructor-approval').each((function(anchor) {
			anchor.onclick = function(e){ return false; };
			anchor.observe('click', this.requestForm.bind(this));
		}).bind(this));
	},
	
	requestForm : function(event)
	{
		this.clicked = event.findElement('a');
		var href = this.clicked.href + '&ajax=1';
		var options = {
			method    : 'get',
			onSuccess : this.showForm.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(href, options);
	},
	
	showForm : function(transport)
	{
		if (!this.formbox) {
			this.formbox = new Fw_Popupbox();
		}
		if (!this.backdrop) {
			this.backdrop = new Fw_Backdrop_Clear();
		}
		this.formbox.update(transport.responseText);
		this.formbox.show();
		this.backdrop.show();
		this.backdrop.observe('click', this.hideForm.bind(this));
		var closelink = Fw_CloseLink(this.formbox.down());
		closelink.observe('click', this.hideForm.bind(this));
		var form = this.formbox.down('form');
		form.onsubmit = function(e){ return false; };
		form.observe('submit', this.submitForm.bind(this));
	},
	
	submitForm : function(event)
	{
		var form = event.findElement('form');
		var href = form.action + '&ajax=1';
		var options = {
			method    : 'post',
			onSuccess : this.showResult.bind(this),
			onFailure : this.showError.bind(this),
			parameters : { o : form['o'].value, approval : form['approval'].value }
		};
		new Ajax.Request(href, options);
		Event.stop(event);
		this.formbox.hide();
		this.backdrop.hide();
		this.clicked.innerHTML = 'Updating...';
	},
	
	showResult : function(transport)
	{
		this.clicked.innerHTML = transport.responseText;
	},
	
	hideForm : function(event)
	{
		this.formbox.hide();
		this.backdrop.hide();
	},
	
	showError : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
	
});

new Instructor_Approval();



var Workflow_Person = Class.create({

	clicked  : null,
	
	initialize : function()
	{
		$$('a.ajax-workflow-person').each((function(anchor) {
			anchor.onclick = function(e){ return false; };
			anchor.observe('click', this.submitRequest.bind(this));
		}).bind(this));
	},
	
	submitRequest : function(event)
	{
		this.clicked = event.findElement('a');
		var href = this.clicked.href + '&ajax=1';
		var options = {
			method    : 'get',
			onSuccess : this.showResult.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(href, options);
		this.clicked.innerHtml('Updating...');
	},
	
	showResult : function(transport)
	{
		this.clicked.innerHTML = transport.responseText;
		this.initialize();
	},
	
	showError : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
	
});

new Workflow_Person();

