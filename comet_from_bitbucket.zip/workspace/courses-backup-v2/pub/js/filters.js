



var Popup_Window_Local = Class.create({
	
	backdrop  : null,
	closelink : null,
	content   : null,
	events    : null,
	trigger   : null,
	
	settings : {
		padding: 8,
		borderWidth: 2,
		sideMargin : 50,
		triggerMargin: 2,
		zIndex : 51
	},
	
	initialize : function(trigger, content)
	{
		this.trigger = $(trigger);
		this.content = $(content);
		if (!this.trigger || !this.content) return;
		this.trigger.href = 'javascript:void(0);';
		this.events = {};
		this.observeTrigger(true);	
	},
	
	observeTrigger : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.trigger = this.showcontent.bindAsEventListener(this);
			this.trigger.observe('click', this.events.trigger);
		} else {
			this.trigger.stopObserving('click', this.events.trigger);
		}
	},
	
	showcontent : function()
	{
		this.observeTrigger(false);
		var popTop = this.trigger.cumulativeOffset().top + this.trigger.getHeight() + this.settings.triggerMargin;
		var body = $$('body')[0];
		var popWidth = this.content.getWidth();
		var bodWidth = body.getWidth();
		var fitWidth = bodWidth - (this.settings.sideMargin * 2);
		if (fitWidth < popWidth) {
			popWidth = fitWidth;
		}
		var extraWidth = (this.settings.padding + this.settings.borderWidth) * 2;
		//var popLeft = (bodWidth - popWidth - extraWidth) / 2;
		var popLeft = this.trigger.cumulativeOffset().left;
		var styles = {
			display: 'block',  
			position: 'absolute',
			zIndex: this.settings.zIndex,
			left: popLeft + 'px',
			top: popTop + 'px',
			width: popWidth + 'px',
			padding: this.settings.padding + 'px',
			borderWidth: this.settings.borderWidth + 'px'
		}
		this.content.setStyle(styles);
		this.content.show();
		if (!this.backdrop) {
			this.backdrop = new Fw_Backdrop_Dark();	
		}
		this.backdrop.show();
		this.events.hidepopup = this.hidecontent.bindAsEventListener(this);
		this.trigger.observe('click', this.events.hidepopup);
		this.backdrop.observe('click', this.events.hidepopup);
		this.closelink = this.content.down('p.close_link a');
		if (this.closelink) {
			this.closelink.href = 'javascript:void(0);'; 
			this.closelink.observe('click', this.events.hidepopup);
		}
	},
	
	hidecontent : function()
	{
		this.trigger.stopObserving('click', this.events.hidepopup);
		this.backdrop.stopObserving('click', this.events.hidepopup);
		if (this.closelink) {
			this.closelink.stopObserving('click', this.events.hidepopup);
		}
		this.observeTrigger(true);
		this.backdrop.hide();
		this.content.hide();
	}
	
});

new Popup_Window_Local('trigger-quarter-picker', 'quarter-picker');
new Popup_Window_Local('trigger-curriculum-picker', 'curriculum-picker');
new Popup_Window_Local('trigger-haschange-picker', 'haschange-picker');
new Popup_Window_Local('trigger-year-picker', 'year-picker');
new Popup_Window_Local('trigger-responsible-picker', 'responsible-picker');
new Popup_Window_Local('trigger-roomstatus-picker', 'roomstatus-picker');
new Popup_Window_Local('trigger-rou-picker', 'rou-picker');
new Popup_Window_Local('trigger-tag-picker', 'tag-picker');
new Popup_Window_Local('trigger-staffroles-picker', 'staffroles-picker');