
var AjaxWindow = Class.create({

	backdrop   : null,
	box        : null,
	events     : null,
	trigger    : null,
		
	initialize : function(trigger)
	{
		this.events = {};
		this.trigger = $(trigger);
		this.events.trigger = this.requestContent.bindAsEventListener(this);
		this.trigger.onclick = function() {return false;};
		this.trigger.observe('click', this.events.trigger);
	},
	
	requestContent : function()
	{
		var url = this.trigger.href + '&ajax=1';
		var options = {
			method    : 'get',
			onSuccess : this.handleResponse.bind(this),
			onFailure : this.handleError.bind(this)
		};
		new Ajax.Request(url, options);
	},

	handleResponse : function(transport)
	{
		this.box = new Fw_Popupbox();
		this.box.update(transport.responseText);
		this.box.show();
		this.backdrop = new Fw_Backdrop_Dark();
		this.backdrop.show();
		this.observeBackdrop(true);
	},
	
	hidedetail : function(transport)
	{
		this.box.hide();
		this.backdrop.hide();
		this.observeBackdrop(false);
	},
	
	observeBackdrop : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.hidedetail = this.hidedetail.bindAsEventListener(this);
			this.backdrop.observe('click', this.events.hidedetail);
		} else {
			this.backdrop.stopObserving('click', this.events.hidedetail);
		}
	},
	
	handleError : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
	
});


$$('a.ajax-window').each(function(e){
	new AjaxWindow(e);
});