/**
 *  Fw_Ajax
 *  Javascript Class (abstract)
 *
 *  Provides infrastructure for Ajax requests. Functional child classes can 
 *  be created by specifying settings and overriding the getFormURL() and 
 *  getSubmitData() methods. See the COE techwiki for detailed docs and 
 *  examples.
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
var Fw_Ajax = Class.create({

	defaults : {
		ajaxURL       : null,
		viewStyle     : 'popup',  //'inline', 'custom'
		formStyle     : 'single', //'multi'
		submitStyle   : 'ajax',   //'submit'
		triggerId     : null,
		formBoxId     : null,
		processBoxId  : null,
		resultsBoxId  : null,
		backdropDark  : true,
		updateMessage : 'Updating...'
	},
	
	view     : null,
	form     : null,
	settings : null,
	
	initialize : function(triggerId)
	{
		this.settings = Fw_GetSettings(this.settings, this.defaults);
		this.settings.triggerId = triggerId;
		this.events = {};
		
		if (this.settings.viewStyle == 'popup') {
			this.view = new Fw_AjaxView_Popup(this);
		} else if (this.settings.viewStyle == 'inline') {
			this.view = new Fw_AjaxView_Inline(this);
			this.settings.formStyle = 'single';
		} else if (this.settings.viewStyle == 'custom') {
			this.view = new Fw_AjaxView_Custom(this);
		} else {
			this.showAppMessage(message, 'Javascript Fw_Ajax error. Invalid setting for "viewStyle"');
		}
		
		if (this.settings.formStyle == 'single') {
			this.form = new Fw_AjaxForm_Single(this);
		} else if (this.settings.formStyle == 'multi') {
			this.form = new Fw_AjaxForm_Multi(this);
		} else {
			this.showAppMessage(message, 'Javascript Fw_Ajax error. Invalid setting for "viewStyle"');
		}
		
		this.view.observeTrigger(true);	
	},
	
	getFormURL : function()
	{
		return this.settings.ajaxURL;
	},

	getSubmitURL : function()
	{
		return this.settings.ajaxURL;
	},

	getSubmitData : function()
	{
		alert('The abstract method Fw_Ajax::getSubmitData must be implemented');
	},
	
	showForm : function(transport)
	{
		this.view.showForm(transport);
		this.form.observe();
	},
	
	showResult : function(transport)
	{
		this.form.stopObserving();
		this.view.showResult(transport);
	},
	
	revert : function()
	{
		this.form.stopObserving();
		this.view.revert();
	},
	
	requestForm : function()
	{
		var options = {
			method    : 'get',
			onSuccess : this.showForm.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(this.getFormURL(), options);
	},
	
	submitForm : function(event)
	{
		if (this.settings.submitStyle == 'ajax') {
			if (event.type == 'submit');
			Event.stop(event);
			this.submitAjax();
		} else {
			this.submitFull();
		}
	},
	
	submitAjax : function()
	{
		var options = {
			method     : 'post',
			onSuccess  : this.showResult.bind(this),
			onFailure  : this.showError.bind(this),
			parameters : this.getSubmitData()
		};
		new Ajax.Request(this.getSubmitURL(), options);
		this.view.showProcessing();
	},
	
	submitFull : function()
	{
		var form = this.view.getFormBox().down('form');
		var extra = $H(this.getSubmitData());
		extra.each(function(field) {
			var attrs = {
				type  : 'hidden',
				name  : field.key,
				value : field.value
			};
			var input = new Element('input', attrs);
			form.insert(input);
		});
	},
	
	showError : function(transport)
	{
		this.showAppMessage(transport.responseText, 'error');
	},
	
	showAppMessage : function(message, cssClassName)
	{
		if (typeof(cssClassName) == "undefined") {
			cssClassName = null;
		}
		var messagebox = null;
		var mboxes = $$('div.message_box');
		if (mboxes) {
			if (mboxes.length > 0) {
				messagebox = mboxes[0];
			}
		}
		if (messagebox) {
			var innerbox = messagebox.down().down();
			if (cssClassName) {
				innerbox.addClassName(cssClassName);
			}
			innerbox.update(message);
			messagebox.show();
		} else {
			alert(message);
		}
	},
	
	showAppMessageError : function(message)
	{
		this.showAppMessage(message, 'error');
	},
	
	showAppMessageSuccess : function(message)
	{
		this.showAppMessage(message, 'success');
	},
	
	showAppMessageWarning : function(message)
	{
		this.showAppMessage(message, 'warning');
	}
	
});

/**
 *  Fw_AjaxForm
 *  Javascript Class (abstract)
 *
 *  This is a strategy class for use with Fw_Ajax. Fw_AjaxForm classes define how
 *  an Ajax form should be observed to trigger a submit or to cancel the interaction.
 *  Child classes need to implement observe() and stopObserving().
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
var Fw_AjaxForm = Class.create({
	
	ctrl     : null,
	events   : null,
	
	initialize : function(controller)
	{
		this.events = {};
		this.ctrl = controller;
	},
	
	observe : function() 
	{
		alert('The abstract method Fw_AjaxForm::observe must be implemented');
	},
	
	stopObserving : function() 
	{
		alert('The abstract method Fw_AjaxForm::stopObserving must be implemented');
	},
	
	keypress : function(keyupEvent)
	{
		if (keyupEvent.keyCode == Event.KEY_ESC) {
			this.ctrl.revert(keyupEvent);
		}
		if (keyupEvent.keyCode == Event.KEY_RETURN) {
			this.ctrl.submitForm(keyupEvent);
		}
	}
	
});

/**
 *  Fw_AjaxForm_Single
 *  Javascript Class
 *
 *  Provides utility to watch a single HTML input to trigger either an Ajax
 *  submit routine or to cancel the input. Enter key triggers submit. On 
 *  select elements change also triggers submit. Escape key or loss of focus
 *  triggers the Fw_Ajax::revert().
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
var Fw_AjaxForm_Single = Class.create(Fw_AjaxForm, {
	
	input : null,
	
	observe : function() 
	{
		this.input = this.ctrl.view.getFormBox().down();
		this.events = {};
		this.events.submit   = this.ctrl.submitForm.bindAsEventListener(this.ctrl);
		this.events.hide     = this.ctrl.revert.bindAsEventListener(this.ctrl);
		this.events.keypress = this.keypress.bindAsEventListener(this);
		
		this.input.observe('blur', this.events.hide);
		this.input.observe('keyup', this.events.keypress);
		if (this.input.type == 'text') {
			this.input.focus();
			this.input.select();
		} else {
			this.input.observe('change', this.events.submit);
			this.input.focus();
		}		
	},
	
	stopObserving : function() 
	{
		this.input.stopObserving('blur', this.events.hide);
		this.input.stopObserving('keyup', this.events.keypress);
		if (this.input.type != 'text') {
			this.input.stopObserving('change', this.events.submit);
		}
	}
	
});

/**
 *  Fw_AjaxForm_Multi
 *  Javascript Class
 *
 *  Provides utility to watch a form with multiple inputs for a sumbit
 *  action and triggers Fw_Ajax::submitForm() action.
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
var Fw_AjaxForm_Multi = Class.create(Fw_AjaxForm, {
	
	form : null,
	
	observe : function() 
	{
		this.form = this.ctrl.view.getFormBox().down('form');
		this.events = {};
		this.events.submit = this.ctrl.submitForm.bindAsEventListener(this.ctrl);
		this.form.observe('submit', this.events.submit);
	},
	
	stopObserving : function() 
	{
		this.form.stopObserving('submit', this.events.submit);
	}
	
});

/**
 *  Fw_AjaxView
 *  Javascript Class (abstract)
 *
 *  Fw_AjaxView classes are strategy classes that manage the display of HTML
 *  page elements during and Ajax transaction. 
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
var Fw_AjaxView = Class.create({
	
	ctrl     : null,
	events   : null,
	
	initialize : function(controller)
	{
		this.ctrl = controller;
		alert('The abstract method Fw_AjaxView::initialize must be implemented');
	},
	
	observeTrigger : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.trigger = this.ctrl.requestForm.bindAsEventListener(this.ctrl);
			this.trigger.observe('click', this.events.trigger);
		} else {
			this.trigger.stopObserving('click', this.events.trigger);
		}
	},
	
	showForm : function(transport)
	{
		alert('The abstract method Fw_AjaxView::showForm must be implemented');
	},
	
	showProcessing : function()
	{
		alert('The abstract method Fw_AjaxView::showProcessing must be implemented');
	},
	
	showResult : function(transport)
	{
		alert('The abstract method Fw_AjaxView::showResult must be implemented');
	},
	
	revert : function()
	{
		alert('The abstract method Fw_AjaxView::revert must be implemented');
	},
	
	getFormBox : function()
	{
		alert('The abstract method Fw_AjaxView::getFormBox must be implemented');
	}
	
});

/**
 *  Fw_AjaxView_Inline
 *  Javascript Class
 *
 *  Presents a full Ajax transaction within a single page element.
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
var Fw_AjaxView_Inline = Class.create(Fw_AjaxView, {
	
	trigger  : null,
	oldValue : null,
	
	initialize : function(controller)
	{
		this.events = {};
		this.ctrl = controller;
		this.trigger = $(this.ctrl.settings.triggerId);
	},
	
	showForm : function(transport)
	{
		this.observeTrigger(false);
		this.oldValue = this.trigger.innerHTML;
		this.trigger.update(transport.responseText);
	},
	
	showProcessing : function()
	{
		this.trigger.update(this.ctrl.settings.updateMessage);
	},
	
	showResult : function(transport)
	{
		this.trigger.update(transport.responseText);
		this.observeTrigger(true);
	},
	
	revert : function(event)
	{
		this.trigger.update(this.oldValue);
		this.observeTrigger(true);
	},
	
	getFormBox : function()
	{
		return this.trigger;
	}
	
});

/**
 *  Fw_AjaxView_Popup
 *  Javascript Class
 *
 *  Simulates a pop-up window via HTML.
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
var Fw_AjaxView_Popup = Class.create(Fw_AjaxView, {
	
	trigger    : null,
	resultbox  : null,
	processbox : null,
	backdrop   : null,
	formbox    : null,
	
	initialize : function(controller)
	{
		this.events = {};
		this.ctrl = controller;
		this.trigger = $(this.ctrl.settings.triggerId);
		this.processbox = $(this.ctrl.settings.processBoxId);
		this.resultbox = $(this.ctrl.settings.resultsBoxId);
		this.backdrop = new Fw_Backdrop_Dark();
		this.formbox = new Fw_Popupbox();
	},
	
	showForm : function(transport)
	{
		this.observeTrigger(false);
		this.backdrop.show();
		this.formbox.show();
		this.formbox.update(transport.responseText);
		this.events.hide = this.ctrl.revert.bindAsEventListener(this.ctrl);
		this.backdrop.observe('click', this.events.hide);
	},
	
	showProcessing : function(transport)
	{
		if (this.processbox) {
			this.formbox.hide();
			this.backdrop.stopObserving('click', this.events.hide);
			this.backdrop.hide();
			this.processbox.update(this.ctrl.settings.updateMessage);
		} else {
			this.formbox.update(this.ctrl.settings.updateMessage);
		}
	},
	
	showResult : function(transport)
	{
		this.formbox.hide();
		this.backdrop.stopObserving('click', this.events.hide);
		this.backdrop.hide();
		if (this.resultbox) {
			this.resultbox.update(transport.responseText);
		} else {
			this.ctrl.showAppMessageSuccess(transport.responseText);
		}
		this.observeTrigger(true);
	},
	
	revert : function(transport)
	{
		this.formbox.hide();
		this.backdrop.hide();
		this.observeTrigger(true);
	},
	
	getFormBox : function()
	{
		return this.formbox;
	}
	
});

/**
 *  Fw_AjaxView_Custom
 *  Javascript Class
 *
 *  Places the Ajax states in existing HTML elements specified in the 
 *  Fw_Ajax::settings. 
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
var Fw_AjaxView_Custom = Class.create(Fw_AjaxView, {
	
	trigger    : null,
	resultbox  : null,
	processbox : null,
	formbox    : null,
	
	initialize : function(controller)
	{
		this.events = {};
		this.ctrl = controller;
		this.trigger = $(this.ctrl.settings.triggerId);
		this.formbox = $(this.ctrl.settings.formBoxId);
		this.processbox = $(this.ctrl.settings.processBoxId);
		this.resultbox = $(this.ctrl.settings.resultsBoxId);
	},
	
	showForm : function(transport)
	{
		this.formbox.update(transport.responseText);
	},
	
	showProcessing : function()
	{
		this.formbox.update('');
		if (this.processbox) {
			this.processbox.update(this.ctrl.settings.updateMessage);
		} else {
			this.resultbox.update(this.ctrl.settings.updateMessage);
		}
	},
	
	showResult : function(transport)
	{
		if (this.processbox) {
			this.processbox.update('');
		}
		this.resultbox.update(transport.responseText);
	},
	
	revert : function()
	{
		this.formbox.update('');
		this.processbox.update('');
	},
	
	getFormBox : function()
	{
		return this.formbox;
	}
	
});