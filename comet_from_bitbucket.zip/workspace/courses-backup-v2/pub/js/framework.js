
/**
 *  Fw_GetParamValue
 *  Javascript Function
 *
 *  Locates an anchor tag within the provided container that has the class name
 *  "close_link". If the element does not already exist it is created and inserted.
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
function Fw_CloseLink(container)
{
	var c = $(container);
	var closelink = c.down('a.close_link');
	if (!closelink) {
		var closelink = new Element('a', {'class' : 'close_link'});
		closelink.update('close X');
		c.insert({ top : closelink });
	}
	return closelink;
}

/**
 *  Fw_Backdrop_Clear
 *  Javascript Class
 *
 *  Generates an invisible page overlay at z-index 50 that javascript events
 *  can be attached to. This overlay is used with pop-up items (forms, menus)
 *  so when the user clicks "off" of the item in focus a page specific reset
 *  method can be called.
 *
 *  Example:
 *  var backdrop = new Fw_Backdrop_Clear();
 *  backdrop.show();
 *  backdrop.observe('click', myResetFunction);
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */

var Fw_Backdrop_Clear = Class.create({

	backdropId : 'Fw_PageMaskLayer',
	backdrop : null,
	
	createBackdrop : function()
	{
		this.backdrop = $(this.backdropId);
		if (!this.backdrop) {
			this.backdrop = new Element('div', { id : this.backdropId });
			this.backdrop.setStyle(this.getStyles());
			var body = $$('body')[0];
			body.insert(this.backdrop);
		}
	},
	
	getStyles : function()
	{
		return {
			display: 'block',  
			position: 'absolute',
			zIndex: 40,
			top: '0px',
			left: '0px',
			width: '100%',
			overflow: 'hidden'
		};
	},
	
	show : function()
	{
		if (this.backdrop == null) {
			this.createBackdrop();
		}
		var html = $$('html')[0];
		var body = $$('body')[0];
		var vpHeight = document.viewport.getHeight();
		var height = Math.max( body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight, vpHeight);
		this.backdrop.style.height = height + 'px';
		this.backdrop.show();
	},
	
	hide : function()
	{
		if (this.backdrop) {
			this.backdrop.hide();
			//this.backdrop.stopObserving('click', this.hideEvent);
		}
	},
	
	observe : function(eventname, method)
	{
		if (!this.backdrop) {
			this.createBackdrop();
		}
		this.backdrop.observe(eventname, method);	
	},
	
	stopObserving : function(eventname, method)
	{
		if (this.backdrop) {
			this.backdrop.stopObserving(eventname, method);	
		}
	}
	
});

/**
 *  Fw_Backdrop_Dark
 *  Javascript Class
 *  extends Fw_Backdrop_Clear
 *
 *  Generates an shaded page overlay at z-index 50 that javascript events
 *  can be attached to. This overlay is used with pop-up items (forms, menus)
 *  so when the user clicks "off" of the item in focus a page specific reset
 *  method can be called.
 *
 *  Example:
 *  var backdrop = new Fw_Backdrop_Dark();
 *  backdrop.show();
 *  backdrop.observe('click', myResetFunction);
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
 
var Fw_Backdrop_Dark = Class.create(Fw_Backdrop_Clear, {
	 
	backdropId : 'Fw_PageMaskLayer_Dk',
	opacity : 50,
	
	getStyles : function()
	{
		var opacityD = this.opacity / 100;
		return {
			display: 'block',  
			position: 'absolute',
		    opacity: opacityD,                      
		    MozOpacity: opacityD,                   
		    filter: 'alpha(opacity=' + this.opacity + ')', 
		    backgroundColor: '#000', 
			zIndex: 40,
			left: '0px',
			top: '0px',
			width: '100%',
			overflow: 'hidden'
		};
	}

});

/**
 *  Fw_AppMessage
 *  Javascript Class
 *
 *  Provides javascript access to the Application Message box. This is a
 *  styled and overlayed div that allows feedback on application processing.
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */

var Fw_AppMessage = Class.create({
	
	messagebox : null,
	
	initialize : function(settings)
	{
		var mboxes = $$('div.message_box');
		if (mboxes) {
			if (mboxes.length > 0) {
				this.messagebox = mboxes[0];
			}
		}
	},
	
	hide : function()
	{
		if (this.messagebox) {
			this.messagebox.hide();	
		}
	},
	
	show : function(message, cssClassName)
	{
		if (typeof(message) == "undefined") {
			message = null;
		}
		if (typeof(cssClassName) == "undefined") {
			cssClassName = null;
		}
		if (this.messagebox) {
			var innerbox = this.messagebox.down().down();
			if (cssClassName) {
				innerbox.className = cssClassName;
			}
			innerbox.update(message);
			this.messagebox.show();
		} else {
			alert(message);
		}
	},
	
	showError : function(message)
	{
		this.show(message, 'error');
	},
	
	showSuccess : function(message)
	{
		this.show(message, 'success');
	},
	
	showWarning : function(message)
	{
		this.show(message, 'warning');
	}
	
});

/**
 *  Fw_DeactivateLink
 *  Javascript Function
 *
 *  Removes the default, follow link, behavior from an HTML anchor tag. This 
 *  simple approach has been working, but using this funtion to keep the process 
 *  encapsulated in case it needs to be tweaked.
 *
 *  @author Paul Hanisko
 */
function Fw_DeactivateLink(anchor)
{
	anchor.onclick = function(e) { return false; }
}

/**
 *  Fw_GetParamValue
 *  Javascript Function
 *
 *  Searches the href of the provided anchor for a URL query string parameter
 *  that matches the param argument. Returns the value of that parameter.
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
function Fw_GetParamValue(anchor, param)
{
	if (typeof(anchor)=='string') {
		var href = anchor;
	} else {
		if (anchor.href) {
			var href = anchor.href;
		} else {
			return null;
		}
	}
	if (href.indexOf('?') == -1) {
		return null;
	}
	var paramsearch = new RegExp("\\b"+param+"=([^&]*)");
	var found = href.match(paramsearch);
	if (found) {
		return decodeURI(found[1]);
	} else {
		return null;
	}
}

/**
 *  Fw_GetSettings
 *  Javascript Function
 *
 *  This function combines the properties of two objects and returns the
 *  results. The purpose of the method is to take a runtime "settings" 
 *  hash and overlay that with a hash of "default" settings.
 *
 *  The first argument (settings) may be empty. The second argument (defaults)
 *  should contain every property that needs to be defined with a fallback
 *  value.
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */

function Fw_GetSettings(settings, defaults)
{
	if (typeof(settings) == "undefined") {
		return defaults;
	}
	var defs = $H(defaults);
	defs.each(function(d) {
		if (typeof(settings[d.key]) == "undefined") {
			settings[d.key] = d.value;
		}
	});
	return settings;
}

/**
 *  Fw_PopupMenu
 *  Javascript Class
 *
 *  Generates clickable menus within a web page. A menu is composed of an
 *  activation link with a class of "fw_show_menu" followed by a block 
 *  element that contains the menu choices. For example:
 *
 *  <a class="fw_show_menu">Click to show menu</a>
 *  <ul>
 *      <li><a href="?choice=1">Item One</a></li>
 *      <li><a href="?choice=2">Item Two</a></li>
 *      <li><a href="?choice=3">Item Three</a></li>
 *  </ul>
 *
 *  Activation: the following line should be included in a javascript file
 *  at the bottom of your page to activate your "fw_show_menu" triggers
 *
 *  $$('a.fw_show_menu').each( function(menuLink) { new Fw_PopupMenu(menuLink); });
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
 
var Fw_PopupMenu = Class.create({

	backdrop : null,
	events   : null,
	menu     : null,
	trigger  : null,
	
	defaults : {
		minMenuWidth  : 80,
		menuZIndex    : 51,
		edgeMargin    : 10
	},
	
	initialize : function(trigger)
	{
		this.trigger = $(trigger);
		this.trigger.href = 'javascript:void(0);';
		this.menu = this.trigger.next();
		this.menu.hide();
		this.backdrop = new Fw_Backdrop_Clear();
		this.events = {};
	},
	
	hideMenu : function()
	{
		// Stop listening to the backdrop
		if (this.backdrop) this.backdrop.stopObserving('click', this.events.hide);
		// Display the menu items
		this.backdrop.hide();
		this.menus.hide();
	},
	
	showMenu : function()
	{
		var body = $$('body')[0];
		var menuHeight = this.menu.getHeight() + this.defaults.edgeMargin;
		var menuWidth = this.menu.getWidth() + this.defaults.edgeMargin;
		var windowHeight = document.documentElement.scrollHeight;
	
		// Create a default position based on the link that opens this menu
		var pos = this.trigger.cumulativeOffset();
		pos.top = pos.top + this.trigger.getHeight() + 4;
	
		// If the position would place the menu outside the viewport adjust it back
		var maxleft = body.getWidth() - menuWidth;
		var maxtop  = windowHeight - menuHeight;
		if (pos.left > maxleft) { pos.left = maxleft; }
		if (pos.top  > maxtop)  { pos.top  = maxtop; }
	
		// Update the styles for the new position
		var styles = {
			position : 'absolute',
			zIndex   : this.defaults.menuZIndex,
			left     : pos.left + 'px',
			top      : pos.top + 'px'
		}
		this.menus.setStyle(styles);
	
		// Display the menu items
		this.backdrop.show();
		this.menus.show();
		
		// Set up the click-off event
		this.events.hide = this.hideMenu.bindAsEventListener(this);
		this.backdrop.observe('click', this.events.hide);
	}
	
});

/**
 *  Fw_Popupbox
 *  Javascript Class
 *
 *  Creates an HTML div element that simulates a pop-up window inline on a
 *  page. Dynamically generates the required style rules to position the 
 *  window properly in the viewport. General appearance style should be 
 *  configured through external CSS style sheet.
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
var Fw_Popupbox = Class.create({
	
	settings   : null,
	box        : null,
	
	defaults : {
		popupBoxId : 'ajax_form_container',
		fixedWidth : null,
		maxWidth   : 800,
		topMargin  : 190,
		sideMargin : 200,
		padding    : 0,
		border     : 0,
		zIndex     : 51,
		relElement : null,
		relSide    : 'below',
		relAlign   : 'left',
		relMargin  : 2,
		pageMargin : 5
	},
	
	initialize : function(settings)
	{
		this.settings = Fw_GetSettings(settings, this.defaults);
	},
	
	createBox : function()
	{
		var body = $$('body')[0];
		this.box = $(this.settings.popupBoxId);
		if (!this.box) {
			this.box = new Element('div', { id : this.settings.popupBoxId });
			body.insert(this.box);
		}
		var setWidth = 400;
		var setLeft = 0;
		var setTop = 0;
		if (this.settings.fixedWidth) {
			setWidth = this.settings.fixedWidth;
		} else {
			setWidth = this.settings.maxWidth;
			var fitWidth = body.getWidth() - (this.settings.sideMargin * 2);
			if (fitWidth < setWidth) {
				setWidth = fitWidth;
			}
		}
		var styles = {
			display: 'block',  
			position: 'absolute',
			zIndex: this.settings.zIndex,
			width: setWidth + 'px',
			padding: this.settings.padding + 'px',
			borderWidth: this.settings.border + 'px'
		}
		this.box.setStyle(styles);
	},
	
	positionBox : function()
	{
		var html = $$('html')[0];
		var body = $$('body')[0];
		if (this.settings.relElement) {
			var rel = $(this.settings.relElement);
		}
		if (rel) {
			var relPos = rel.cumulativeOffset();
			if (this.settings.relSide == 'left') {
				setLeft = relPos.left - (this.box.getWidth() + this.settings.relMargin);
			} else if (this.settings.relSide == 'right') {
				setLeft = relPos.left + rel.getWidth() + this.settings.relMargin;
			} else { // remaining values are above or below
				if (this.settings.relAlign == 'right') {
					setLeft = relPos.left + rel.getWidth() - this.box.getWidth();
				} else if (this.settings.relAlign == 'center') {
					setLeft = (relPos.left + (rel.getWidth() / 2)) - (this.box.getWidth() / 2);
				} else { // align left edges
					setLeft = relPos.left;
				}
			}

			if (this.settings.relSide == 'above') {
				setTop = relPos.top - (this.box.getHeight() + this.settings.relMargin);
			} else if (this.settings.relSide == 'below') {
				setTop = relPos.top + rel.getHeight() + this.settings.relMargin;
			} else { // remaining values are left or right
				if (this.settings.relAlign == 'bottom') {
					setTop = relPos.top + rel.getHeight() - this.box.getHeight();
				} else if (this.settings.relAlign == 'middle') {
					setTop = (relPos.top + (rel.getHeight() / 2)) - (this.box.getHeight() / 2);
				} else { // align top edges
					setTop = relPos.top;
				}
			}
			
		} else {
			// reposition the popupbox into the current scrolled position
            setLeft = (body.getWidth() - this.box.getWidth()) / 2;
			setTop = this.settings.topMargin + document.viewport.getScrollOffsets().top;
		}
		// if element got positioned outside of view port, move it back
		if (setLeft < this.settings.pageMargin) {
			setLeft = this.settings.pageMargin;
		}
		if ((setLeft + this.box.getWidth() + this.settings.pageMargin) > body.getWidth()) {
			setLeft = body.getWidth() - this.box.getWidth() - this.settings.pageMargin;
		}
		// if element got positioned outside of view port, move it back
		var contentHeight = Math.max(body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight, document.viewport.getHeight());
		if (setTop < this.settings.pageMargin) {
			setTop = this.settings.pageMargin;
		}
		if ((setTop + this.box.getHeight() + this.settings.pageMargin) > contentHeight) {
			setTop = contentHeight - this.box.getHeight() - this.settings.pageMargin;
			if (setTop < this.settings.pageMargin) setTop = this.settings.pageMargin;
		}
		//		var extraWidth = (this.settings.padding + this.settings.border) * 2;
		this.box.style.left = setLeft + 'px';
		this.box.style.top = setTop + 'px';
	},
	
	show : function()
	{
		if (this.box == null) {
			this.createBox();
		}
		this.positionBox();
		this.box.show();
	},
	
	hide : function()
	{
		if (this.box != null) {
			this.box.hide();
		}
	},
	
	down : function(cssSelector)
	{
		cssSelector = (typeof(cssSelector) == "undefined") ? '*' : cssSelector;
		if (this.box == null) {
			this.createBox();
		}
		return this.box.down(cssSelector);
	},
	
	observe : function(eventname, method)
	{
		if (this.box == null) {
			this.createBox();
		}
		this.box.observe(eventname, method);	
	},
	
	select : function(cssSelector)
	{
		if (this.box == null) {
			this.createBox();
		}
		return this.box.select(cssSelector);	
	},
	
	stopObserving : function(eventname, method)
	{
		if (this.box == null) {
			return;
		}
		this.box.stopObserving(eventname, method);	
	},
	
	update : function(content)
	{
		if (this.box == null) {
			this.createBox();
		}
		this.box.update(content);
	},
	
	positionBy : function(element, side, alignment)
	{
		if (typeof(side) == "undefined") {
			side = 'below';
		}
		if (typeof(alignment) == "undefined") {
			alignment = 'left';
		}
		this.settings.relElement = element;
		this.settings.relSide = side;
		this.settings.relAlign = alignment;
	},
	
	setPopupBoxId : function(boxid)
	{
		this.settings.popupBoxId = boxid;
	}
	
});


/**
 *  Fw_Mask
 *  Javascript Class
 *
 *  Creates an HTML div element that can be positioned to invisibly cover a base
 *  page element. The invisible mask allows for the adjustment of event trigger 
 *  areas without changing the size of elements on the page. Fw_Mask is similar 
 *  to the Fw_PageMask class, but only covers a smaller specified area.
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
var Fw_Mask = Class.create({
	
	settings : null,
	box : null,
	
	defaults : {
		maskBoxId  : 'ajax_area_mask',
		zIndex     : 45,
		padding    : 10
	},
	
	initialize : function(settings)
	{
		this.settings = Fw_GetSettings(settings, this.defaults);
	},
	
	createBox : function()
	{
		var body = $$('body')[0];
		this.box = new Element('div', { id : this.settings.maskBoxId });
		var styles = {
			display: 'block',  
			position: 'absolute',
			zIndex: this.settings.zIndex,
			left: '0px',
			width: '1px'
		}
		this.box.setStyle(styles);
		body.insert(this.box);
	},
	
	wrapElement : function(element)
	{
		this.box = $(this.settings.maskBoxId);
		if (this.box == null) {
			this.createBox();
		}
		var pos = element.cumulativeOffset();
		this.box.style.left   = (pos.left - this.settings.padding) + 'px';
		this.box.style.top    = (pos.top - this.settings.padding) + 'px';
		this.box.style.width  = (element.getWidth() + (this.settings.padding * 2)) + 'px';
		this.box.style.height = (element.getHeight() + (this.settings.padding * 2)) + 'px';
	},
	
	show : function()
	{
		if (this.box == null) {
			this.createBox();
		}
		this.box.show();
	},
	
	hide : function()
	{
		if (this.box != null) {
			this.box.hide();
		}
	},
	
	setStyle : function(styles)
	{
		this.box.setStyle(styles);
	},
	
	down : function(cssSelector)
	{
		cssSelector = (typeof(cssSelector) == "undefined") ? '*' : cssSelector;
		if (this.box == null) {
			this.createBox();
		}
		return this.box.down(cssSelector);
	},
	
	observe : function(eventname, method)
	{
		if (this.box == null) {
			this.createBox();
		}
		this.box.observe(eventname, method);	
	},
	
	stopObserving : function(eventname, method)
	{
		if (this.box == null) {
			return;
		}
		this.box.stopObserving(eventname, method);	
	}
	
});

/**
 *  Creates mouseover menus. Menus are identified by anchor tags with the
 *  class "fw_menu_trigger". The next element in the document (e.g. an <ul>)
 *  will be treated as the menu. The menu is hidden until the trigger is 
 *  hovered over.
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
var Fw_Menu = Class.create({

	trigger  : null,
	menu     : null,
	mask     : null,
	events   : null,
	backdrop : null,
	
	settings : {
		maskPadding : 0,
		maskZIndex  : 51
	},
	
	initialize : function(trigger)
	{
		this.events = {};
		this.trigger = $(trigger);
		this.menu = this.trigger.next();
		if (!this.menu) {
			console.log('Missing menu element for "'+trigger.innerHTML+'"');
			return;
		}
		this.menu.hide();
		this.observeTrigger(true); 
	},
	
	showMenu : function()
	{
		this.observeTrigger(false);
		if (!this.backdrop) {
			this.backdrop = new Fw_Backdrop_Clear();	
		}
		this.trigger.style.position = 'relative';
		this.trigger.style.zIndex = this.settings.maskZIndex;
		this.menu.style.position = 'absolute';
		this.menu.style.zIndex = this.settings.maskZIndex;
		this.menu.show();
		this.positionMenu();
		this.mask = new Fw_Mask();
		this.mask.wrapElement(this.menu);
		this.mask.show();
		this.backdrop.show();
		this.observeBackdrop(true);
	},
	
	positionMenu : function()
	{
		var pos = this.trigger.cumulativeOffset();
		this.menu.style.top = (pos.top + this.trigger.getHeight()) + 'px';
		if (this.trigger.style.textAlign == 'right') {
			this.menu.style.left = (pos.left + this.trigger.getWidth() - this.menu.getWidth()) + 'px';
		} else {
			this.menu.style.left = pos.left + 'px';
		}
	},
	
	hideMenu : function()
	{
		this.observeBackdrop(false);
		this.backdrop.hide();
		this.mask.hide();
		this.trigger.style.zIndex = 1;
		this.menu.hide();
		this.observeTrigger(true);
	},
	
	observeBackdrop : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.backdrop = this.hideMenu.bindAsEventListener(this);
			this.backdrop.observe('mouseover', this.events.backdrop);
		} else {
			this.backdrop.stopObserving('mouseover', this.events.backdrop);
		}
	},
	
	observeTrigger : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.trigger = this.showMenu.bindAsEventListener(this);
			this.trigger.observe('mouseover', this.events.trigger);
		} else {
			this.trigger.stopObserving('mouseover', this.events.trigger);
		}
	}

});

/**
 *  Provides javascript access to the Application Message box. This is a styled and 
 *  overlayed div that allows feedback on application processing.
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
var Fw_AppMessage = Class.create({
	
	message : function(message, cssClassName)
	{
		if (typeof(cssClassName) == "undefined") {
			cssClassName = null;
		}
		var messagebox = null;
		var mboxes = $$('div.message_box');
		if (mboxes) {
			if (mboxes.length > 0) {
				messagebox = mboxes[0];
			}
		}
		if (messagebox) {
			var innerbox = messagebox.down().down();
			if (cssClassName) {
				innerbox.addClassName(cssClassName);
			}
			innerbox.update(message);
			messagebox.show();
		} else {
			alert(message);
		}
	},
	
	error : function(message)
	{
		this.message(message, 'error');
	},
	
	success : function(message)
	{
		this.message(message, 'success');
	},
	
	warning : function(message)
	{
		this.message(message, 'warning');
	}
	
});

/**
 *  Overrides default behavior of a link and displays the referenced
 *  page in a pop-up window.
 *
 *  @author Paul Hanisko
 *  @package UW_COE_Framework
 */
var Fw_Help_Popup = Class.create({

	trigger : null,
	url : null,
	popup : null,
	backdrop : null,
	
	initialize : function(trigger)
	{
		this.events = {};
		this.trigger = $(trigger);
		this.url = this.trigger.href+'?ajax=1';
		this.trigger.onclick = function() {return false;};
		this.events.gethelp = this.gethelp.bindAsEventListener(this);
		this.trigger.observe('click', this.events.gethelp);
	},
	
	gethelp : function(event)
	{
		this.trigger.stopObserving('click', this.events.gethelp);
		var options = {
			method    : 'get',
			onSuccess : this.showhelp.bind(this),
			onFailure : this.hidehelp.bind(this)
		};
		new Ajax.Request(this.url, options);
		//Event.stop(event);
	},
	
	showhelp : function(transport)
	{
		if (!this.popup) {
			this.popup = new Fw_Popupbox({
				popupBoxId : 'ajax_help_message',
				maxWidth   : 500,
				topMargin  : 190,
				sideMargin : 300,
				padding    : 10,
				border     : 2,
				zIndex     : 51
			});
		}
		if (!this.backdrop) {
			this.backdrop = new Fw_Backdrop_Dark();
		}
		this.popup.update(transport.responseText);
		this.popup.show();
		this.backdrop.show();
		this.events.hidehelp = this.hidehelp.bindAsEventListener(this);
		this.backdrop.observe('click', this.events.hidehelp);
		this.popup.observe('click', this.events.hidehelp);
	},
	
	hidehelp : function()
	{
		this.backdrop.stopObserving('click', this.events.hidehelp);
		this.popup.stopObserving('click', this.events.hidehelp);
		this.backdrop.hide();
		this.popup.hide();
		this.events.gethelp = this.gethelp.bindAsEventListener(this);
		this.trigger.observe('click', this.events.gethelp);
	},
	
	showerror : function(transport)
	{
		var appmessage = new Fw_AppMessage();
		appmessage.showError(transport.responseText);
	}
		
});

