



var Test_Popup = Class.create({
	
	backdrop  : null,
	closelink : null,
	popup     : null,
	events    : null,
	trigger   : null,
		
	initialize : function(trigger)
	{
		this.trigger = $(trigger);
		if (!this.trigger) return;
		this.trigger.onclick = function(e){ return false; };
		this.events = {};
		this.observeTrigger(true);
	},
	
	observeTrigger : function(activate)
	{
		activate = (typeof(activate) == "undefined") ? true : Boolean(activate);
		if (activate) {
			this.events.trigger = this.showcontent.bindAsEventListener(this);
			this.trigger.observe('click', this.events.trigger);
		} else {
			this.trigger.stopObserving('click', this.events.trigger);
		}
	},
	
	showcontent : function()
	{
		this.observeTrigger(false);
		var placement = this.trigger.id.match(/[^\-]+/g);
		this.popup = new Fw_Popupbox({ fixedWidth: 200 });
		this.popup.setPopupBoxId('popup-content');
		this.popup.positionBy(this.trigger, placement[1], placement[2]);
		
		this.popup.show();
		if (!this.backdrop) {
			this.backdrop = new Fw_Backdrop_Dark();	
		}
		this.backdrop.show();
		this.events.hidepopup = this.hidecontent.bindAsEventListener(this);
		this.trigger.observe('click', this.events.hidepopup);
		this.backdrop.observe('click', this.events.hidepopup);
		this.closelink = this.popup.down('p.close_link a');
		if (this.closelink) {
			this.closelink.href = 'javascript:void(0);'; 
			this.closelink.observe('click', this.events.hidepopup);
		}
	},
	
	hidecontent : function()
	{
		this.trigger.stopObserving('click', this.events.hidepopup);
		this.backdrop.stopObserving('click', this.events.hidepopup);
		if (this.closelink) {
			this.closelink.stopObserving('click', this.events.hidepopup);
		}
		this.observeTrigger(true);
		this.backdrop.hide();
		this.popup.hide();
	}
	
});

$$('table.test-popups a').each(function(e){
	new Test_Popup(e);
});

