
var msgs = $$('div.message_box');
msgs.each( function(element) {
	$(element).observe('click', hide_app_message);
});

function hide_app_message()
{
	var msgs = $$('div.message_box');
	msgs.each( function(element) {
		$(element).hide();
	});
}

$$('a.fw_menu_trigger').each(function(e){
	new Fw_Menu(e);
});

$$('a.popup-help').each(function(e){
	new Fw_Help_Popup(e);
});

var Search_Collapse = Class.create({

	button     : null,
	hasfocus   : false,
	overbutton : false,
	query      : null,
	
	initialize : function(trigger)
	{
		this.trigger = $(trigger);
		this.button = $('search-submit');
		if (!this.button) {
			return;
		}
		this.button.observe('mouseover', this.buttonOver.bind(this));
		this.button.observe('mouseout', this.buttonOut.bind(this));
		this.trigger.observe('focus', this.gotFocus.bind(this));
		this.trigger.observe('blur', this.lostFocus.bind(this));
		this.shrinkSearch();
	},
	
	buttonOver : function()
	{
		this.overbutton = true;
	},
	
	buttonOut : function()
	{
		this.overbutton = false;
		if (this.hasfocus == false) {
			this.shrinkSearch();
		}
	},
	
	gotFocus : function()
	{
		this.hasfocus = true;
		this.growSearch();
	},
	
	lostFocus : function()
	{
		this.hasfocus = false;
		if (this.overbutton == false) {
			this.shrinkSearch();
		}
	},
	
	growSearch : function()
	{
		this.trigger.style.width = '300px';
		this.button.show();
	},
	
	shrinkSearch : function()
	{
		this.trigger.style.width = '100px';
		this.button.hide();
	}
	
});

if ($('search-query')) {
	new Search_Collapse('search-query');
}


/*
 *  Provides enrollment detail pop up window
 */
var Enrollment_Details = Class.create({

	backdrop   : null,
	details    : null,
		
	initialize : function(trigger)
	{
		this.attachHandlers(); 
		document.observe('report:refresh', this.attachHandlers.bind(this));
	},
	
	attachHandlers : function()
	{
		$$('a.enrollment-brief').each((function(e){
			var trigger = $(e);
			trigger.observe('click', this.showdetail.bind(this));
		}).bind(this));
	},

	showdetail : function(event)
	{
		if (this.details) {
			this.hidedetails()
		}
		var trigger = event.element();
		this.details = trigger.next();
		this.details.style.position = 'absolute';
		this.details.style.zIndex = 40;
		//var posleft = this.trigger.cumulativeOffset().left - this.details.getWidth() + this.trigger.up().getWidth() - 8;
		var posleft = trigger.up().cumulativeOffset().left + trigger.up().getWidth() - this.details.getWidth() + 1;
		this.details.style.left = posleft+'px';
		this.details.show();
		if (!this.backdrop) {
			this.backdrop = new Fw_Backdrop_Clear();
			this.backdrop.observe('click', this.hidedetails.bind(this));
		}
		this.backdrop.show();
	},
	
	hidedetails : function(transport)
	{
		this.details.hide();
		this.backdrop.hide();
	}
	
});

new Enrollment_Details();

var AjaxWindow = Class.create({

	backdrop   : null,
	box        : null,
	closelink  : null,
	handlers   : null,
	selector   : null,
		
	initialize : function(selector)
	{
		this.selector = selector;
		this.handlers = {
			'requestContent' : this.requestContent.bind(this),
			'hideWindow'     : this.hideWindow.bind(this)
		};
		this.attachHandlers();
		document.observe('report:refresh', this.attachHandlers.bind(this));
	},
	
	attachHandlers : function()
	{
		$$(this.selector).each((function(anchor) {
			anchor.onclick = function(e){ return false; };
			anchor.observe('click', this.handlers.requestContent);
		}).bind(this));
	},
	
	requestContent : function(event)
	{
		Event.stop(event);
		var anchor = event.element();
		var url = anchor.href
		if (url.indexOf('?') > -1) {
			url = url + '&ajax=1';
		} else {
			url = url + '?ajax=1';
		}
		var options = {
			method    : 'get',
			onSuccess : this.handleResponse.bind(this),
			onFailure : this.handleError.bind(this)
		};
		new Ajax.Request(url, options);
	},

	handleResponse : function(transport)
	{
		if (!this.box) {
			this.box = new Fw_Popupbox({topMargin:120});
		}
		this.box.update(transport.responseText);
		this.box.show();
		if (!this.backdrop) {
			this.backdrop = new Fw_Backdrop_Dark();
			this.backdrop.observe('click', this.handlers.hideWindow);
		}
		this.backdrop.show();
		var liner = this.box.down();
		var closelink = Fw_CloseLink(liner);
		closelink.observe('click', this.handlers.hideWindow);
	},
	
	hideWindow : function(event)
	{
		this.box.hide();
		this.backdrop.hide();
	},
	
	handleError : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	}
	
});

Event.observe(window, 'load', function() {
	new AjaxWindow('a.ajax-window');
});




var Report_Parameter_Picker = Class.create({

	basetime  : null,
	fullbox   : null,
	handlers  : null,
	summary   : null,
	picker    : null,
	clicked   : null,
	params    : {},
	refresh   : null,
	reportbox : null,
	
	initialize : function()
	{
		this.fullbox = $('report-pickers');
		this.picker = this.fullbox.down('div.picker');
		this.summary = $('report-title');
		this.handlers = {
			'changeParam'     : this.changeParam.bind(this),
			'externalTrigger' : this.externalTrigger.bind(this),
			'requestPicker'   : this.requestPicker.bind(this),
			'requestReset'   : this.requestReset.bind(this),
			'showMoreOptions' : this.showMoreOptions.bind(this)
		}
		$$('a.report-param-picker').each((function(anchor) {
			anchor.onclick = function(e){ return false; };
			anchor.observe('click', this.handlers.requestPicker);
			if (anchor.getAttribute('paramname')) {
				this.params[anchor.getAttribute('paramname')] = anchor;
			}
		}).bind(this));
		this.observeExternal();
		if ($('report-pickers-close')) {
			$('report-pickers-close').observe('click', this.closePickerWindow.bind(this));
		}
		this.fullbox.select('a.reset').each((function(anchor) {
			anchor.onclick = function(e){ return false; };
			anchor.observe('click', this.handlers.requestReset);
		}).bind(this));
		this.basetime = new Date().getTime() / 1000;
		Event.observe(window, 'load', this.applyHash.bind(this));
		var refreshLink = $('refresh-report');
		if (refreshLink) {
			this.refresh = refreshLink.href;
		} else {
			console.log('Page does not have a id="refresh-report"');
		}
		this.reportbox = $('report-container');
		if (!this.reportbox) {
			console.log('Page does not have a div id="report-container"');
		}
	},
	
	observeExternal : function()
	{
		$$('a.report-extra-picker').each((function(anchor) {
			anchor.onclick = function(e){ return false; };
			anchor.observe('click', this.handlers.externalTrigger);
		}).bind(this));
	},
	
	externalTrigger : function(event)
	{
		this.timeout();
		var anchor = event.element();
		var target = anchor.getAttribute('activates');
		if (target && typeof this.params[target] !== "undefined") {
			this.clicked = this.params[target];
			var options = {
				method    : 'get',
				onSuccess : this.showPicker.bind(this),
				onFailure : this.showError.bind(this)
			};
			new Ajax.Request(this.params[target].href, options);
		}
	},
	
	requestPicker : function(event)
	{
		this.timeout();
		this.clicked = event.element();
		var options = {
			method    : 'get',
			onSuccess : this.showPicker.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(event.element().href, options);
	},
	
	requestReset : function(event)
	{
		this.timeout();
		this.clicked = event.element();
		if (typeof this.params['curriculum'] !== "undefined") {
			this.clicked = this.params['curriculum'];
		}
		var options = {
			method    : 'get',
			onSuccess : this.updateAll.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(event.element().href, options);
	},
	
	showPicker : function(transport)
	{
		this.fullbox.show();
		this.fullbox.select('div.sections li').each((function(item) {
			item.removeClassName('selected');
		}).bind(this));
		this.clicked.up().addClassName('selected');
		this.picker.update(transport.responseText);
		this.setPickerHeight();
		this.picker.select('a').each((function(anchor) {
			anchor.onclick = function(e){ return false; };
			if (anchor.hasClassName('show-more')) {
				anchor.observe('click', this.handlers.showMoreOptions);
			} else {
				anchor.observe('click', this.handlers.changeParam);
			}
		}).bind(this));
	},
	
	closePickerWindow : function()
	{
		this.fullbox.hide();
	},
	
	changeParam : function(event)
	{
		this.timeout();
		var options = {
			method    : 'get',
			onSuccess : this.updateAll.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(event.element().href, options);
	},
	
	updateAll : function(transport)
	{
		this.timeout();
		this.showPicker(transport);
		var options = {
			method    : 'get',
			onSuccess : this.refreshReport.bind(this),
			onFailure : this.showError.bind(this)
		};
		new Ajax.Request(this.refresh, options);
	},
	
	refreshReport : function(transport)
	{
		this.reportbox.update(transport.responseText);
		var refresh = this.reportbox.down('div.summary-refresh');
		if (refresh && refresh.innerHTML) {
			this.summary.update(refresh.innerHTML);
			refresh.remove();
			this.observeExternal();
		}
		var refresh = this.reportbox.down('div.title-refresh');
		if (refresh && refresh.innerHTML) {
			document.title = refresh.innerHTML;
			refresh.remove();
		}
		var refresh = this.reportbox.down('div.url-refresh');
		if (refresh) {
			window.location.assign('#'+refresh.innerHTML);
			refresh.remove();
		}
		document.fire('report:refresh', this);
	},
	
	showMoreOptions : function(event)
	{
		var anchor = event.element();
		var list = anchor.up().up();
		list.select('a.more').each(function(e){
			e.toggle();
		});
		if (anchor.hasClassName('less')) {
			anchor.removeClassName('less');
			anchor.update('more');
		} else {
			anchor.addClassName('less');
			anchor.update('less');
		}
		this.setPickerHeight();
	},
	
	applyHash : function()
	{
		var hash = window.location.hash;
		if (hash && hash != '#tour') {
			var url = this.refresh + '&hash=' + encodeURIComponent(hash);
			var options = {
				method    : 'get',
				onSuccess : this.refreshReport.bind(this),
				onFailure : this.showError.bind(this)
			};
			new Ajax.Request(url, options);
		}
	},
	
	setPickerHeight : function()
	{
		this.picker.setStyle({height : 'auto'});
		if (this.picker.getHeight() < (this.fullbox.getHeight() - 40)) {
			this.picker.setStyle({height : (this.fullbox.getHeight() - 40) + 'px'});
		}
	},
	
	showError : function(transport)
	{
		var m = new Fw_AppMessage();
		m.error(transport.responseText);	
	},
	
	timeout : function()
	{
		var now = new Date().getTime() / 1000;
		// pubcookie hard inactive timeout is 30 minutes
		if ((now - this.basetime) > 1200) {
			location.reload(true);
		}
	}
	
});

if ($('report-pickers')) {
	new Report_Parameter_Picker();
}

var Toggle_Elements = Class.create({
	
	triggerClass   : null,
	
	initialize : function(triggerClass)
	{
		this.triggerClass = triggerClass;
		document.observe('report:refresh', this.attachListeners.bind(this));
		this.attachListeners();	
		
	},

	attachListeners : function(event) {
		var thisObject = this;
		$$(this.triggerClass).each(function(element) {
			element.href = 'javascript:void(0);';
			element.observe('click', thisObject.toggleElement.bind(thisObject));
		});
	},

	toggleElement : function(event) 
	{
		var elementClicked = event.findElement(this.triggerClass);
		$(elementClicked.readAttribute('data-target')).toggle();
	},
	
});

new Toggle_Elements('a.toggle-element');
