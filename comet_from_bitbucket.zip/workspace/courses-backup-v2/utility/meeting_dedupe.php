<?php
/**
 * @package UW_COE_Courses
 */
/**
 * A bug caused us to get extra meeting records. This script finds the
 * duplicates and removes them.
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();

$db->query('DELETE FROM meeting WHERE start IS NULL AND end IS NULL AND (dows IS NULL OR dows = \'\')');

$db->query('DELETE FROM t_meetingdupe');

for ($n = 1; $n <= 3; ++$n) {
	$sql = 'INSERT INTO t_meetingdupe '
	     . 'SELECT offeringid, meetingnumber, count(offeringid) '
	     . 'FROM meeting '
	     . 'WHERE meetingnumber = '.$n.' '
	     . 'GROUP BY offeringid, meetingnumber';
	$db->query($sql);
}

$db->query('DELETE FROM t_meetingdupe WHERE quantity = 1');

$todo = $db->fetchAssoc('SELECT * FROM t_meetingdupe ORDER BY offeringid');

foreach ($todo as $row) {
	$meetings = Db_Meeting::FetchMultiple('offeringid = '.$row['offeringid'].' AND meetingnumber = '.$row['meetingnumber']);
	$goodone = null;
	$badones = array();
	foreach ($meetings as $meeting) {
		if ($meeting->building && is_null($goodone)) {
			$goodone = $meeting;
		} else {
			$badones[] = $meeting;
		}
	}
	if ($goodone) {
		// have a meeting with a building so we can delete whole badone list
		echo '*** Found a keeper meetingid '.$goodone->meetingid.' for offeringid '.$goodone->offeringid.' start:'.$goodone->start.' building:'.$goodone->building."\n";
		$i = 0;
	} else {
		echo ':-/ No meetings have buildings for offeringid '.$row['offeringid'].", just keeping first one\n";
		// none of the meetings have a building, so just keept the first one
		$i = 1;
	}
	while ($i < count($badones)) {
		echo '  Deleting meetingid '.$badones[$i]->meetingid.' for offeringid '.$badones[$i]->offeringid.' start:'.$badones[$i]->start.' building:'.$badones[$i]->building."\n";
		$badones[$i]->delete();
		++$i;
	}
}
