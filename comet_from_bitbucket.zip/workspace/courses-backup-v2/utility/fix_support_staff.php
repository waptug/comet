<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Set support staff flag on person record and remove from primary instuctor
 * slot.
 */

require __DIR__.'/utility-setup.php';


$supportids = array(
	1284,
	1279,
	1210,
	1211,
	1248,
	1206,
	1234,
	1260,
	1259,
);

$db = DbFactory::GetConnection();

foreach ($supportids as $personid) {
	$person = new Db_Person($personid);
	echo 'Updating '.eFirstLast($person).PHP_EOL;
	$person->issupport = true;
	$person->save();
	$db->query('UPDATE staff SET timesched = 0, role = \'support\' WHERE personid = '.$personid);
}