<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Shared setup routines for utility script run from console command line
 * @author hanisko
 */

// Default PHP save path not accessible to regular users
session_save_path('/tmp');
// by pass authorization for utility shell script
$fw_noauth = true; 
// run the normal set up script
require __DIR__.'/../inc/initialize.php';
