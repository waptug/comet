<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Go through staff records with role = 'instructor' and try to update
 * to 'faculty' or 'adjunct' based on flags set on the related person
 * record.
 *  
 */

require __DIR__.'/utility-setup.php';

$todo = Db_Staff::FetchMultiple("role = 'instructor'");

foreach ($todo as $staff) {
	if ($staff->person->isfaculty) {
		$staff->role = 'faculty';
		$staff->save();
	} elseif ($staff->person->isadjunct) {
		$staff->role = 'adjunct';
		$staff->save();
	}
}
