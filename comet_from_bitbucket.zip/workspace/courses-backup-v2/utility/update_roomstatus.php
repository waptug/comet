<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Walks through every offering record and recalculates the best value for
 * roomstatus based on offering properties.
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();

$todo = $db->fetchColumn('SELECT offeringid FROM offering ORDER BY year, quarter, courseid');

foreach ($todo as $offeringid) {
	$offering = new Db_Offering($offeringid);
	$offering->calculateRoomStatus();
	$offering->save();
	echo '- '.$offering->offeringid.' roomstatus = '.$offering->roomstatus.PHP_EOL;
}