<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Connects to the SWS course resources and updates local cache data with course
 * information as represented in the UW Time Schedule(UWTS). This is only necessary when database
 * structure related to the Db_Course entity changes and new data needs to be populated
 *
 * At launch, this script will be run manually by a system administrator.
 *
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$update = new \Update\Process\SwsCourseOnly();
$update->addLogger(new Logger_File('/www/courses/logs/general_education_updater.log'));
$update->addLogger(new Logger_Stdout());
$update->run();