<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Locates all course offerings with wildcard titles and reassigns
 * them to the basic no wildcard version of the course.
 * 
 * Should be a one-time script after wildcard data got scrambled during
 * an import.
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();

$todolist = $db->fetchColumn('SELECT courseid FROM course WHERE wildcardtitle IS NOT NULL');

foreach ($todolist as $courseid) {
	$course = new Db_Course($courseid);
	// locate main course
	$filters = array(
		'wildcardtitle IS NULL',
		'curriculum = '.$db->quote($course->curriculum),
		'courseno = '.$course->courseno
	);
	$samecourseno = Db_Course::FetchMultiple($filters);
	if (count($samecourseno)) {
		// if we found a course with a NULL wildcard title that becomes the master course
		// set all of the offerings with current courseid to the master course courseid
		$db->query('UPDATE offering SET courseid = '.$samecourseno[0]->courseid.' WHERE courseid = '.$courseid);
		echo $course->curriculum.' '.$course->courseno.' '.$course->wildcardtitle.' use courseid '.$samecourseno[0]->courseid."\n";
		echo '    UPDATE offering SET courseid = '.$samecourseno[0]->courseid.' WHERE courseid = '.$courseid.";\n";
	} else {
		// otherwise erase this wildcard title and let this become the master course 
		$course->wildcardtitle = null;
		$course->save();
		echo '** '.$course->curriculum.' '.$course->courseno.' ('.$course->courseid.") - made this record the master course\n";
	}
}