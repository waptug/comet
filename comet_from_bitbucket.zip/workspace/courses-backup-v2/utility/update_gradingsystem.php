<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Gather course offering grading system values from the UW Student Web
 * Service course section resource.
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();

$sql = 'SELECT o.offeringid, o.year, o.quarter, o.section, c.courseid, c.curriculum, c.courseno '
     . 'FROM offering o '
     . 'INNER JOIN course c '
     . 'ON o.courseid = c.courseid '
     . 'WHERE o.gradingsystem IS NULL';

$todo = $db->fetchAssoc($sql);

$this_quarter = Db_Quarter::GetQuarter();

// Check web service for section types

foreach ($todo as $row) {
	echo $row['year'].' '.$row['quarter'].' '.$row['curriculum'].' '.$row['courseno'].' '.$row['section'].' ';
	if ($row['year'] > $this_quarter->year || ($row['year'] == $this_quarter->year && $row['quarter'] > $this_quarter->quarter)) {
		echo "skipped future quarter\n";
		continue;
	}
	$sws = new RestClient_CourseSection($row['year'], $row['quarter'], $row['curriculum'], $row['courseno'], $row['section']);
	usleep(250000);
	if ($sws->recordExists()) {
		$offering = new Db_Offering($row['offeringid']);
		echo $sws->gradingsystem.' ';
		if ($sws->gradingsystem == 'credit/no credit') {	
			$offering->gradingsystem = 5;
		} else {
			$offering->gradingsystem = 1;
		}
		$offering->save();
		echo ' - Set to '.$offering->gradingsystem."\n";
	} else {
		echo "Not found\n";
	}
}

// Guess section types based on previous sections

echo "\n\n=========================================================================\n";
echo "Search previous offerings\n";
echo "=========================================================================\n\n";
$todo = $db->fetchAssoc($sql);

foreach ($todo as $row) {
	echo $row['year'].' '.$row['quarter'].' '.$row['curriculum'].' '.$row['courseno'].' '.$row['section'].' ';
	$sql = 'SELECT gradingsystem FROM offering WHERE courseid = '.$row['courseid'].' AND gradingsystem IS NOT NULL ORDER BY offeringid DESC LIMIT 0,1';
	$gs = $db->fetchOne($sql);
	if ($gs) {
		$offering = new Db_Offering($row['offeringid']);
		$offering->gradingsystem = $gs;
		$offering->save();
		echo ' - Set to '.$offering->gradingsystem."\n";
	} else {
		echo "Not found\n";
	}
}