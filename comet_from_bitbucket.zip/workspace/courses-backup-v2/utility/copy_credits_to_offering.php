<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Run once maintenance routine for adding offering specific credits
 * information. By default, copy the values from the parent course
 * record.
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';


$db = DbFactory::GetConnection();

$todo = $db->fetchColumn('SELECT offeringid FROM offering ORDER BY year, quarter, courseid');

foreach ($todo as $offeringid) {
	$offering = new Db_Offering($offeringid);
	$offering->creditcontrol = $offering->course->coursecreditcontrol;
	$offering->creditmin = $offering->course->coursecreditmin;
	$offering->creditmax = $offering->course->coursecreditmax;
	$offering->save();
	echo '- '.$offering->offeringid.' = '.$offering->creditcontrol.' '.$offering->creditmin.' '.$offering->creditmax.' '.PHP_EOL;
}
