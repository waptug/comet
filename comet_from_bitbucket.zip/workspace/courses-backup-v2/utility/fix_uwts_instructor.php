<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Go through system by offering/meeting and make sure that one
 * and only one instructor is designated as the primary instructor
 * listed in UW time schedule.
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();

$todo = $db->fetchAssoc('SELECT DISTINCT offeringid, meetingnumber FROM staff');

foreach ($todo as $row) {
	
	$sql = 'SELECT s.staffid, s.timesched '
	     . 'FROM staff s '
	     . 'INNER JOIN person p '
	     . 'ON s.personid = p.personid '
	     . 'WHERE s.offeringid = '.$row['offeringid'].' '
	     . 'AND s.meetingnumber = '.$row['meetingnumber'].' '
	     . "AND s.role IN('faculty', 'adjunct', 'instructor')"
	     . 'AND p.issupport <> 1';
	$results = $db->fetchPairs($sql);
	$staffid = false;
	$hasuwts = false;
	foreach ($results as $staffid => $timesched) {
		if ($timesched) {
			$hasuwts = true;
			break;
		}
	}
	if (!$hasuwts && $staffid) {
		$db->query('UPDATE staff SET timesched = 1 WHERE staffid = '.$staffid);
	}
	
}