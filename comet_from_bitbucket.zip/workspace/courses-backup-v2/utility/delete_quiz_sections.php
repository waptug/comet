<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Delete quiz sections and child records from database
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();

// test cases, single meeting on a single day, multiple days, true multiple meetings with distinct start/end times
//$todo = array(1639, 1673, 4053);
$todo = $db->fetchColumn('SELECT offeringid FROM offering WHERE sectiontype = \'QZ\'');

foreach ($todo as $offeringid) {
	
	$plan = new Db_Offering($offeringid);
	$plan->delete();
	
}