<?php
/**
 * Import person data from a CSV data file.
 */

require __DIR__.'/utility-setup.php';
$importdir = __DIR__.'/../uploads/import';

// set verbose = true here or with -v on command line to see
// detailed progress
$verbose = false;
$datestring = false;

// Check for command line arguments
$arg = (bool) count($argv);
while ($arg !== false) {
	$arg = next($argv);
	switch ($arg) {
    	case '-d':
			$datestring = next($argv);
			break;
    	case '-v':
    		$verbose = true;
			break;
		default:
			break;
	}
}

// If a load date was not provided use today's date
if (!$datestring) {
	$datestring = date('Ymd');
}

$filename = $importdir .'/offering_credits_'. $datestring .'.csv';

$importer = new Importer_Credits($filename);
$importer->saveAll();

echo 'Complete.'.PHP_EOL;

/*
// Testing mode
echo "Processing course data from $filename\n";
while ($importer->readRecord()) {
	if ($importer->offering)
		echo $importer->offering->offeringid.' '.$importer->offering->creditcontrol.' '.$importer->offering->creditmin.' '.$importer->offering->creditmax.PHP_EOL;
	else 
		echo $importer->offeringid.' not found'.PHP_EOL;
}
*/

