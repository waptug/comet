<?php
/**
 * Test the first and last name parser
 */

require __DIR__.'/utility-setup.php';

// set verbose = true here or with -v on command line to see
// detailed progress
$verbose = false;
$datestring = false;

// Check for command line arguments
$arg = (bool) count($argv);
while ($arg !== false) {
	$arg = next($argv);
	switch ($arg) {
    	case '-d':
			$datestring = next($argv);
			break;
    	case '-v':
    		$verbose = true;
			break;
		default:
			break;
	}
}

// If a load date was not provided use today's date
if (!$datestring) {
	$datestring = date('Ymd');
}

$first = new Parser_FirstOnly();
$last = new Parser_LastOnly();
$filename = $importdir .'/'. $datestring .'_persons.csv';
$datareader = new DataReader_Commadelimited($filename);

//print_r($record);
//exit;

$record = $datareader->next();
while ($record) {
	echo $record[2];
	echo ' - ';
	echo $first->getValue($record[2]);
	echo ' - ';
	echo $last->getValue($record[2]);
	echo "\n";
	$record = $datareader->next();
}
