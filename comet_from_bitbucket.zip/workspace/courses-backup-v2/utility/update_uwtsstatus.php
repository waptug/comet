<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Walks through every offering record and recalculates the best value for
 * uwtsstatus based on differences between plan and uwts fields.
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();

$todo = $db->fetchColumn('SELECT offeringid FROM offering ORDER BY year, quarter, courseid');

$updater = new \Update\Offering\FromUwts();

foreach ($todo as $offeringid) {
	$offering = new Db_Offering($offeringid);
	if ($offering->uwts) {
		$updater->update($offering->uwts, $offering);
	}
	echo '- '.$offering->offeringid.' uwtsstatus = '.$offering->uwtsstatus.PHP_EOL;
}