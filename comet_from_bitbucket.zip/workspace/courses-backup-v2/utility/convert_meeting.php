<?php
/**
 * Convert meeting table structure to new format. Changed 3/6/2012 on development
 * @package UW_COE_Courses
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();

// test cases, single meeting on a single day, multiple days, true multiple meetings with distinct start/end times
//$todo = array(1639, 1673, 4053);
$todo = $db->fetchColumn('SELECT DISTINCT offeringid FROM meeting_old ORDER BY offeringid');

foreach ($todo as $offeringid) {
	
	// Get data from old table
	$sql = 'SELECT * FROM meeting_old WHERE offeringid = '.$offeringid.' ORDER BY dow, start, end';
	$results = $db->fetchAssoc($sql);
	$data = array();
	$meetingnumber = 0;
	
	// organize it into meeting structure
	foreach ($results as $row) {
		$index = $row['start'].'-'.$row['end'];
		if (!array_key_exists($index, $data)) {
			$data[$index] = array(
				'offeringid' => $row['offeringid'],
				'meetingnum' => ++$meetingnumber,
				'start'      => $row['start'],
				'end'        => $row['end'],
				'daylist'    => array()
			);
		}
		$data[$index]['daylist'][] = $row['dow'];
	}
	
	// save data back by meeting
	foreach ($data as $mtgfields) {
		$meeting = new Db_Meeting(0);
		$meeting->offeringid = $mtgfields['offeringid'];
		$meeting->meetingnumber = $mtgfields['meetingnum'];
		$meeting->start = $mtgfields['start'];
		$meeting->end = $mtgfields['end'];
		$meeting->daylist = $mtgfields['daylist'];
		$meeting->save();
	}
	
}