<?php
require __DIR__.'/utility-setup.php';

$db = \DbFactory::GetConnection();
$sql = "SELECT me.meetingid as meetingid, og.offeringid as offeringid, og.year as `year`,og.quarter as quarter,co.curriculum as curriculum, co.courseno as courseno, og.meetingsummary as meetingsummary FROM course co inner join offering og on og.courseid=co.courseid inner join meeting me on og.offeringid=me.offeringid WHERE (og.year=2014 AND og.quarter=4) OR (og.year>=2015) ORDER BY og.offeringid";
$results = $db->fetchAssoc($sql);
foreach ($results as $row) {
    if(!isset($current_offering)) {
        $current_offering = new Db_Offering($row['offeringid']);
        $meetings = new \Offering\Components\Meetings($current_offering);
        $offering_meeting_summary = (isset($row['meetingsummary']) && $row['meetingsummary']!=null ? $row['meetingsummary'] : "");

    } 
    elseif($row['offeringid']!=$current_offering->offeringid) {
        if($meetings->getMeetingSummary()!=$offering_meeting_summary) {
            echo $current_offering->offeringid."   ";
            echo $meetings->getMeetingSummary()."   ";
            echo $offering_meeting_summary."   ";
            echo "MISS!\n";
        }
        unset($current_offering);
        unset($meetings);
        unset($offering_meeting_summary);
        $current_offering = new Db_Offering($row['offeringid']);
        $meetings = new \Offering\Components\Meetings($current_offering);
        $offering_meeting_summary = (isset($row['meetingsummary']) && $row['meetingsummary']!=null ? $row['meetingsummary'] : "");
    }
    $meetings->addMeeting(new Db_Meeting($row['meetingid']));

}

unset($current_offering);
unset($meetings);
unset($offering_meeting_summary);
