<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Walks through every offering record and recalculates the value of
 * jointsummary field
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();

$todo = $db->fetchColumn('SELECT offeringid FROM offering ORDER BY year, quarter, courseid');

foreach ($todo as $offeringid) {
	$offering = new Db_Offering($offeringid);
	$offering->jointsummary = $offering->joint->getSummary();
	$offering->save();
	echo '- '.$offering->offeringid.' jointsummary = '.$offering->jointsummary.PHP_EOL;
}