<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Calculates an average credit hours awarded to a single student for
 * variable credit classes. This value is used to estimate SCH for 
 * offerings based on this estimate * enrollment.
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$verbose = false;

$db = DbFactory::GetConnection();

$todo = $db->fetchColumn("SELECT courseid FROM course WHERE creditcontrol <> 'fixed'");

// select offerings of this course than have enrollment and sch data
$sql = 'SELECT enrollmentcurrent, studentcredithours '
     . 'FROM offering '
     . 'WHERE enrollmentcurrent > 0 '
     . 'AND studentcredithours > 0 '
     . 'AND courseid = ';

$testrows = 40;
$testcount = 0;

foreach ($todo as $courseid) {
	$course = new Db_Course($courseid);
	if ($verbose) echo $course->getSummaryName().PHP_EOL;
	$actuals = $db->fetchAssoc($sql.$courseid);
	if (!$actuals) {
		// dont bother dividing by zero if there are no offerings for this course
		if ($verbose) echo '  no offerings for this course with actual enrollment/sch'.PHP_EOL;
		continue;
	}
	$count = 0;
	$total = 0;
	foreach ($actuals as $actual) {
		$mean = (int)($actual['studentcredithours'] / $actual['enrollmentcurrent']);
		$total = $total + $mean;
		++$count;
		if ($verbose) echo '  '.$mean.' = '.$actual['studentcredithours'].' / '.$actual['enrollmentcurrent'].PHP_EOL;
	}
	$course->creditestimate = (int)($total / $count);
	$course->save();
	if ($verbose) {
		echo '  -------------------------------------'.PHP_EOL
		   . '  '.$course->creditestimate.' = '.$total.' / '.$count.PHP_EOL
		   . '  -------------------------------------'.PHP_EOL;
	}
	//if (++$testcount > $testrows) break;
}

echo 'Complete.'.PHP_EOL;