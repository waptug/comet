<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Connects to the SWS course resources and updates local cache data with course 
 * information as represented in the UW Time Schedule(UWTS). This quarterly 
 * maintenance routine updates data for historical course offerings. 
 * 
 * At launch, this script will be run manually by a system administrator.
 * 
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

// Set up debug output to standard output
$GLOBALS['UWTS_SHOW_DEBUG_OUTPUT'] = true;
if (array_key_exists('UWTS_SHOW_DEBUG_OUTPUT', $GLOBALS) && $GLOBALS['UWTS_SHOW_DEBUG_OUTPUT'] === true) {
	$main_show_debug = true;
	$main_debug_section = PHP_EOL.PHP_EOL.'**************************************************************************'.PHP_EOL;
}

if ($main_show_debug) echo $main_debug_section.'** CANCEL HISTORICAL PLAN RECORDS THAT ARE NOT IN UWTS'.PHP_EOL;
if ($main_show_debug) echo '. Try 2012-3'.PHP_EOL;
Db_Offering::CancelNotInUwts('2012', 3);
if ($main_show_debug) echo '. Try 2012-4'.PHP_EOL;
Db_Offering::CancelNotInUwts('2012', 4);
if ($main_show_debug) echo '. Try 2013-1'.PHP_EOL;
Db_Offering::CancelNotInUwts('2013', 1);
if ($main_show_debug) echo '. Try 2013-2'.PHP_EOL;
Db_Offering::CancelNotInUwts('2013', 2);