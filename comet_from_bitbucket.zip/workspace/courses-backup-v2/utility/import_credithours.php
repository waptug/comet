<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Import student credit hour data from a CSV data file.
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';
$importdir = __DIR__.'/../uploads/import';

// set verbose = true here or with -v on command line to see
// detailed progress
$verbose = false;
$datestring = false;

// Check for command line arguments
$arg = (bool) count($argv);
while ($arg !== false) {
	$arg = next($argv);
	switch ($arg) {
    	case '-d':
			$datestring = next($argv);
			break;
    	case '-v':
    		$verbose = true;
			break;
		default:
			break;
	}
}

// If a load date was not provided use today's date
if (!$datestring) {
	$datestring = date('Ymd');
}

$filename = $importdir .'/sch_'. $datestring .'.csv';

if (!is_readable($filename)) {
	echo 'Cannot access '.$filename.PHP_EOL;
	exit;
}

// Just do it mode
echo "Processing student credit hour data from $filename\n";
$importer = new Importer_CreditHours($filename);
$importer->saveAll();

echo "Done.\n";
