<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Go through person records marked as 'faculty' or 'adjunct' and insure they 
 * are system users.
 */

require __DIR__.'/utility-setup.php';

$todo = Db_Person::FetchMultiple("isfaculty = 1 OR isadjunct = 1");

foreach ($todo as $person) {
	$person->saveUser();
}
