<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Connects to the SWS course resources and updates local cache data with course
 * information as represented in the UW Time Schedule(UWTS). This quarterly
 * maintenance routine updates data for historical course offerings.
 *
 * At launch, this script will be run manually by a system administrator.
 *
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$update = new \Update\Process\SwsQuarterly();
$update->addLogger(new Logger_File('/www/courses/logs/updater.log'));
$update->addLogger(new Logger_Stdout());
$update->run();