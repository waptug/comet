<?php
/**
 * Loop through all course offering records and recalculate the
 * meeting summary string based on the existing meeting records.
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();

$todolist = $db->fetchColumn('SELECT offeringid FROM offering');

foreach ($todolist as $offeringid) {
	$offering = new Db_Offering($offeringid);
	$offering->meetingsummary = $offering->getMeetingSummary();
	$offering->save();
}