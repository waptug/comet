<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Deduplicate the person records.
 */

require __DIR__.'/utility-setup.php';

$keep_personid = false;
$merge_personids = array();
$commit = false;

$arg = true;
while ($arg !== false) {
	$arg = next($argv);
	if ($arg == '--commit') {
		$commit = true;
	} elseif (!$keep_personid) {
		$keep_personid = (int)$arg;
	} else {
		$int = (int)$arg;
		if ($int) $merge_personids[] = (int)$arg;
	}
}

if (!$keep_personid || count($merge_personids) == 0) {
	script_show_help();
	exit;
}

$keep = new Db_Person($keep_personid);

if (!$keep->recordExists()) {
	echo 'keep_personid '.$keep_personid.' is not a known personid'.PHP_EOL;
	exit;
}

if (!$commit) {
	echo 'Following person records'.PHP_EOL;
	foreach ($merge_personids as $personid) {
		$merge = new Db_Person($personid);
		if ($merge->recordExists()) {
			$identifiers = array(
				$merge->firstname,
				$merge->lastname,
				$merge->uwnetid,
				$merge->ein,
				$merge->regid
			);
			echo '  ('.$personid.') '.implode(' ',$identifiers).PHP_EOL;
		} else {
			echo '  ('.$personid.') no Person record found in system'.PHP_EOL;
		}
	}
	echo 'Will be merged into'.PHP_EOL;
	$identifiers = array(
		$keep->firstname,
		$keep->lastname,
		$keep->uwnetid,
		$keep->ein,
		$keep->regid
	);
	echo '  ('.$keep->personid.') '.implode(' ',$identifiers).PHP_EOL;
	echo PHP_EOL.'Run the following php command to commit this merge'.PHP_EOL;
	echo '  php -f '.$_SERVER['SCRIPT_NAME'].' -- '.$keep_personid.' '.implode(' ',$merge_personids).' --commit'.PHP_EOL;
	exit;
}

$person_properties = array(
	'lastname',
	'uwnetid',
	'ein',
	'regid',
	'email',
	'phone',
	'area',
	'isfaculty',
	'isadjunct',
	'isstudentstaff'
);

$linked_tables = array(
	'staff',
	'personorgunit',
	'uwtsstaff'		
);

$db = DbFactory::GetConnection();

foreach ($merge_personids as $personid) {

	$merge = new Db_Person($personid);
	foreach ($person_properties as $property) {
		if (!$keep->$property && $merge->$property) $keep->$property = $merge->$property;
	}
	// use the shortest not empty firstname to eliminate middle names and initials
	if ($merge->firstname && strlen($merge->firstname) < strlen($keep->firstname)) {
		$keep->firstname = $merge->firstname;
	}
	$keep->save();
	foreach ($linked_tables as $table) {
		$db->query('UPDATE `'.$table.'` SET personid = '.$keep_personid.' WHERE personid = '.$personid);
	}
	// have to dig into JSON values for repetition records
	$sql = 'SELECT repetitionid, staffjson '
	     . 'FROM repetition '
	     . 'WHERE staffjson LIKE \'%"personid":'.$personid.',%\' '
	     . 'OR staffjson LIKE \'%"personid":'.$personid.'}%\'';
	$repetition = $db->fetchPairs($sql);
	foreach ($repetition as $repetitionid => $staffjson) {
		$old = '"personid":'.$personid;
		$new = '"personid":'.$keep_personid;
		$staffjson = str_replace($old.',', $new.',', $staffjson);
		$staffjson = str_replace($old.'}', $new.'}', $staffjson);
		$db->query('UPDATE repetition SET staffjson = '.$db->quote($staffjson).' WHERE repetitionid = '.$repetitionid);
	}
	
	$db->query('DELETE FROM person WHERE personid = '.$personid);
}

echo 'Merge complete.'.PHP_EOL;
exit;

function script_show_help()
{
	echo 'Run this script and specify a personid to keep and one or more personids to merge into the keep record.'.PHP_EOL;
	echo 'php -f '.$_SERVER['SCRIPT_NAME'].' -- KEEP MERGE [MERGE] [MERGE] ...'.PHP_EOL;
	echo 'php -f '.$_SERVER['SCRIPT_NAME'].' -- 1001 1211 1311'.PHP_EOL;
}