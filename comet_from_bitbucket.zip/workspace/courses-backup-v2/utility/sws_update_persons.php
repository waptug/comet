<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Connects to the SWS course resources and updates local person data. This
 * is a one time script for the deployment of the UWTS version of courses 
 * database. After the initial run, person record updates are handled in the 
 * sws_daily_update.php batch script.
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();
$todolist = $db->fetchColumn('SELECT personid FROM person WHERE regid IS NULL');

foreach ($todolist as $personid) {
	$person = new Db_Person($personid);
	$sws = new \Update\Person\FromSws($person);
	$r = $sws->updateEmptyFields();
	if ($r) {
		$person->save();
		echo '+ Set '.View_Person::FirstLast($person).' regid to '.$person->regid.PHP_EOL;
	} else {
		echo 'X '.View_Person::FirstLast($person).' not found in service ('.$person->ein.','.$person->uwnetid.')'.PHP_EOL;
	}
}
