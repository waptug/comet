<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Connects to the SWS course resources and updates local cache data with course 
 * information as represented in the UW Time Schedule(UWTS). This maintenance 
 * routine is scheduled as a local cronjob.
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$update = new \Update\Process\SwsDaily();
$update->addLogger(new Logger_File('/www/courses/logs/updater.log'));
//$update->addLogger(new Logger_Stdout());
if($update->getLock())
    $update->run();
