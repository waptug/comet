<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Go through staff records with role = 'instructor' and try to update
 * to 'faculty' or 'adjunct' based on flags set on the related person
 * record.
 *  
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();

$todo = $db->fetchColumn('SELECT offeringid FROM offering');

foreach ($todo as $offeringid) {
	$offering = new Db_Offering($offeringid);
	$offering->setEnrollmentEstimate($offering->enrollmentestimate);
	$offering->setEnrollmentLimit($offering->enrollmentlimit);
	$offering->save();
}
