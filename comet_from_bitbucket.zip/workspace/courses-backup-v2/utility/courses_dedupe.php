<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Locates all course duplicate course records, moves offerings to the 
 * lowest courseid record and deletes the others.
 * 
 * Should be a one-time script after wildcard data got scrambled during
 * an import.
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();

// change course wildcardtitles with empty string value null
$db->query("UPDATE course SET wildcardtitle = NULL WHERE wildcardtitle = ''");

$sql = 'SELECT curriculum, courseno, count(courseid) AS qty ' 
     . 'FROM course '
     . 'WHERE wildcardtitle IS NULL '
     . 'GROUP BY curriculum, courseno';

$todolist = $db->fetchAssoc($sql);

foreach ($todolist as $row) {
	if ($row['qty'] == 1) continue;
	$courseids = $db->fetchColumn('SELECT courseid FROM course WHERE curriculum = '.$db->quote($row['curriculum']).' AND courseno = '.$row['courseno']);
	echo 'Merging courseids '.implode(',',$courseids).' courses for '.$row['curriculum'].' '.$row['courseno']."\n";
	for ($i = 1; $i < count($courseids); ++$i) {
		$sql = 'UPDATE offering SET courseid = '.$courseids[0].' WHERE courseid = '.$courseids[$i];
		echo "   $sql\n";
		$db->query($sql);
		$sql = 'DELETE FROM course WHERE courseid = '.$courseids[$i];
		echo "   $sql\n";
		$db->query($sql);
	}
}