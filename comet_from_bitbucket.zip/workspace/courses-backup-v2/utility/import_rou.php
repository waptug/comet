<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Import Responsible Organizational Units for courses from a CSV text file
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';
$importdir = __DIR__.'/../uploads/import';

// set verbose = true here or with -v on command line to see
// detailed progress
$verbose = false;
$datestring = false;

// Check for command line arguments
$arg = (bool) count($argv);
while ($arg !== false) {
    $arg = next($argv);
    switch ($arg) {
        case '-d':
            $datestring = next($argv);
            break;
        case '-v':
            $verbose = true;
            break;
        default:
            break;
    }
}

// If a load date was not provided use today's date
if (!$datestring) {
    $datestring = date('Ymd');
}

$filename = $importdir .'/rous_'. $datestring .'.csv';

$importer = new Importer_Rous($filename);
$importer->saveAll();

/*
while ($importer->readRecord()) {
	echo $importer->course->curriculum.' '.$importer->course->courseno.' ';
	echo ' ('.$importer->rou->rouid.') '.$importer->rou->rou_name.' ';
	echo ' ('.$importer->rou->rouid.') '.$importer->rou->approver_personid.' ';
	if ($importer->rouperson) {
		echo ' (staff)'.$importer->rouperson->personid.' ';
	}
	echo PHP_EOL;
}
*/