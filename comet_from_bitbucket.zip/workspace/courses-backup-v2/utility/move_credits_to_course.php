<?php
/**
 * Move the credit fields from the offering table to the course
 * table.
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();

$sql = 'SELECT offeringid, fixedcredits, varcredits '
     . 'FROM offering '
     . 'WHERE varcredits IS NOT NULL '
     . 'OR fixedcredits IS NOT NULL';

$results = $db->fetchAssoc($sql);

foreach ($results as $row) {
	$offering = new Db_Offering($row['offeringid']);
	if ($row['fixedcredits']) {
		$offering->course->creditcontrol = 'fixed';
		$offering->course->creditfixed = $row['fixedcredits'];
		$offering->course->creditmin = null;
		$offering->course->creditmax = null;
	} else {
		$offering->course->creditcontrol = 'variable';
		$offering->course->creditfixed = null;
		if (strpos($row['varcredits'], '-')) {
			$bits = explode('-', $row['varcredits']);
			$offering->course->creditmin = (int) $bits[0];
			$offering->course->creditmax = (int) $bits[1];
		} else {
			$offering->course->creditmax = (int) $row['varcredits'];
		}
		
	}
	/* DEBUG * /
	echo 'IN: '.$row['offeringid'].':'.$row['fixedcredits'].':'.$row['varcredits'];
	echo ' OUT: '.$offering->course->creditcontrol
		.'/'.$offering->course->creditfixed 
		.'/'.$offering->course->creditmin 
		.'/'.$offering->course->creditmax;
	echo "\n";
	*/ 
	$offering->course->save();
}
echo "Complete.\n";