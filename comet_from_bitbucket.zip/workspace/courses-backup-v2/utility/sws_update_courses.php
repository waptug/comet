<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Connects to the SWS course resources and updates local cache data with course 
 * information as represented in the UW Time Schedule(UWTS). This manual update
 * searches for new course records.
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$update = new \Update\Process\Adhoc();
$update->parameters['quarters'] = new \QuarterIterator('ALL',-1);
$update->addJob('courses', '\Update\Course\Job');
$update->addLogger(new Logger_File('/www/courses/logs/updater.log'));
$update->addLogger(new Logger_Stdout());
$update->run();