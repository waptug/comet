<?php
/**
 * Import person data from a CSV data file.
 */

require __DIR__.'/utility-setup.php';

$importdir = '/www/courses/uploads/import';

// set verbose = true here or with -v on command line to see
// detailed progress
$verbose = false;
$datestring = false;

// Check for command line arguments
$arg = (bool) count($argv);
while ($arg !== false) {
	$arg = next($argv);
	switch ($arg) {
    	case '-d':
			$datestring = next($argv);
			break;
    	case '-v':
    		$verbose = true;
			break;
		default:
			break;
	}
}

// If a load date was not provided use today's date
if (!$datestring) {
	$datestring = date('Ymd');
}

$filename = $importdir .'/'. $datestring .'_courses.csv';

// Testing mode
echo "Processing course data from $filename\n";
$importer = new Importer_Courses($filename);
while ($importer->readRecord()) {
	//if ($importer->course->wildcardtitle) {
	echo "==================================================\n";
	echo 'curriculum: '.$importer->course->curriculum."\n";
	echo 'courseno: '.$importer->course->courseno."\n";
	echo 'wildcardtitle: '.$importer->course->wildcardtitle."\n";
	echo 'title: '.$importer->course->title."\n";
	echo 'shorttitle: '.$importer->course->shorttitle."\n";
	echo 'general_education: '.$importer->course->general_education."\n";
	echo "..................................................\n";	
	echo 'year: '.$importer->offering->year."\n";
	echo 'quarter: '.$importer->offering->quarter."\n";
	echo 'section: '.$importer->offering->section."\n";
	echo 'type: '.$importer->offering->type."\n";
	echo 'sln: '.$importer->offering->sln."\n";
	echo 'enrolled: '.$importer->offering->enrolled."\n";
	echo 'credithours: '.$importer->offering->credithours."\n";
	echo "..................................................\n";	
	echo 'days: '.implode('',$importer->meeting->daylist).' '.$importer->meeting->start.' to '.$importer->meeting->end."\n";
	echo 'building: '.$importer->meeting->building."\n";
	echo 'room: '.$importer->meeting->room."\n";
	echo "..................................................\n";
	echo 'instructor ein: '.$importer->instructor."\n";
	//}	
}
// If this is just a test run stop now
exit;


