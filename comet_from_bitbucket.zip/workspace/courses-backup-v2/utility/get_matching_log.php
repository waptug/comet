<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Outputs content of the matching log from database to standard output.
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$all = Db_UwtsMatchingLog::FetchMultiple();

foreach ($all as $log) {
	echo $log->getSummary().PHP_EOL;
}
 