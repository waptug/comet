<?php
/**
 * Test the day of week parser
 */

require __DIR__.'/utility-setup.php';

$parser = new Parser_Title();

$test_values = array(
	'Smnr in Mathematics Education.elementary Emphasis',
	'Content Area ESL Instruction',
	'Discourse in The.Mathematic.Classroom',
	'Multi-ethnic Studies,methods,content,and Materials',
	'Issues & Debates In U.s. Preservice Teacher Education',
	'Teaching The Bilingual-bicultural Student',
	'Foundation Ii:moral &History Contexts for Leaders',
	'Foundations Iii:dynamics of Organizations, Policy',
	'Foundations Iv:fiscal & Legal Contexts for Leaders',
	'Leadership Inquiry Iii:refining&Design &Analysis',
	'Asian Americans And Pacific Islanders In Higher Education',
	'Clsrm Mgmt of Phys,Prob,of Indv Sevr/prof Disabld',
	'Specfc Numberacy:Tech-elem Stdnts with Mild Disab',
	'Researching/assessing The Impact Of International Experiences In Higher Education'
);

foreach ($test_values as $input) {
	$input = strtoupper($input);
	echo "$input = ";
	$out = $parser->getValue($input);
	echo $out."\n";
}