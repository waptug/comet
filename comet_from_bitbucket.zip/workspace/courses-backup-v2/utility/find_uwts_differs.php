<?php
/**
 * @package edu.uw.education.courses
 */
/**
 * Description of find_uwts_differs.php
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$offeringid = 5706;
$plan = new Db_Offering($offeringid);
$uwts = $plan->getUwts();
if (!$uwts) {
    echo 'x offeringid '.$offeringid.' does not have a matching UWTS record'.PHP_EOL;
    exit;
}

$updater = new Update\Offering\FromUwts();

// Update readonly fields
$updater->updateReadOnly($uwts, $plan);

// Find differences
$diffs = $updater->getDiffFields($uwts, $plan);
echo count($diffs).' differences'.PHP_EOL;
echo implode(', ', $diffs).PHP_EOL;
