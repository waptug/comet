<?php
/**
 * Go through staff records with role = 'instructor' and try to update
 * to 'faculty' or 'adjunct' based on flags set on the related person
 * record.
 *  
 */

require __DIR__.'/utility-setup.php';

// defaults for command line arguments
$verbose = false;
$confirmed = false;

// Check for command line arguments
$arg = (bool) count($argv);
while ($arg !== false) {
	$arg = next($argv);
	switch ($arg) {
    	case '--confirm':
			$confirmed = true;
			break;
    	case '-v':
    		$verbose = true;
			break;
		default:
			break;
	}
}

if (!$confirmed) {
	echo "You are about to delete all the historical course offering records. Is that really what you want to do?\n";
	echo "Run this script again with a --confirm flag if you are sure.\n";
	exit(1);
}

$todo = Db_Offering::FetchMultiple("status = 'historical'");

foreach ($todo as $offering) {
	$offering->delete();
}

DbFactory::GetConnection()->query('DELETE FROM course WHERE courseid NOT IN (SELECT DISTINCT courseid FROM offering)');
DbFactory::GetConnection()->query('DELETE FROM offeringrule WHERE courseid NOT IN (SELECT courseid FROM course)');