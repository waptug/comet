<?php
/**
 * Copy workflow entries to log
 */

require __DIR__.'/utility-setup.php';

$db = DbFactory::GetConnection();
$sql = 'SELECT steptype, completed, completedby, offeringid FROM workflowstep WHERE completed IS NOT NULL';

$results = $db->fetchAssoc($sql);

foreach ($results as $row) {
	$log = new Db_ActivityLog_Entered(0);
	$log->uwnetid = $row['completedby'];
	$log->entered = $row['completed'];
	$log->action = $row['steptype'];
	if ($row['offeringid'] == 0) continue;
	$log->offeringid = $row['offeringid'];
	$log->save();
}

$db->query('delete from activitylog where offeringid = 0');