<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Go through staff records with role = 'instructor' and try to update
 * to 'faculty' or 'adjunct' based on flags set on the related person
 * record.
 *  
 */

require __DIR__.'/utility-setup.php';

$offeringid = 5383;

$plan = new Db_Offering($offeringid);

echo 'Updating offeringid '.$offeringid.' - '.$plan->getSummaryName().PHP_EOL;

$uwts = Db_UwtsOffering::FetchBySection($plan->year, $plan->quarter, $plan->curriculum, $plan->courseno, $plan->section);

if ($uwts->recordExists()) {
	echo 'Updating uwtsoffering '.$uwts->uwtsofferingid.PHP_EOL;
} else {
	echo 'New uwtsoffering cache record'.PHP_EOL;
}

$sws = new \Update\Uwts\FromSws($uwts);
$sws->updateAll();
$uwts->save();


echo 'Done'.PHP_EOL;