<?php
/**
 * @package edu.uw.education.courses
 */
/** 
 * Deletes UWTS offering records
 * Cleans up buggy data in UWTS import process where duplicate sequential records
 * are created.
 * @author hanisko
 */

require __DIR__.'/utility-setup.php';

$calledscript = $_SERVER['SCRIPT_NAME'];

// defaults for command line arguments
$confirmed = false;
$todo = array();

// Check for command line arguments
$arg = (bool) count($argv);
while ($arg !== false) {
    $arg = next($argv);
    switch ($arg) {
        case '--confirm':
            $confirmed = true;
            break;
        default:
            $uwtsofferingid = (int) $arg;
            if ($uwtsofferingid) {
                $todo[] = $uwtsofferingid;
            }
            break;
    }
}

if (count($todo) == 0) {
    echoArray(array(
        '',
        'Delete UWTS offering and child records ',
        '---------------------------------------',
        '',
        'Run this script with one or more UWTS offering ids as arguments. Running this script without',
        'the --confirm flag will preview which UWTS offerings will be deleted.',
        '  php -f '.$calledscript.' -- 1234 [2345 3456 ...]',
        '',
    ));
    exit(1);
}

if (!$confirmed) {
    echoArray(array(
        '',
        'Delete UWTS offering and child records ',
        'Running in preview mode. Following ',
        '  php -f '.$calledscript.' -- 1234 [2345 3456 ...]',
        '',
    ));
}

foreach ($todo as $uwtsofferingid) {
    $uwts = new Db_UwtsOffering($uwtsofferingid);
    if (!$uwts->recordExists()) {
        echo 'x '.$uwtsofferingid.' UWTS Offering ID NOT FOUND'.PHP_EOL;
        continue;
    }
    $name = eQuarter($uwts->year, $uwts->quarter).' '.$uwts->curriculum.' '.$uwts->courseno.' '.$uwts->section;
    if ($confirmed) {
        echo 'X '.$name.' [DELETED]'.PHP_EOL;
        $uwts->delete();
    } else {
        echo '* '.$name.PHP_EOL;
    }
}

if (!$confirmed) {
    echoArray(array(
        '',
        'Run this script again with the confirmed flag.',
        '  php -f '.$calledscript.' -- '.implode(' ',$todo).' --confirm',
        '',
    ));
    exit(1);
}

function echoArray($message)
{
    foreach ($message as $line) {
        echo $line.PHP_EOL;
    }
}
