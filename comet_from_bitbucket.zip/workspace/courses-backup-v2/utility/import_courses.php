<?php
/**
 * Import person data from a CSV data file.
 */

require __DIR__.'/utility-setup.php';
$importdir = __DIR__.'/../uploads/import';

// set verbose = true here or with -v on command line to see
// detailed progress
$verbose = false;
$datestring = false;

// Check for command line arguments
$arg = (bool) count($argv);
while ($arg !== false) {
	$arg = next($argv);
	switch ($arg) {
    	case '-d':
			$datestring = next($argv);
			break;
    	case '-v':
    		$verbose = true;
			break;
		default:
			break;
	}
}

// If a load date was not provided use today's date
if (!$datestring) {
	$datestring = date('Ymd');
}

$filename = $importdir .'/'. $datestring .'_courses.csv';

// Testing mode
/*
echo "Processing course data from $filename\n";
$importer = new Importer_Courses($filename);
while ($importer->readRecord()) {
	//if ($importer->course->wildcardtitle) {
	echo "==================================================\n";
	echo 'department: '.$importer->course->department."\n";
	echo 'courseno: '.$importer->course->courseno."\n";
	echo 'wildcardtitle: '.$importer->course->wildcardtitle."\n";
	echo 'title: '.$importer->course->title."\n";
	echo 'shorttitle: '.$importer->course->shorttitle."\n";
	echo 'general_education: '.$importer->course->general_education."\n";
	echo "..................................................\n";	
	echo 'year: '.$importer->offering->year."\n";
	echo 'quarter: '.$importer->offering->quarter."\n";
	echo 'section: '.$importer->offering->section."\n";
	echo 'type: '.$importer->offering->type."\n";
	echo 'sln: '.$importer->offering->sln."\n";
	echo 'enrolled: '.$importer->offering->enrolled."\n";
	echo 'credithours: '.$importer->offering->credithours."\n";
	echo "..................................................\n";	
	foreach ($importer->meetings as $meeting) {
		echo $meeting->dow.': '.$meeting->start.' to '.$meeting->end."\n";
	}
	echo "..................................................\n";
	echo 'instructor ein: '.$importer->instructor."\n";
	//}	
}
// If this is just a test run stop now
exit;
*/

// Just do it mode
echo "Processing course data from $filename\n";
$importer = new Importer_Courses($filename);
$importer->saveAll();

/*
   Clean up Independant study & Practicum staff assignments
   In the Importer all independant & practicum staff are flagged
   not listed in time schedule, because these offerings generally
   list several faculty. 
   
   The routine goes back and finds course offerings of type 'IS' or
   'PR' and when they have only one staff assigned sets them back as
   the UW time schedule listed instructor
*/

echo "Setting single staff on IS/PR as UW timesched instructor\n";

$db = DbFactory::GetConnection();

$todo = $db->fetchColumn("SELECT offeringid FROM offering WHERE sectiontype IN ('IS', 'PR')");

foreach ($todo as $offeringid) {
	$found = $db->fetchOne("SELECT COUNT(personid) AS found FROM staff WHERE offeringid = $offeringid");
	if ($found == 1) {
		$db->query("UPDATE staff SET timesched = 1 WHERE offeringid = $offeringid");
	}
}


/*
	Loops through each course offering and recalculates the meeting 
	summary field.
*/

echo "Updating meeting summary fields\n";

$todolist = $db->fetchColumn('SELECT offeringid FROM offering');

foreach ($todolist as $offeringid) {
	$offering = new Db_Offering($offeringid);
	$offering->meetingsummary = $offering->getMeetingSummary();
	$offering->save();
}


echo "Done.\n";
