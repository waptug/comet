<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Returns the merged application config settings.
 * Merges the arrays found in application_config.php and environment_local.php also check for
 * environment_local.php in an external directory. This allows us to keep server specific
 * configuration in a directory not affected by deployments.
 */

$out = include __DIR__.'/application_config.php';

if (file_exists(__DIR__.'/environment_local.php')) {
    $local = include __DIR__.'/environment_local.php';
    $out = array_replace_recursive($out, $local);
}

if (file_exists('/www/local/courses/config/environment_local.php')) {
    $local = include '/www/local/courses/config/environment_local.php';
    $out = array_replace_recursive($out, $local);
}

return $out;
