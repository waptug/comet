<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Config values in this file will be merged over the configuration in application_config.php
 * and use this to configure your environment.
 *
 * This his is where you should include env specific settings and sensitive information like passwords.
 *
 * ## SAMPLE FILE - DO NOT PUT VALUES HERE ##
 * This file is included in version control, do not add sensitive values
 * Copy this to environment_local.php and put your configurations there.
 */

return array(
    'database' => array(
        'courses' => array(
            'password' => 'AFTER_COPYING_FILE_PUT_PASSWORD_HERE',
        )
    ),
    'ajax' => array(
        'hostname' => 'AFTER_COPYING_FILE_PUT_HTTP_HOSTNAME',
    ),
);