<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Application config settings.
 *
 * Values from environment_local.php will be merged over these settings. This allows you to keep any
 * sensitive data (eg. passwords) in a separate file that is not checked into version control.
 */

$basedir = realpath(__DIR__.'/..');

return array(
    'database' => array(
        'courses' => array(
            'type'     => 'pdo_mysql',
            'host'     => '127.0.0.1',
            'username' => 'root',
            'password' => 'SET_IN_ENVIRONMENT_LOCAL_PHP',
            'dbname'   => 'coursestest',
        )
    ),
    'uwnetid_lookup' => array(
        'url' => 'http://orestes.education.washington.edu/services/netid_lookup/0.1/'
    ),
    'faculty_directory' => array(
        'url' => 'http://orestes.education.washington.edu/services/directory/0.1/'
    ),
    'logging' => array(
        'dir' => $basedir.'/logs',
    ),
    'attachment' => array(
        'syllabus_path' => '/var/www/html/backup/uploads/courses/syllabus'
    ),
    'sws' => array(
        'url'      => 'https://ws.admin.washington.edu/student/v5/',
        'authcert' => $basedir.'/etc/pki/tls/certs/dev-comet-sws-access.socialwork.uw.edu.crt',
        'keyfile'  => $basedir.'/etc/pki/tls/certs/dev-comet-sws-access.socialwork.uw.edu.key',
    )/*,
    'ajax' => array(
        'hostname' => 'SET_IN_ENVIRONMENT_LOCAL_PHP',
    ),
    'paths' => array(
        'base'        => $basedir,
        'controllers' => $basedir.'/controllers',
        'views'       => $basedir.'/app/views'
    ),
    'person' => array(
        'url'      => 'https://ws.admin.washington.edu/student/v5/',
        'authcert' => $basedir.'/ssl/elektra/signed.pem',
        'keyfile'  => $basedir.'/ssl/elektra/private.pem',
    ),
    'coe_directory_url' => 'http://orestes.education.washington.edu/services/'*/
);
