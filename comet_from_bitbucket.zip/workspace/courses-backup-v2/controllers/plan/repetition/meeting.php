<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Add, change or remove repetition rule meeting times.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

require '../inc/initialize.php';

$offeringid = Request::UserInput('o', Request::$integer_scrub);
if(is_null($offeringid) || $offeringid == "")
	$redirect = '/report/course-repetition';
else
	$redirect = '/offering?o='.$offeringid.'&tab=repetition';
$repetitionid = Request::UserInput('r', Request::$integer_scrub);
$index = Request::UserInput('i', Request::$integer_scrub);

$repetition = new Db_Repetition($repetitionid);

if (!$repetition->recordExists()) {
	redirect($redirect, 'E~Missing data to edit a repetition rule');
	exit;
}


$form = new Form_Repetition_Meeting($repetition, $index);

if (Request::IsPost()) {
	if ($form->process()) {
		redirect($redirect);
		exit;	
	}
}

View_PageTitle::GetInstance()->set('Meeting Repetition');

include 'top.phtml';
?>


<h1>Course Offering Meetings</h1>


<div style="float:left;width:800px;margin:auto;">


	<form method="post" action="<?php echo(Request::Phpself()); ?>?">
		<input type="hidden" id="repetitionid" name="r" value="<?php echo $repetitionid; ?>" />
		<input type="hidden" id="index" name="i" value="<?php echo $index; ?>" />
		<input type="hidden" id="offeringid" name="o" value="<?php echo $offeringid; ?>" />
	
		<div class="legend">Edit Repetition Rule Meeting</div>
		<fieldset>
		
		<?php 
			$form->daylist->render();
			$form->starttime->render();
			$form->endtime->render();
		?>
			
		</fieldset>
			
		<div class="submitbox">
			<input type="submit" name="action" value="Save" />
			<input type="submit" name="action" value="Delete" />
		</div>
	
	</form>

</div>


<?php 
include 'bottom.phtml';
