<?php

/*************************************************************************
 *                                                                       *
 * class.html2text.inc                                                   *
 *                                                                       *
 *************************************************************************
 *                                                                       *
 * Converts HTML to formatted plain text                                 *
 *                                                                       *
 * Copyright (c) 2005-2007 Jon Abernathy <jon@chuggnutt.com>             *
 * All rights reserved.                                                  *
 *                                                                       *
 * This script is free software; you can redistribute it and/or modify   *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation; either version 2 of the License, or     *
 * (at your option) any later version.                                   *
 *                                                                       *
 * The GNU General Public License can be found at                        *
 * http://www.gnu.org/copyleft/gpl.html.                                 *
 *                                                                       *
 * This script is distributed in the hope that it will be useful,        *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the          *
 * GNU General Public License for more details.                          *
 *                                                                       *
 * Author(s): Jon Abernathy <jon@chuggnutt.com>                          *
 *                                                                       *
 * Last modified: 08/08/07                                               *
 *                                                                       *
 *************************************************************************/

namespace Htmltotext;

/**
 * @property string $html
 * @property string $text
 */
class HtmlToText
{

    /**
     *  Contains the HTML content to convert.
     *
     *  @var string $html
     *  @access public
     */
    protected $_html;

    /**
     *  Contains the converted, formatted text.
     *
     *  @var string $text
     *  @access public
     */
    protected $_text;

    /**
     *  Maximum width of the formatted text, in columns.
     *
     *  Set this value to 0 (or less) to ignore word wrapping
     *  and not constrain text to a fixed-width column.
     *
     *  @var integer $width
     *  @access public
     */
    public $width = 80;

    protected $replacements = array(
        array( // Windows carriage return
            'pattern'  => "/\r/",
            'literal'  => '',
        ),
        array( // Newlines and tabs
            'pattern'  => "/[\n\t]+/",
            'literal'  => ' ',
        ),
        array( // Runs of spaces, pre-handling
            'pattern'  => "/[ ]{2,}/",
            'literal'  => ' ',
        ),
        array( // <script> blocks
            'pattern'  => '/<script[^>]*>.*?<\/script>/i',
            'literal'  => '',
        ),
        array( // <style> blocks
            'pattern'  => '/<style[^>]*>.*?<\/style>/i',
            'literal'  => '',
        ),
        array( // headings h1 ... h6
            'pattern'  => '/<(h[123456])[^>]*>(.*?)<\/h[123456]>/i',
            'callback' => 'convertHeading',
        ),
        array( // paragraph open tag
            'pattern'  => '/<p[^>]*>/i',
            'literal'  => "\n\n\t",
        ),
        array( // line break
            'pattern'  => '/<br[^>]*>/i',
            'literal'  => "\n",
        ),
        array( // bold
            'pattern'  => '/<b[^>]*>(.*?)<\/b>/i',
            'callback' => 'convertStrong',
        ),
        array( // strong
            'pattern'  => '/<strong[^>]*>(.*?)<\/b>/i',
            'callback' => 'convertStrong',
        ),
        array( // italic
            'pattern'  => '/<i[^>]*>(.*?)<\/i>/i',
            'callback' => 'convertEmphasis',
        ),
        array( // emphasis
            'pattern'  => '/<em[^>]*>(.*?)<\/i>/i',
            'callback' => 'convertEmphasis',
        ),
        array( // ul open tag
            'pattern'  => '/(<ul[^>]*>|<\/ul>)/i',
            'literal'  => "\n\n",
        ),
        array( // ol open tag
            'pattern'  => '/(<ol[^>]*>|<\/ol>)/i',
            'literal'  => "\n\n",
        ),
        array( // li with close
            'pattern'  => '/<li[^>]*>(.*?)<\/li>/i',
            'callback' => 'convertListItem',
        ),
        array( // li open only
            'pattern'  => "/<li[^>]*>/i",
            'literal'  => "\n\t* ",
        ),
        array( // link anchor tag
            'pattern'  => '/<a [^>]*href="([^"]+)"[^>]*>(.*?)<\/a>/i',
            'callback' => 'convertLink',
        ),
        array( // horiz rule
            'pattern'  => '/<hr[^>]*>/i',
            'literal'  => "\n-------------------------\n",
        ),
        array( // table open
            'pattern'  => '/(<table[^>]*>|<\/table>)/i',
            'literal'  => "\n\n",
        ),
        array( // table row
            'pattern'  => '/(<tr[^>]*>|<\/tr>)/i',
            'literal'  => "\n",
        ),
        array( // table data
            'pattern'  => '/<td[^>]*>(.*?)<\/td>/i',
            'callback' => 'convertTableData',
        ),
        array( // table heading
            'pattern'  => '/<th[^>]*>(.*?)<\/th>/i',
            'callback' => 'convertTableHeading',
        ),
        array( // Non-breaking space
            'pattern'  => '/&(nbsp|#160);/i',
            'literal'  => ' ',
        ),
        array( // Double quotes
            'pattern'  => "/&(quot|rdquo|ldquo|#8220|#8221|#147|#148);/i",
            'literal'  => '"',
        ),
        array( // Single quotes
            'pattern'  => "/&(apos|rsquo|lsquo|#8216|#8217);/i",
            'literal'  => "'",
        ),
        array( // Greater-than
            'pattern'  => "/&gt;/i",
            'literal'  => '>',
        ),
        array( // Less-than
            'pattern'  => "/&lt;/i",
            'literal'  => '<',
        ),
        array( // Ampersand
            'pattern'  => '/&(amp|#38);/i',
            'literal'  => '&',
        ),
        array( // Copyright
            'pattern'  => '/&(copy|#169);/i',
            'literal'  => '(c)',
        ),
        array( // Trademark
            'pattern'  => '/&(trade|#8482|#153);/i',
            'literal'  => '(tm)',
        ),
        array( // Registered
            'pattern'  => '/&(reg|#174);/i',
            'literal'  => '(R)',
        ),
        array( // mdash
            'pattern'  => '/&(mdash|#151|#8212);/i',
            'literal'  => '--',
        ),
        array( // ndash
            'pattern'  => '/&(ndash|minus|#8211|#8722);/i',
            'literal'  => '-',
        ),
        array( // Bullet
            'pattern'  => '/&(bull|#149|#8226);/i',
            'literal'  => '*',
        ),
        array( // Pound sign
            'pattern'  => '/&(pound|#163);/i',
            'literal'  => 'L',
        ),
        array( // Euro sign
            'pattern'  => '/&(euro|#8364);/i',
            'literal'  => 'EUR',
        ),
        array( // Unknown/unhandled entities
            'pattern'  => '/&[^&;]+;/i',
            'literal'  => '',
        ),
        array( // Runs of spaces, post-handling
            'pattern'  => '/[ ]{2,}/',
            'literal'  => ' ',
        ),
    );

    /**
     *  Contains the base URL that relative links should resolve to.
     *
     *  @var string $url
     *  @access public
     */
    public $url;

    /**
     *  Indicates whether content in the $html variable has been converted yet.
     *
     *  @var boolean $_converted
     *  @access private
     *  @see $html, $text
     */
    public $_converted = false;

    /**
     *  Contains URL addresses from links to be rendered in plain text.
     *
     *  @var string $_link_list
     *  @access private
     *  @see _build_link_list()
     */
    public $_link_list = '';
    
    /**
     *  Number of valid links detected in the text, used for plain text
     *  display (rendered similar to footnotes).
     *
     *  @var integer $_link_count
     *  @access private
     *  @see _build_link_list()
     */
    public $_link_count = 0;

    /**
     *  Constructor.
     *
     *  If the HTML source string (or file) is supplied, the class
     *  will instantiate with that source propagated, all that has
     *  to be done it to call get_text().
     *
     *  @param string $html source HTML content
     */
    public function __construct($html = '')
    {
        $this->html = $html;
    }

    public function __get($name)
    {
        switch($name) {
            case 'text':
                return $this->get_text();
                break;
            case 'html':
                return $this->_html;
                break;
            default:
                return null;
                break;
        }
    }

    public function __set($name, $value)
    {
        switch($name) {
            case 'html':
                $this->_html = $value;
                $this->_converted = false;
                break;
            default: break;
        }
    }

    public function __isset($name)
    {
        switch($name) {
            case 'html':
                return (bool) $this->_html;
                break;
            case 'text':
                return $this->_converted;
                break;
            default:
                return false;
                break;
        }
    }

    /**
     * @param array $matches
     * @return string
     */
    public function convertEmphasis(array $matches)
    {
        return '*'.trim($matches[1]).'*';
    }

    /**
     * @param array $matches
     * @return string
     */
    public function convertLink(array $matches)
    {
        return $this->_build_link_list($matches[1], $matches[2]);
    }

    /**
     * @param array $matches
     * @return string
     */
    public function convertListItem(array $matches)
    {
        return '  * '.trim($matches[1]);
    }

    /**
     * @param array $matches
     * @return string
     */
    public function convertStrong(array $matches)
    {
        return '**'.trim($matches[1]).'**';
    }

    /**
     * @param array $matches
     * @return string
     */
    public function convertHeading(array $matches)
    {
        $text = trim($matches[2]);
        switch ($matches[1]) {
            case 'h1':
                $out = "\n\n".strtoupper($text)."\n==============================\n\n";
                break;
            case 'h2':
                $out = "\n\n$text\n------------------------------\n\n";
                break;
            default:
                $out = "\n\n$text\n\n";
                break;

        };
        return $out;
    }

    /**
     * @param array $matches
     * @return string
     */
    public function convertTableData(array $matches)
    {
        return '    '.trim($matches[1])."\n";
    }

    /**
     * @param array $matches
     * @return string
     */
    public function convertTableHeading(array $matches)
    {
        return '    **'.trim($matches[1]).'**'."\n";
    }

    /**
     *  Returns the text, converted from HTML.
     *  @return string
     */
    public function get_text()
    {
        if ( !$this->_converted ) {
            $this->_convert();
        }
        return $this->_text;
    }

    /**
     * Workhorse function that does actual conversion.
     *
     * First performs custom tag replacement specified by $search and
     * $replace arrays. Then strips any remaining HTML tags, reduces whitespace
     * and newlines to a readable format, and word wraps the text to
     * $width characters.
     *
     * @access private
     * @return void
     */
    private function _convert()
    {
        // Variables used for building the link list
        $this->_link_count = 0;
        $this->_link_list = '';

        $text = trim(stripslashes($this->html));

        // Run our defined search-and-replace
        foreach ($this->replacements as $r) {
            if (isset($r['callback'])) {
                $text = preg_replace_callback($r['pattern'], array($this, $r['callback']), $text);
            } else {
                $replacement = (isset($r['literal'])) ? $r['literal'] : '';
                $text = preg_replace($r['pattern'], $replacement, $text);
            }
        }


        // Strip any other HTML tags
        $text = strip_tags($text);

        // Bring down number of empty lines to 2 max
        $text = preg_replace('/\n\s+\n/', "\n\n", $text);
        $text = preg_replace('/[\n]{3,}/', "\n\n", $text);

        // Add link list
        if ( !empty($this->_link_list) ) {
            $text .= "\n\nLinks:\n------\n" . $this->_link_list;
        }

        if ( $this->width > 0 ) {
            $text = wordwrap($text, $this->width);
        }
        $this->_text = $text;
        $this->_converted = true;
    }

    /**
     *  Helper function called by preg_replace() on link replacement.
     *
     *  Maintains an internal list of links to be displayed at the end of the
     *  text, with numeric indices to the original point in the text they
     *  appeared. Also makes an effort at identifying and handling absolute
     *  and relative links.
     *
     *  @param string $link URL of the link
     *  @param string $display Part of the text to associate number with
     *  @access private
     *  @return string
     */
    private function _build_link_list( $link, $display )
    {
        if ( substr($link, 0, 7) == 'http://' || substr($link, 0, 8) == 'https://' ||
             substr($link, 0, 7) == 'mailto:' ) {
            ++$this->_link_count;
            $footnote = '[' . $this->_link_count . ']';
            $this->_link_list .= "$footnote $display \n$link\n\n";
        } elseif ( substr($link, 0, 11) == 'javascript:' ) {
            // Don't count the link; ignore it
            $footnote = '';
        // what about href="#anchor" ?
        } else {
            ++$this->_link_count;
            if ( substr($link, 0, 1) != '/' ) {
                $this->_link_list .= '/';
            }
            $footnote = '[' . $this->_link_count . ']';
            $this->_link_list .= "$footnote $display \n$link\n\n";
        }

        return $display .' '. $footnote;
    }

}
