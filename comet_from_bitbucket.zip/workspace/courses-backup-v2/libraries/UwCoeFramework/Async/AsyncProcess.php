<?php
/**
 * @package UW_COE_Framework
 */

namespace UwCoeFramework\Async;

class AsyncProcess
{
	private static $linux_php_locations = array(
		'/usr/local/zend/bin/php',
		'/usr/bin/php',
		'/usr/local/bin/php',
	);
	
	public function absolutePhp()
	{
		if ($this->isWindows()) {
			return 'php';
		}
		foreach (self::$linux_php_locations as $filename) {
			if (file_exists($filename)) {
				return $filename;
			}
		}
		return 'php';
	}

	/**
	 * Launches a background process (note, provides no security itself, $call must be sanitized prior to use)
	 * @param string $call the system call to make
	 * @author raccettura
	 */
	public function launch($call) 
	{
		if ($this->isWindows()) {
			pclose(popen('start /b '.$call, 'r'));
		} else {
			pclose(popen($call.' 2>&1 /dev/null &', 'r'));
		}
		return true;
	}
	
	
	/**
	 * Tells if we are running on Windows Platform
	 * @author raccettura
	 */
	protected function isWindows()
	{
		if (PHP_OS == 'WINNT' || PHP_OS == 'WIN32') {
			return true;
		}
		return false;
	}
	
}