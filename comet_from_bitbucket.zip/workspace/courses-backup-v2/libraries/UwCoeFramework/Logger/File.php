<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Writes log messages to a local text file.
 * @author hanisko
 */
namespace UwCoeFramework\Logger;
 
class File implements LoggerInterface
{
	private $handle;
	private $filename;
	
	public function __construct($filename)
	{
		if (!is_writable($filename)) {
			throw new \Exception('Log file '.$filename.' is not writable');
		}
		$this->filename = $filename;
	}
	
	public function write($message)
	{
		fwrite($this->getHandle(), date('Y-m-d H:i:s').' '.$message.PHP_EOL);
	}
	
	protected function getHandle()
	{
		if (is_null($this->handle)) {
			$this->handle = fopen($this->filename, 'a');
			if ($this->handle === false) {
				throw new \Exception('Failed to open '.$this->filename.' for logging');
			}
		}
		return $this->handle;
	}
	
	public function __destruct() 
	{
		if (!is_null($this->handle)) {
			fclose($this->handle);
		}
	}
	
}