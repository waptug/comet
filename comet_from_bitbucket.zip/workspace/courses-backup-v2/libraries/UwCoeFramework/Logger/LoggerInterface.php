<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Defines an interface for logging strategies
 * @author hanisko
 */
namespace UwCoeFramework\Logger;

interface LoggerInterface
{
	public function write($message);
}