<?php
/**
 * @package UW_COE_Framework
 */
/**
 * A report listener provide additional processing that will be triggered by
 * ReportAbstract events
 * @author hanisko
 */
namespace UwCoeFramework\Reports;

interface ListenerInterface
{
	public function trigger($eventname, ReportAbstract $report);
}