<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Base report parameter object that encapsulates rules around a specific field
 * affecting how user input is processed, SQL query, and how report is described.
 * @author hanisko
 */
namespace UwCoeFramework\Reports;

use UwCoeFramework\Reports\ReportAbstract;

abstract class ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Default';
	protected $urlparam;
	protected $usesticky = true;
	protected $value;
	
	/**
	 * @var ReportAbstract $report
	 */
	protected $report;

	public function __construct($config, ReportAbstract $report)
	{
		$this->report = $report;
		if (array_key_exists('default', $config)) $this->setDefault($config['default']);
		if (array_key_exists('make-null', $config)) $this->setMakeNull($config['make-null']);
		if (array_key_exists('locked', $config)) $this->setLocked($config['locked']);
		if (array_key_exists('required', $config)) $this->setRequired($config['required']);
		if (array_key_exists('use-sticky', $config)) $this->setUseSticky($config['use-sticky']);
		if (array_key_exists('value', $config)) $this->setValue($config['value']);
		if (array_key_exists('url-param', $config)) $this->setUrlParam($config['url-param']);
		if (array_key_exists('scrub-strategy', $config)) $this->setScrubStrategy($config['scrub-strategy']);
	}

	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		return;
	}
	
	/**
	 * If additional tables are required to filter by this parameter inserts
	 * a SQL JOIN phrase with its appropriate ON clause to the end of the 
	 * provided array.
	 * @param array
	 */
	public function addJoin(&$joinphrases)
	{
		return;
	}

	/**
	 * If a URL parameter is required by this parameter's current
	 * value it is added to the end of the $parameters array argument
	 * @param array
	 */
	public function addUrlParam(&$parameters)
	{
		if ($this->urlparam && ((string)$this->value != (string)$this->default)) {
			$parameters[$this->urlparam] = $this->value;
		}
	}
	
	/**
	 * Returns a string representation of the value of this report parameter
	 * usable in a human readable description.
	 * @return string
	 */
	abstract public function getDescription();

	/**
	 * Returns a description of this value that is useful in building filename
	 * when the report is downloaded.
	 * @return string|NULL
	 */
	public function getDescriptionFilename()
	{
		return null;
	}

	/**
	 * If current value of this parameter matches the default returns NULL,
	 * otherwise returns a string representation of the value of this report 
	 * parameter usable in a human readable description 
	 * @return string|NULL
	 */
	public function getDescriptionUnlessDefault()
	{
		if ($this->valueIsNotDefault()) {
			return $this->getDescription();
		} else {
			return null;
		}
	}
	
	/**
	 * Check user input for a value for this report parameter and
	 * try to assign the value. The sticky array can provide values
	 * overridden by user input, but stored at the session level 
	 * instead of in the request.
	 * @param array $sticky
	 */
	public function getUserInput($sticky = array())
	{
		if ($this->locked) {
			return;
		}
		if (array_key_exists($this->urlparam, $_GET)) {
			$value = $_GET[$this->urlparam];
		} elseif (array_key_exists($this->urlparam, $_POST)) {
			$value = $_POST[$this->urlparam];
		} elseif (array_key_exists($this->urlparam, $sticky)) {
			$value = $sticky[$this->urlparam];
		} else {
			$this->value = $this->default;
			return;
		}
		$value = $this->makeNull($value);
		$value = \Request::GetInstance()->getScrubber($this->scrubstrategy)->scrub($value);
		$this->setValue($value);
	}
	
	/**
	 * Returns true if the provided value matches the default value, does identical 
	 * checking when comparing NULL.
	 * @param string $value
	 * @return boolean
	 */
	public function isDefault($value)
	{
		// if $value or $default are null, strict comparison
		if (is_null($this->default)) {
			return ($value === $this->default);
		}
		if (is_null($value)) {
			return ($value === $this->default);
		}
		if ($this->default == $value) {
			return true;
		}
		return false;
	}

	/**
	 * @return the $default
	 */
	public function getDefault()
	{
		return $this->default;
	}
	
	/**
	 * @return the $makenull
	 */
	public function getMakeNull()
	{
		return $this->makenull;
	}
	
	/**
	 * @return the $locked
	 */
	public function getLocked()
	{
		return $this->locked;
	}
	
	/**
	 * @return the $required
	 */
	public function getRequired()
	{
		return $this->required;
	}
	
	/**
	 * @return the $urlparam
	 */
	public function getUrlparam()
	{
		return $this->urlparam;
	}
	
	/**
	 * @return the $usesticky
	 */
	public function getUsesticky()
	{
		return $this->usesticky;
	}
	
	/**
	 * @return the $value
	 */
	public function getValue()
	{
		return $this->value;
	}
	
	/**
	 * If the provided value is configured as a null equivalent for this parameter
	 * returns null, otherwise returns the value unchanged.
	 * @param mixed $value
	 * @return mixed
	 */
	public function makeNull($value)
	{
		foreach ($this->makenull as $nullequivalent) {
			if ($value === $nullequivalent) {
				return null;
			}
		}
		return $value;
	}
	
	/**
	 * Provide hook for parameter value clean-up or conversion. This method
	 * is called during setValue() processing.
	 * @param string $value
	 * @return string
	 */
	protected function parseValue($value)
	{
		return $value;
	}
	
	/**
	 * Sets the default value for this parameter and overrides current value
	 * @param mixed $default
	 */
	public function setDefault($default)
	{
		$default = $this->makeNull($default);
		$this->default = $default;
		$this->setValue($default);
	}
	
	/**
	 * @param array $makenull
	 */
	public function setMakeNull($makenull)
	{
		$this->makenull = $makenull;
	}
	
	/**
	 * @param boolean $locked
	 */
	public function setLocked($locked)
	{
		$this->locked = $locked;
	}
	
	/**
	 * @param boolean $required
	 */
	public function setRequired($required)
	{
		$this->required = $required;
	}
	
	/**
	 * @param field_type $urlparam
	 */
	public function setUrlparam($urlparam)
	{
		$this->urlparam = $urlparam;
	}

	/**
	 * @param boolean $usesticky
	 */
	public function setUsesticky($usesticky)
	{
		$this->usesticky = $usesticky;
	}
	
	/**
	 * @param field_type $value
	 */
	final public function setValue($value)
	{
		if ($this->locked) {
			return;
		}
		$value = $this->makeNull($value);
		$value = $this->parseValue($value);
		if (is_null($value) && $this->required) {
			$this->setValue($this->default);
		} else {
			$this->value = $value;
		}
	}

	/**
	 * Returns true if this parameter's current value is not the default value
	 * @return boolean
	 */
	public function valueIsNotDefault()
	{
		return !$this->isDefault($this->value);
	}
	

}