<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Inspects settings on a ReportAbstract object and provide human readable
 * text description of the report parameters.
 * @author hanisko
 */
namespace UwCoeFramework\Reports;

abstract class DescriptionAbstract
{
	protected $report;
	
	public function __construct(ReportAbstract $report)
	{
		$this->report = $report;
	}
	
	/**
	 * Returns an ordered array describing the key parameter values of this report
	 * @return array
	 */
	public function getFullDescription()
	{
		return implode(', ', $this->getFullDescriptionParts());
	}

	/**
	 * Returns an ordered array describing the key parameter values of this report
	 * @return array
	 */
	abstract public function getFullDescriptionParts();
	
	/**
	 * Returns a plain text string usable as a download filename when this report
	 * is requested. Does not include file extension.
	 * @return string
	 */
	public function getFilename()
	{
		return implode('-', $this->getFilenameParts());
	}
	
	/**
	 * Returns an array of parameter value descriptions suitable for building a 
	 * download filename.
	 * @return array
	 */
	abstract public function getFilenameParts();
	
}