<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Base report object that encapsulates a SQL query that generates a linked
 * collection of objects. The query can optionally be modified by an internal
 * collection of parameters defined in the report config.
 * @author hanisko
 */
namespace UwCoeFramework\Reports;

abstract class ReportAbstract
{
	protected $describer;
	protected $reportName = 'Report';
	protected $listeners;
	protected $useStickyParams = false;
	protected $params;
	protected $pickerManager;
	protected $sqlFilters;
	protected $sqlJoins;
	protected $viewCode = 'DEFAULT';
	protected $viewUrl;
	
	public $sql;
	public $intro;
	public $title;
	public $type;
	public $view;
	public $csvview;
	
	/**
	 * @triggers config.post
	 */
	public function __construct() 
	{
		$this->configure($this->getConfig());
	}

	/**
	 * Add a listener object to the report.
	 * @param ListenerInterface $listener
	 */
	public function addListener(ListenerInterface $listener)
	{
		$this->listeners[] = $listener;
	}

	/**
	 * Add a configured parameter object to the report.
	 * @param string $name
	 * @param ParameterAbstract $param
	 */
	public function addParam($name, ParameterAbstract $param)
	{
		$this->params[$name] = $param;
	}
	
	/**
	 * Generates an array list of database where clause filters and join statements
	 * and stores them in the $sqlFilters and $sqlJoin properties. Loops through
	 * each report parameter object and adds a database filter to the list if
	 * needed.
	 */
	protected function buildSqlPhrases()
	{
		$this->sqlFilters = array();
		$this->sqlJoins = array();
		foreach ($this->params as $param) {
			$param->addFilter($this->sqlFilters);
			$param->addJoin($this->sqlJoins);
		}
	}

	/**
	 * Reset any report params that have sticky values set to their defaults
	 */
	public function clearStickyParams()
	{
		if (!array_key_exists('crs_sticky_filters', $_SESSION)) {
			return;
		}
		if (!is_array($_SESSION['crs_sticky_filters'])) {
			unset($_SESSION['crs_sticky_filters']);
			return;
		}
		if (array_key_exists($this->type, $_SESSION['crs_sticky_filters'])) {
			unset($_SESSION['crs_sticky_filters'][$this->type]);
		}
		foreach ($this->params as $param) {
			$param->setValue($param->getDefault());
		}
	}

	/**
	 * Read a configuration array and populate report properties, create param
	 * objects, strategy objects.
	 * @triggers 'config.post'
	 * @param array $config
	 */
	public function configure($config)
	{
		if (array_key_exists('report-name', $config)) {
			$this->setReportName($config['report-name']);
		}
		$this->listeners = array();
		if (array_key_exists('listeners', $config)) {
			foreach ($config['listeners'] as $classname) {
				$this->addListener(new $classname());
			}
		}
		if (array_key_exists('use-sticky-params', $config)) {
			$this->setUseStickyParams($config['use-sticky-params']);
		}
		$this->params = array();
		if (array_key_exists('params', $config)) {
			foreach ($config['params'] as $name => $paramConfig) {
				if (!is_array($paramConfig)) continue;
				$this->createParam($name, $paramConfig);
			}
		}
		if (array_key_exists('picker-manager', $config)) {
			$classname = $config['picker-manager'];
			if (array_key_exists('picker-list', $config)) {
				$pickers = $config['picker-list'];
			} else {
				$pickers = array();
			}
			$this->setPickerManager(new $classname($pickers));
		}
		if (array_key_exists('describer', $config)) {
			$classname = $config['describer'];
			$this->describer = new $classname($this);
		}
		if (array_key_exists('view-url', $config)) {
			$this->viewUrl = $config['view-url'];
		}
		$this->trigger('config.post');
	}

	/**
	 * Instantiate parameter object based on a config array and add it to the report.
	 * @param string $name
	 * @param array $config
	 */
	public function createParam($name, $config) 
	{
		if (!array_key_exists('class-name', $config)) {
			throw new \Exception('Cannot create report parameter '.$name.', no "class-name" configured');
		}
		$classname = $config['class-name'];
		$this->params[$name] = new $classname($config, $this);
    }
    
    /**
     * Return an array that provides configuration parameters for this report
     * @return array
     */
    abstract public function getConfig();

	/**
	 * Returns an object with logic for generating human readable description
	 * of report and its parameters.
	 * @return mixed
	 */
	public function getDescriptionStrategy()
	{
		return $this->describer;
	}
	
	/**
	 * Return an specific ParameterAbstract object 
	 * @return \UwCoeFramework\Reports\ParamAbstract|null
	 */
    public function getParam($name)
    {
    	if ($this->hasParam($name)) {
    		return $this->params[$name];
    	} else {
    		return null;
    	}
    }
	
	/**
	 * Returns the full list of ParameterAbstract objects 
	 * @return array[ParameterAbstract]
	 */
    public function getParamList()
    {
    	return $this->params;
    }
	
	/**
	 * Returns the current values of a report parameter. This accessor can safely inspect
	 * parameters that may not be set.
	 * @param string $parameter
	 * @return string|null
	 */
	public function getParamValue($parameter)
	{
		if (array_key_exists($parameter, $this->params)) {
			return $this->params[$parameter]->getValue();
		} else {
			return null;
		}
	}
	
	/**
	 * Return the report parameters in an associative array using query string
	 * field names as indices. If $setvalue hash is provide the current report
	 * parameters are replaced with the values in $setvalue
	 * @param array $setvalues
	 * @return array
	 */
	public function getQueryParams($setvalues = array())
	{
		$out = array();
		// generate a list of parameters that vary from their default
		foreach ($this->params as $param) {
			$param->addUrlParam($out);
		}
		// Update any provided override values
		foreach ($setvalues as $key => $value) {
			if (is_null($value) && array_key_exists($key, $out)) {
				unset($out[$key]);
			} else {
				$out[$key] = $value;
			}
		}
		return $out;
	}
	
	/**
	 * @return the $pickerManager
	 */
	public function getPickerManager()
	{
		return $this->pickerManager;
	}
    
    /**
     * @return the $reportName
     */
    public function getReportName()
    {
    	return $this->reportName;
    }
    
	/**
	 * Gather reports parameters from user input. Fields are delivered though
	 * HTTP GET query string or HTTP POST fields. Optional $override array
	 * allows user input to be trumped by runtime parameters.
	 * @param array $override
	 */
	public function getUserInput($override = array())
	{
		foreach ($this->params as $param) {
			$param->getUserInput($this->getStickyParams());
		}
		foreach ($override as $name => $value) {
			if (array_key_exists($name, $this->params)) {
				$this->params[$name]->setValue($value);
			}
		}
		$this->storeStickyParams();
	}
	
	/**
	 * Return an array of report parameter values that have been stored 
	 * in session memory
	 * @return array
	 */
	protected function getStickyParams()
	{
		if (!$this->useStickyParams || !array_key_exists('crs_sticky_filters', $_SESSION)) {
			return array();
		}
		if (!is_array($_SESSION['crs_sticky_filters'])) {
			return json_decode($_SESSION['crs_sticky_filters'], true);
		}
		if (array_key_exists($this->type, $_SESSION['crs_sticky_filters'])) {
			return json_decode($_SESSION['crs_sticky_filters'][$this->type], true);
		}
		return array();
	}
    
    /**
     * @return the $useStickyParams
     */
    public function getUseStickyParams()
    {
    	return $this->useStickyParams;
    }
    
    /**
     * Shorthand accessor to param values
     * @return the $viewUrl
     */
    public function getValue($param_name)
    {
    	if ($this->hasParam($param_name)) {
    		return $this->getParam($param_name)->getValue();
    	} else {
    		return null;
    	}
    }

	/**
	 * Returns a string that identifies this specific report implementation for
	 * the report factory.
	 * @return string
	 */
	public function getViewCode()
	{
		return $this->viewCode;
	}
    
    /**
     * @return the $viewUrl
     */
    public function getViewUrl()
    {
    	return $this->viewUrl;
    }

    /**
     * Return true if a ParameterAbstract object is identified by $name
     * @param string $name
     * @return boolean
     */
    public function hasParam($name)
    {
    	return array_key_exists($name, $this->params);
    }

    /**
     * Return true if a picker is identified by $name
     * @param string $name
     * @return boolean
     */
    public function hasPicker($name)
    {
    	if ($this->pickerManager) {
    		return $this->pickerManager->hasPicker($name);
    	} else {
    		return false;
    	}
    }

    /**
     * Return the $sqlJoins as a single string. If there are no $sqlJoins 
     * defined returns the empty string
     * @return string
     */
    protected function implodeSqlJoins()
    {
    	if (is_array($this->sqlJoins)) {
    		return ' '.implode(' ', $this->sqlJoins).' ';
    	} else {
    		return '';
    	}
    }
    
    /**
     * Return the $sqlFilters as a single string WHERE clause. If there are no
     * $sqlFilters defined returns the empty string
     * @return string
     */
    protected function implodeSqlFilters()
    {
    	if (count($this->sqlFilters) < 1) {
    		return '';
    	}
    	return ' WHERE '.implode(' AND ',$this->sqlFilters).' ';
    }

    /**
     * Include files that contain HTML for pickers assigned to this report. 
     * Delegates to the PickerManagerAbstract object if it exists or does
     * nothing. 
     * @param string $name
     * @return boolean
     */
    public function includePickers()
    {
    	if ($this->pickerManager) {
    		$this->pickerManager->includePickers();
    	}
    }
    
    /**
     * Merges two configuration structures with the values from the second 
     * argument overwriting the first. Individual ['params'] array are
     * merged
     * @param array $base
     * @param array $more
     * @return array
     */
    public function mergeConfig($base, $more)
    {
    	// Overwrite $base report configurations with $more value
    	foreach ($more as $key => $value) {
    		if ($key == 'params') continue;
    		$base[$key] = $value;
    	}
    	// Process parameter configurations
    	if (!array_key_exists('params', $more)) return $base;
    	if (!array_key_exists('params', $base)) $base['params'] = array();
    	foreach ($more['params'] as $name => $config) {
    		// if the $config is null, remove this parameter from the configuration
    		if (is_null($config)) {
    			if (array_key_exists($name, $base['params'])) unset($base['params'][$name]);
    			continue;
    		}
    		if (!array_key_exists($name, $base['params'])) {
    			$base['params'][$name] = array();
    		}
    		foreach ($more['params'][$name] as $key => $value) {
    			$base['params'][$name][$key] = $value;
    		}
    	}
    	return $base;
    }

    /**
     * If $name identifies ParameterAbstract object it is removed from the report
     * @param string $name
     * @return boolean
     */
    public function removeParam($name)
    {
    	if (array_key_exists($name, $this->params)) {
    		unset($this->params[$name]);
    	}
    }

    /**
     * Query the data store and populate the object tree that makes up this report
     */
    abstract public function load();

	/**
	 * @param field_type $pickerManager
	 */
	public function setPickerManager ($pickerManager)
	{
		$this->pickerManager = $pickerManager;
	}
    
    /**
     * @param string $reportName
     */
    public function setReportName($reportName)
    {
    	$this->reportName = $reportName;
    }
    
    /**
     * @param boolean $useStickyParams
     */
    public function setUseStickyParams($useStickyParams)
    {
    	$this->useStickyParams = $useStickyParams;
    }

	/**
	 * Set a string that identifies this specific report implementation for
	 * the report factory.
	 */
	public function setViewCode($code)
	{
		$this->viewCode = $code;
	}

    /**
     * @param string $viewUrl
     */
    public function setViewUrl($viewUrl)
    {
    	$this->viewUrl = $viewUrl;
    }
	
	/**
	 * Write current report parameters to sticky params (SESSION) if the report
	 * is set to use sticky params.
	 */
	protected function storeStickyParams()
	{
		if (!$this->useStickyParams) {
			return;
		}
		if (!array_key_exists('crs_sticky_filters', $_SESSION) || !is_array($_SESSION['crs_sticky_filters'])) {
			$_SESSION['crs_sticky_filters'] = array();
		}
		$_SESSION['crs_sticky_filters'][$this->type] = json_encode($this->getQueryParams());
	}
    
    /**
     * Notify all attached listeners of the specified event
     * @param unknown_type $eventname
     */
    protected function trigger($eventname)
    {
    	foreach ($this->listeners as $listener) {
    		$listener->trigger($eventname, $this);
    	}
    }
    
}