<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Manages the merging of multiple configuration arrays
 * @author hanisko
 */
namespace UwCoeFramework\Reports;

class Configuration
{
	private $config;

	public function __construct()
	{
		$this->config = array();
	}

	/**
	 * Merges the existing report configuration with the values in the $more
	 * array. Individual ['params'] array are merged
	 * @param array $more
	 */
	public function addConfig($more)
	{
		// Overwrite $this->config report configurations with $more value
		foreach ($more as $key => $value) {
			if ($key == 'params') continue;
			$this->config[$key] = $value;
		}
		// Process parameter configurations
		if (!array_key_exists('params', $more)) return;
		if (!array_key_exists('params', $this->config)) $this->config['params'] = array();
		foreach ($more['params'] as $name => $config) {
			// if the $config is null, remove this parameter from the configuration
			if (is_null($config)) {
				if (array_key_exists($name, $this->config['params'])) unset($this->config['params'][$name]);
				continue;
			}
			if (!array_key_exists($name, $this->config['params'])) {
				$this->config['params'][$name] = array();
			}
			foreach ($more['params'][$name] as $key => $value) {
				$this->config['params'][$name][$key] = $value;
			}
		}
	}
	
	/**
	 * Returns the $config array
	 * @return array
	 */
	public function getConfig()
	{
		return $this->config;
	}
	
	/**
	 * Replace the current configuration with the provided array
	 * @param array $config
	 */
	public function setConfig($config)
	{
		$this->config = $config;
	}

} 