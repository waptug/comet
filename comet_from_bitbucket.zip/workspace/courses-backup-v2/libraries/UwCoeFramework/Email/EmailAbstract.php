<?php
/**
 * @package UW_COE_Framework
 */
/**
 * An email wrapper. This class sends email via SMTP using Zend Framework 1.11. It
 * adds email redirect for testing and hooks to inject application specific messages
 * and event handling.
 * @author hanisko
 */
namespace UwCoeFramework\Email;

use UwCoeFramework\Logger\LoggerInterface;
use HtmlToText\HtmlToText;

abstract class EmailAbstract
{
	const FORMAT_TEXTONLY  = 1;
	const FORMAT_HTMLONLY  = 2;
	const FORMAT_TEXTHTML  = 3;
	
	private $_ztransport;
	
	protected $from_email;
	protected $from_name;
	protected $to;
	protected $cc;
	protected $bcc;
	protected $replyto_email;
	protected $replyto_name;
	protected $subject;
	protected $bodyhtml;
	protected $bodytext;
	
	protected $config;
	protected $logstack;
	protected $redirect;
	protected $sendformat;
	
	public function __construct($config)
	{
		if (!is_array($config) || !array_key_exists('smtp_server', $config)) {
			throw new \Exception('Missing email config');
		}
		$this->config = $config;
		$this->sendformat = self::FORMAT_TEXTHTML;
		$this->to = array();
		$this->cc = array();
		$this->bcc = array();
		$this->logstack = array();
		// cautiously set redirect by default, allow child classes to switch
		// mailer back into production mode
		$this->setRedirect($this->getRedirectDefault());
	}

	/**
	 * Add an address and name that the email will be sent to
	 * @param string $email
	 * @param string $name
	 */
	public function addTo($email, $name = '')
	{
		$email = $this->validEmail($email);
		$this->to[$email] = $name;
	}

	/**
	 * Add an address and name that the email will be sent to as CC
	 * @param string $email
	 * @param string $name
	 */
	public function addCc($email, $name = '')
	{
		$email = $this->validEmail($email);
		$this->cc[$email] = $name;
	}

	/**
	 * Add an address and name that will receive a Blind CC 
	 * @param string $email
	 * @param string $name
	 */
	public function addBcc($email, $name = '')
	{
		$email = $this->validEmail($email);
		$this->bcc[$email] = $name;
	}
	
	/**
	 * Add a Logger object that progress
	 * @param LoggerInterface $logger
	 */
	public function addLogger(LoggerInterface $logger)
	{
		$this->logstack[] = $logger;
	}
	
	/**
	 * Returns the HTML version of the email body assembled with 
	 * specified header, footer, and redirect message.
	 * @return string
	 */
	public function assembleBodyHtml()
	{
		$out = array();
		if ($this->redirect) {
			$out[] = $this->getRedirectMessage(true);
		}
		$out[] = $this->getHeader(true);
		$out[] = $this->getBodyHtml(); 
		$out[] = $this->getFooter(true);
		return implode(PHP_EOL,$out);
	}
	
	/**
	 * Returns the plain text version of the email body assembled with 
	 * specified header, footer, and redirect message.
	 * @return string
	 */
	public function assembleBodyText()
	{
		if ($this->bodyhtml && !$this->bodytext) {
			$convert = new HtmlToText($this->bodyhtml);
			$this->bodytext = trim($convert->text);
		}
		$out = array();
		if ($this->redirect) {
			$out[] = $this->getRedirectMessage();
		}
		$out[] = $this->getHeader();
		$out[] = $this->getBodyText(); 
		$out[] = $this->getFooter();
		return implode(PHP_EOL,$out);
	}
	
	/**
	 * Assemble an email address and a person name into an email address string
	 * @param string $email
	 * @param string $name
	 * @return string
	 */
	public function assembleNameEmail($email, $name = '')
	{
		if ($name) {
			return '"'.$name.'" <'.$email.'>';
		} else {
			return $email;
		}
	}

	/**
	 * Return the HTML string to be used as the message body
	 * @return string
	 */
	public function getBodyHtml()
	{
		return $this->bodyhtml;
	}

	/**
	 * Return the plain text string to be used as the message body
	 * @return string
	 */
	public function getBodyText()
	{
		return $this->bodytext;
	}

	/**
	 * Return the from email address as an array with email address as the
	 * key and name as the value
	 * @return string
	 */
	public function getFrom()
	{
		return array($this->from_email => $this->from_name);
	}
	
	/**
	 * Return the from email address as a string including name and
	 * bracket enclosed email
	 * @return string
	 */
	public function getFromAsString()
	{
		if ($this->from_name) {
			return '"'.$this->from_name.'" <'.$this->from_email.'>';
		} else {
			return $this->from_email;
		}
	}
	
	/**
	 * Returns a string that gets inserted into the email message body at the top 
	 * of the message. The test message will go first, followed by this header, 
	 * followed by the message body.
	 * @param boolean $asHtml specify TRUE to get an HTML fragment
	 * @return string
	 */
	protected function getHeader($asHtml = false)
	{
		return '';
	}
	
	/**
	 * Returns a string that gets inserted into the email message body at the bottom
	 * of the message.
	 * @param boolean $asHtml specify TRUE to get an HTML fragment
	 * @return string
	 */
	protected function getFooter($asHtml = false)
	{
		return '';
	}

	/**
	 * Returns a safe e-mail address this message will be redirected to
	 * @return string
	 */
	public function getRedirect()
	{
		return $this->redirect;
	}

	/**
	 * Returns a safe e-mail address to send this message to when
	 * in a testing environment.
	 * @return string
	 */
	abstract protected function getRedirectDefault();

	/**
	 * Returns an explanatory message to be inserted into e-mails that are
	 * redirected to a testing email address instead of the actual "to" and "cc"
	 * addresses. This happens when email is sent from a dev or testing
	 * environment.
	 *
	 * @param boolean $asHtml specify TRUE to get an HTML fragment
	 * @return string
	 */
	protected function getRedirectMessage($asHtml = false)
	{
		if ($asHtml) {
			$out = '<p style="color:#c00;font-style:italic;">TEST MODE: This messages is being '
				. 'redirected to you because it was sent from a testing environment. If this email '
				. 'had been generated on the production site it would have been sent to <br />'
				. '<strong>To:</strong> '.htmlspecialchars($this->getToAsString()).'</p>';
		} else { 
			return " -- TEST MODE: This messages is being redirected to you because it was sent from\n"
				.  " -- a testing environment. If this email had been generated on the production\n"
				.  " -- site it would have been sent to \n"
				.  " -- TO: ".$this->getToAsString()."\n";
		}
		return $out;
	}
	
	/**
	 * Returns the list of To addresses in a 
	 * @return array
	 */
	public function getTo()
	{
		return $this->to;
	}
	
	public function getToAsString()
	{
		$out = array();
		foreach ($this->to as $email => $name) {
			$out[] = $this->assembleNameEmail($email, $name);
		}
		return implode(', ',$out);
	}

	/**
	 * Writes the provided message to any loggers that were provided via addLogger()
	 * @param string $message
	 */
	public function log($message) 
	{
		foreach ($this->logstack as $logger) {
			$logger->write($message);
		}
	}
	
	/**
	 * Create a trackable record of an error condition
	 * @param \Exception $e
	 */
	protected function notifyException(\Exception $e)
	{
		$dump = $e->getMessage().PHP_EOL.$e->getTraceAsString().PHP_EOL.print_r($this, true);
		$this->log($dump);
	}
	
	/**
	 * A generic function that is called at the beginning of the send()
	 * method before any field processing is started. If this method
	 * returns false send() is aborted.
	 * @return boolean
	 */
	protected function preProcessing()
	{
		return true;
	}
	
	/**
	 * A generic function that is called after all field processing is 
	 * complete and immediately before the email message is sent. If 
	 * this method returns false send() is aborted.
	 * @return boolean
	 */
	protected function preSend()
	{
		return true;
	}
	
	/**
	 * A generic function that is called after the email is sent, but
	 * only if the send was successful.
	 * @return boolean
	 */
	protected function postSend()
	{
		return true;
	}
	
	/**
	 * Provide an HTML string to be used as the message body
	 * @param string $html
	 */
	public function setBodyHtml($html)
	{
		$this->bodyhtml = $html;
	}

	/**
	 * Provide a plain text string to be used as the message body
	 * @param string $body
	 */
	public function setBodyText($body)
	{
		$this->bodyplaintext = $body;
	}
	
	/**
	 * Set the address and name the email will be labeled as from
	 * @param string $email
	 * @param string $name
	 */
	public function setFrom($email, $name = '')
	{
		$email = $this->validEmail($email);
		$this->from_email = $email;
		$this->from_name = $name;
	}

	/**
	 * Provide a substitute email address deliver message to. When redirect is
	 * set message will be sent only to the redirect address and debugging 
	 * information will be included in the message with the actual To:, Cc: 
	 * and Bcc: values.
	 * @return string
	 */
	public function setRedirect($email = null)
	{
		if (is_null($email)) {
			$this->redirect = null;
			return;
		}
		$email = $this->validEmail($email);
		$this->redirect = $email;
	}
	
	/**
	 * Set the address and name the email will be labeled as reply to
	 * @param string $email
	 * @param string $name
	 */
	public function setReplyTo($email, $name = '')
	{
		$email = $this->validEmail($email);
		$this->replyto_email = $email;
		$this->replyto_name = $name;
	}
	
	/**
	 * Set the markup format this email will be sent in HTML, plain text only or
	 * HTML and text (default)
	 * @param integer $format
	 */
	public function setSendFormat($format)
	{
		switch ($format) {
			case self::FORMAT_TEXTONLY:
			case self::FORMAT_HTMLONLY:
			case self::FORMAT_TEXTHTML:
				$this->sendformat = $format;
				break;
			default:
				$this->sendformat = self::FORMAT_TEXTHTML;
				break;
		}
	}
	
	/**
	 * Set the subject line of the email
	 * @param string $subject
	 */
	public function setSubject($subject)
	{
		$this->subject = $subject;
	}
	
	/**
	 * Send an email.
	 * @return boolean
	 */
	public function send()
	{
		// fire off any defined preProcessing routines
		$success = $this->preProcessing();
		if (!$success) return false;
		
		// make sure we have required fields
		if (!$this->from_email) {
			$e = new \Exception('Email From address not set');
			$this->notifyException($e);
			throw $e;
		}
		if (count($this->to) < 1) {
			$e = new \Exception('Email To address not set');
			$this->notifyException($e);
			throw $e;
		}
		if (!$this->subject) {
			$e = new \Exception('Email Subject line not set');
			$this->notifyException($e);
			throw $e;
		}
		if ($this->sendformat == self::FORMAT_HTMLONLY || $this->sendformat == self::FORMAT_TEXTHTML) {
			if (!$this->bodyhtml) {
				$e = new \Exception('Email HTML body not set');
				$this->notifyException($e);
				throw $e;
			}	
		} else {
			if (!$this->bodyhtml && !$this->bodytext) {
				$e = new \Exception('Email body text not set');
				$this->notifyException($e);
				throw $e;
			}
		}
		
		// create and populate Zend Mail object
		$zmail = new \Zend_Mail();
		
		$zmail->setFrom($this->from_email, $this->from_name);
		
		/*
		// Server email approach
		$zmail->setFrom($this->config['smtp_from_email'], $this->config['default_from_name']);
		$zmail->setReplyTo($this->from_email, $this->from_name);
		*/
		
		if ($this->redirect) {
			$zmail->addTo($this->redirect);
		} else {
			foreach ($this->to as $email => $address) {
				$zmail->addTo($email, $address);
			}
			foreach ($this->cc as $email => $address) {
				$zmail->addCc($email, $address);
			}
			foreach ($this->bcc as $email => $address) {
				$zmail->addBcc($email, $address);
			}
		}
		// temporary testing & error tracking 2/2/2012
		//$zmail->addBcc('hanisko@uw.edu', 'Paul Hanisko');
		
		// set the subject
		$zmail->setSubject($this->subject);
		
		// define an HTML message body
		if ($this->sendformat == self::FORMAT_HTMLONLY || $this->sendformat == self::FORMAT_TEXTHTML) {
			$zmail->setBodyHtml($this->assembleBodyHtml());
		}
		// define a text message body
		if ($this->sendformat == self::FORMAT_TEXTONLY || $this->sendformat == self::FORMAT_TEXTHTML) {
			$zmail->setBodyText($this->assembleBodyText());
		}
		
		// Call any pre send email tasks
		$success = $this->preSend();
		if (!$success) return false;

		$this->setTransport();
		
		// Send the message, then delete the mail object for a fresh start
		try {
			$zmail->send();
		} catch (\Exception $e) {
			$this->notifyException($e);
			throw $e;
		}
		
		// Call any post send email tasks
		return $this->postSend();
	}
	
	
	/**
	 * Sets the Email transport system to be used to send email. By default
	 * sets up for SMTP delivery, but allows override
	 */
	public function setTransport(Zend_Mail_Transport $transport = null)
	{
		if (is_null($transport)) {
			if (is_null($this->_ztransport)) {
				$zconf = array();
				if (array_key_exists('smtp_encrypt_protocol', $this->config)) {
					$zconf['ssl'] = $this->config['smtp_encrypt_protocol'];
				}
				if (array_key_exists('smtp_port', $this->config)) {
					$zconf['port'] = $this->config['smtp_port'];
				}
				if (array_key_exists('smtp_username', $this->config)) {
					$zconf['auth'] = 'login';
					$zconf['username'] = $this->config['smtp_username'];
					$zconf['password'] = $this->config['smtp_password'];
				}
				$this->_ztransport = new \Zend_Mail_Transport_Smtp($this->config['smtp_server'], $zconf);
			}
			$transport = $this->_ztransport;
		}
		\Zend_Mail::setDefaultTransport($transport);
	}
	
	/**
	 * Validates and returns an email message
	 * @param string $email value to be tested as an email address
	 * @return string
	 * @throws \Exception
	 */
	protected function validEmail($email)
	{
		$valid = filter_var($email, FILTER_VALIDATE_EMAIL);
		if (!$valid) {
			$e = new \Exception('Not a valid email address "'.$email.'"');
			$this->notifyException($e);
			throw $e;
		}
		return $valid;
	}
	
}