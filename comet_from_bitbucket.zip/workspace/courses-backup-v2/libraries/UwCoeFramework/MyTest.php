<?php
namespace UwCoeFramework;

class MyTest
{
	
	public function whatAmI()
	{
		echo __CLASS__ . PHP_EOL;
	}
	
}