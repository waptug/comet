<?php
/**
 * Provides a local application cache of of Db_Person objects.
 * Minimizes trips to the database for resolving display names.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Cache_Person
{
	private static $_cache;
	private static $_uwnetid_map;

	/**
	 * Find a person object that matches a personid or
	 * uwnetid parameter.
	 * @param mixed $searchterm integer personid or string uwnetid
	 * @return Db_Person
	 */
	public static function Locate($searchterm)
	{
		if (is_null(self::$_cache)) {
			self::LoadCache();
		}
		if (array_key_exists($searchterm, self::$_cache)) {
			return self::$_cache[$searchterm];
		}
		if (array_key_exists($searchterm, self::$_uwnetid_map)) {
			return self::$_uwnetid_map[$searchterm];
		}
		// Return a null person
		return Db_Person::GetUnknownPerson($searchterm);
	}
	
	/**
	 * Load known persons into memory.
	 */
	private static function LoadCache()
	{
		$result = DbFactory::GetConnection()->fetchAssoc('SELECT * FROM person');
		self::$_cache = array();
		self::$_uwnetid_map = array();
		foreach ($result as $row) {
			self::$_cache[$row['personid']] = Db_Person::Register($row);
			if ($row['uwnetid']) {
				self::$_uwnetid_map[$row['uwnetid']] = self::$_cache[$row['personid']];
			}
		}
	}

}