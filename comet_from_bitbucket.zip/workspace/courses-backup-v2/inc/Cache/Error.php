<?php
/**
 * Provides logging for RestClient errors.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Framework
 */

class Cache_Error extends DbObject 
{
	private static $_expires = 2592000; // One month in seconds. 86400 (1 day) x 30
	
	public function __construct($errorid, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'c_error');
		$this->addPrimaryKeyField('errorid', $errorid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('url');
		$this->addField('httpcode', self::TYPE_INT);
		$this->addField('response');
		
		if ($autoload) { $this->load(); }
	}
	
	public static function Purge($limit = 0)
	{
		$db = DbConnection::GetInstance();
		$limit = (int) $limit;
		if (!$limit) {
			$limit = time() - self::$_expires;
		}
		$db->query('DELETE FROM c_error WHERE attempted < ' . $db->quote($limit, 'date'));
	}
	
	
}