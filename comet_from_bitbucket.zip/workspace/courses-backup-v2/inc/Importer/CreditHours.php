<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Defines an import process for updating actual student credit
 * hours on course offering records.
 * @author hanisko
 */

class Importer_CreditHours extends Importer
{
	protected static $skip_section_types = array('QZ');
	
	protected static $MAP = array(
		'year' => 0,
		'quarter' => 1,
		'curriculum' => 2,
		'courseno' => 3,
		'section' => 4,
		'studentcredithours' => 5,
		'sln' => 6
	);
	protected static $PARSERS = array(
		'year' => 'Parser_Integer',
		'quarter' => 'Parser_Integer',
		'curriculum' => 'Parser_Text',
		'courseno' => 'Parser_Integer',
		'studentcredithours' => 'Parser_Integer',
		'sln' => 'Parser_Integer'
	);
	
	public $offering;
		
	public function __construct($filename)
	{
		$this->datareader = new DataReader_Commadelimited($filename);
		$this->map = self::$MAP;
		$this->parsers = self::$PARSERS;
	}

	/**
	 * Do import scrub and conversion routines on one record, but
	 * do not trigger save routines.
	 */
	public function readRecord()
	{
		$goodrecord = false;
		while (!$goodrecord) {
			// Read next record
			$this->record = $this->datareader->next();
			
			// Datareader returns false at end of input stream
			if ($this->record === false) {
				return false;
			}
			// How many fields did we find?
			$this->fieldcount = count($this->record);
			
			$year = $this->getValue('year');
			if ($year > 1900 && $year < 2100) {
				$goodrecord = true;
			}
		}
		// Try to match up using course offering SLN
		$year = $this->getValue('year');
		$quarter = $this->getValue('quarter');
		$sln = $this->getValue('sln');
		$offeringid = Db_Offering::FindSLN($year, $quarter, $sln);
		if ($offeringid) {
			$this->offering = new Db_Offering($offeringid);
			$this->offering->studentcredithours = $this->getValue('studentcredithours');
		} else {
			// Update only, no match we continue
			$this->offering = null;
		}
		return true;
	}
	
	/**
	 * Store the last record tested in the target data store.
	 */
	public function saveRecord()
	{
		if ($this->offering) $this->offering->save();
	}
	
}