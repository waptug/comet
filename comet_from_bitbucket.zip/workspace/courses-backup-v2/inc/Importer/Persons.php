<?php
/**
 * Defines an import process for loading Person records from
 * a CSV text file and importing them into the database.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Importer_Persons extends Importer
{
	protected static $MAP = array(
		'ein' => 0,
		'uwnetid' => 1,
		'firstname' => 2,
		'lastname' => 2
	);
	protected static $PARSERS = array(
		'ein'       => 'Parser_Integer',
		'uwnetid'   => 'Parser_Text',
		'firstname' => 'Parser_FirstOnly',
		'lastname'  => 'Parser_LastOnly'
	);
	
	public $person;
	
	public function __construct($filename)
	{
		$this->datareader = new DataReader_Commadelimited($filename);
		$this->map = self::$MAP;
		$this->parsers = self::$PARSERS;
	}

	/**
	 * Do import scrub and conversion routines on one record, but
	 * do not trigger save routines.
	 */
	public function readRecord()
	{
		$goodrecord = false;
		while (!$goodrecord) {
			// Read next record
			$this->record = $this->datareader->next();
			
			// Datareader returns false at end of input stream
			if ($this->record === false) {
				return false;
			}
			// How many fields did we find?
			$this->fieldcount = count($this->record);
			
			$ein = $this->getValue('ein');
			if ($ein) {
				$goodrecord = true;
			}
		}
		$person = Db_Person::FetchByEin($ein);
		$uwnetid = $this->getValue('uwnetid');
		if (!$person->recordExists() && $uwnetid){
			$person = Db_Person::FetchByUwnetid($uwnetid);
		}
		$person->firstname = $this->getValue('firstname');
		$person->lastname = $this->getValue('lastname');
		$person->ein = $ein;
		$person->uwnetid = $uwnetid;
		if (!$person->email && $person->uwnetid) {
			$person->email = $person->uwnetid.'@uw.edu';
		}
		$person->source = 'IMPORT';
		$this->person = $person;
		
		if (!$person->lastname && $person->ein) {
			$uwperson = new Db_UwPerson($person->ein);
			if ($uwperson->recordExists()) {
				$person->firstname = $uwperson->firstname;
				$person->lastname = $uwperson->lastname;
				$person->uwnetid = $uwperson->uwnetid;
			}
		}
		
		return true;
	}
	
	/**
	 * Store the last record tested in the target data store.
	 */
	public function saveRecord()
	{
		if ($this->person->uwnetid) {
			$this->person->save();
		}
	}
	
}
