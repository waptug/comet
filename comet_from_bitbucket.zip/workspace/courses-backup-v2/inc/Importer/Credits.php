<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Defines an import process for updating section credits on 
 * Db_Offering records
 * @author hanisko
 */

class Importer_Credits extends Importer
{
	protected static $MAP = array(
		'offeringid' => 0,
		'creditcontrolcode' => 1,
		'creditsmin' => 2,
		'creditsmax' => 3,
	);
	protected static $PARSERS = array(
		'offeringid' => 'Parser_Integer',
		'creditcontrolcode' => 'Parser_Integer',
		'creditsmin' => 'Parser_Integer',
		'creditsmax' => 'Parser_Integer',
	);
	
	public $offering;
	public $offeringid;
		
	public function __construct($filename)
	{
		$this->datareader = new DataReader_Commadelimited($filename);
		$this->map = self::$MAP;
		$this->parsers = self::$PARSERS;
	}

	/**
	 * Do import scrub and conversion routines on one record, but
	 * do not trigger save routines.
	 */
	public function readRecord()
	{
		$goodrecord = false;
		while (!$goodrecord) {
			// Read next record
			$this->record = $this->datareader->next();
			
			// Datareader returns false at end of input stream
			if ($this->record === false) {
				return false;
			}
			// How many fields did we find?
			$this->fieldcount = count($this->record);
			
			$offeringid = $this->getValue('offeringid');
			if ($offeringid) {
				$goodrecord = true;
			}
		}
		$this->offering = new Db_Offering($offeringid);
		if ($this->offering->recordExists()) {
			switch($this->getValue('creditcontrolcode')) {
				case 1: // = fixed credit
					$this->offering->creditcontrol = 'fixed';
					$this->offering->creditmin = $this->getValue('creditsmin');
					$this->offering->creditmax = null;
					break;
				case 2: // = variable credit, min to max credits
					$this->offering->creditcontrol = 'variable';
					$this->offering->creditmin = $this->getValue('creditsmin');
					$this->offering->creditmax = $this->getValue('creditsmax');
					break;
				case 3: // = variable credit, min or max credits
					$this->offering->creditcontrol = 'minormax';
					$this->offering->creditmin = $this->getValue('creditsmin');
					$this->offering->creditmax = $this->getValue('creditsmax');
					break;
				case 0: // = zero credits
					$this->offering->creditcontrol = 'fixed';
					$this->offering->creditmin = 0;
					$this->offering->creditmax = null;
					break;
				case 9: // = variable credit, min to max credits
					$this->offering->creditcontrol = 'open';
					$this->offering->creditmin = 1;
					$this->offering->creditmax = 25;
					break;
				default:
					throw new Exception('Unknown credit control code '.$this->getValue('creditcontrolcode'));
					break;
			}
		} else {
			// Update only, no match we continue
			$this->offering = null;
			$this->offeringid = $offeringid;
		}
		return true;
	}
	
	/**
	 * Store the last record tested in the target data store.
	 */
	public function saveRecord()
	{
		if ($this->offering) $this->offering->save();
	}
	
}