<?php
/**
 * Defines an import process for loading funding type records from
 * a CSV text file and importing them into the database.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Importer_Funding extends Importer
{
	protected static $MAP = array(
		'year' => 0,
		'quarter' => 1,
		'sln' => 2,
		'selfsustaining' => 3,
	);
	protected static $PARSERS = array(
		'year' => 'Parser_Integer',
		'quarter' => 'Parser_Integer',
		'sln' => 'Parser_Integer',
		'selfsustaining' => 'Parser_BooleanNotNull'
	);
	
	public $offering;
	
	public function __construct($filename)
	{
		$this->datareader = new DataReader_Commadelimited($filename);
		$this->map = self::$MAP;
		$this->parsers = self::$PARSERS;
	}

	/**
	 * Do import scrub and conversion routines on one record, but
	 * do not trigger save routines.
	 */
	public function readRecord()
	{
		$goodrecord = false;
		while (!$goodrecord) {
			// Read next record
			$this->record = $this->datareader->next();
			
			// Datareader returns false at end of input stream
			if ($this->record === false) {
				return false;
			}
			// How many fields did we find?
			$this->fieldcount = count($this->record);
			
			$year = $this->getValue('year');
			if ($year) {
				$goodrecord = true;
			}
		}
		$quarter = $this->getValue('quarter');
		$sln = $this->getValue('sln');
		$this->offering = Db_Offering::FetchBySLN($year, $quarter, $sln);
		if ($this->offering instanceof Db_Offering) {
			if ($this->getValue('selfsustaining')) {
				$this->offering->funding = 'SS';
			} else {
				$this->offering->funding = 'St';
			}
		}
		
		return true;
	}
	
	/**
	 * Store the last record tested in the target data store.
	 */
	public function saveRecord()
	{
		if (!is_null($this->offering)) {
			$this->offering->save();
		}
	}
	
}