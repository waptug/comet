<?php
/**
 * Defines an import process for loading UW Person records from
 * a CSV text file and importing them into the database.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Importer_UwPersons extends Importer
{
	protected static $MAP = array(
		'ein' => 0,
		'uwnetid' => 1,
		'firstname' => 2,
		'lastname' => 2
	);
	protected static $PARSERS = array(
		'ein'       => 'Parser_Integer',
		'uwnetid'   => 'Parser_Text',
		'firstname' => 'Parser_FirstOnly',
		'lastname'  => 'Parser_LastOnly'
	);
	
	public $person;
	
	public function __construct($filename)
	{
		$this->datareader = new DataReader_Commadelimited($filename);
		$this->map = self::$MAP;
		$this->parsers = self::$PARSERS;
	}

	/**
	 * Do import scrub and conversion routines on one record, but
	 * do not trigger save routines.
	 */
	public function readRecord()
	{
		$goodrecord = false;
		while (!$goodrecord) {
			// Read next record
			$this->record = $this->datareader->next();
			
			// Datareader returns false at end of input stream
			if ($this->record === false) {
				return false;
			}
			// How many fields did we find?
			$this->fieldcount = count($this->record);
		
			$ein = $this->getValue('ein');
			if ($ein) {
				$goodrecord = true;
			}
		}
		$person = new Db_UwPerson($ein);
		$person->firstname = $this->getValue('firstname');
		$person->lastname = $this->getValue('lastname');
		$person->uwnetid = $this->getValue('uwnetid');
		$this->person = $person;
		
		return true;
	}
	
	/**
	 * Store the last record tested in the target data store.
	 */
	public function saveRecord()
	{
		if ($this->person->ein) {
			$this->person->save();
		}
	}
	
}