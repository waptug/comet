<?php
/**
 * Defines an import process for loading Person records from
 * a CSV text file and importing them into the database.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Importer_Courses extends Importer
{
	protected static $skip_section_types = array('QZ');
	
	private $current_quarter;
	
	protected static $MAP = array(
		'year' => 0,
		'quarter' => 1,
		'section' => 2,
		'sectiontype' => 3,
		'sln' => 4,
		'enrolled' => 5,
		'credithours' => 6,
		'curriculum' => 7,
		'courseno' => 8,
		'title' => 9,
		'shorttitle' => 10,
		'wildcardtitle' => 11,
		'general_education' => 12,
		'dow' => 13,
		'start' => 14,
		'end' => 15,
		'ein' => 16,
		'selfsustaining' => 17,
		'building' => 18,
		'room' => 19,
		'meetingnumber' => 20,
		'summerterm' => 21
	);
	protected static $PARSERS = array(
		'year' => 'Parser_Integer',
		'quarter' => 'Parser_Integer',
		'section' => 'Parser_Text',
		'sectiontype' => 'Parser_Text',
		'sln' => 'Parser_Integer',
		'enrolled' => 'Parser_Integer',
		'credithours' => 'Parser_Integer',
		'curriculum' => 'Parser_Text',
		'courseno' => 'Parser_Integer',
		'title' => 'Parser_Title',
		'shorttitle' => 'Parser_Title',
		'wildcardtitle' => 'Parser_Title',
		'general_education' => 'Parser_Text',
		'dow' => 'Parser_DayOfWeekList',
		//'dow' => 'Parser_RawData',
		'start' => 'Parser_Time',
		'end' => 'Parser_Time',
		'ein' => 'Parser_Integer',
		'selfsustaining' => 'Parser_BooleanNotNull',
		'building' => 'Parser_TextStarNull',
		'room' => 'Parser_TextStarNull',
		'meetingnumber' => 'Parser_Integer',
		'summerterm' => 'Parser_Summerterm'
	);
	
	public $course;
	public $offering;
	public $instructor;
	public $meeting;
		
	public function __construct($filename)
	{
		$this->datareader = new DataReader_Commadelimited($filename);
		$this->map = self::$MAP;
		$this->parsers = self::$PARSERS;
		$this->current_quarter = Db_Quarter::GetQuarter();
	}

	/**
	 * Do import scrub and conversion routines on one record, but
	 * do not trigger save routines.
	 */
	public function readRecord()
	{
		$goodrecord = false;
		while (!$goodrecord) {
			// Read next record
			$this->record = $this->datareader->next();
			
			// Datareader returns false at end of input stream
			if ($this->record === false) {
				return false;
			}
			// How many fields did we find?
			$this->fieldcount = count($this->record);
			
			$sln = $this->getValue('sln');
			if ($sln) {
				$goodrecord = true;
			}
		}
		// Try to match up using course offering SLN
		$year = $this->getValue('year');
		$quarter = $this->getValue('quarter');
		$sln = $this->getValue('sln');
		$wildcardtitle = $this->getValue('wildcardtitle');
		$offeringid = Db_Offering::FindSLN($year, $quarter, $sln);
		if ($offeringid) {
			$offering = new Db_Offering($offeringid);
			$course = new Db_Course($offering->courseid);
		} else {
			// Otherwise match down using course wildcard title
			$course = Db_Course::FetchMatch($this->getValue('curriculum'), $this->getValue('courseno'), $wildcardtitle);
			$offering = Db_Offering::FetchMatch($course->courseid, $year, $quarter, $this->getValue('section'));
		}
		
		$course->title = $this->getValue('title');
		$course->shorttitle = $this->getValue('shorttitle');
		// Don't replace a wildcard title with a blank value
		if ($wildcardtitle) {
			$course->wildcardtitle = $wildcardtitle;
		}
		$course->general_education = $this->getValue('general_education');
		$this->course = $course;

		$offering->summerterm = $this->getValue('summerterm');
		$offering->sectiontype = $this->getValue('sectiontype');
		$offering->sln = $sln;
		$offering->enrolled = $this->getValue('enrolled');
		$offering->credithours = $this->getValue('credithours');
		if ($this->getValue('selfsustaining')) {
			$offering->funding = 'SS';
		} else {
			$offering->funding = 'St';
		}
		// Calculate status, set current and past quarters to historical, set future quarters to planned if they do not already have a value
		if ($offering->year > $this->current_quarter->year || ($offering->year == $this->current_quarter->year && $offering->quarter >= $this->current_quarter->quarter)) {
			$offering->status = 'historical';
		} else {
			if (!$offering->status) {
				$offering->status = 'planned';
			}
		}
		$this->offering = $offering;

		$meetingnumber = $this->getValue('meetingnumber');
		$meetingnumber = ($meetingnumber) ? $meetingnumber : 1;
		$this->meeting = Db_Meeting::FetchMatch($offering->offeringid, $meetingnumber);
		$start = $this->getValue('start');
		$end = $this->getValue('end');
		if ($offering->type != 'QZ') self::adjustTimes($start, $end);
		$this->meeting->start = $start;
		$this->meeting->end = $end;
		$this->meeting->daylist = $this->getValue('dow');
		$this->meeting->building = $this->getValue('building');
		$this->meeting->room = $this->getValue('room');
		$this->instructor = $this->getValue('ein');
		
		return true;
	}
	
	/**
	 * Store the last record tested in the target data store.
	 */
	public function saveRecord()
	{
		// Don't import quiz sections
		if ($this->offering->type == 'QZ') {
			return;
		}
		if ($this->course->curriculum) {
			$this->course->save();
		} else {
			throw new Exception('Missing import data for Db_Course object');
		}
		if ($this->course->courseid && $this->offering->year) {
			$this->offering->courseid = $this->course->courseid;
			$this->offering->save();
		} else {
			throw new Exception('Missing import data for Db_Offering object');
		}
		if ($this->offering->offeringid) {
			$this->meeting->offeringid = $this->offering->offeringid;
			$this->meeting->save();
		} else {
			throw new Exception('Missing import data for Db_Meeting object');
		}
		if ($this->instructor) {
			if ($this->offering->offeringid) {
				$person = Db_Person::FetchByEin($this->instructor);
				if (!$person->recordExists()) {
					$person->lastname = 'unknown';
					$person->save();
				}
				$staff = Db_Staff::FetchMatch($this->offering->offeringid, $person->personid);
				$staff->meetingnumber = $this->meeting->meetingnumber;
				if ($person->isfaculty) {
					$staff->role = 'faculty';
				} elseif ($person->isadjunct) {
					$staff->role = 'adjunct';
				} else {
					$staff->role = 'instructor';
				}
				if ($this->offering->type == 'IS' || $this->offering->type == 'PR') {
					// for internships and practicums many faculty are listed as staff
					// but none should be listed as primary
					$staff->timesched = 0;
				} else {
					$staff->timesched = 1;
				}
				$staff->save();
			} else {
				throw new Exception('Missing import data for Db_Staff object');
			}
		}
	}
	
	/**
	 * Make sure that the parsed times have courses ending after they
	 * start. In case of error intelligently adjust the values.
	 * @param string $start
	 * @param string $end
	 */
	public function adjustTimes(&$start, &$end)
	{
		// only a problem if the meeting starts after it ends
		if ($start > $end) {
			$s = explode(':', $start);
			$e = explode(':', $end);
			if ($e[0] < 10) {
				// if we have an end time before 10AM that is probably the problem
				$e[0] = $e[0] + 12;
			} elseif ($s[0] > 20) {
				// if we have an start time after 8PM that is probably the problem
				$s[0] = $s[0] - 12;
			} elseif ($e[0] < 13 && $s[0] > 18) {
				// if we have an end time before noon and a start time after 6PM adjust the start time back
				$s[0] = $s[0] - 12;
			} else {
				// something happening here we have not accounted for
				throw new Exception('Nonsensical course times parsed '.$start.' to '.$end);
			}
			$start = sprintf('%02d:%02d', $s[0], $s[1]);
			$end = sprintf('%02d:%02d', $e[0], $e[1]);
		}
	}
	
}