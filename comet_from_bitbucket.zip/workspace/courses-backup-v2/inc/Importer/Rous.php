<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Import ROU data from a spreadsheet
 * @author Paul Hanisko
 */

class Importer_Rous extends Importer
{
 
	protected static $divisions = array(
		'undergraduate' => array(
				'id'       => 1,
				'name'     => 'Undergraduate divison',
				'approver' => 1046,  // personid Carol Davis
				'staff'    => 1338), // melmoser
		'professional'  => array(
				'id'       => 2,
				'name'     => 'Professional divison',
				'approver' => 1019,  // personid Cap Peck
				'staff'    => 1210), // kjewell
		'graduate'      => array(
				'id'       => 3,
				'name'     => 'Graduate divison',
				'approver' => 1053,  // personid Deb McCutchen
				'staff'    => 1211), // mlindsay
		'unknown'       => array(
				'id'       => 999,
				'name'     => 'unknown',
				'approver' => 1245,  // personid Karen
				'staff'    => 1245), // kemath
	);
	
	protected static $MAP = array(
		'division' => 0,
		'rouname'  => 1,
		'approver' => 2,
		'courseid' => 3,
	);
	protected static $PARSERS = array(
		'division' => 'Parser_Text',
		'rouname'  => 'Parser_Text',
		'approver' => 'Parser_Text',
		'courseid' => 'Parser_Integer',
	);
	
	private $rouindex;
	
	public $rou;
	public $course;
	public $rouperson;
	
	public function __construct($filename)
	{
		$this->datareader = new DataReader_Commadelimited($filename);
		$this->map = self::$MAP;
		$this->parsers = self::$PARSERS;
		$this->loadRouIndex();
	}
	
	protected function loadRouIndex()
	{
		$this->rouindex = array();
		$db = DbFactory::GetConnection();
		$results = $db->fetchAssoc('SELECT * FROM rou');
		foreach ($results as $row) {
			$o = new Db_Rou($row['rouid'], false);
			$o->init($row);
			$this->rouindex[$row['rou_name']] = $o;
		}
	}
	
	protected function getRou($name, $parent, $approver_uwnetid = null)
	{
		$parent = trim(str_replace('division', '', strtolower($parent)));
		if (!array_key_exists($parent, self::$divisions)) {
			throw new Exception('Undefined division "'.$parent.'"');
		}
		$div = self::$divisions[$parent];
		if (!$name) {
			$name = $div['name'];
		}
		$name = str_replace('(', '', $name);
		$name = str_replace(')', ':', $name);
		if (array_key_exists($name, $this->rouindex)) {
			return $this->rouindex[$name];
		}
		$rou = new Db_Rou(0);
		$rou->rou_name = $name;
		$rou->parent_rouid = $div['id'];
		if ($approver_uwnetid) {
			$person = Db_Person::FetchByUwnetid($approver_uwnetid);
			if ($person->recordExists()) {
				$rou->approver_personid = $person->personid;
			}
		}
		if (!$rou->approver_personid) {
			$rou->approver_personid = $div['approver'];
		}
		$this->rouperson = Db_Person::Get($div['staff']);
		$rou->addPerson($this->rouperson);
		$this->rouindex[$rou->rou_name] = $rou;
		return $rou;
	}
	
	/**
	 * Do import scrub and conversion routines on one record, but
	 * do not trigger save routines.
	 */
	public function readRecord()
	{
		// Read next record
		$this->record = $this->datareader->next();
		// Datareader returns false at end of input stream
		if ($this->record === false) {
			return false;
		}
		// How many fields did we find?
		$this->fieldcount = count($this->record);
		$this->rouperson = null;
		$this->rou = $this->getRou($this->getValue('rouname'), $this->getValue('division'), $this->getValue('approver'));
		$this->course = new Db_Course($this->getValue('courseid'));
		$this->course->rouid = $this->rou->rouid;
		return true;
	}
	
	public function saveRecord()
	{
		$this->rou->save();
		if ($this->course->recordExists()) {
			$this->course->rouid = $this->rou->rouid;
			$this->course->save();
		} else {
			debug(__METHOD__.' not a valid courseid '.$this->course->courseid);
		}
	}
	
}