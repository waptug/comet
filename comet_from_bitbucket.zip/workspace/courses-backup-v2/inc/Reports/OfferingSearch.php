<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Searches for offerings matching the provided search parameters
 * @author hanisko
 */
namespace Reports;

use Reports\Constants as RC;

class OfferingSearch extends CoursesAbstract
{
	private $sections;
	private $curricula;
	private $institution;
	private $keywords;
	private $numbers;
	private $quarters;
	private $years;
	
	public $query;
	public $courseid;
	public $curriculum;
	public $courseno;
	public $year;
	public $quarter;
	
	public static $quarter_map = array(
		'WINTER' => 1,
		'WIN'    => 1,
		'SPRING' => 2,
		'SPR'    => 2,
		'SUMMER' => 3,
		'SUM'    => 3,
		'AUTUMN' => 4,
		'AUT'    => 4,
		'FALL'   => 4,
	);
	
	/**
	 * Returns an array containing the key objects of this report, in the
	 * base implementation an array of Db_Offering objects.
	 * @return array[Db_Offering]
	 */
	public function getReport()
	{
		$this->lazyload();
		return $this->index['offerings'];
	}
		
	/**
	 * Gather reports parameters from user input. Fields are delivered though
	 * HTTP GET query string or HTTP POST fields. Optional $override array
	 * allows user input to be trumped by runtime parameters.
	 * @param array $override
	 */
	public function getUserInput($override = array())
	{
		$db = \DbFactory::GetConnection();
		$this->query = \Request::GetInstance()->getUserInput('q');
		$this->sections = array();
		$this->curricula = array();
		$this->coursenos = array();
		$this->institution = null;
		$this->keywords = array();
		$this->numbers = array();
		$this->quarters = array();
		$this->years = array();
		
		// break query into words
		$parsed = str_replace("\t", ' ', $this->query);
		$parsed = preg_replace('/  +/', ' ', $parsed);
		$parsed = trim($parsed);
		$words = explode(' ', $parsed);
		
		foreach ($words as $w) {
			if (!$w) continue;
			$w = strtoupper($w);
			if (array_key_exists($w, RC::$curriculum_map)) {
				$this->curricula[] = $db->quote(RC::$curriculum_map[$w]);	
			} elseif (array_key_exists($w, self::$quarter_map)) {
				$this->quarters[] = self::$quarter_map[$w];	
			} elseif (is_numeric($w)) {
				$w = (int)$w;
				if ($w > 99 && $w < 1000) {
					$this->coursenos[] = $w;
				} elseif ($w > 2000 && $w < 2050) {
					$this->years[] = $db->quote($w);
				} else {
					$this->numbers[] = $w;
				}
			} elseif (strlen($w) == 1) {
				$this->sections[] = $db->quote($w);	
			} elseif ($w == 'UWEO' || $w == 'STATE') {
				$this->institution = $db->quote($w);	
			} else {
				$this->keywords[] = $db->quote('%'.$w.'%');
			}
		}
	}
	
	/**
	 * Loads report data from the database. Handled automatically by getReport()
	 * method, but allows for alteration and re-running of query.
	 */
	public function load()
	{
		$this->initReport();
		$db = \DbFactory::GetConnection();
		$this->courseid = null;
		$this->curriculum = null;
		$this->courseno = null;
		$this->year = null;
		$this->quarter = null;
		
		if (count($this->curricula) == 1) $this->curriculum = $this->curricula[0];
		if (count($this->coursenos) == 1) $this->courseno = $this->coursenos[0];
		if (count($this->years) == 1)     $this->year = $this->years[0];
		if (count($this->quarters) == 1)  $this->quarter = $this->quarters[0];
		if ($this->curriculum && $this->courseno) {
			$sql = 'SELECT courseid '
			     . 'FROM course '
			     . 'WHERE curriculum = '.$this->curriculum.' '
			     . 'AND courseno = '.$this->courseno.' '
			     . 'ORDER BY wildcardtitle';
			$this->courseid = $db->fetchOne($sql);
		}
		$filters = array();
		$keyword_clause = '';
		if ($this->curricula) $filters[] = 'c.curriculum IN('.implode(',',$this->curricula).')';
		if ($this->institution) $filters[] = 'o.institution = '.$this->institution;
		if ($this->sections)  $filters[] = 'o.section IN('.implode(',',$this->sections).')';
		if ($this->years)     $filters[] = 'o.year IN('.implode(',',$this->years).')';
		if ($this->quarters)  $filters[] = 'o.quarter IN('.implode(',',$this->quarters).')';
		if ($this->coursenos) $filters[] = 'c.courseno IN('.implode(',',$this->coursenos).')';
		if ($this->numbers)   $filters[] = 'o.sln IN('.implode(',',$this->numbers).')';
		if ($this->keywords) {
			foreach ($this->keywords as $kw) {
				$kw_each = array();
				
				// Locate titles matching this keyword
				$kw_each[] = '(c.title LIKE '.$kw.' OR c.wildcardtitle LIKE '.$kw.')';
				
				// Locate people matching this keyword
				$person_filter = 'p.firstname LIKE '.$kw.' OR p.lastname LIKE '.$kw.' OR p.uwnetid LIKE '.$kw;
				$sql = 'SELECT DISTINCT s.offeringid FROM staff s INNER JOIN person p ON s.personid = p.personid WHERE '.$person_filter;
				$offering_ids_by_person = $db->fetchColumn($sql);
				if ($offering_ids_by_person) {
					$kw_each[] = '(o.offeringid IN('.implode(',',$offering_ids_by_person).'))';
				}
				
				// Locate tags matching this keyword
				$sql = 'SELECT DISTINCT tc.courseid FROM tagcourse tc INNER JOIN tag t ON tc.tagid = t.tagid WHERE t.name LIKE '.$kw;
				$course_ids_by_tag = $db->fetchColumn($sql);
				if ($course_ids_by_tag) {
					$kw_each[] = '(o.courseid IN('.implode(',',$course_ids_by_tag).'))';
				}
				
				// The outer filter needs only match one of these specific keyword conditions
				$filters[] = '('.implode(' OR ',$kw_each).')';
			}
		}
		$where = \DbObject::MakeWhereClause($filters);
		$sql = 'SELECT c.*, o.*, s.staffid, s.personid, s.role, s.timesched, s.buyoutreason, p.* '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'LEFT OUTER JOIN staff s '
		     . 'ON o.offeringid = s.offeringid '
		     . 'AND s.meetingnumber = 1 '
		     . 'AND s.timesched = 1 '
		     . 'LEFT OUTER JOIN person p '
		     . 'ON s.personid = p.personid '
		     . $where
		     .' ORDER BY o.year, o.quarter, c.curriculum, c.courseno, o.section, c.wildcardtitle, c.title';
		$this->sql = $sql;
		$results = $db->fetchAssoc($sql);
		//debug(__METHOD__."\n".$sql);
		foreach ($results as $row) {
			$offering = $this->registerOffering($row);
			$offering->setCourse($this->registerCourse($row));
			if ($row['staffid']) {
				$staff = $this->registerStaff($row);
				$staff->setPerson($this->registerPerson($row));
				$offering->setInstructor($staff);
			} else {
				$offering->noInstructor();
			}
		}
	}
	
}