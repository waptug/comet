<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report that returns a list of people
 * @author hanisko
 */
namespace Reports;

class People extends CoursesAbstract
{

	public function getConfig()
	{
		$config = array(
			'report-name'       => 'People',
			'picker-list'       => array(),
			'use-sticky-params' => true,
			'params'            => array(
				'division' => array('class-name' => 'Reports\Params\Division'),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
	public function getDivisions()
	{
		$this->lazyload();
		return $this->index['divisions'];
	}
	
	public function getPersonsByDivision($division) 
	{
		if (isset($this->index['by-division'][$division])) {
			return $this->index['by-division'][$division];
		} else {
			return array();
		}
	}

	/**
	 * Returns an array containing the key objects of this report, in the
	 * base implementation an array of Db_Offering objects.
	 * @return array[Db_Offering]
	 */
	public function getReport()
	{
		$this->lazyload();
		return $this->index['persons'];
	}
	
	public function initReport()
	{
		parent::initReport();
		$this->index['divisions'] = array(
			'und'   => 'Carol Davis',
			'grad'  => 'Joy Williamson-Lott',
			'pro'   => 'Cap Peck',
		);
		$this->index['by-division'] = array(
			'und'   => array(),
			'grad'  => array(),
			'pro'   => array(),
		);
	}

	/**
	 * Loads report data from the database. Handled automatically by getReport()
	 * method, but allows for alteration and re-running of query.
	 */
	public function load()
	{
		$this->initReport();
		$this->buildSqlPhrases();
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT p.* '
		     . 'FROM person p '
		     . $this->implodeSqlJoins()
		     . $this->implodeSqlFilters()
		     . 'ORDER BY p.lastname, p.firstname';
		$this->sql = $sql;
		$results = $db->fetchAssoc($sql);
		//debug(__METHOD__."\n".$sql);
		foreach ($results as $row) {
			$person = $this->registerPerson($row);
			if (isset($this->index['by-division'][$person->area])) {
				$this->index['by-division'][$person->area][] = $person;
			}
		}
	}

}