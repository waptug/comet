<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report of course records with repetition rules
 * @author hanisko
 */
namespace Reports;

class CoursesRepetition extends Courses
{
	
	public function getConfig()
	{
		$config = array(
			'report-name'       => 'Courses with Repetition Rules',
			'picker-list'       => array('curriculum', 'rou'),
			'params'            => array(
				'curriculum' => array('class-name' => 'Reports\Params\Curriculum'),
				'tag'        => array('class-name' => 'Reports\Params\CourseTag'),
				'hasrule'    => array('class-name' => 'Reports\Params\CourseRepetition'),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
}