<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report of offerings with a specific tag
 * @author hanisko
 */
namespace Reports;

class Tags extends Offerings
{
	
	public function getConfig()
	{
		$config = array(
			'report-name'  => 'Tags',
			'listeners'    => array('\Reports\TimePeriod\CurrentAcademicYear', '\Reports\TimePeriod\AcademicYearOnly'),
			'picker-list'  => array('year', 'curriculum', 'tag'),
			'params'       => array(
				'tag'      => array(
					'class-name' => 'Reports\Params\Tag', 
					'default'    => 'TEP', 
					'required'   => true),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
}