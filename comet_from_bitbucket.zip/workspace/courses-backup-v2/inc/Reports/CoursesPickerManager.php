<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Manages the parameter value picker interface for a report. Keeps track
 * of which pickers the report is using and includes HTML fragments to 
 * support them.
 * @author hanisko
 */
namespace Reports;

class CoursesPickerManager
{

	protected static $PickerIncludes = array(
		'curriculum'  => 'tools/part-curriculum-picker.phtml',
		'quarter'     => 'tools/part-quarter-picker.phtml',
		'rou'         => 'tools/part-rou-picker.phtml',
		'roomstatus'  => 'tools/part-roomstatus-picker.phtml',
		'tag'         => 'tools/part-tag-picker.phtml',
		'tags'        => '',
		'year'        => 'tools/part-year-picker.phtml',
		'staffroles'  => 'tools/part-staffroles-picker.phtml',
		'haschange'   => 'tools/part-haschange-picker.phtml'
	);
	
	protected $pickers;
	
	public function __construct($pickers)
	{
		$this->pickers = array();
		foreach ($pickers as $name) {
			$this->addPicker($name);
		}
	}
	
	public function addPicker($name)
	{
		if ($this->hasPicker($name)) {
			return;
		}
		if (!array_key_exists($name, self::$PickerIncludes)) {
			throw new \Exception('Unconfigured picker '.$name.' added to report');
		}
		$this->pickers[] = $name;
	}
	
	public function getPickerList()
	{
		return $this->pickers;
	}
	
	public function hasPicker($name)
	{
		return in_array($name, $this->pickers);	
	}
	
	public function includePickers()
	{
		foreach ($this->pickers as $name) {
			include self::$PickerIncludes[$name];
		}
	}
	
}