<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report of offerings that need attention in UW Time Schedule
 * @author hanisko
 */
namespace Reports;

use Reports\Constants as RC;

class TimeSchedule extends Offerings
{
	
	public function getConfig()
	{
		$config = array(
			'report-name'       => 'UW Time Schedule',
			'listeners'         => array('\Reports\TimePeriod\NextQuarter'),
			'use-sticky-params' => true,
			'picker-list'       => array('quarter', 'curriculum'),
			'params'      => array(
				'quarter'        => array('class-name' => 'Reports\Params\Quarter', 'required' => true),
				'curriculum'     => array(
					'class-name' => 'Reports\Params\Curriculum', 
					'default'    => 'EDC&I', 
					'required'   => false),
				'uwtsstatus'     => array(
					'class-name' => 'Reports\Params\UwtsStatus', 
					'default'    => RC::SHOW_NEEDS_ACTION, 
					'required'   => true),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
}