<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report of offerings within a specific academic year
 * @author hanisko
 */
namespace Reports;

class YearSummary extends Offerings
{
	
	public function getConfig()
	{
		$config = array(
			'report-name'  => 'Year Summary',
			'listeners'    => array('\Reports\TimePeriod\CurrentAcademicYear', '\Reports\TimePeriod\AcademicYearOnly'),
			'picker-list'  => array('year', 'curriculum'),
			'params'       => array(
				'curriculum'     => array(
					'class-name' => 'Reports\Params\Curriculum', 
					'default'    => 'EDUC', 
					'required'   => false),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
}