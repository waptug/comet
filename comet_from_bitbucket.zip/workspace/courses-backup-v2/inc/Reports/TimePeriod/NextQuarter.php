<?php
/**
 * @package UW_COE_Courses
 */
/**
 * A report listener that sets the report default year and quarter to
 * the next quarter.
 * @author hanisko
 */
namespace Reports\TimePeriod;

use UwCoeFramework\Reports\ReportAbstract;

class NextQuarter extends SetQuarterAbstract
{
	
	public function setDefaultQuarter(ReportAbstract $report)
	{
		if ($this->currentQuarter->quarter == 4) {
			$report->getParam('year')->setDefault($this->currentQuarter->year + 1);
			$report->getParam('quarter')->setDefault(1);
		} else {
			$report->getParam('year')->setDefault($this->currentQuarter->year);
			$report->getParam('quarter')->setDefault($this->currentQuarter->quarter + 1);
		}
	}
	
}
