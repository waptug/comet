<?php
/**
 * @package UW_COE_Courses
 */
/**
 * A report listener that forces the report to be based on an Academic Year
 * by removing the quarter parameter.
 * @author hanisko
 */
namespace Reports\TimePeriod;

use UwCoeFramework\Reports\ReportAbstract;
use UwCoeFramework\Reports\ListenerInterface;

class AcademicYearOnly implements ListenerInterface
{
	public function trigger($eventname, ReportAbstract $report)
	{
		switch ($eventname) {
			case 'config.post':
				$this->lockQuarterParam($report);
				break;
			default:
				break;
		}
	}
	
	public function lockQuarterParam(ReportAbstract $report) 
	{
		$report->getParam('quarter')->setDefault(null);
		$report->getParam('quarter')->setLocked(true);
	}
	
}
