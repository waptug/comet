<?php
/**
 * @package UW_COE_Courses
 */
/**
 * A report listener that sets the report default year and quarter to
 * a specific time period relative to the current quarter.
 * @author hanisko
 */
namespace Reports\TimePeriod;

use UwCoeFramework\Reports\ReportAbstract;
use UwCoeFramework\Reports\ListenerInterface;

abstract class SetQuarterAbstract implements ListenerInterface
{
	protected $currentQuarter;

	public function __construct()
	{
		$this->currentQuarter = \Db_Quarter::FetchCurrentQuarter();
	}
	
	public function trigger($eventname, ReportAbstract $report)
	{
		switch ($eventname) {
			case 'config.post':
				$this->setDefaultQuarter($report);
				break;
			default:
				break;
		}
	}
	
	abstract public function setDefaultQuarter(ReportAbstract $report);
	
}
