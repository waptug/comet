<?php
/**
 * @package UW_COE_Courses
 */
/**
 * A report listener that sets the report default year and quarter to
 * the current academic year.
 * @author hanisko
 */
namespace Reports\TimePeriod;

use UwCoeFramework\Reports\ReportAbstract;

class CurrentAcademicYear extends SetQuarterAbstract
{
	
	public function setDefaultQuarter(ReportAbstract $report)
	{
		if ($this->currentQuarter->quarter == 4) {
			// in Autumn this year is the academic year
			$report->getParam('year')->setDefault($this->currentQuarter->year);
		} else {
			// in Winter, Spring, and Summer, last year indicates the current academic year
			$report->getParam('year')->setDefault($this->currentQuarter->year - 1);
		}
		$report->getParam('quarter')->setDefault(null);
	}
	
}
