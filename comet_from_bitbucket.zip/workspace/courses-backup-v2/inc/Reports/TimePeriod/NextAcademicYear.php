<?php
/**
 * @package UW_COE_Courses
 */
/**
 * A report listener that sets the report default year and quarter to
 * the next academic year.
 * @author hanisko
 */
namespace Reports\TimePeriod;

use UwCoeFramework\Reports\ReportAbstract;

class setDefaultQuarter extends SetQuarterAbstract
{
	
	public function setDefaultQuarter(ReportAbstract $report)
	{
		$report->getParam('year')->setDefault($this->currentQuarter->year);
		$report->getParam('quarter')->setDefault($this->currentQuarter->quarter);
	}
	
}
