<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report of meetings times for a specific quarter
 * @author hanisko
 */
namespace Reports;

use UwCoeFramework\Reports\Configuration;
use Reports\Constants as RC;

class Meetings extends Offerings
{
	public function getConfig()
	{
		$config = array(
			'report-name'  => 'Meetings',
			'listeners'    => array('\Reports\TimePeriod\CurrentQuarter'),
			'picker-list'  => array('quarter', 'curriculum'),
			'params'       => array(
				'quarter'     => array('class-name' => 'Reports\Params\Quarter', 'required' => true),
				'hasmeetings' => array('class-name' => 'Reports\Params\Quarter', 'default' => null, 'use-sticky' => false),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
	public function getReport()
	{
		$this->lazyload();
		return $this->index['weekview'];
	}
	
	public function getMeetings()
	{
		$this->lazyload();
		return $this->index['meetings'];
	}
	
	protected function initReport()
	{
		parent::initReport();
		$this->index['weekview'] = array(array(),array(),array(),array(),array(),array(),array());
	}

	public function load()
	{
		$this->initReport();
		$this->buildSqlPhrases();
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT md.*, m.*, o.*, c.* '
		     . 'FROM meetingday md '
		     . 'INNER JOIN meeting m '
		     . 'ON md.meetingid = m.meetingid '
		     . 'INNER JOIN offering o '
		     . 'ON m.offeringid = o.offeringid '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . $this->implodeSqlJoins()
		     . $this->implodeSqlFilters()
		     . 'ORDER BY md.dow, m.start, m.end, o.year, o.quarter, c.curriculum, c.courseno, o.section, c.wildcardtitle, c.title';
		$this->sql = $sql;
		$results = $db->fetchAssoc($sql);
		$dedupe = array(array(),array(),array(),array(),array(),array(),array());
		foreach ($results as $row) {
			if (isset($dedupe[$row['dow']][$row['meetingid']])) continue;
			$offering = $this->registerOffering($row);
			$offering->setCourse($this->registerCourse($row));
			$meeting = $this->registerMeeting($row);
			$meeting->setOffering($offering);
			$this->index['weekview'][$row['dow']][] = $meeting;
			$dedupe[$row['dow']][$row['meetingid']] = true;
		}
	}
	
}