<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report of course records with a specific tag
 * @author hanisko
 */
namespace Reports;

class TagCourses extends Courses
{
	
	public function getConfig()
	{
		$config = array(
			'report-name'       => 'Courses by Tag',
			'picker-list'       => array('tag', 'curriculum'),
			'use-sticky-params' => true,
			'params'            => array(
				'curriculum'    => array('class-name' => 'Reports\Params\Curriculum'),
				'tag'           => array(
					'class-name'   => 'Reports\Params\CourseTag', 
					'default'      => 4, // 'TEP'
					'required'     => true
				),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
}