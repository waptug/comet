<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report of offerings that can be edited by a repetion rule
 * @author hanisko
 */
namespace Reports;

class RepetitionUpdateable extends CoursesAbstract
{
	
	public function getConfig()
	{
		$config = array(
			'report-name'  => 'Updateable Repetition',
			'params'       => array(
				'repetition'   => array('class-name' => 'Reports\Params\RepetitionRule'),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
	public function load()
	{
		$this->initReport();
		$db = \DbFactory::GetConnection();
		$cq = \Db_Quarter::FetchCurrentQuarter();
		$y = $db->quote($cq->year);
		$q = $cq->quarter;
		$sql = 'SELECT c.*, o.*, s.staffid, s.personid, s.role, s.timesched, s.buyoutreason, p.* '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'LEFT OUTER JOIN staff s '
		     . 'ON o.offeringid = s.offeringid '
		     . 'AND s.meetingnumber = 1 '
		     . 'AND s.timesched = 1 '
		     . 'LEFT OUTER JOIN person p '
		     . 'ON s.personid = p.personid '
		     . "WHERE (o.year > '".$cq->year."' OR (o.year > '".$cq->year."' AND o.quarter >= ".$q.')) '
		     . 'AND o.repetitionid = '.$this->getValue('repetition').' '
		     . 'AND o.status = \'expected\' '
		     . 'ORDER BY o.year, o.quarter, c.curriculum, c.courseno, o.section, c.wildcardtitle, c.title';
		$this->sql = $sql;
		$results = $db->fetchAssoc($sql);
		//debug(__METHOD__."\n".$sql);
		foreach ($results as $row) {
			$offering = $this->registerOffering($row);
			$offering->setCourse($this->registerCourse($row));
			if ($row['staffid']) {
				$staff = $this->registerStaff($row);
				$staff->setPerson($this->registerPerson($row));
				$offering->setInstructor($staff);
			} else {
				$offering->noInstructor();
			}
		}
	}

	public function getReport()
	{
		$this->lazyload();
		return $this->index['offerings'];
	}
	
}