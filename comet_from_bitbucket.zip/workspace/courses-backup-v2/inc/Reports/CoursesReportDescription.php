<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Inspects settings on a Reports_Courses object and provide human readable
 * text description of the report parameters.
 * @author hanisko
 */
namespace Reports;

use UwCoeFramework\Reports\DescriptionAbstract;
use UwCoeFramework\Reports\ReportAbstract;
 
class CoursesReportDescription extends DescriptionAbstract
{
	private static $ordered_params = array(
		'year',
		'quarter',
		'curriculum',
		'rou',
		'tags'		
	);

	/**
	 * Returns an array of parameter value descriptions suitable for building a
	 * download filename.
	 * @return array
	 */
	public function getFilenameParts()
	{
		$out = array($this->report->getReportName());
		foreach (self::$ordered_params as $name) {
			if ($this->report->hasParam($name)) {
				$text = $this->report->getParam($name)->getDescriptionFilename();
				if ($text) $out[] = $text;
			}
		}
		foreach ($this->report->getParamList() as $name => $param) {
			if (!in_array($name, self::$ordered_params)) {
				$text = $param->getDescriptionFilename();
				if ($text) $out[] = $text;
			}
		}
		return $out;
	}

	public function getFullDescription()
	{
		return implode(', ', $this->getFullDescriptionParts());
	}
	
	/**
	 * Returns an ordered array describing the key parameter values of this report
	 * @return array
	 */
	public function getFullDescriptionParts()
	{
		$out = array($this->report->getReportName());
		foreach (self::$ordered_params as $name) {
			if ($this->report->hasParam($name)) {
				$text = $this->report->getParam($name)->getDescription();
				if ($text) $out[] = $text;
			}
		}
		foreach ($this->report->getParamList() as $name => $param) {
			if (!in_array($name, self::$ordered_params)) {
				$text = $param->getDescription();
				if ($text) $out[] = $text;
			}
		}
		return $out;
	}
	
	public function getPeriod()
	{
		if ($this->report->hasParam('period')) {
			return $this->report->getParam('period')->getDescription();
		}
		if (!$this->report->hasParam('year')) {
			return '';
		}
		$year = $this->report->getParam('year')->getValue();
		if (!$this->report->hasParam('quarter') || is_null($this->report->getParam('quarter')->getValue())) {
			return $year.'-'.($year+1);
		} else {
			return eQuarter($year, $this->report->getParam('quarter')->getValue());
		}
	}
	
}