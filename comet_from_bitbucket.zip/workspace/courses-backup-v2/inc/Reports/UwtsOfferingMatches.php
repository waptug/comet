<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Generates a report of course offerings that match on year, quarter, curriculum
 * and course number. This report is used for linking UWTS cache records to local
 * plan records.
 * @author hanisko
 */
namespace Reports;

use Reports\Constants as RC;

class UwtsOfferingMatches extends Offerings
{
	
	public function getConfig()
	{
		$config = array(
			'report-name'  => 'Link to UWTS',
			'params'       => array(
				'courseno'     => array(
					'class-name' => 'Reports\Params\Courseno'),
				'uwtslinked'     => array(
					'class-name' => 'Reports\Params\UwtsLinked', 
					'default'    => RC::SHOW_ALL),
				'canceled'     => array(
					'class-name' => 'Reports\Params\Canceled', 
					'default'    => RC::SHOW_ALL),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}

	public function __construct(\Db_UwtsOffering $uwts)
	{
		parent::__construct();
		$this->getParam('year')->setValue($uwts->year);
		$this->getParam('quarter')->setValue($uwts->quarter);
		$this->getParam('curriculum')->setValue($uwts->curriculum);
		$this->getParam('courseno')->setValue($uwts->courseno);
	}
	
}
