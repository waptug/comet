<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Adds application specific functionality to the ReportAbstract class
 * @author hanisko
 */
namespace Reports;

class Rous extends CoursesAbstract
{
	public function getConfig()
	{
		$config = array(
			'report-name'       => 'Responsible Organizational Units',
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
	protected function initReport()
	{
		$this->index['rous'] = array();
		$this->index['top'] = array();
	}
	
	/**
	 * Query the data store and populate the object tree that makes up this report
	 */
	public function load()
	{
		$this->initReport();
		$db = \DbFactory::GetConnection();
		// load ROUs
		$sql = 'SELECT r.*, p.* '
		     . 'FROM rou r '
		     . 'INNER JOIN person p '
		     . 'ON r.approver_personid = p.personid '
		     . 'ORDER BY r.rou_name, p.lastname, p.firstname';
		$this->sql = $sql;
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			$rou = \Db_Rou::Register($row);
			$rou->setPersons(array());
			$person = \Db_Person::Register($row);
			$rou->setApprover($person);
			$this->index['rous'][$row['rouid']] = $rou;
			if (!$rou->parent_rouid) {
				$this->index['top'][] = $rou;
			}
		}
		// link rous to their parents
		foreach ($this->index['rous'] as $rou) {
			if (array_key_exists($rou->parent_rouid, $this->index['rous'])) {
				$this->index['rous'][$rou->parent_rouid]->addChildRou($rou);
			}
		}
		// load admins
		$sql = 'SELECT rp.rouid, p.* '
		     . 'FROM rouperson rp '
		     . 'INNER JOIN person p '
		     . 'ON rp.personid = p.personid '
		     . 'ORDER BY p.lastname, p.firstname';
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			if (array_key_exists($row['rouid'], $this->index['rous'])) {
				$person = \Db_Person::Register($row);
				$this->index['rous'][$row['rouid']]->addPerson($person);
			}
		}
	}
	
	public function getReport()
	{
		$this->lazyload();
		return $this->index['top'];
	}
	
	public function getSelectOptions()
	{
		$this->lazyload();
		$out = array();
		foreach ($this->getReport() as $rou) {
			$out[$rou->rouid] = '** '.$rou->rou_name.' **';
    		foreach ($rou->getChildRous() as $child_rou) {
    			$out[$child_rou->rouid] = $child_rou->rou_name;
    		}    
    	}
    	return $out;
	}
	
}