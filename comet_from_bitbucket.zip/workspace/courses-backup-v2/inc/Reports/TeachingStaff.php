<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report of offerings with a specific tag
 * @author hanisko
 */
namespace Reports;

class TeachingStaff extends Offerings
{
	
	public function getConfig()
	{
		$config = array(
			'report-name'  => 'Teaching Staff',
			'listeners'    => array('\Reports\TimePeriod\CurrentQuarter'),
			'picker-list'  => array('quarter', 'curriculum', 'staffroles'),
			'params'       => array(
				'staffroles'     => array('class-name' => 'Reports\Params\StaffRoles', 'default' => 2),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
	/**
	 * Returns an array containing the key objects of this report, in this
	 * report, an array of Db_Staff objects.
	 * @return array[Db_Staff]
	 */
	public function getReport()
	{
		$this->lazyload();
		return $this->index['report'];
	}
	
	/**
	 * Returns an array of Db_Person objects included in this report.
	 * @return array[Db_Person]
	 */
	public function getPeople()
	{
		$this->lazyload();
		return $this->index['persons'];
	}
	
	protected function initReport()
	{
		parent::initReport();
		$this->index['report'] = array();
	}
	
	/**
	 * Loads report data from the database. Handled automatically by getReport()
	 * method, but allows for alteration and re-running of query.
	 */
	public function load()
	{
		$db = \DbFactory::GetConnection();
		$this->initReport();
		$this->buildSqlPhrases();
		$sql = 'SELECT c.*, o.*, s.staffid, s.personid, s.role, s.timesched, s.buyoutreason, p.* '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'INNER JOIN staff s '
		     . 'ON o.offeringid = s.offeringid '
		     . 'INNER JOIN person p '
		     . 'ON s.personid = p.personid '
		     . $this->implodeSqlJoins()
		     . $this->implodeSqlFilters()
		     .' ORDER BY o.year, o.quarter, c.curriculum, c.courseno, o.section, c.wildcardtitle, c.title';
		$this->sql = $sql;
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			$offering = $this->registerOffering($row);
			$offering->setCourse($this->registerCourse($row));
			if ($row['staffid']) {
				$staff = $this->registerStaff($row);
				$staff->setPerson($this->registerPerson($row));
				if ($staff->role == 'buyout') {
					$offering->setBuyout($staff);
				} else {
					$staff->setOffering($offering);
					$this->index['report'][] = $staff;
				}
			} else {
				$offering->noInstructor();
			}
		}
	}
	
}