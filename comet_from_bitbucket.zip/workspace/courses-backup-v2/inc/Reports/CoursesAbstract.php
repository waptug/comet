<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Adds application specific functionality to the ReportAbstract class
 * @author hanisko
 */
namespace Reports;

use UwCoeFramework\Reports\ReportAbstract;
use UwCoeFramework\Reports\Configuration;

abstract class CoursesAbstract extends ReportAbstract
{
	protected $objectTypes = array(
		'courses'   => '\Db_Course',
		'offerings' => '\Db_Offering',
		'meetings'  => '\Db_Meeting',
		'staff'     => '\Db_Staff',
		'persons'   => '\Db_Person',
		'rous'      => '\Db_Rou',
	);
	
	protected $index;
	protected $viewCsvUrl;
	
	public $csvview;
	public $intro;
	public $title;
	public $type;
	public $view;
	
	/**
	 * @return the $viewCsvUrl
	 */
	public function getViewCsvUrl ()
	{
		if ($this->viewCsvUrl) {
			return $this->viewCsvUrl;
		} else {
			return '/reports/csv/offerings';
		}
	}

	/**
	 * @param field_type $viewCsvUrl
	 */
	public function setViewCsvUrl($viewCsvUrl)
	{
		$this->viewCsvUrl = $viewCsvUrl;
	}

	public function __get($name)
	{
		switch($name) {
			case 'description':
				return $this->getDescriptionStrategy();
				break;
			default:
				return null;
				break;
		}
	}
	
	/**
	 * Return an array that provides configuration parameters for this report
	 * @return array
	 */
	public function getConfig()
	{
		return array(
			'picker-manager' => '\Reports\CoursesPickerManager',
			'describer'      => '\Reports\CoursesReportDescription',
		);
	}
	
	/**
	 * Return a human readable string describing a time period this report covers
	 * @return string
	 */
	public function getPeriod()
	{
		if ($this->describer) {
			return $this->describer->getPeriod();
		} else {
			return '';
		}
	}
	
	/**
	 * Returns true if this report has a quarter based period and includes more
	 * than one quarter
	 * @return boolean
	 */
	public function includesMultipleQuarters()
	{
		if ($this->hasParam('year')) {
			if ($this->hasParam('quarter')) {
				if ($this->getValue('quarter') == 0) {
					return true;
				}
				if ($this->hasParam('length') && $this->getValue('length') > 1) {
					return true;
				}
				// has non zero quarter and no length 
				return false;
			}
			// has year, not quarter, Academic year
			return true;
		}
		// no year, not time period based report
		return false;
	}

	/**
	 * Reset the internal object registries to empty arrays. Call this before 
	 * loading a report.
	 */
	protected function initReport()
	{
		$this->index = array();
		foreach ($this->objectTypes as $type => $classname) {
			$this->index[$type] = array();
		}
	}
	
	/**
	 * Load report objects from the database, but only if they have not already
	 * been loaded
	 */
	public function lazyload()
	{
		if (!is_array($this->index)) {
			$this->load();
		}
	}
	
	/**
	 * Provides a generic register implementation for objects that require
	 * only a single $id field in their constructor
	 * @param string $type
	 * @param string $id
	 * @param array $row
	 * @return mixed
	 */
	protected function registerObject($type, $id, $row) 
	{
		if (!isset($this->index[$type][$id])) {
			$classname = $this->objectTypes[$type];
			$this->index[$type][$id] = new $classname($id, false);
			$this->index[$type][$id]->init($row);
		}
		return $this->index[$type][$id];
	}
	
	/**
	 * Verify that a Db_Course object matching the data specified in the
	 * associative array $row exists in the registry. Create the object
	 * if needed and return the object.
	 * @param array $row
	 * @return Db_Course
	 */
	protected function registerCourse($row)
	{
		return $this->registerObject('courses', $row['courseid'], $row);
	}
	
	/**
	 * Verify that a Db_Meeting object matching the data specified in the
	 * associative array $row exists in the registry. Create the object
	 * if needed and return the object.
	 * @param array $row
	 * @return Db_Meeting
	 */
	protected function registerMeeting($row)
	{
		return $this->registerObject('meetings', $row['meetingid'], $row);
	}
	
	/**
	 * Verify that a Db_Offering object matching the data specified in the
	 * associative array $row exists in the registry. Create the object
	 * if needed and return the object.
	 * @param array $row
	 * @return Db_Offering
	 */
	protected function registerOffering($row)
	{
		return $this->registerObject('offerings', $row['offeringid'], $row);
	}
	
	/**
	 * Verify that a Db_Staff object matching the data specified in the
	 * associative array $row exists in the registry. Create the object
	 * if needed and return the object.
	 * @param array $row
	 * @return Db_Staff
	 */
	protected function registerStaff($row)
	{
		return $this->registerObject('staff', $row['staffid'], $row);
	}
	
	/**
	 * Verify that a Db_Person object matching the data specified in the
	 * associative array $row exists in the registry. Create the object
	 * if needed and return the object.
	 * @param array $row
	 * @return Db_Person
	 */
	protected function registerPerson($row)
	{
		return $this->registerObject('persons', $row['personid'], $row);
	}
	
	/**
	 * Verify that a Db_Rou object matching the data specified in the
	 * associative array $row exists in the registry. Create the object
	 * if needed and return the object.
	 * @param array $row
	 * @return Db_Rou
	 */
	protected function registerRou($row)
	{
		return $this->registerObject('rous', $row['rouid'], $row);
	}
	
}
