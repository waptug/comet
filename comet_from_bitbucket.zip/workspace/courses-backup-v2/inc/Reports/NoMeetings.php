<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report of meetings times for a specific quarter
 * @author hanisko
 */
namespace Reports;

use UwCoeFramework\Reports\Configuration;
use Reports\Constants as RC;

class NoMeetings extends Offerings
{
	public function getConfig()
	{
		$config = array(
			'report-name'  => 'No Meetings',
			'listeners'    => array('\Reports\TimePeriod\CurrentQuarter'),
			'picker-list'  => array('quarter', 'curriculum'),
			'params'       => array(
				'quarter'     => array('class-name' => 'Reports\Params\Quarter', 'required' => true),
				'hasmeetings' => array('class-name' => 'Reports\Params\Quarter', 'default' => RC::MEETINGS_NO_MEETINGS, 'use-sticky' => false),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
	public function getReport()
	{
		$this->lazyload();
		return $this->index['offerings'];
	}

	public function load()
	{
		$this->initReport();
		$this->buildSqlPhrases();
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT c.*, o.*, s.staffid, s.personid, s.role, s.timesched, s.buyoutreason, p.* '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'LEFT OUTER JOIN staff s '
		     . 'ON o.offeringid = s.offeringid '
		     . 'AND s.timesched = 1 '
		     . 'LEFT OUTER JOIN person p '
		     . 'ON s.personid = p.personid '
		     . $this->implodeSqlJoins()
		     . $this->implodeSqlFilters()
		     . 'ORDER BY o.year, o.quarter, c.curriculum, c.courseno, o.section, c.wildcardtitle, c.title';
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			$offering = $this->registerOffering($row);
			$offering->setCourse($this->registerCourse($row));
			if ($row['staffid']) {
				$staff = $this->registerStaff($row);
				$staff->setPerson($this->registerPerson($row));
				$offering->setInstructor($staff);
			} else {
				$offering->noInstructor();
			}
		}
	}
	
}