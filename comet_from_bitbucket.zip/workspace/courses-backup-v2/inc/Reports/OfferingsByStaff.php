<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report of offerings with a specific tag
 * @author hanisko
 */
namespace Reports;

use \Reports\Constants as RC;

class OfferingsByStaff extends Offerings
{
	
	public function getConfig()
	{
		$config = array(
			'report-name'       => 'Tags',
			'listeners'         => array('\Reports\TimePeriod\CurrentAcademicYear', '\Reports\TimePeriod\AcademicYearOnly'),
			'use-sticky-params' => false,
			'picker-list'       => array('year'),
			'params'            => array(
				'buyoutfor' => array('class-name' => 'Reports\Params\Buyoutfor'),
				'uwnetid'   => array('class-name' => 'Reports\Params\Uwnetid'),
				'classroom' => array('class-name' => 'Reports\Params\Classroom', 'default' => RC::SHOW_ALL),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
	/**
	 * Query the data store and populate the object tree that makes up this report
	 */
	public function load()
	{
		$this->initReport();
		$this->index['byquarter'] = array(1=>array(),2=>array(),3=>array(),4=>array());
		$this->buildSqlPhrases();
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT c.*, o.* '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'LEFT OUTER JOIN staff s '
		     . 'ON o.offeringid = s.offeringid '
		     . 'LEFT OUTER JOIN person p '
		     . 'ON s.personid = p.personid '
		     . $this->implodeSqlJoins()
		     . $this->implodeSqlFilters()
		     .' ORDER BY o.year, o.quarter, c.curriculum, c.courseno, o.section, c.wildcardtitle, c.title';
		$this->sql = $sql;
		$results = $db->fetchAssoc($sql);
		//debug(__METHOD__."\n".$sql);
		foreach ($results as $row) {
			$offering = $this->registerOffering($row);
			$offering->setCourse($this->registerCourse($row));
			// create a reference to this offering in the By Quarter structure
			if ($row['quarter'] > 0 && $row['quarter'] < 5) {
				$this->index['byquarter'][$row['quarter']][] = $offering;
			}
		}
	}
	
}