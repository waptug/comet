<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Container for constants shared by Courses reports
 * @author hanisko
 */
namespace Reports;

class Constants
{
	const SHOW_ALL = 1;
	const SHOW_ONLY = 2;
	const SHOW_NOT = 3;
	
	const SHOW_NEEDS_ACTION = 2;
	const SHOW_UP_TO_DATE = 3;
	
	// Constants for enrollment
	const ENROLLMENT_FIELD_EXPECTED = 1;
	const ENROLLMENT_FIELD_ACTUAL = 2;
	const ENROLLMENT_LARGE = 40;
	const ENROLLMENT_LOW = 30;
	
	// Constants for Param\HasMeeting
	const MEETINGS_HAS_MEETINGS = 1;
	const MEETINGS_NO_MEETINGS = 2;

	public static $quarter_map = array(
		'winter' => 1,
		'win'    => 1,
		'spring' => 2,
		'spr'    => 2,
		'summer' => 3,
		'sum'    => 3,
		'autumn' => 4,
		'aut'    => 4,
		'fall'   => 4,
		'all'    => null
	);

	public static $curriculum_map = array(
		'EDC&I' => 'EDC&I',
		'EDCI'  => 'EDC&I',
		'EDPSY' => 'EDPSY',
		'EDLPS' => 'EDLPS',
		'EDSPE' => 'EDSPE',
		'ECFS'  => 'ECFS',
		'EDTEP' => 'EDTEP',
		'TEP'   => 'EDTEP',
		'EDUC'  => 'EDUC',
		'ALL'   => null
	);
}