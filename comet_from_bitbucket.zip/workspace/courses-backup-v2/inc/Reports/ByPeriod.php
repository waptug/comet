<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Adds application specific functionality to the ReportAbstract class
 * @author hanisko
 */
namespace Reports;

use UwCoeFramework\Reports\Configuration;
use Reports\Constants as RC;

class ByPeriod extends Offerings
{
	
	public function getConfig()
	{
		$config = array(
			'report-name'       => 'Offerings',
			'listeners'         => array('\Reports\TimePeriod\CurrentQuarter'),
			'use-sticky-params' => true,
			'picker-list'       => array('quarter', 'curriculum'),
			'params'            => array(
				'period'          => array('class-name' => 'Reports\Params\Period'),
				'year'            => array('class-name' => 'Reports\Params\Year'),
				'quarter'         => array('class-name' => 'Reports\Params\Quarter'),
				'length'          => array('class-name' => 'Reports\Params\Length'),
				'tag'             => null,
				'tags'            => array('class-name' => 'Reports\Params\Tags'),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
		
}