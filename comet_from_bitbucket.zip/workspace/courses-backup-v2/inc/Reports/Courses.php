<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report of course records with a specific tag
 * @author hanisko
 */
namespace Reports;

class Courses extends CoursesAbstract
{
	
	public function getConfig()
	{
		$config = array(
			'report-name'       => 'Courses',
			'picker-list'       => array('curriculum', 'tag'),
			'use-sticky-params' => true,
			'params'            => array(
				'curriculum' => array('class-name' => 'Reports\Params\Curriculum'),
				'tag'        => array('class-name' => 'Reports\Params\CourseTag'),
				'rou'        => array('class-name' => 'Reports\Params\Rou'), 
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}

	/**
	 * Returns an array containing the key objects of this report, in the
	 * base implementation an array of Db_Offering objects.
	 * @return array[Db_Offering]
	 */
	public function getReport()
	{
		$this->lazyload();
		return $this->index['courses'];
	}
	
	/**
	 * Loads report data from the database. Handled automatically by getReport()
	 * method, but allows for alteration and re-running of query.
	 */
	public function load()
	{
		$this->initReport();
		$this->buildSqlPhrases();
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT c.*, r.* '
		     . 'FROM course c '
		     . 'INNER JOIN rou r '
		     . 'ON c.rouid = r.rouid '
		     . $this->implodeSqlJoins()
		     . $this->implodeSqlFilters()
		     . 'ORDER BY c.curriculum, c.courseno, c.wildcardtitle, c.title';
		$this->sql = $sql;
		$results = $db->fetchAssoc($sql);
		//debug(__METHOD__."\n".$sql);
		foreach ($results as $row) {
			$course = $this->registerCourse($row);
			$course->setRou($this->registerRou($row));
		}
		foreach ($this->index['rous'] as $rou) {
			if ($rou->parent_rouid && array_key_exists($rou->parent_rouid, $this->index['rous'])) {
				$rou->setParent($this->index['rous'][$rou->parent_rouid]);
			}
		}
	}
	
}