<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report of offerings that have changes requests
 * @author hanisko
 */
namespace Reports;

class ChangeRequests extends Offerings
{
	
	public function getConfig()
	{
		$config = array(
			'report-name'  => 'Change Requests',
			'listeners'    => array('\Reports\TimePeriod\NextQuarter'),
			'picker-list'  => array('year', 'curriculum', 'haschange'),
			'params'       => array(
				'haschange'      => array(
					'class-name' => 'Reports\Params\HasChange', 
					'default'    => 1, // 'Open Change Requests' 
					'required'   => true),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
}