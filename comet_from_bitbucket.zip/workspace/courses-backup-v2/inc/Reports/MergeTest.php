<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Adds application specific functionality to the ReportAbstract class
 * @author hanisko
 */
namespace Reports;

use UwCoeFramework\Reports\Configuration;

class MergeTest extends Offerings
{
	public function getConfig()
	{
		$config = array(
			'report-name'       => 'MergeTest',
			'params'            => array(
				'year' => array(
					'default'        => 2015,
					'value'          => 2015,
				),
				'quarter' => null,
				'someparam' => array(
					'class-name'     => 'Reports\Params\SomeParam',
					'default'        => 'test',
					'make-null'      => array(0,''),
					'locked'         => false,
					'required'       => false,
					'use-sticky'     => true,
					'value'          => 'test',
					'url-param'      => 'something',
					'scrub-strategy' => 'Default'
				),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
		
	/**
	 * Query the data store and populate the object tree that makes up this report
	 */
	public function load()
	{
		
	}
	
}