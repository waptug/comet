<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Parameter that filters reports based on whether offerings have
 * change requests link to them.
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class HasMeeting extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'hasmeeting';
	protected $usesticky = true;
	protected $value = null;
	
	public static $hasmeeting_values = array(
		0 => 'All offerings',
		1 => 'Has meetings',
		2 => 'No meetings'
	);
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		$db = \DbFactory::GetConnection();
		
		if ($this->value == 1) { // 'Has Meetings'
			$filters[] = "(o.meetingsummary <> '' AND o.meetingsummary IS NOT NULL)";
		
		} elseif  ($this->value == 2) { // 'No Meetings'
			$filters[] = "(o.meetingsummary = '' OR o.meetingsummary IS NULL)";
		
		}
	}
	
	/**
	 * Set report parameter for inclusion of offerings that have meetings
	 *   1 => 'Has Meetings',
	 *   2 => 'No Meetings'
	 * If an invalid value is provided the report default is assigned.
	 * @param integer $value
	 */
	public function parseValue($value)
	{
		if (array_key_exists($value, self::$hasmeeting_values)) {
			return $value;
		} else {
			return null;
		}
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		if (array_key_exists($this->value, self::$hasmeeting_values)) {
			return self::$hasmeeting_values[$this->value];
		} else {
			return null;
		}
	}
	
}