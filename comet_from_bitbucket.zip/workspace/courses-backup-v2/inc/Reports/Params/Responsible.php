<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Adds application specific functionality to the ReportAbstract class
 * @author hanisko
 */
namespace Reports;

use Reports\Constants as RC;

class Responsible extends Offerings
{
	public function getConfig()
	{
		$config = array(
			'report-name' => 'Responsible',
			'picker-list' => array('quarter', 'rou'),
			'params'      => array(
				'rou'     => array(
						'class-name' => 'Reports\Params\Rou', 
						'required'   => true,
						'default'    => 3),
				'quarter' => array(
						'class-name' => 'Reports\Params\Quarter',
						'required'   => true),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
}