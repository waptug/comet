<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report period parameter, captures year, quarter and number of quarters
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class Period extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = true;
	protected $scrubstrategy = 'Default';
	protected $urlparam = 'period';
	protected $usesticky = true;
	protected $value;
	
	protected $lastyear;
	protected $lastquarter;
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		if (!$this->year()) {
			return;
		}
		if ($this->length() && $this->quarter()) {
			$filters[] = $this->generateQuarterRangeFilters();
		} elseif ($this->quarter()) {
			$filters[] = "(o.year = '".$this->year()."' AND o.quarter = ".$this->quarter().")";
		} else { 
			$nextyear = $this->year() + 1;
			$filters[] = "((o.year = '".$this->year()."' AND o.quarter = 4) OR (o.year = '$nextyear' AND o.quarter IN(1,2,3)))";
		}
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		$this->calculateLast();
		if ($this->length() > 1 && $this->quarter()) {
			$out = eQuarter($this->year(), $this->quarter()).' through '.eQuarter($this->lastyear, $this->lastquarter);
		} elseif ($this->quarter()) {
			$out = eQuarter($this->year(), $this->quarter());
		} elseif ($this->year()) {
			$out = eQuarter($this->year());
		} else {
			$out = '';
		}
		return $out;
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a file name.
	 * @return string
	 */
	public function getDescriptionFilename()
	{
		return $this->getDescription();
	}
	
	protected function calculateLast()
	{
		if ($this->quarter()) {
			if ($this->length() && $this->quarter()) {
				$this->lastyear = $this->year() + (int)(($this->quarter() + $this->length() - 1) / 4);
				$this->lastquarter = ($this->quarter() + $this->length() - 1) % 4;
				if ($this->lastquarter == 0) {
					$this->lastquarter = 4;
					--$this->lastyear;
				}
			} else {
				$this->lastyear = $this->year();
				$this->lastquarter = $this->quarter();
			}
		} else {
			$this->lastyear = $this->year() + 1;
			$this->lastquarter = 3;
		}
	}
	
	/**
	 * Generates a SQL filter claused based on a start quarter and number of quarters
	 * @return string
	 */
	protected function generateQuarterRangeFilters()
	{
		$this->calculateLast();
		if ($this->year() == $this->lastyear) {
			$quarters = array();
			for ($q = $this->quarter(); $q <= $this->lastquarter; ++$q) {
				$quarters[] = $q;
			}
			$filter = "(o.year = '".$this->year()."' AND o.quarter IN(".implode(',',$quarters)."))";
		} else {
			switch ($this->quarter()) {
				case 1:  $fy_quarters = '1,2,3,4';  break;
				case 2:  $fy_quarters = '2,3,4';    break;
				case 3:  $fy_quarters = '3,4';      break;
				default: $fy_quarters = '4';        break;
			}
			switch ($this->lastquarter) {
				case 1:  $ly_quarters = '1';        break;
				case 2:  $ly_quarters = '1,2';      break;
				case 4:  $ly_quarters = '1,2,3,4';  break;
				default: $ly_quarters = '1,2,3';    break;
			}
			$filters = array(
				"(o.year = '".$this->year()."' AND o.quarter IN(".$fy_quarters."))",
				"(o.year = '".$this->lastyear."' AND o.quarter IN(".$ly_quarters."))",
			);
			if ($this->lastyear > ($this->year() + 1)) {
				$filters[] = "(o.year > '".$this->year()."' AND o.year < '".$this->lastyear."')";
			}
			$filter = '('.implode(' OR ',$filters).')';
		}
		return $filter;
	}
	
	/**
	 * Provide hook for parameter value clean-up or conversion. This method
	 * is called during setValue() processing.
	 * @param string $value
	 * @return string
	 */
	protected function parseValue($value)
	{
		$parts = explode('-',$value);
		$this->setYear($parts[0]);
		if (isset($parts[1])) {
			$this->setQuarter($parts[1]);
			if (isset($parts[2])) {
				$this->setLength($parts[2]);
			} else {
				$this->setLength(null);
			}
		} else {
			$this->setQuarter(null);
			$this->setLength(null);
		}
		if ($this->quarter()) {
			if ($this->length()) {
				$value = $this->year().'-'.$this->quarter().'-'.$this->length();
			} else {
				$value = $this->year().'-'.$this->quarter();
			}
		} else {
			$value = $this->year();
		}
		return $value;
	}
	
	protected function year()
	{
		return $this->report->getParam('year')->getValue();
	}
	
	protected function quarter()
	{
		return $this->report->getParam('quarter')->getValue();
	}
	
	protected function length()
	{
		return $this->report->getParam('length')->getValue();
	}
	
	protected function setYear($value)
	{
		$this->report->getParam('year')->setValue($value);
	}
	
	protected function setQuarter($value)
	{
		$this->report->getParam('quarter')->setValue($value);
	}
	
	protected function setLength($value)
	{
		$this->report->getParam('length')->setValue($value);
	}
	
}