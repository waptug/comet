<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report staff role parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class StaffRoles extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'staffroles';
	protected $usesticky = true;
	protected $value = null;
	
	public static $rolecategories = array(
		1 => 'All staff roles',
		4 => 'Faculty',
		3 => 'Adjuncts',
		5 => 'Teaching Assistants & graders',
		2 => 'Funded staff roles',
		7 => 'Faculty, Adjuncts, Instructors',
		6 => 'Uncategorized instructors'
	);
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		switch ($this->value) {
			case 2: //'Funded staff roles',
				$filters[] = "s.role NOT IN('faculty', 'instructor')";
				break;
			case 3: //'Adjuncts',
				$filters[] = "s.role IN('adjunct', 'buyout')";
				break;
			case 4: //'Faculty',
				$filters[] = "s.role = 'faculty'";
				break;
			case 5: //'Teaching Assistants & graders',
				$filters[] = "s.role IN('ta', 'grader')";
				break;
			case 6: //'Uncategorized instructors'
				$filters[] = "s.role = 'instructor'";
				break;
			case 7: //'Faculty, Adjuncts, Instructors',
				$filters[] = "s.role IN('faculty', 'adjunct', 'instructor')";
				break;
			case 1: //'All staff roles'
			default:
				break;
		}
	}
	
	/**
	 * Set report parameter for inclusion of records by staff role
	 * @param integer $value
	 */
	public function parseValue($value)
	{
		if (array_key_exists($value, self::$rolecategories)) {
			return $value;
		} else {
			return null;
		}
	}
	
	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a heading. If the report object is using a picker related
	 * to this parameter provides an anchor tag wrapper.
	 * @return string
	 */
	public function getDescription()
	{
		switch ($this->value) {
			case 2: //,
				$text = 'Funded Staff Roles';
				break;
			case 3: //'Adjuncts',
				$text = 'Adjuncts';
				break;
			case 4: //'Faculty',
				$text = 'Faculty';
				break;
			case 5: //'Teaching Assistants & graders',
				$text = 'Teaching Assistants & Graders';
				break;
			case 6: //'Uncategorized instructors'
				$text = 'Uncategorized Instructors';
				break;
			case 7: //'Faculty, Adjuncts, Instructors',
				$text = 'Faculty, Adjuncts, or Instructors';
				break;
			case 1: //'All staff roles'
			default:
				$text = 'All Staff Roles';
				break;
		}
		return $text;
	}
	
}