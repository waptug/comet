<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report year parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;
use Reports\Constants as RC;

class Classroom extends ParamAbstract
{
	public static $values = array(
		RC::SHOW_ALL  => 'All section types',
		RC::SHOW_ONLY => 'Lecture or seminar',
		RC::SHOW_NOT  => 'Independent study or practicum',
	);
	
	protected $default = RC::SHOW_ALL;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'classroom';
	protected $usesticky = true;
	protected $value = null;
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		if ($this->value == RC::SHOW_ONLY) {
			$filters[] = "o.sectiontype IN('LC','SM')";
		} elseif  ($this->value == RC::SHOW_NOT) {
			$filters[] = "o.sectiontype NOT IN('LC','SM')";
		}
	}
	
	/**
	 * Set report parameter for inclusion of classroom section types. Constants
	 * are provided for
	 *   SHOW_ALL - all offerings regardless of section type
	 *   SHOW_ONLY - classroom sections types Lecture 'LC' and Seminar 'SM'
	 *   SHOW_NOT - includes only non classroom section types
	 * If an invalid value is provided the report default is assigned.
	 * @param integer $value
	 */
	public function setClassroom($value)
	{
		$this->setValue($value);
	}
	
	/**
	 * Set report parameter for inclusion of classroom section types. Constants
	 * are provided for
	 *   SHOW_ALL - all offerings regardless of section type
	 *   SHOW_ONLY - classroom sections types Lecture 'LC' and Seminar 'SM'
	 *   SHOW_NOT - includes only non classroom section types
	 * If an invalid value is provided the report default is assigned.
	 * @param integer $value
	 */
	public function parseValue($value)
	{
		switch ($value) {
			case RC::SHOW_ALL:
			case RC::SHOW_ONLY:
			case RC::SHOW_NOT:
				return $value;
				break;
			default:
				return null;
				break;
		}
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		if (isset(self::$values[$this->value])) {
			return self::$values[$this->value];
		} else {
			return self::$values[1];
		}
	}
	
}