<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report staff role parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class PersonHasArea extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = null;
	protected $usesticky = false;
	protected $value = null;
	
	public static $values = array(
		0 => 'All staff',
		1 => 'Staff has area',
		2 => 'Staff without area',
	);
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		switch ($this->value) {
			case 1: // 'Staff has area'
				$filters[] = "p.area IN('und','grad','pro')";
				break;
			case 3: // 'Staff without area',
				$filters[] = "p.area NOT IN('und','grad','pro')";
				break;
			case 1: //'All staff regardless of areas'
			default:
				break;
		}
	}
	
	public function getDescription()
	{
		return '';
	}
	
}