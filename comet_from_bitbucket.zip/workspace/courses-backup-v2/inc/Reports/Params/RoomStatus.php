<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Room Schedule status parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;
use Reports\Constants as RC;

class RoomStatus extends ParamAbstract
{	
	protected $default = RC::SHOW_ALL;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'roomstatus';
	protected $usesticky = true;
	protected $value = null;
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		if ($this->value == RC::SHOW_NEEDS_ACTION) {
			$filters[] = 'o.roomstatus >= 10 AND o.roomstatus < 90';
		} elseif  ($this->value == RC::SHOW_UP_TO_DATE) {
			$filters[] = 'o.roomstatus >= 90';
		}
	}
	
	/**
	 * Set report parameter for inclusion of offerings that need room schedule
	 * updates
	 *   SHOW_ALL - offerings regardless of room status
	 *   SHOW_NEEDS_ACTION - offerings that need room schedule revisited
	 *   SHOW_UP_TO_DATE - offerings that are up to date with room schedule
	 * If an invalid value is provided the report default is assigned.
	 * @param integer $value
	 */
	public function parseValue($value)
	{
		$out = null;
		switch ($value) {
			case RC::SHOW_ALL:
			case RC::SHOW_NEEDS_ACTION:
			case RC::SHOW_UP_TO_DATE:
				$out = $value;
				break;
			default:
				break;
		}
		return $out;
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		switch ($this->value) {
			case RC::SHOW_NEEDS_ACTION:
				$out = 'Room Schedule Needs Action';
				break;
			case RC::SHOW_UP_TO_DATE:
				$out = 'Room Schedule Up to Date';
				break;
			case RC::SHOW_ALL:
				$out = 'Room Schedule All Statuses';
				break;
			default:
				$out = null;
				break;
		}
		return $out;
	}
	
}