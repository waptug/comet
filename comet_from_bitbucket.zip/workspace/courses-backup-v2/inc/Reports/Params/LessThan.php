<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report year parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;
use Reports\Constants as RC;
 
class LessThan extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array('');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'lessthan';
	protected $usesticky = true;
	protected $value = null;
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		if ($this->value) {
			if ($this->report->getValue('enrollmentfield') == RC::ENROLLMENT_FIELD_ACTUAL) {
				$filters[] = 'o.enrollmentcurrent < '.$this->value;
			} else {
				$filters[] = '((o.enrollmentlimit = 0 AND o.enrollmentestimate < '.$this->value.') OR (o.enrollmentestimate = 0 AND o.enrollmentlimit < '.$this->value.'))';
			}
		}
	}
	
	/**
	 * Assign a value to be used for this parameter in this report
	 * @param string
	 */
	public function parseValue($value)
	{
		if ($value <= 0) {
			return null;
		}
		// there has to be at least one valid enrollment value between greaterthan < searchfor < lessthan
		if ($this->getValue('greaterthan') > ($value - 2)) {
			$this->report->getParam('greaterthan')->setValue(null);
		}
		return $value;
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		if ($this->value) {
			return $this->report->getParam('enrollmentfield')->getEnrollmentField().' less than '.$this->value;
		} else {
			return null;
		}
	}
	
}