<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report teaching staff filter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class Staff extends Person
{
	protected $relationship = ' has teaching staff ';

}
