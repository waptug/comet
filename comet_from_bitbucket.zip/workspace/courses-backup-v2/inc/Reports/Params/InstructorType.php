<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report parameter for type of instructor
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class InstructorType extends ParamAbstract
{
    public static $filters = array(
        0 => 'Include all offerings',
        1 => 'No instructor',
        2 => 'Faculty instructor',
        3 => 'Adjunct instructor',
    );
    protected $default = null;
    protected $locked = false;
    protected $makenull = array(0, '');
    protected $required = false;
    protected $scrubstrategy = 'Integer';
    protected $urlparam = 'instructor';
    protected $usesticky = true;
    protected $value = null;

    /**
     * If a database filter is required by this parameter's current
     * value it is added to the end of the $filter array argument
     * @param array
     */
    public function addFilter(&$filters)
    {
        switch ($this->value) {
            case 1: // 'No instructor'
                $filters[] = 's.staffid IS NULL';
                break;
            case 2: // 'Faculty instructor'
                $filters[] = "p.isfaculty = 1";
                break;
            case 3: // 'Adjunct instructor'
                $filters[] = "p.isadjunct = 1";
                break;
            default: // 0 => 'Include all offerings'
                break;
        }
    }

    /**
     * Set value for this report parameter
     * @param integer $value
     * @return string
     */
    public function parseValue($value)
    {
        if (array_key_exists($value, self::$filters)) {
            return $value;
        } else {
            return null;
        }
    }

    /**
     * Returns a string representation of the value of this report parameter
     * usable in a human readable description.
     * @return string
     */
    public function getDescription()
    {
        if (array_key_exists($this->value, self::$filters)) {
            return self::$filters[$this->value];
        } else {
            return self::$filters[0];
        }
    }

}