<?php
/**
 * @package UW_COE_Courses
 */
/**
 * UW Time Schedule status parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;
use Reports\Constants as RC;

class UwtsStatus extends ParamAbstract
{	
	protected $default = RC::SHOW_ALL;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'uwts';
	protected $usesticky = true;
	protected $value = null;
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		if ($this->value == RC::SHOW_NEEDS_ACTION) {
			$filters[] = "((o.status <> 'canceled' AND o.uwtsstatus IN(0,1,3,4)) OR (o.status = 'canceled' AND o.uwtsstatus IN(1,2)))";
			
		} elseif  ($this->value == RC::SHOW_UP_TO_DATE) {
			$filters[] = 'o.uwtsstatus = 2';
		}
	}
	
	/**
	 * Set report parameter for inclusion of offerings that need room schedule
	 * updates
	 *   SHOW_ALL - offerings regardless of UWTS status
	 *   SHOW_NEEDS_ACTION - offerings that need UWTS revised
	 *   SHOW_UP_TO_DATE - offerings that are up to date in UWTS
	 * If an invalid value is provided the report default is assigned.
	 * @param integer $value
	 */
	public function parseValue($value)
	{
		$out = null;
		switch ($value) {
			case RC::SHOW_ALL:
			case RC::SHOW_NEEDS_ACTION:
			case RC::SHOW_UP_TO_DATE:
				$out = $value;
				break;
			default:
				break;
		}
		return $out;
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		switch ($this->value) {
			case RC::SHOW_NEEDS_ACTION:
				$out = 'Differs from UWTS';
				break;
			case RC::SHOW_UP_TO_DATE:
				$out = 'Up to date in UWTS';
				break;
			case RC::SHOW_ALL: 
			default:
				$out = null;
				break;
		}
		return $out;
	}
	
}
