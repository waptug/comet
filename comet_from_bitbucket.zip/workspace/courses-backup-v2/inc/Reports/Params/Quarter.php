<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report year parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class Quarter extends ParamAbstract
{
	public static $quarter_map = array(
		'winter' => 1,
		'win'    => 1,
		'spring' => 2,
		'spr'    => 2,
		'summer' => 3,
		'sum'    => 3,
		'autumn' => 4,
		'aut'    => 4,
		'fall'   => 4
	);
	
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Default';
	protected $urlparam = 'q';
	protected $usesticky = false;
	protected $value;

	/**
	 * Recognize string quarter identifiers
	 * @param string
	 * @return string
	 */
	public function parseValue($value)
	{
		$value = strtolower($value);
		if (array_key_exists($value, self::$quarter_map)) {
			return self::$quarter_map[$value];
		}
		$value = (int)$value;
		if ($value > 0 && $value < 5) {
			return $value;
		} else {
			return null;
		}
	}

	public function getDescription()
	{
		// quarter description is returned from the period param
		return null;
	}
	
}