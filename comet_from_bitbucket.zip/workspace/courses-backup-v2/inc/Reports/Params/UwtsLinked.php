<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report parameter, based on whether offering is linked to a UW time
 * schedule cache record
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;
use Reports\Constants as RC;

class UwtsLinked extends ParamAbstract
{
	protected $default = RC::SHOW_ALL;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'uwtslinked';
	protected $usesticky = true;
	protected $value = null;
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		switch ($this->value) {
			case RC::SHOW_ONLY: 
				$filters[] = 'u.offeringid IS NOT NULL';
				break;
			case RC::SHOW_NOT: 
				$filters[] = 'u.offeringid IS NULL';
				break;
			case RC::SHOW_ALL: 
			default: 
				break;
		}
		return;
	}
	
	/**
	 * If additional tables are required to filter by this parameter inserts
	 * a SQL JOIN phrase with its appropriate ON clause to the end of the 
	 * provided array.
	 * @param array
	 */
	public function addJoin(&$joinphrases)
	{
		if ($this->value != RC::SHOW_ALL) {
			$joinphrases[] = 'LEFT OUTER JOIN uwtsoffering u ON o.offeringid = u.offeringid';
		}
	}
	
	/**
	 * Assign a value to be used for this parameter in this report
	 * @param string
	 */
	public function parseValue($value)
	{
		$out = null;
		switch ($value) {
			case RC::SHOW_ALL: 
			case RC::SHOW_ONLY: 
			case RC::SHOW_NOT: 
				$out = $value;
				break;
			default: 
				break;
		}
		return $out;
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		switch ($this->value) {
			case RC::SHOW_ONLY: 
				$out = 'Linked to UWTS record';
				break;
			case RC::SHOW_NOT: 
				$out = 'Not linked to UWTS record';
				break;
			case RC::SHOW_ALL: 
			default:
				$out = null;
				break;
		}
		return $out;
	}
	
}