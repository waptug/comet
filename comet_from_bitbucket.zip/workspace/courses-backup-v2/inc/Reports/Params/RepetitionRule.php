<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report parameter, filters reports to offerings created by a specific
 * repetition rule
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;
 
class RepetitionRule extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'repetition';
	protected $usesticky = false;
	protected $value = null;
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		return;
	}
	
	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		if ($this->value) {
			return 'repetitionid = '.$this->value;
		} else {
			return null;
		}
	}
	
}