<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report year parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;
use Reports\Constants as RC;

class Curriculum extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Default';
	protected $urlparam = 'c';
	protected $usesticky = true;
	protected $value;
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		if ($this->value) {
			$filters[] = 'c.curriculum = '.\DbFactory::GetConnection()->quote($this->value);
		}
	}
	
	/**
	 * Assign a value to be used for this parameter in this report
	 * @param string
	 */
	public function parseValue($value)
	{
		$value = strtoupper($value);
		if (array_key_exists($value, RC::$curriculum_map)) {
			return RC::$curriculum_map[$value];
		} else {
			return null;
		}
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		if ($this->value) {
			return $this->value;
		} else {
			return 'All College of Education';
		}
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a file name.
	 * @return string
	 */
	public function getDescriptionFilename()
	{
		return $this->getDescription();
	}
	
}
