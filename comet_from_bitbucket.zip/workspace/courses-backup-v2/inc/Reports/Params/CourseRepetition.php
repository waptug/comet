<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report parameter that filters by courses that have repetition rules
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;
use Reports\Constants as RC;

class CourseRepetition extends ParamAbstract
{
	protected $default = RC::SHOW_ONLY;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'hasrule';
	protected $usesticky = false;
	protected $value = null;

	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		return;
	}
	
	/**
	 * If additional tables are required to filter by this parameter inserts
	 * a SQL JOIN phrase with its appropriate ON clause to the end of the
	 * provided array.
	 * @param array
	 */
	public function addJoin(&$joinphrases)
	{
		if ($this->value) {
			$joinphrases[] = 'INNER JOIN (SELECT DISTINCT courseid FROM repetition) AS hasrep ON c.courseid = hasrep.courseid';
		}
	}
	
	/**
	 * Set report parameter for inclusion of classroom section types. Constants
	 * are provided for
	 *   SHOW_ALL - all offerings regardless of section type
	 *   SHOW_ONLY - classroom sections types Lecture 'LC' and Seminar 'SM'
	 *   SHOW_NOT - includes only non classroom section types
	 * If an invalid value is provided the report default is assigned.
	 * @param integer $value
	 */
	public function parseValue($value)
	{
		switch ($value) {
			case RC::SHOW_ALL:
			case RC::SHOW_ONLY:
			case RC::SHOW_NOT:
				return $value;
				break;
			default:
				return null;
				break;
		}
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		switch ($this->value) {
			case RC::SHOW_NOT:
				$out = 'Courses without repetition rules';
				break;
			case RC::SHOW_ONLY:
				$out = 'Courses with repetition rules';
				break;
			case RC::SHOW_ALL:
			default:
				$out = null;
				break;
		}
		return $out;
	}
	
}