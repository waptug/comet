<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report length (number of quarters) parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class Length extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'length';
	protected $usesticky = false;
	protected $value;
	
	public function getDescription()
	{
		// quarter description is returned from the period param
		return null;
	}
	
}