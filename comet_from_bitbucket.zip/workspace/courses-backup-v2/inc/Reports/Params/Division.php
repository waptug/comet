<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Manages a report parameter for affiliation with an associate dean
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class Division extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Default';
	protected $urlparam = 'division';
	protected $usesticky = true;
	protected $value = null;

	protected $valid_values = array('grad', 'und', 'pro', 'any');
	
    /**
     * If a database filter is required by this parameter's current
     * value it is added to the end of the $filter array argument
     * @param array
     */
    public function addFilter(&$filters)
    {
		if ($this->value == 'any') {
			$filters[] = "p.area IN('grad','und','pro')";
		} elseif ($this->value) {
			$filters[] = "p.area = '".$this->value."'";
		}
    }
    
    /**
     * Assign a value to be used for this parameter in this report
     * @param string
     */
    public function parseValue($value)
    {
        if (in_array($value, $this->valid_values)) {
            return $value;
        }
        return null;
    }

    /**
     * Returns a string representation of the value of this report parameter
     * usable in a human readable description.
     * @return string
     */
    public function getDescription()
    {
    	if ($this->value == 'any') {
			$out = 'Affiliated with any division';
		} elseif ($this->value) {
			$out = 'Affiliated with division'.strtoupper($this->value);
		} else {
			$out = null;
        }
        return $out;
    }

}