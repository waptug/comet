<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report canceled parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;
use Reports\Constants as RC;

class Canceled extends ParamAbstract
{
	protected $default = RC::SHOW_NOT;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'canceled';
	protected $usesticky = true;
	protected $value;
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		if ($this->value == RC::SHOW_ONLY) {
			$filters[] = "o.status = 'canceled'";
		} elseif  ($this->value == RC::SHOW_NOT) {
			$filters[] = "o.status <> 'canceled'";
		}
	}
	
	/**
	 * Set report parameter for inclusion of canceled course offerings. Constants
	 * are provided for
	 *   SHOW_ALL - offerings canceled or not
	 *   SHOW_ONLY - only included canceled offerings
	 *   SHOW_NOT - show offerings that are not canceled
	 * If an invalid value is provided the report default is assigned.
	 * @param integer $value
	 */
	public function parseValue($value)
	{
		switch ($value) {
			case RC::SHOW_ALL:
			case RC::SHOW_ONLY:
			case RC::SHOW_NOT:
				return $value;
				break;
			default:
				return null;
				break;
		}
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		switch ($this->value) {
			case RC::SHOW_ALL:
				$out = 'Includes canceled';
				break;
			case RC::SHOW_ONLY:
				$out = 'Only canceled';
				break;
			case RC::SHOW_NOT:
				$out = 'Not canceled';
				break;
			default:
				$out = null;
				break;
		}
		return $out;
	}
	
}