<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report tag parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class Tags extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Default';
	protected $urlparam = 'tags';
	protected $usesticky = true;
	protected $value = null;
	
	protected $selected = array();
	protected $taglist;
	protected $urlparamdeselect = 'xtags';
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		return;
	}
	
	/**
	 * If additional tables are required to filter by this parameter inserts
	 * a SQL JOIN phrase with its appropriate ON clause to the end of the 
	 * provided array.
	 * @param array
	 */
	public function addJoin(&$joinphrases)
	{
		if ($this->value) {
			$joinphrases[] = 'INNER JOIN tagcourse tag ON o.courseid = tag.courseid AND tag.tagid IN('.$this->value.') ';
		}
	}
	
	public function addSelected($tagid) 
	{
		$tagid = (int)$tagid;
		if ($tagid == 0) {
			$this->selected = array();
			return;
		}
		$tag = \Db_Tag::Get($tagid);
		if ($tag->recordExists()) {
			$this->selected[$tagid] = $tag;
		}	
	}
		
	public function getSelectedTags()
	{
		return $this->selected;
	}
	
	/**
	 * Check user input for a value for this report parameter and
	 * try to assign the value. The sticky array can provide values
	 * overridden by user input, but stored at the session level 
	 * instead of in the request.
	 * @param array $sticky
	 */
	public function getUserInput($sticky = array())
	{
		if ($this->locked) {
			return;
		}
		if (array_key_exists($this->urlparam, $sticky)) {
			$value = $this->makeNull($sticky[$this->urlparam]);
			$this->setValue($value);
		}
		if (array_key_exists($this->urlparam, $_GET)) {
			$add = $_GET[$this->urlparam];
		} elseif (array_key_exists($this->urlparam, $_POST)) {
			$add = $_POST[$this->urlparam];
		} else {
			$add = false;
		}
		if ($add) {
			$ids = explode(',', $add);
			foreach ($ids as $tagid) $this->addSelected($tagid);
		}
		if (array_key_exists($this->urlparamdeselect, $_GET)) {
			$remove = $_GET[$this->urlparamdeselect];
		} elseif (array_key_exists($this->urlparamdeselect, $_POST)) {
			$remove = $_POST[$this->urlparamdeselect];
		} else {
			$remove = false;
		}
		if ($remove) {
			$ids = explode(',', $remove);
			foreach ($ids as $tagid) $this->removeSelected($tagid);
		}
		if ($this->selected) {
			$this->value = implode(',',array_keys($this->selected));
		} else {
			$this->value = null;
		}
	}
	
	public function isSelected($tagid)
	{
		return array_key_exists($tagid, $this->selected);
	}
	
	/**
	 * Assign a value to be used for this parameter in this report
	 * @param string
	 */
	public function parseValue($value)
	{
		$selected = array();
		if (is_null($value)) {
			return null;
		}
		$ids = explode(',', $value);
		foreach ($ids as $tagid) $this->addSelected($tagid);
		if ($this->selected) {
			return implode(',',array_keys($this->selected));
		} else {
			return null;
		}
	}
	
	public function removeSelected($tagid) 
	{
		$tagid = (int)$tagid;
		if (array_key_exists($tagid, $this->selected)) {
			unset($this->selected[$tagid]);
		}
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a heading. If the report object is using a picker related
	 * to this parameter provides an anchor tag wrapper.
	 * @return string
	 */
	public function getDescription()
	{
		if ($this->selected) {
			$names = array();
			foreach ($this->selected as $tag) $names[] = ucwords($tag->name); 
			$out = 'Has tag '.e(implode(' or ', $names));
		} else {
			$out = null;
		}
		return $out;
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a file name.
	 * @return string
	 */
	public function getValueFilename()
	{
		if ($this->value) {
			return str_replace(' ', '-', $this->getDescription());
		} else {
			return null;
		}
	}
	
}