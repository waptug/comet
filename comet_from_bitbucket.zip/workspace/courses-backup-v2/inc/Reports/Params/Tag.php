<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report tag parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class Tag extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Default';
	protected $urlparam = 't';
	protected $usesticky = true;
	protected $value = null;
	
	protected $tagid;
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		return;
	}
	
	/**
	 * If additional tables are required to filter by this parameter inserts
	 * a SQL JOIN phrase with its appropriate ON clause to the end of the 
	 * provided array.
	 * @param array
	 */
	public function addJoin(&$joinphrases)
	{
		if ($this->value) {
			$joinphrases[] = 'INNER JOIN tagcourse tag ON o.courseid = tag.courseid AND tag.tagid = '.$this->tagid.' ';
		}
	}
	
	/**
	 * Returns a Db_Tag object if the provided or stored value matches a Tag record
	 * in the system
	 * @return Db_Tag|null
	 */
	public function getTag($value = null)
	{
		if (is_null($value)) {
			if ($this->tagid) {
				// use verified tagid if we have one
				return \Db_Tag::Get($this->tagid);
			}
			$value = $this->value;
		}
		if (!$value) {
			return null;
		}
		// Match a string tag to a system tagid
		$db = \DbFactory::GetConnection();
		$tagid = $db->fetchOne('SELECT tagid FROM tag WHERE name = '.$db->quote($value));
		if ($tagid) {
			$o = \Db_Tag::Get($tagid);
		} elseif (is_numeric($value)) {
			$o = \Db_Tag::Get((int)$value);
		} else {
			$o = null;
		}
		if ($o && $o->recordExists()) {
			// located a Db_Tag record, valid value
			$this->tagid = $o->tagid;
			return $o;
		} else {
			return null;
		}
	}
	
	public function getTagId()
	{
		if ($this->tagid) {
			return $this->tagid;
		}
		return null;
	}
	
	/**
	 * Assign a value to be used for this parameter in this report
	 * @param string
	 */
	public function parseValue($value)
	{
		$tag = $this->getTag($value);
		if ($tag) {
			return $tag->name;
		} else {
			return null;
		}
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a heading. If the report object is using a picker related
	 * to this parameter provides an anchor tag wrapper.
	 * @return string
	 */
	public function getDescription()
	{
		$tag = $this->getTag();
		if ($tag) {
			$out = 'Has tag '.e(ucwords($tag->name));
		} else {
			$out = null;
		}
		return $out;
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a file name.
	 * @return string
	 */
	public function getValueFilename()
	{
		if ($this->value) {
			return 'with-tag-'.$this->value;
		} else {
			return null;
		}
	}
	
}