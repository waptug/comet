<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Manages a report parameter for instructor
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class Person extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'person';
	protected $usesticky = true;
	protected $value = null;

	protected $relationship = ' has instructor ';
	
    /**
     * If a database filter is required by this parameter's current
     * value it is added to the end of the $filter array argument
     * @param array
     */
    public function addFilter(&$filters)
    {
		if ($this->getPerson()) {
			$filters[] = 's.personid = '.$this->value;
		}
    }

    /**
     * Returns a Db_Rou object if the _value field refers to an existing 
     * record, null otherwise.
     * @return Db_Rou|null
     */
    public function getPerson($value = null)
    {
    	if (is_null($value)) {
    		$value = $this->value;
    	}
        $out = null;
        if ($value) {
            $person = \Db_Person::Get($value);
            if ($person->recordExists()) {
                $out = $person;
            }
        }
        return $out; 
    }
    
    /**
     * Assign a value to be used for this parameter in this report
     * @param string
     */
    public function parseValue($value)
    {
        if ($value) {
            $person = $this->getPerson($value);
            if ($person) {
                return $value;
            }
        }
        return null;
    }

    /**
     * Returns a string representation of the value of this report parameter
     * usable in a human readable description.
     * @return string
     */
    public function getDescription()
    {
        if ($this->value) {
			$person = $this->getPerson();
			$out = $this->relationship.\View_Person::FirstLast($person);
        } else {
			$out = null;
        }
        return $out;
    }

}