<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report parameter for "offered through institution" field
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;
 
class Institution extends ParamAbstract
{
	public static $filters = array(
		0 => 'Any funding/institution',
		2 => 'State funding',
		3 => 'UWEO (self-sustaining)'
	);
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'institution';
	protected $usesticky = true;
	protected $value = null;
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		switch ($this->value) {
			case 2: // 'State funding',
				$filters[] = "o.institution = 'state'";
				break;
			case 3: // 'UWEO',
				$filters[] = "o.institution = 'uweo'";
				break;
			case 1: //'Any funding types'
			default:
				break;
		}
	}
	
	/**
	 * Set value for this report parameter
	 * @param integer $value
	 */
	public function parseValue($value)
	{
		if (array_key_exists($value, self::$filters)) {
			return $value;
		} else {
			return null;
		}
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		if (array_key_exists($this->value, self::$filters)) {
			return self::$filters[$this->value];
		} else {
			return self::$filters[0];
		}
	}
	
}