<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report year parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;
use Reports\Constants as RC;
 
class GreaterThan extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array('');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'greaterthan';
	protected $usesticky = true;
	protected $value = null;
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		if (!is_null($this->value)) {
			if ($this->report->getParam('enrollmentfield')->getValue() == RC::ENROLLMENT_FIELD_ACTUAL) {
				$filters[] = 'o.enrollmentcurrent > '.$this->value;
			} else {
				$filters[] = '(o.enrollmentestimate > '.$this->value.' OR o.enrollmentlimit > '.$this->value.')';
			}
		}
	}
	
	/**
	 * Assign a value to be used for this parameter in this report
	 * @param string
	 */
	public function parseValue($value)
	{
		if (is_null($value)) {
			return null;
		}
		// there has to be at least one valid enrollment value between greaterthan < searchfor < lessthan
		if ($this->getValue('lessthan') < ($value + 2)) {
			$this->report->getParam('lessthan')->setValue(null);
		}
		return $value;
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		if (!is_null($this->value)) {
			return $this->report->getParam('enrollmentfield')->getEnrollmentField().' greater than '.$this->value;
		} else {
			return null;
		}
	}
	
}