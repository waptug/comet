<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report parameter for section funding model
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;
 
class Funding extends ParamAbstract
{
	public static $fundingfilters = array(
		0 => 'All funding types',
		2 => 'State funding',
		3 => 'Self sustaining'
	);
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'funding';
	protected $usesticky = true;
	protected $value = null;
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		switch ($this->value) {
			case 2: //'State funding',
				$filters[] = "o.funding = 'St'";
				break;
			case 3: //'Self sustaining',
				$filters[] = "o.funding = 'SS'";
				break;
			case 1: //'All funding types'
			default:
				break;
		}
	}
	
	/**
	 * Set value for this report parameter
	 * @param integer $value
	 */
	public function parseValue($value)
	{
		if (array_key_exists($value, self::$fundingfilters)) {
			return $value;
		} else {
			return null;
		}
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		if (array_key_exists($this->value, self::$fundingfilters)) {
			return self::$fundingfilters[$this->value];
		} else {
			return null;
		}
	}
	
}