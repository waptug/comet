<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Manages a report parameter for Responsible Organizational Unit (ROU). Filters
 * a query for courses to those owned by an ROU or one of that ROUs children.
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class Rou extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'rou';
	protected $usesticky = true;
	protected $value = null;

    /**
     * If a database filter is required by this parameter's current
     * value it is added to the end of the $filter array argument
     * @param array
     */
    public function addFilter(&$filters)
    {
		if ($this->value) {
			$filters[] = '(rou.rouid = '.$this->value.' OR rou.parent_rouid = '.$this->value.')';
		}
    }

    /**
     * If additional tables are required to filter by this parameter inserts
     * a SQL JOIN phrase with its appropriate ON clause to the end of the
     * provided array.
     * @param array
     */
    public function addJoin(&$joinphrases)
    {
		if ($this->value) {
            $joinphrases[] = 'INNER JOIN rou ON c.rouid = rou.rouid';
        }
    }

    /**
     * Returns a Db_Rou object if the _value field refers to an existing 
     * record, null otherwise.
     * @return Db_Rou|null
     */
    public function getRou($value = null)
    {
    	if (is_null($value)) {
    		$value = $this->value;
    	}
        $out = null;
        if ($value) {
            $rou = \Db_Rou::Get($value);
            if ($rou->recordExists()) {
                $out = $rou;
            }
        }
        return $out; 
    }
    
    /**
     * Assign a value to be used for this parameter in this report
     * @param string
     */
    public function parseValue($value)
    {
        $rou = $this->getRou($value);
        if ($rou) {
            return $value;
        }
        return null;
    }

    /**
     * Returns a string representation of the value of this report parameter
     * usable in a human readable description.
     * @return string
     */
    public function getDescription()
    {
        if ($this->value) {
            $rou = $this->getRou();
            $out = $rou->rou_name;
        } else {
            $out = 'Any ROU';
        }
        return $out;
    }

    /**
     * Returns a string representation of the value of this report parameter
     * usable in a file name.
     * @return string
     */
    public function getDescriptionFilename()
    {
		$rou = $this->getRou();
        if ($rou) {
        	$out = 'rou-'.$rou->rou_name;
        	$out = str_replace('&', 'and', $out);
        	$out = str_replace(' ', '-', $out);
            return $out;
        } else {
            return null;
        }
    }

}