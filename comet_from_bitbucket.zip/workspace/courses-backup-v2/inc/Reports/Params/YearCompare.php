<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report year parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class YearCompare extends Period
{

	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		if (!$this->year()) {
			return;
		}
		$quarter = ($this->quarter()) ? $this->quarter() : 4;
		$filters[] = "((o.year = '".$this->year()."' OR o.year = '".($this->year() - 1)."') AND o.quarter = ".$this->quarter().")";
	}
	
}