<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report tag parameter filters only on Tags attached to Course records
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class CourseTag extends Tag
{
	
	/**
	 * If additional tables are required to filter by this parameter inserts
	 * a SQL JOIN phrase with its appropriate ON clause to the end of the 
	 * provided array.
	 * @param array
	 */
	public function addJoin(&$joinphrases)
	{
		if ($this->value) {
			$joinphrases[] = 'INNER JOIN tagcourse tag ON c.courseid = tag.courseid AND tag.tagid = '.$this->tagid.' ';
		}
	}
	
}