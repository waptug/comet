<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report filter for person who is responsible for a change request
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class ChangePerson extends Person
{
	protected $relationship = ' belongs to ';


}