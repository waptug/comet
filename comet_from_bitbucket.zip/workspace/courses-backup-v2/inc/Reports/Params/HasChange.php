<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Parameter that filters reports based on whether offerings have
 * change requests link to them.
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class HasChange extends ParamAbstract
{
	protected $default = 1; // 'Open Change Requests'
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'haschange';
	protected $usesticky = true;
	protected $value = null;
	
	public static $change_statuses = array(
		1 => 'Open Change Requests',
		2 => 'Resolved Change Requests',
		3 => 'Any Change Requests',
	);
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		$db = \DbFactory::GetConnection();
		
		if ($this->value == 1) { // 'Open Change Requests'
			$haschange = $db->fetchColumn('SELECT DISTINCT offeringid FROM changes WHERE parent_changeid IS NULL AND resolution_changeid IS NULL');
		
		} elseif  ($this->value == 2) { // 'Resolved Change Requests'
			$haschange = $db->fetchColumn('SELECT DISTINCT offeringid FROM changes WHERE parent_changeid IS NULL AND resolution_changeid IS NOT NULL');
		
		} else { // 3 'Any Change Requests'
			$haschange = $db->fetchColumn('SELECT DISTINCT offeringid FROM changes WHERE parent_changeid IS NULL');
		}
		$filters[] = 'o.offeringid IN('.implode(',',$haschange).')';
	}
	
	/**
	 * Set report parameter for inclusion of offerings that need room schedule
	 * updates
	 *   SHOW_ALL - offerings regardless of change requests
	 *   SHOW_ONLY - offerings that have change requests
	 *   SHOW_NOT - offerings that are up to date with room schedule
	 * If an invalid value is provided the report default is assigned.
	 * @param integer $value
	 */
	public function parseValue($value)
	{
		if (array_key_exists($value, self::$change_statuses)) {
			return $value;
		} else {
			return null;
		}
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		if (array_key_exists($this->value, self::$change_statuses)) {
			return self::$change_statuses[$this->value];
		} else {
			return null;
		}
	}
	
}