<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report teaching staff filter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class Uwnetid extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Default';
	protected $urlparam = 'u';
	protected $usesticky = true;
	protected $value = null;
	
	/**
	 * If a database filter is required by this parameter's current
	 * value it is added to the end of the $filter array argument
	 * @param array
	 */
	public function addFilter(&$filters)
	{
		$person = $this->getPerson();
		if ($person) {
			$filters[] = 's.personid = '.$person->personid;
		}
	}
	
	/**
	 * Return a Db_Person object identified by the provided UW NetID value
	 * or by the current value of this param
	 * @param string $value
	 * @return \Db_Person|NULL
	 */
	public function getPerson($value = null)
	{
		if (is_null($value)) {
			$value = $this->value;
		}
		if (!$value) {
			return null;
		}
		$person = \Db_Person::FetchByUwnetid($value);
		if ($person->recordExists()) {
			return $person;
		} else {
			return null;
		}
	}
	
	/**
	 * Assign a value to be used for this parameter in this report
	 * @param string
	 */
	public function parseValue($value)
	{
		$person = $this->getPerson($value);
		if ($person) {
			return $value;
		} else {
			return null;
		}
	}
	
	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		if ($this->value) {
			$person = $this->getPerson();
			return 'Has teaching staff '.\View_Person::FirstLast($person);
		} else {
			return null;
		}
	}
	
	/**
	 * Set the value of this report parameter by passing a person object
	 * @param Db_Person $person
	 */
	public function setPerson(\Db_Person $person)
	{
		$this->setValue($person->uwnetid);
	}
	
}