<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report year parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;

class Year extends ParamAbstract
{
	protected $default = null;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = true;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'y';
	protected $usesticky = false;
	protected $value;
	
	public function parseValue($value)
	{
		$value = (int)$value;
		if ($value < 1900 || $value > 2100) {
			return null;
		} else {
			return $value;
		}
	}
	
	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		// handled by period parameter
		return null;
	}
	
}