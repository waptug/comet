<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report year parameter
 * @author hanisko
 */
namespace Reports\Params;

use UwCoeFramework\Reports\ParamAbstract;
use Reports\Constants as RC;

class EnrollmentField extends ParamAbstract
{
	protected $default = RC::ENROLLMENT_FIELD_ACTUAL;
	protected $locked = false;
	protected $makenull = array(0, '');
	protected $required = false;
	protected $scrubstrategy = 'Integer';
	protected $urlparam = 'enrollmentfield';
	protected $usesticky = true;
	protected $value = null;
	
	/**
	 * Set the field (actual or expected) that the greater and less than
	 * parameters should be compared to. If an invalid $value is provided 
	 * the report default is assigned.
	 * @param string $value
	 */
	public function parseValue($value)
	{
		switch ($value) {
			case RC::ENROLLMENT_FIELD_ACTUAL:
			case RC::ENROLLMENT_FIELD_EXPECTED:
				$out = $value;
				break;
			default:
				$out = null;
				break;
		}
		return $out;
	}

	/**
	 * Returns a string representation of the value of this report parameter 
	 * usable in a human readable description.
	 * @return string
	 */
	public function getDescription()
	{
		return null;
	}
	
	public function getEnrollmentField()
	{
		switch ($this->value) {
			case RC::ENROLLMENT_FIELD_ACTUAL:
				$out =  'Actual enrollment';
				break;
			case RC::ENROLLMENT_FIELD_EXPECTED:
				$out =  'Estimated enrollment';
				break;
			default:
				$out = null;
				break;
		}
		return $out;
	}
	
}