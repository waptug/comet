<?php
/**
 * @package UW_COE_Courses 
 */
/**
 * Report for the build a quarter tool. Presents a list of the focus
 * quarter offerings plus a list of offerings from the same quarter
 * last year.
 * @author hanisko
 */
namespace Reports;

use Reports\Constants as RC;

class ChooseClone extends CoursesAbstract
{
	public function getConfig()
	{
		$config = array(
			'report-name'       => 'Offerings',
			'listeners'         => array('\Reports\TimePeriod\CurrentQuarter'),
			'use-sticky-params' => true,
			'picker-list'       => array('quarter', 'curriculum'),
			'params'            => array(
				'year'            => array('class-name' => 'Reports\Params\Year'),
				'quarter'         => array('class-name' => 'Reports\Params\Quarter'),
				'courseid'        => array('class-name' => 'Reports\Params\Courseid'),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
	public function initReport()
	{
		parent::initReport();
		$this->index['previous_year'] = array();
		$this->index['past'] = array();
		$this->index['future'] = array();
	}
	
	/**
	 * Loads report data from the database. Handled automatically by getReport()
	 * method, but allows for alteration and re-running of query.
	 */
	public function load()
	{
		$this->initReport();
		$sql = 'SELECT c.*, o.*, s.staffid, s.personid, s.role, s.timesched, s.buyoutreason, p.* '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'LEFT OUTER JOIN staff s '
		     . 'ON o.offeringid = s.offeringid '
		     . 'AND s.meetingnumber = 1 '
		     . 'AND s.timesched = 1 '
		     . 'LEFT OUTER JOIN person p '
		     . 'ON s.personid = p.personid '
		     . 'WHERE o.courseid = '.$this->getValue('courseid').' '
		     . 'AND [[TIME_PERIOD]] '
		     . 'ORDER BY o.year DESC, o.quarter DESC, c.curriculum, c.courseno, o.section, c.wildcardtitle, c.title';
		
		// load same quarter last year
		$time = 'o.year = \''.($this->getValue('year') - 1).'\' AND o.quarter = '.$this->getValue('quarter');
		$this->loadOfferings('previous_year', str_replace('[[TIME_PERIOD]]', $time, $sql));
		
		// load historical quarters
		$now = \Db_Quarter::FetchCurrentQuarter();
		$time = "(o.year < '".$now->year."' OR (o.year = '".$now->year."' AND o.quarter <= ".$now->quarter.'))';
		$this->loadOfferings('past', str_replace('[[TIME_PERIOD]]', $time, $sql));
		
		// load future quarters
		$time = "(o.year > '".$now->year."' OR (o.year = '".$now->year."' AND o.quarter > ".$now->quarter.'))';
		$this->loadOfferings('future', str_replace('[[TIME_PERIOD]]', $time, $sql));
	}
	
	/**
	 * Loads an array of Db_Offerings to the specified $property using the 
	 * specified SQL statement 
	 * @param string $property_name
	 * @param string $period_filter
	 */
	protected function loadOfferings($property, $sql)
	{
		$db = \DbFactory::GetConnection();
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			$offering = $this->registerOffering($row);
			$offering->setCourse($this->registerCourse($row));
			if ($row['staffid']) {
				$staff = $this->registerStaff($row);
				$staff->setPerson($this->registerPerson($row));
				$offering->setInstructor($staff);
			} else {
				$offering->noInstructor();
			}
			$this->index[$property][] = $offering;
		}
	}
	
	/**
	 * Returns an array of Db_Offering objects from the targeted quarter
	 * @return array[Db_Offering]
	 */
	public function getFutureOfferings()
	{
		$this->lazyload();
		return $this->index['future'];
	}
	
	/**
	 * Returns an array of Db_Offering objects from the same quarter
	 * previous year
	 * @return array[Db_Offering]
	 */
	public function getPastOfferings()
	{
		$this->lazyload();
		return $this->index['past'];
	}
	
	/**
	 * Returns an array of Db_Offering objects from the same quarter
	 * previous year
	 * @return array[Db_Offering]
	 */
	public function getLastYear()
	{
		$this->lazyload();
		return $this->index['previous_year'];
	}
	
	/**
	 * Returns an array containing the key objects of this report, in the
	 * base implementation an array of Db_Offering objects.
	 */
	public function getReport()
	{
		return $this->getLastYear();
	}
	
}