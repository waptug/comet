<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Adds application specific functionality to the ReportAbstract class
 * @author hanisko
 */
namespace Reports;

use Reports\Constants as RC;

class Enrollment extends Offerings
{
	public function getConfig()
	{
		$config = array(
			'report-name'       => 'Offerings',
			'params'            => array(
				'year'       => array('class-name' => 'Reports\Params\Year'),
				'quarter'    => array('class-name' => 'Reports\Params\Quarter'),
				'curriculum' => array('class-name' => 'Reports\Params\Curriculum'),
				'canceled'   => array('class-name' => 'Reports\Params\Canceled'),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
	/**
	 * Query the data store and populate the object tree that makes up this report
	 */
	public function load()
	{
		$this->initReport();
		$this->index['byquarter'] = array(1=>array(),2=>array(),3=>array(),4=>array());
		$this->buildSqlPhrases();
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT c.*, o.*, s.staffid, s.personid, s.role, s.timesched, s.buyoutreason, p.* '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'LEFT OUTER JOIN staff s '
		     . 'ON o.offeringid = s.offeringid '
		     . 'AND s.meetingnumber = 1 '
		     . 'AND s.timesched = 1 '
		     . 'LEFT OUTER JOIN person p '
		     . 'ON s.personid = p.personid '
		     . $this->implodeSqlJoins()
		     . $this->implodeSqlFilters()
		     .' ORDER BY o.year, o.quarter, c.curriculum, c.courseno, o.section, c.wildcardtitle, c.title';
		$this->sql = $sql;
		$results = $db->fetchAssoc($sql);
		//debug(__METHOD__."\n".$sql);
		foreach ($results as $row) {
			$offering = $this->registerOffering($row);
			$offering->setCourse($this->registerCourse($row));
			if ($row['staffid']) {
				$staff = $this->registerStaff($row);
				$staff->setPerson($this->registerPerson($row));
				$offering->setInstructor($staff);
			} else {
				$offering->noInstructor();
			}
			// create a reference to this offering in the By Quarter structure
			if ($row['quarter'] > 0 && $row['quarter'] < 5) {
				$this->index['byquarter'][$row['quarter']][] = $offering;
			}
		}
	}
	
	public function getReport()
	{
		$this->lazyload();
		return $this->index['offerings'];
	}
	
}