<?php
/**
 * @package UW_COE_Courses 
 */
/**
 * Report for the build a quarter tool. Presents a list of the focus
 * quarter offerings plus a list of offerings from the same quarter
 * last year.
 * @author hanisko
 */
namespace Reports;

use UwCoeFramework\Reports\Configuration;
use Reports\Constants as RC;
 
class CompareQuarters extends Offerings
{
	public function getConfig()
	{
		$config = array(
			'report-name'       => 'Build Quarter',
			'listeners'         => array('\Reports\TimePeriod\NextQuarter'),
			'use-sticky-params' => true,
			'picker-list'       => array('quarter', 'curriculum'),
			'params'            => array(
				'period'      => array('class-name' => 'Reports\Params\YearCompare'),
				'year'        => array('class-name' => 'Reports\Params\Year'),
				'quarter'     => array(
						'class-name' => 'Reports\Params\Quarter',
						'required'   => true,
				),
				'curriculum'  => array(
						'class-name' => 'Reports\Params\Curriculum',
						'default'    => 'EDUC',
				),
				'canceled'    => array(
						'class-name' => 'Reports\Params\Canceled',
						'default'    => RC::SHOW_ALL,
				),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
	/**
	 * Returns an array of Db_Offering objects from the same quarter
	 * previous year
	 * @return array[Db_Offering]
	 */
	public function getLastYear()
	{
		$this->lazyload();
		return $this->index['lastyear'];
	}
	
	/**
	 * Returns an array containing the key objects of this report, in the
	 * base implementation an array of Db_Offering objects.
	 */
	public function getReport()
	{
		$this->lazyload();
		return $this->index['sectionmap'];
	}
	
	/**
	 * Returns an array of Db_Offering objects from the targeted quarter
	 * @return array[Db_Offering]
	 */
	public function getWorkingQuarter()
	{
		$this->lazyload();
		return $this->index['currquarter'];
	}

	/**
	 * Reset the internal object registries to empty arrays. Call this before
	 * loading a report.
	 */
	protected function initReport()
	{
		parent::initReport();
		$this->index['sectionmap'] = array();
		$this->index['currquarter'] = array();
		$this->index['lastyear'] = array();
	}
	
	/**
	 * Loads report data from the database. Handled automatically by getReport()
	 * method, but allows for alteration and re-running of query.
	 */
	public function load()
	{
		$this->initReport();
		$this->buildSqlPhrases();
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT c.*, o.*, s.staffid, s.personid, s.role, s.timesched, s.buyoutreason, p.* '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'LEFT OUTER JOIN staff s '
		     . 'ON o.offeringid = s.offeringid '
		     . 'AND s.meetingnumber = 1 '
		     . 'AND s.timesched = 1 '
		     . 'LEFT OUTER JOIN person p '
		     . 'ON s.personid = p.personid '
		     . $this->implodeSqlJoins()
		     . $this->implodeSqlFilters()
		     .' ORDER BY o.year, o.quarter, c.curriculum, c.courseno, o.section, c.wildcardtitle, c.title';
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			$offering = $this->registerOffering($row);
			$offering->setCourse($this->registerCourse($row));
			if ($row['staffid']) {
				$staff = $this->registerStaff($row);
				$staff->setPerson($this->registerPerson($row));
				$offering->setInstructor($staff);
			} else {
				$offering->noInstructor();
			}
			$this->index['currquarter'][] = $offering;
			$index = $row['curriculum'].'-'.$row['courseno'].'-'.$row['section'];
			if (!array_key_exists($index, $this->index['sectionmap'])) {
				$this->index['sectionmap'][$index] = array(null,null);
			}
			if ($row['year'] == $this->getParam('year')->getValue()) {
				$this->index['currquarter'][] = $offering;
				$this->index['sectionmap'][$index][0] = $offering;
			} else {
				$this->index['lastyear'][] = $offering;
				$this->index['sectionmap'][$index][1] = $offering;
			}
		}
		ksort($this->index['sectionmap']);
	}
	
}