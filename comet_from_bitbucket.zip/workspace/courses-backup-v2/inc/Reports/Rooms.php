<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report of offerings that need attention in UW Time Schedule
 * @author hanisko
 */
namespace Reports;

use Reports\Constants as RC;

class Rooms extends Offerings
{
	
	public function getConfig()
	{
		$config = array(
			'report-name'       => 'Room Schedule',
			'listeners'         => array('\Reports\TimePeriod\NextQuarter'),
			'use-sticky-params' => true,
			'picker-list'       => array('quarter', 'curriculum', 'roomstatus'),
			'params'      => array(
				'quarter'        => array('class-name' => 'Reports\Params\Quarter', 'required' => true),
				'roomstatus'     => array('class-name' => 'Reports\Params\RoomStatus','default' => RC::SHOW_NEEDS_ACTION,),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
}