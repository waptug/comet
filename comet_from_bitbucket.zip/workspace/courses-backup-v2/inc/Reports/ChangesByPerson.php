<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Report of offerings where a specified person is responsible for a
 * change request
 * @author hanisko
 */
namespace Reports;

class ChangesByPerson extends CoursesAbstract
{
	private $fetch;
	
	public function getConfig()
	{
		$config = array(
			'report-name'  => 'Change Requests',
			'params'       => array(
				'changeperson'   => array(
					'class-name' => 'Reports\Params\ChangePerson',
					'default'    => \User::GetLoggedInUser()->personid, 
					'required'   => true),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
	protected function initReport()
	{
		parent::initReport();
		$this->objectTypes['changes'] = '\Db_ChangeMessage';
		$this->index['report'] = array();
		$this->index['changes'] = array();
		$this->fetch = array();
	}
	
	public function load()
	{
		$this->initReport();
		$this->buildSqlPhrases();
		$db = \DbFactory::GetConnection();
		// get changeids where person has been asked
		$sql = 'SELECT ask.changeid, ask.parent_changeid, ask.offeringid '
		     . 'FROM changes ask '
		     . 'INNER JOIN changes parent '
		     . 'ON parent.changeid = ask.parent_changeid '
		     . 'INNER JOIN offering o '
		     . 'ON ask.offeringid = o.offeringid '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'WHERE ask.ask_response_changeid IS NULL '
		     . 'AND parent.resolution_changeid IS NULL '
		     . 'AND ask.ask_personid = '.$this->getValue('changeperson');
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			$this->addFetch('changeid', $row['changeid']);
			$this->addFetch('changeid', $row['parent_changeid']);
			$this->addFetch('offeringid', $row['offeringid']);
			$this->index['report'][$row['changeid']] = null;
		}
		// get changeids where person is admin
		$sql = 'SELECT changes.changeid, changes.offeringid '
		     . 'FROM changes '
		     . 'INNER JOIN offering o '
		     . 'ON changes.offeringid = o.offeringid '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '  
		     . 'INNER JOIN rouperson '
		     . 'ON c.rouid = rouperson.rouid ' 
		     . 'WHERE rouperson.rou_role = \'admin\' ' 
		     . 'AND parent_changeid IS NULL '
		     . 'AND resolution_changeid IS NULL '
		     . 'AND rouperson.personid = '.$this->getValue('changeperson');
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			$this->addFetch('changeid', $row['changeid']);
			$this->addFetch('offeringid', $row['offeringid']);
			$this->index['report'][$row['changeid']] = null;
		}
		// load changes
		if ($this->countFetch('changeid')) {
			$sql = 'SELECT c.*, p.* '
			     . 'FROM changes c '
			     . 'INNER JOIN person p '
			     . 'ON c.author_personid = p.personid '
			     . 'WHERE c.changeid IN('.$this->getFetchList('changeid').') '
			     .' ORDER BY c.entered_date';
			$results = $db->fetchAssoc($sql);
			foreach ($results as $row) {
				$change = $this->registerChange($row);
				$change->setAuthor($this->registerPerson($row));
			}
		}
		// load offerings
		if ($this->countFetch('offeringid')) {
			$sql = 'SELECT c.*, o.*, s.staffid, s.personid, s.role, s.timesched, s.buyoutreason, p.* '
			     . 'FROM offering o '
			     . 'INNER JOIN course c '
			     . 'ON o.courseid = c.courseid '
			     . 'LEFT OUTER JOIN staff s '
			     . 'ON o.offeringid = s.offeringid '
			     . 'AND s.meetingnumber = 1 '
			     . 'AND s.timesched = 1 '
			     . 'LEFT OUTER JOIN person p '
			     . 'ON s.personid = p.personid '
			     . 'WHERE o.offeringid IN('.$this->getFetchList('offeringid').') '
			     .' ORDER BY o.year, o.quarter, c.curriculum, c.courseno, o.section, c.wildcardtitle, c.title';
			$results = $db->fetchAssoc($sql);
			foreach ($results as $row) {
				$offering = $this->registerOffering($row);
				$offering->setCourse($this->registerCourse($row));
				if ($row['staffid']) {
					$staff = $this->registerStaff($row);
					$staff->setPerson($this->registerPerson($row));
					$offering->setInstructor($staff);
				} else {
					$offering->noInstructor();
				}
			}
		}
		// link changes to parents, offering, and report
		foreach ($this->index['changes'] as $change) {
			if (array_key_exists($change->parent_changeid, $this->index['changes'])) {
				$change->setParent($this->index['changes'][$change->parent_changeid]);
			}
			if (array_key_exists($change->offeringid, $this->index['offerings'])) {
				$change->setOffering($this->index['offerings'][$change->offeringid]);
			}
			if (array_key_exists($change->changeid, $this->index['report'])) {
				$this->index['report'][$change->changeid] = $change;
			}
		}
	}
	
	public function getReport()
	{
		$this->lazyload();
		return $this->index['report'];
	}
	
	/**
	 * Maintain a list of database items to retrieve from the database, adds 
	 * unique instance of 
	 * @param string $type
	 * @param string $id
	 */
	private function addFetch($type, $id)
	{
		if (!is_array($this->fetch)) {
			$this->fetch = array();
		}
		if (!array_key_exists($type, $this->fetch)) {
			$this->fetch[$type] = array();
		}
		if (!in_array($id, $this->fetch[$type])) {
			$this->fetch[$type][] = $id;
		}
	}

	/**
	 * Returns a count of the stored ids for the specified type
	 * @param string $type
	 * @return integer
	 */
	private function countFetch($type)
	{
		if (!is_array($this->fetch)) {
			return 0;
		}
		if (!array_key_exists($type, $this->fetch)) {
			return 0;
		}
		return count($this->fetch[$type]);
	}

	/**
	 * Returns a list of the stored ids as a comma separated list for the specified type
	 * @param string $type
	 * @return string
	 */
	private function getFetchList($type)
	{
		if (!is_array($this->fetch)) {
			return '';
		}
		if (!array_key_exists($type, $this->fetch)) {
			return '';
		}
		return implode(',',$this->fetch[$type]);
	}
	
	/**
	 * Verify that a Db_Course object matching the data specified in the
	 * associative array $row exists in the registry. Create the object
	 * if needed and return the object.
	 * @param array $row
	 * @return \Db_ChangeMessage
	 */
	protected function registerChange($row)
	{
		return $this->registerObject('changes', $row['changeid'], $row);
	}
	
}