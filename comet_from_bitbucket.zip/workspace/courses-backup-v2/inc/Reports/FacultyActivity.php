<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Adds application specific functionality to the ReportAbstract class
 * @author hanisko
 */
namespace Reports;

class FacultyActivity extends Offerings //CoursesAbstract
{
	public function getConfig()
	{
		$config = array(
			'report-name'       => 'Faculty Activity',
			'listeners'         => array('\Reports\TimePeriod\CurrentAcademicYear', '\Reports\TimePeriod\AcademicYearOnly'),
			'use-sticky-params' => true,
			'picker-list'       => array('year'),
			'params'            => array(
				'personhasarea'   => array('class-name' => 'Reports\Params\PersonHasArea', 'default' => 1),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}

	private static $areas = array(
		'und'   => 'Carol Davis',
		'grad'  => 'Joy Williamson-Lott',
		'pro'   => 'Cap Peck',
	);

	/**
	 * Return an array list of COE areas that faculty can be
	 * associated with.
	 * @return array
	 */
	public function getAreas()
	{
		return self::$areas;
	}
	
	/**
	 * Return an array list of Db_Person objects representing the
	 * faculty associated with the specified area.
	 * @param string $area
	 * @return array[Db_Person]
	 */
	public function getFaculty($area)
	{
		if (array_key_exists($area, $this->index['by_area']) && !is_null($this->index['by_area'][$area])) {
			return $this->index['by_area'][$area];
		} else {
			return array();
		}
	}
	
	/**
	 * Returns an array list of Db_Offering objects representing offerings
	 * where the specified faculty has a staff role.
	 * @param \Db_Person $faculty
	 * @return array[Db_Offering]
	 */
	public function getOfferingsByFaculty(\Db_Person $faculty)
	{
		if (array_key_exists($faculty->personid, $this->index['by_faculty']) && !is_null($this->index['by_faculty'][$faculty->personid])) {
			return $this->index['by_faculty'][$faculty->personid];
		} else {
			return array();
		}
	}
	
	public function getReport()
	{
		if (!is_array($this->index['by_area'])) {
			$this->load();
		}
		return $this->index['by_area'];
	}
	
	protected function initReport()
	{
		parent::initReport();
		$this->index['by_faculty'] = array();
		$this->index['by_area'] = array_fill_keys(array_keys(self::$areas), null);
	}
	
	/**
	 * Loads report data from the database. Handled automatically by getReport()
	 * method, but allows for alteration and re-running of query.
	 */
	public function load()
	{
		$this->initReport();
		$this->buildSqlPhrases();
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT * FROM person WHERE area IS NOT NULL ORDER BY lastname, firstname';
		$results = $db->fetchAssoc($sql);
		$this->faculty = array();
		foreach ($results as $row) {
			// Register a Db_Person object and create a reference in the by area list
			$this->index['by_area'][$row['area']][] = $this->registerPerson($row);
		}
		$sql = 'SELECT c.*, o.*, s.staffid, s.personid, s.role, s.timesched, s.buyoutreason, p.* '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'LEFT OUTER JOIN staff s '
		     . 'ON o.offeringid = s.offeringid '
		     . 'LEFT OUTER JOIN person p '
		     . 'ON s.personid = p.personid '
		     . $this->implodeSqlJoins()
		     . $this->implodeSqlFilters()
		     .' ORDER BY o.year, o.quarter, c.curriculum, c.courseno, o.section, c.wildcardtitle, c.title';
		$this->sql = $sql;
		$results = $db->fetchAssoc($sql);
		//debug(__METHOD__."\n".$sql);
		foreach ($results as $row) {
			$offering = $this->registerOffering($row);
			$offering->setCourse($this->registerCourse($row));
			if ($row['staffid']) {
				$staff = $this->registerStaff($row);
				$staff->setPerson($this->registerPerson($row));
				$offering->setInstructor($staff);
			}
			if (!array_key_exists($row['personid'], $this->index['by_faculty'])) {
				$this->index['by_faculty'][$row['personid']] = array();
			}
			$this->index['by_faculty'][$row['personid']][] = $offering;
		}
		// add instructor count
		$sql = 'SELECT s.offeringid, COUNT(s.staffid) AS qty '
		     . 'FROM staff s '
		     . 'INNER JOIN person p '
		     . 'ON s.personid = p.personid '
		     . "WHERE s.role IN('faculty','adjunct','instructor') "
		     . 'AND p.issupport = 0 '
		     . 'GROUP BY s.offeringid';
		$results = $db->fetchPairs($sql);
		foreach ($results as $offeringid => $count) {
			if (array_key_exists($offeringid, $this->index['offerings'])) {
				$this->index['offerings'][$offeringid]->setInstructorCount($count);
			}
		}
	}
	
}