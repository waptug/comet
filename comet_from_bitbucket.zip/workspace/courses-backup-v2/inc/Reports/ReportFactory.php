<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Factory class for generating report objects
 */
namespace Reports;

class ReportFactory
{
	private static $report_settings = array(
		'public' => array(
			'class'   => '\Reports\Offerings',
			'view'    => 'report/views/offerings/public.phtml',
			'csvview' => 'report/views/csv/offerings.phtml',
			'title'   => 'College of Education Course Plan',
			'intro'   => null,
		),
		'public-seattle' => array(
			'class'   => '\Reports\PublicSeattle',
			'view'    => 'report/views/offerings/student_view.phtml',
			'csvview' => 'report/views/csv/offerings.phtml',
			'title'   => 'College of Education - Seattle Campus',
			'intro'   => null,
		),
		'public-uweo' => array(
			'class'   => '\Reports\PublicUweo',
			'view'    => 'report/views/offerings/student_view.phtml',
			'csvview' => 'report/views/csv/offerings.phtml',
			'title'   => 'College of Education - UW Professional & Continuing Education',
			'intro'   => null,
		),
		'offerings' => array(
			'class'   => '\Reports\Offerings',
			'view'    => 'report/views/offerings/table.phtml',
			'csvview' => 'report/views/csv/offerings.phtml',
			'title'   => 'Course Offerings',
			'intro'   => null,
		),
		'year-summary' => array(
			'class'   => '\Reports\YearSummary',
			'view'    => 'report/views/offerings/year-summary.phtml',
			'csvview' => 'report/views/csv/offerings.phtml',
			'title'   => 'Year Summary',
			'intro'   => null,
		),
		'week' => array(
			'class'   => '\Reports\Meetings',
			'view'    => 'report/views/meetings/week.phtml',
			'csvview' => 'report/views/csv/offerings.phtml',
			'title'   => 'Weekly Meeting Schedule by Quarter',
			'intro'   => null,
		),
		'syllabus' => array(
			'class'   => '\Reports\Offerings',
			'view'    => 'report/views/offerings/syllabus.phtml',
			'csvview' => 'report/views/csv/syllabus.phtml',
			'title'   => 'Offerings Syllabus',
			'intro'   => null,
		),
		'compare-quarters' => array(
			'class'   => '\Reports\CompareQuarters',
			'view'    => 'report/views/offerings/compare-quarters.phtml',
			'csvview' => 'report/views/csv/offerings.phtml',
			'title'   => 'Compare Quarters',
			'intro'   => null,
		),
		'plan-quarter' => array(
			'class'   => '\Reports\CompareQuarters',
			'view'    => 'report/views/offerings/plan-quarter.phtml',
			'csvview' => 'report/views/csv/offerings.phtml',
			'title'   => 'Compare Quarters',
			'intro'   => null,
		),
		'uwts' => array(
			'class'   => '\Reports\TimeSchedule',
			'view'    => 'report/views/offerings/uwts.phtml',
			'csvview' => 'report/views/csv/offerings.phtml',
			'title'   => 'Needs Update in UW Time Schedule',
			'intro'   => null,
		),
		'rooms' => array(
			'class'   => '\Reports\Rooms',
			'view'    => 'report/views/offerings/rooms.phtml',
			'csvview' => 'report/views/csv/rooms.phtml',
			'title'   => 'Room Schedule Entry',
			'intro'   => null,
		),
		'faculty-activity' => array(
			'class'   => '\Reports\FacultyActivity',
			'view'    => 'report/views/offerings/faculty-activity.phtml',
			'csvview' => 'report/views/csv/faculty-activity.phtml',
			'title'   => 'Faculty Activity',
			'intro'   => null,
		),
		'courses' => array(
			'class'   => '\Reports\Courses',
			'view'    => 'report/views/courses/table.phtml',
			'csvview' => 'report/views/csv/courses.phtml',
			'title'   => 'Courses',
			'intro'   => null,
		),
		'course-tag' => array(
			'class'   => '\Reports\TagCourses',
			'view'    => 'report/views/courses/table.phtml',
			'csvview' => 'report/views/csv/courses.phtml',
			'title'   => 'Course Tags',
			'intro'   => null,
		),
		'course-repetition' => array(
			'class'   => '\Reports\CoursesRepetition',
			'view'    => 'report/views/courses/repetition.phtml',
			'csvview' => 'report/views/csv/repetition-rules.phtml',
			'title'   => 'Courses with Repetition Rules',
			'intro'   => null,
		),
		'people-quarter' => array(
			'class'   => '\Reports\TeachingStaff',
			'view'    => 'report/views/people/table-email.phtml',
			'csvview' => 'report/views/csv/persons.phtml',
			'title'   => 'Teaching Staff by Quarter',
			'intro'   => null,
		),
			
	);
	
	/**
	 * Returns a Reports_Offering class based on $type
	 * @param string $type
	 * @return \Reports\CoursesAbstract
	 */
	public static function Get($type)
	{
		if (array_key_exists($type, self::$report_settings)) {
			$settings = self::$report_settings[$type];
		} else {
			$settings = self::$report_settings['offerings'];
		}
		$report = new $settings['class']();
		$report->type = $type;
		$report->view = $settings['view'];
		$report->title = $settings['title'];
		$report->csvview = $settings['csvview'];
		$report->intro = $settings['intro'];
		return $report;
	}
	
}