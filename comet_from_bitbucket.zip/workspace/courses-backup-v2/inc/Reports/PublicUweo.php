<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Public student view of course plan, locked to UWPCE (uweo)
 * @author hanisko
 */
namespace Reports;

use Reports\Constants as RC;

class PublicUweo extends Offerings
{
	
	public function getConfig()
	{
		$config = array(
			'picker-list'  => array('year', 'curriculum', 'tags'),
			'params'       => array(
				'institution'     => array(
					'class-name' => 'Reports\Params\Institution', 
					'default'    => 3,  
					'locked'     => true),
				'canceled'        => array(
					'class-name' => 'Reports\Params\Canceled', 
					'default'    => RC::SHOW_NOT,  
					'locked'     => true),
				'rou'             => null, 
				'classroom'       => null,
				'enrollmentfield' => null,
				'lessthan'        => null,
				'greaterthan'     => null,
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
}