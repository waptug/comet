<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Adds application specific functionality to the ReportAbstract class
 * @author hanisko
 */
namespace Reports;

use Reports\Constants as RC;

class Responsible extends Offerings
{
	public function getConfig()
	{
		$config = array(
			'report-name' => 'Responsible',
			'picker-list' => array('quarter', 'rou'),
			'params'      => array(
				'rou'     => array(
						'class-name' => 'Reports\Params\Rou', 
						'required'   => true,
						'default'    => 3, 
						'use-sticky' => true),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
	/**
	 * Reset the internal object registries to empty arrays. Call this before
	 * loading a report.
	 */
	protected function initReport()
	{
		parent::initReport();
		$this->index['notscheduled'] = array();
	}
	
	/**
	 * Query the data store and populate the object tree that makes up this report
	 */
	public function load()
	{
		parent::load();
		// add not scheduled
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT c.* '
		     . 'FROM course c '
		     . 'WHERE c.rouid = '.$this->getValue('rou').' '
		     . 'ORDER BY c.curriculum, c.courseno, c.wildcardtitle, c.title';
		$results = $db->fetchAssoc($sql);
		//debug(__METHOD__."\n".$sql);
		foreach ($results as $row) {
			if (!array_key_exists($row['courseid'], $this->index['courses'])) {
				$course = new \Db_Course($row['courseid'], false);
				$course->init($row);
				$this->index['notscheduled'][$course->courseid] = $course;
			}
		}
	}
	
	public function getNotScheduled()
	{
		$this->lazyload();
		return $this->index['notscheduled'];
	}
	
}