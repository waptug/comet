<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Adds application specific functionality to the ReportAbstract class
 * @author hanisko
 */
namespace Reports;

use UwCoeFramework\Reports\Configuration;
use Reports\Constants as RC;

class Offerings extends CoursesAbstract
{
	public function getConfig()
	{
		$config = array(
			'report-name'       => 'Offerings',
			'listeners'         => array('\Reports\TimePeriod\CurrentQuarter'),
			'use-sticky-params' => true,
			'picker-list'       => array('quarter', 'curriculum'),
			'params'            => array(
				'period'          => array('class-name' => 'Reports\Params\Period'),
				'year'            => array('class-name' => 'Reports\Params\Year'),
				'quarter'         => array('class-name' => 'Reports\Params\Quarter'),
				'length'          => array('class-name' => 'Reports\Params\Length'),
				'curriculum'      => array('class-name' => 'Reports\Params\Curriculum'),
				'rou'             => array('class-name' => 'Reports\Params\Rou'),
                'instructor'      => array('class-name' => 'Reports\Params\InstructorType'),
                'canceled'        => array('class-name' => 'Reports\Params\Canceled'),
				'classroom'       => array('class-name' => 'Reports\Params\Classroom'),
				'tags'            => array('class-name' => 'Reports\Params\Tags'),
				'institution'     => array('class-name' => 'Reports\Params\Institution'),
				'enrollmentfield' => array('class-name' => 'Reports\Params\EnrollmentField'),
				'lessthan'        => array('class-name' => 'Reports\Params\LessThan'),
				'greaterthan'     => array('class-name' => 'Reports\Params\GreaterThan'),
			)
		);
		return $this->mergeConfig(parent::getConfig(), $config);
	}
	
	/**
	 * Query the data store and populate the object tree that makes up this report
	 */
	public function load()
	{
		$this->initReport();
		$this->index['byquarter'] = array(1=>array(),2=>array(),3=>array(),4=>array());
		$this->buildSqlPhrases();
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT c.*, o.*, s.staffid, s.personid, s.role, s.timesched, s.buyoutreason, p.* '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'LEFT OUTER JOIN staff s '
		     . 'ON o.offeringid = s.offeringid '
		     . 'AND s.meetingnumber = 1 '
		     . 'AND s.timesched = 1 '
		     . 'LEFT OUTER JOIN person p '
		     . 'ON s.personid = p.personid '
		     . $this->implodeSqlJoins()
		     . $this->implodeSqlFilters()
		     .' ORDER BY o.year, o.quarter, c.curriculum, c.courseno, o.section, c.wildcardtitle, c.title';
		$this->sql = $sql;
		$results = $db->fetchAssoc($sql);
		//debug(__METHOD__."\n".$sql);
		foreach ($results as $row) {
			$offering = $this->registerOffering($row);
			$offering->setCourse($this->registerCourse($row));
			if ($row['staffid']) {
				$staff = $this->registerStaff($row);
				$staff->setPerson($this->registerPerson($row));
				$offering->setInstructor($staff);
			} else {
				$offering->noInstructor();
			}
			// create a reference to this offering in the By Quarter structure
			if ($row['quarter'] > 0 && $row['quarter'] < 5) {
				$this->index['byquarter'][$row['quarter']][] = $offering;
			}
		}
	}
	
	public function getReport()
	{
		$this->lazyload();
		return $this->index['offerings'];
	}
	
	public function getOfferings()
	{
		$this->lazyload();
		return $this->index['offerings'];
	}
	
	public function getOfferingsByQuarter($qtr)
	{
		$this->lazyload();
		return $this->index['byquarter'][$qtr];
	}
	
}