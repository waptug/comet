<?php
/**
 * @package edu.uw.education.courses
 */
/**
 * Factory and registry for the DbConnection objects
 * @author hanisko
 */

class DbFactory
{
	private static $_registry = array();
	
	/**
	 * Returns a database connection object using the dbconfig file 
	 * identified by $name. Returns an existing connection stored in
	 * an internal registry or generates a new connection as needed.
	 * @param string $name
	 * @return DbConnection
	 */
	public static function GetConnection($name = 'courses')
	{
		if (array_key_exists($name, self::$_registry)) {
			return self::$_registry[$name];
		}
		$db_config = (array)Config::getConfig('database');
		if (!array_key_exists($name, $db_config)) {
			throw new Exception('Database configuration for "'.$connection_name.'" not found');
		}
		self::$_registry[$name] = new DbConnection($db_config[$name]);
		return self::$_registry[$name];
	}
	
}
