<?php
/**
 * @package UW_COE_Framework
 */
/** 
 * A generic object store. Provides a central runtime repository of
 * object to minimize overhead and memory usage of multiple instances
 * of the same objects.
 * @author hanisko
 */

class ObjectRegistry
{
	private static $_store;

	public static function Add($type, $key, $object)
	{
		if (!is_array(self::$_store)) {
			self::$_store = array();
		}
		if (!array_key_exists($type, self::$_store)) {
			self::$_store[$type] = array();
		}
		self::$_store[$type][$key] = $object;
	}
	
	public static function Get($type, $key)
	{
		if (!is_array(self::$_store)) {
			self::$_store = array();
		}
		if (!array_key_exists($type, self::$_store)) {
			return null;
		}
		if (array_key_exists($key, self::$_store[$type])) {
			return self::$_store[$type][$key];
		} else {
			return null;
		}
	}
	
}