<?php
/**
 * Initialize all application wide settings and resources. A central 
 * file to be loaded by all scripts which makes available common 
 * resources.
 */

// Set the error communication to strict and verbose
error_reporting(E_ALL | E_STRICT);
ini_set('display_startup_errors', 1); 
ini_set('display_errors', 1);

// set default time zone for PHP 5.1 strict rules
date_default_timezone_set('America/Los_Angeles');

// Add our application specific include directories to the path
$i_basedir = dirname(dirname(__FILE__)); // the application root dir is one up from this directory
set_include_path(get_include_path().PATH_SEPARATOR.$i_basedir.'/views');

// define an autoload function to load classes
require $i_basedir.'/libraries/UwCoeFramework/Autoloader.php';
new UwCoeFramework\Autoloader($i_basedir.'/inc');
new UwCoeFramework\Autoloader($i_basedir.'/libraries');

// Load our standard function libraries
require_once 'funcs_redirect.php';
require_once 'funcs_viewhelpers.php';

// Store the application base URL in the Environment
global $fw_baseurl;
Environment::SetAppBase($fw_baseurl);

// store session data in database
#require 'SessionDb.php';
// start the PHP session
@session_start();

// provides an option to not check authorization
$fw_noauth = array_key_exists('fw_noauth', $GLOBALS) ? $GLOBALS['fw_noauth'] : false;

// check if logged in user is allowed access to this file
if (!$fw_noauth) {
	if (!Acl::HasAuth(Request::Phpself())) {
		header('HTTP/1.0 403 Forbidden');
		include 'error/noauth.phtml';
		exit;
	}
}
