<?php


abstract class Form
{
	// constants to make FormElement->getUserInput() args more readable
	const IS_STRING = false;
	const IS_INTEGER = true;
	const STRIP_TAGS = true;
	const DONT_STRIP_TAGS = false;
	const GET_LIST_VALUE = true;
	
	private $_inputs = null;
	
	public function __construct()
	{
		$this->_inputs = array();
	}
	
	public function __set($name, $value)
	{
		$this->setInput($name, $value);
	}
	
	public function __get($name)
	{
		return $this->getInput($name);
	}
	
	public function __isset($name)
	{
		return (bool) isset($this->_inputs[$name]);
	}
	
	public function __unset($name)
	{
		if (isset($this->_inputs[$name])) {
			unset($this->_inputs[$name]);
		}
	}
	
	/**
	 * Search the form element members for error messages. If
	 * any error messages are found return true.
	 *
	 * @return boolean
	 */
	public function hasErrors()
	{
		$trouble = false;
		foreach ($this->_inputs as $e) {
			if (strlen($e->error) > 0) {
				$trouble = true;
				break;
			}
		}
		return $trouble;
	}
		
	abstract public function process();
	
	/**
	 * Search the provided objects for property names that match
	 * the list of FormElement names. When a matching property is
	 * found copy that value to the form value.
	 *
	 * @param unknown_type $object
	 */
	public function copyObject($object)
	{
		$names = array_keys($this->_inputs);
		foreach ($names as $n) {
			if (isset($object->$n)) {
				$this->_inputs[$n]->value = $object->$n;
			}
		}
	}
	
	/**
	 * Return the FormElement object identified by $name
	 * @param string $name
	 * @return \FormElement
	 */
	public function getInput($name)
	{
		if (array_key_exists($name, $this->_inputs)) {
			return $this->_inputs[$name];
		} else {
			return null;
		}
	}
	
	/**
	 * Return the FormElement object identified by $name
	 * @param \FormElement $input
	 */
	public function setInput($name, $input)
	{
		$this->_inputs[$name] = $input;
	}
	
	/**
	 * Check the query string and POST for user input for a specified
	 * field. Query string (GET) fields have priority. Optionally strip
	 * PHP and HTML code from the input. Return a default value if no 
	 * user input is available.
	 *
	 * @param string $fieldname the name of the GET or POST field to check for
	 * @param string $default a value to use if neither GET or POST is available
	 * @param boolean $striptags whether to apply the strip tags function to this user input
	 * @return string
	 */
	public static function GetUserInput($fieldname, $default = '', $striptags = true)
	{
		global $request, $request_map;
		$value = $default;
		// give high priority to query string
		if (isset($_GET[$fieldname])) {
			$value = trim($_GET[$fieldname]);
		}
		// next check the post
		elseif (isset($_POST[$fieldname])) {
			$value = trim($_POST[$fieldname]);
		}
		// check if this field is expected as a URI embedded argument
		elseif (is_array($request) && is_array($request_map) && ($i = array_search($fieldname, $request_map)) !== false && isset($request[$i])) {
			$value = $request[$i];
		}
		// otherwise use the default
		else {
			$value = $default;
		}
		
		// remove any HTML or PHP code from the input
		if ($striptags) {
			$value = strip_tags($value);
		}
		return $value;
	}

	/**
	 * Check the query string and POST for user input for a specified field in
	 * a case where the field is a list value. Query string (GET) fields have 
	 * priority. Each individual value is processed, optionally stripping PHP 
	 * and HTML code from the input and/or casting values to integers. The 
	 * located values are returned as an array. If no matching field is found an 
	 * empty array is returned.
	 *
	 * @param string $fieldname the name of the GET or POST field to check for
	 * @param boolean $striptags whether to apply the strip tags function to this user input
	 * @param boolean $is_integer whether to cast this user input as integers
	 * @return array
	 */
	public static function GetUserInputList($fieldname, $striptags = true, $is_integer = false)
	{
		$list = array();
		// give high priority to query string
		if (isset($_GET[$fieldname])) {
			$list = $_GET[$fieldname];
		}
		// next check the post
		elseif (isset($_POST[$fieldname])) {
			$list = $_POST[$fieldname];
		}
		
		$max = count($list);
		
		for ($i = 0; $i < $max; ++$i) {
			$list[$i] = trim($list[$i]);
			// remove any HTML or PHP code from the input
			if ($striptags) {
				$list[$i] = strip_tags($list[$i]);
			}
			if ($is_integer) {
				$list[$i] = (int) $list[$i];
			}
		}
		return $list;
	}
	
	/**
	 * Clean up text provided as user input. Provides a variety of options for sanitizing
	 * text.
	 *
	 * @param string $text subject text to be changed
	 * @param bool $striptags strip HTML tags from the input text
	 * @param bool $addHtmlBreaks replace newline characters with HTML <br /> elements
	 * @param int $maxCharacters limit the string length dropping all remaining characters
	 * @return string
	 */
	public static function ScrubText($text, $striptags = true, $addHtmlBreaks = false, $maxCharacters = 0)
	{
		// remove leading and trailing whitespace
		$text = trim($text);
	
		// remove any HTML or PHP code from the input
		if ($striptags) {
			$text = strip_tags($text);
		}
		
		// remove any CR/LF
		$newline = ' ';
		if ($addHtmlBreaks) {
			$newline = '<br />';
		}
		$text = str_replace(chr(10), $newline, $text); //newline
		$text = str_replace(chr(13), ' ', $text); //carriage return
		
		// make multiple spaces singles
		$text = preg_replace('/ +/', ' ', $text);
		
		// reduce the string to a maximum length
		if ($maxCharacters > 0) {
			$text = substr($text, 0, $maxCharacters);
		}
		
		return $text;
	}
	
	/**
	 * Check if an email is in standard format. Return true if it is, false
	 * otherwise.
	 *
	 * @param string $email value to be tested as an email address
	 * @return bool
	 */
	public static function ValidEmail($email)
	{
		$atpos = strrpos($email, '@');
		if ($atpos === false)
		{
			return false; //'no at sign';	
		}
			
		$localpart = substr($email, 0, $atpos);
		$domainpart = substr($email, $atpos + 1);
		$locallength = strlen($localpart);
		$domainlength = strlen($domainpart);
		
		if ($locallength < 1 || $locallength > 64)
		{
			return false; //'local part invalid length';
		}
		else if ($domainlength < 1 || $domainlength > 255)
		{
			return false; //'domain part invalid length';
		}
		
		// leading or trailing . on domain is wrong
		if ($domainpart[0] == '.' || $domainpart[$domainlength - 1] == '.')
		{
			return false; //'dot at beginning or end of domain part';
		}
	
		// two adjacent dots in domains are illegal
		if (strpos($domainpart, '..') !== false) 
		{
			return false; //'double dots in domain part';
		}
		
		// domains must have 2 or more sections
		$domainbits = explode('.', $domainpart);
		if (count($domainbits) < 2) {
			return false; //'domain part needs at least 2 sections';
		}
		
		// any character proceeded by a backslash is legal and 
		// can be removed from the test subject
		$localpart = preg_replace('/\\\\./', '', $localpart);
		
		// any characters enclosed in double quotes are legal and can be removed
		// can be removed from the test subject
		$localpart = preg_replace('/"[^"]+"/', '', $localpart);
		
		// check local part length again with quoted bits deleted
		$locallength = strlen($localpart);
		
		// leading or trailing . on local part is wrong
		if ($locallength > 0) {
			if ($localpart[0] == '.' || $localpart[$locallength - 1] == '.')
			{
				return false; //'dot at beginning or end of local part';
			}
		}
		
		// two adjacent dots in local are illegal
		if (strpos($localpart, '..') !== false) 
		{
			return false; //'double dots in local part';
		}
		
		// search for any left over illegal characters
		$badbits = array();
		if (preg_match('/[^A-Za-z0-9_%=#~\\!\\$\\&\\\'\\*\\+\\-\\/\\?\\^\\`\\{\\|\\}\\.]/', $localpart, $badbits))
		{
			return false; //'found illegal character in local part: ' . implode(', ', $badbits);
		}
		
		return true;
	}
	
}