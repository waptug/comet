<?php
/**
 * Provides methods for gathering and scrubbing user input.
 * 
 * @author Paul Hanisko
 */
class UserInput
{
	const TYPE_STRING   = 0;
	const TYPE_INTEGER  = 1;
	const TYPE_NUMBER   = 2;
	const TYPE_DATETIME = 3;
	const TYPE_BOOLEAN  = 4;
	
	public static $default_scrub = array(
		'default'   => null,
		'trim'      => true,
		'striptags' => true,
		'datatype'  => self::TYPE_STRING,
		'maxlength' => 0,
		'remcrlf'   => false,
		'htmlbr'    => false
	);
	
	public static $integer_scrub = array(
		'default'   => 0,
		'datatype'  => self::TYPE_INTEGER
	);
	
	public static $html_scrub = array(
		'striptags' => false
	);
	
	/**
	 * Return true if this script is responding to an HTTP POST request
	 * @return boolean
	 */
	public static function IsPost()
	{
		if (array_key_exists('REQUEST_METHOD', $_SERVER) && $_SERVER['REQUEST_METHOD'] == 'POST') {
			return true;
		}
		return false;
	}
	
	/**
	 * Return true if this script was invoked from the shell command line
	 * instead of as an HTTP process.
	 * @return boolean
	 */
	public static function IsCommandLine()
	{
		if (array_key_exists('SHELL', $_SERVER) && array_key_exists('TERM', $_SERVER)) {
			if (!array_key_exists('HTTP_HOST', $_SERVER) && !array_key_exists('REMOTE_ADDR', $_SERVER)) {
				return true;
			}
		}
		return false;
	}
		
	/**
	 * Return the request method of the HTTP request (ex. 'POST' or 'GET') that 
	 * invoked this script or 'CMDLINE' if the script was invoked from a shell 
	 * command
	 * @return string
	 */
	public static function Method()
	{
		if (array_key_exists('SHELL', $_SERVER)) {
			return 'CMDLINE';
		}
		if (array_key_exists('REQUEST_METHOD', $_SERVER)) {
			return $_SERVER['REQUEST_METHOD'];
		}
		return null;
	}
	
	/**
	 * Check the query string and POST for user input for a specified
	 * field. Query string (GET) fields have priority. User input is scrubbed
	 * based on settings in the $options array. Following are valid array keys
	 * for the $options array
	 *    'default'   => (null) what to return if field does not exist
	 *    'trim'      => (true) remove leading and trailing whitespace
	 *    'striptags' => (true) remove HTML and PHP markup
	 *    'datatype'  => (TYPE_STRING) input will be cast to this datatype
	 *    'maxlength' => (0) if greater than zero input is cut to this length
	 *    'remcrlf'   => (false) deletes \r and \n from input
	 *    'htmlbr'    => (false) convert CR/LF to <br />
	 *
	 * @param string $fieldname name of the GET or POST field to check for
	 * @param array $options rules to follow when scrubbing user input
	 * @return string
	 */
	public static function get($fieldname, $options = null)
	{
		$options = self::BuildOptions($options);
		
		// give high priority to query string
		if (isset($_GET[$fieldname])) {
			$value = $_GET[$fieldname];
		}
		// next check the post
		elseif (isset($_POST[$fieldname])) {
			$value = $_POST[$fieldname];
		}
		// otherwise use the default
		else {
			$value = $options['default'];
		}
		
		return self::ScrubValue($value, $options);
	}
	
	/**
	 * Check the query string and POST for user input for a specified field 
	 * containing a list of values. Return the list of values as an array. 
	 * Query string (GET) fields have priority. User input is scrubbed based 
	 * on settings in the $options array. Following are valid array keys for 
	 * the $options array
	 *    'default'   => (null) what to return if field does not exist
	 *    'trim'      => (true) remove
	 *    'striptags' => (true) remove HTML and PHP markup
	 *    'datatype'  => (TYPE_STRING) input will be cast to this datatype
	 *    'maxlength' => (0) if greater than zero input is cut to this length
	 *    'remcrlf'   => (false) deletes \r and \n from input
	 *    'htmlbr'    => (false) convert CR/LF to <br />
	 *
	 * @param string $fieldname name of the GET or POST field to check for
	 * @param array $options rules to follow when scrubbing user input
	 * @return string
	 */
	public static function getList($fieldname, $options = null)
	{
		$options = self::BuildOptions($options);
		
		$list = array();
		// give high priority to query string
		if (isset($_GET[$fieldname])) {
			$list = $_GET[$fieldname];
		}
		// next check the post
		elseif (isset($_POST[$fieldname])) {
			$list = $_POST[$fieldname];
		} else {
			// if a default value was provided add that on the list
			if (!is_null($options['default'])) {
				$list[] = $options['default'];
			}
		}
		
		$max = count($list);
		
		for ($i = 0; $i < $max; ++$i) {
			$list[$i] = self::ScrubValue($list[$i], $options);
		}
		return $list;
	}
	
	/**
	 * Merge an associative array of scrub options with the default options
	 * and return the resulting array.
	 * @param array $options
	 * @return array
	 */
	protected static function BuildOptions($options) 
	{
		if (is_array($options)) {
			$opt = array();
			foreach (self::$default_scrub as $key => $value) {
				if (array_key_exists($key, $options)) {
					$opt[$key] = $options[$key];
				} else {
					$opt[$key] = $value;
				}
			}
		} else {
			$opt = self::$default_scrub;
		}
		return $opt;
	}
	
	/**
	 * Use the rules defined in $options array to sanitize user input.
	 * @param string $value raw user input
	 * @param array $options settings for scrubbing input
	 * @return string
	 */
	protected static function ScrubValue($value, $options)
	{
		// null is always a safe/valid value
		if (is_null($value)) {
			return null;
		}
		// PHP casting will efficiently return very safe versions of data
		switch ($options['datatype']) {
			case self::TYPE_INTEGER:
				return (int) $value;
				break;
			case self::TYPE_NUMBER:
				return (double) $value;
				break;
			case self::TYPE_BOOLEAN:
				return (bool) $value;
				break;
			case self::TYPE_DATETIME:
				return strtotime($value);
				break;
			default:
				break;
		}
		// trim leading and trailing whitespace
		if ($options['trim']) {
			$value = trim($value);
		}
		// remove HTML and PHP tags from input
		if ($options['striptags']) {
			$value = strip_tags($value);
		}
		// remove any CR/LF
		if ($options['remcrlf'] || $options['htmlbr']) {
			$newline = ' ';
			if ($options['htmlbr']) {
				$newline = '<br />';
			}
			$value = str_replace(chr(10), $newline, $value); //newline
			$value = str_replace(chr(13), ' ', $value); //carriage return
			// make multiple spaces singles
			$value = preg_replace('/ +/', ' ', $value);
		}
		// reduce the string to a maximum length
		if ($options['maxlength'] > 0) {
			$value = substr($value, 0, $options['maxlength']);
		}
		return $value;
	}
	
}
