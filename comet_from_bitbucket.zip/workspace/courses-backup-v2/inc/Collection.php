<?php

class Collection implements Iterator 
{
	private $_collection;
	private $_indicies;
	private $_position;
	
	public function __construct()
	{
		$this->_collection = array();
		$this->_indicies = array();
		$this->_position = 0;
	}
	
	// return the current element value
	public function current()
	{
		return $this->_collection[$this->_indicies[$this->_position]];
	}
	
	// return the current element key
	public function key()
	{
		return $this->_indicies[$this->_position];
	}
	
	// move pointer to next element in collection
	public function next()
	{
		++$this->_position;
	}
	
	// reset the pointer to the beginning of collection
	public function rewind()
	{
		$this->_position = 0;
	}
	
	// check if the current pointer position is within range of collection
	public function valid()
	{
		return isset($this->_indicies[$this->_position]);
	}
	
	public function __set($name, $value)
	{
		if (isset($this->_collection[$name])) {
			$this->_collection[$name] = $value;
		} else {
			$this->push($name, $value);
		}
	}
	
	public function __get($name)
	{
		if (isset($this->_collection[$name])) {
			return $this->_collection[$name];
		} else {
			return null;
		}
	}
	
	public function __isset($name)
	{
		return (bool) isset($this->_collection[$name]);
	}
	
	public function __unset($name)
	{
		// search for the element to unset
		$location = array_search($name, $this->_indicies);
		// if it wasn't found leave
		if ($location === false) { return; }
		
		// delete that element from the index and collection
		//array_splice($this->_indicies, $location, 1);
		//array_splice($this->_collection, $location, 1);
		
		// How 'bout... THIS!
		unset($this->_collection[$name]);
		// then repopulate the _indicies list
		$this->_indicies = array_keys($this->_collection);
		
		// if the pointer was pointed to an element after the 
		// deleted position, move it back a notch
		if ($this->_position > $location) { --$this->_position; }
	}
	
	/**
	 * Add a new element to the end of the collection
	 *
	 * @param string $index index to reference the value
	 * @param mixed $value value to store in collection
	 */
	public function push($index, $value)
	{
		$this->_indicies[] = $index;
		$this->_collection[$index] = $value;
	}
	
}