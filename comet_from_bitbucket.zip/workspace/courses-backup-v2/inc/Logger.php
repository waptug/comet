<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Provides write access to log files with wrapper methods for consistantly
 * formatted and timestamped messages. Implements the singleton pattern with 
 * an instance available through the GetInstance static method.
 * 
 * @author hanisko
 */
class Logger
{
	private static $_instances = array();
	private $_logfile = '';
	private $_handle;
	
	/**
	 * Create a new instance. Accessible only through the GetInstance()
	 * static method.
	 */
	protected function __construct($name)
	{
		$config = Config::GetConfig();
		$this->_logfile = $config->logging->dir.'/'.$name.'.log';
		
		// do a test run, make sure we can write to the logfile
		if (!is_writable($this->_logfile)) {
			throw new Exception('Log file '.$this->_logfile.' is not writable');
		}
	}
	
	/**
	 * Get an instance of this class. Access through this function enforces
	 * a single instance policy.
	 * @return Logger
	 */
	public static function GetInstance($name = 'application')
	{
		if (!array_key_exists($name, self::$_instances)) {
			self::$_instances[$name] = new self($name);
		}
		return self::$_instances[$name];
	}
	
	/**
	 * Write a string of text to a logfile. Generally this is used by
	 * other log function which create nicely formatted messages.
	 *
	 * @param string $message what to write to the file
	 */
	public function rawMessage($message) 
	{
		// get a file handle
		fwrite($this->getHandle(), $message . PHP_EOL);
	}
	
	/**
	 * Log a debug message
	 *
	 * @param string $message what to log
	 */
	public function debug($message)
	{
		$metadata = date('Y-m-d H:i:s') . ' (' . Request::Phpself() . ') DEBUG: ';
		$this->rawMessage($metadata . $message);
	}
	
	/**
	 * Log an error message
	 *
	 * @param string $error what to write to log
	 */
	public function error($error)
	{
		$metadata = date('Y-m-d H:i:s') . ' (' . Request::Phpself() . ') ERROR: ';
		$this->rawMessage($metadata . $error);
	}
	
	/**
	 * Log a notice message
	 *
	 * @param string $error what to write to log
	 */
	public function notice($error)
	{
		$metadata = date('Y-m-d H:i:s') . ' INFO: ';
		$this->rawMessage($metadata . $error);
	}
	
	/**
	 * Log an database error including the sql you were trying to run
	 *
	 * @param string $error the error message from the database
	 * @param string $sql   the SQL query you were trying to run
	 * @param string $location optional additional details about where this
	 *                         error came from such as include file or function
	 */
	public function dbError($error, $sql, $location='')
	{
		$msg = date('Y-m-d H:i:s') . ' (' . Request::Phpself() . ') ';
		if (strlen($location) > 0) {
			$msg .= $location . ' ';
		} 
		$msg .= 'DB ERROR: ' . $error . PHP_EOL;
		$msg .= '----  SQL Statement  ----'.PHP_EOL
		     .   $sql. PHP_EOL
		     .  '-------------------------';
		$this->rawMessage($msg);
	}
	
	protected function getHandle()
	{
		if (is_null($this->_handle)) {
			$this->_handle = fopen($this->_logfile, 'a');
			if ($this->_handle === false) {
				throw new Exception('Failed to open '.$this->_logfile.' for logging');
			}
		}
		return $this->_handle;
	}
	
	public function __destruct() {
		if (!is_null($this->_handle)) {
			fclose($this->_handle);
		}
	}

}