<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Generate view output of a Db_Offering record. Allows for flexible configuration
 * of view parameters such as showing or hiding various fields, linking to flexible
 * detail views, and modifying output based on the state of the data.
 * @author hanisko
 */

class View_Offering extends View
{
	protected $offering;
	protected $vrs;
		
	/**
	 * If an Html_Anchor object is provided generates a link and returns the provided
	 * $linktext display value wrapped in the link. Otherwise returns the $linktext
	 * unmodified.
	 * @param string $linktext
	 * @param Html_Anchor $linkto
	 * @return string
	 */
	protected function addLink($linktext, $linkto = null)
	{
		if ($linkto instanceof Html_Anchor) {
			return $linkto->getHtml($linktext, array('o'=>$this->offering->offeringid));
		} else {
			return $linktext;
		}
	}

	/**
	 * Returns a short indicator if the primary instructor of the target offering is
	 * and adjunct.
	 * @param Html_Anchor $linkto
	 * @return string
	 */
	public function getAdjunctFlag($linkto = null)
	{
		if ($this->offering->instructor && $this->offering->instructor->role == 'adjunct') {
				$out = ' <span title="Primary instructor is adjunct">(ADJ)</span>';
		} else {
			return '';
		}
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}
	
	/**
	 * Returns concatenated curriculum abbreviation, course number, and section letter
	 * of the current course offering record.
	 * @param Html_Anchor $linkto
	 * @return string
	 */
	public function getCourseNumber($linkto = null)
	{
		$out = e($this->offering->curriculum.' '.$this->offering->courseno.' '.$this->offering->section);
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}
	
	/**
	 * Outputs the offering credit hours as HTML. If the course has already happened
	 * returns actual credit hours. If the course is in the future returns estimated
	 * credit hours with an asterisk.
	 * 
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getCreditHours($linkto = null)
	{
		if ($this->offering->getTimeframe() < 1) { // current or previous quarter
			$out = '<a class="enrollment-brief">'.(int)$this->offering->studentcredithours.' <span class="enrollmenttype">A</span></a>';
		} else {
			$out = '<a class="enrollment-brief">'.(int)$this->offering->studentcredithoursestimate.' <span class="enrollmenttype">E</span></a>';
		}
		return $out . $this->getCreditHoursDetails();
	}

	/**
	 * Outputs actual and estimated student credit hour values as a hidden HTML list.
	 * @return string
	 */
	public function getCreditHoursDetails()
	{
		$out = '<ul class="enrollment-details" style="display:none;">';
		if ($this->offering->getTimeframe() < 0) {
			$out .= '<li>'.(int)$this->offering->studentcredithours.' actual past student credit hours</li>';
		} else {
			$out .= '<li>'.(int)$this->offering->studentcredithours.' actual current student credit hours</li>';
		}
		$out .= '<li>'.(int)$this->offering->studentcredithoursestimate.' student credit hours estimate</li></ul>';
		return $out;
	}
	
	/**
	 * Outputs the enrollment as HTML. If the course has already happened returns 
	 * actual enrollment. If the course is in the future returns estimated enrollment 
	 * with an asterisk.
	 * 
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getEnrolled($linkto = null)
	{
		return $this->getEnrollmentBest();
	}
	
	/**
	 * Outputs the enrollment as HTML. If the course has already happened returns 
	 * actual enrollment. If the course is in the future returns estimated enrollment 
	 * with an asterisk.
	 * @return string
	 */
	public function getEnrollment($linkto = null)
	{
		$out = '<a class="enrollment-brief">'
		     . (int)$this->offering->enrollmentcurrent
		     . ' ('.(int)$this->offering->enrollmentestimate.')';
		if ($this->offering->enrollmentlimit) {
			$out .= ' L';
		}
		return $out . $this->getEnrollmentDetails();
	}
	
	/**
	 * Outputs the enrollment as HTML. If the course has already happened returns 
	 * actual enrollment. If the course is in the future returns estimated enrollment 
	 * with an asterisk.
	 * @return string
	 */
	public function getEnrollmentBest()
	{
		if ($this->offering->getTimeframe() < 1) { // current or previous quarter
			$out = '<a class="enrollment-brief">'.(int)$this->offering->enrollmentcurrent.' <span class="enrollmenttype">A</span></a>';
		} else {
			if ($this->offering->enrollmentlimit) {
				$out = '<a class="enrollment-brief">'.(int)$this->offering->enrollmentlimit.' <span class="enrollmenttype">L</span></a>';
			} else {
				$out = '<a class="enrollment-brief">'.(int)$this->offering->enrollmentestimate.' <span class="enrollmenttype">E</span></a>';
			}
		}
		return $out . $this->getEnrollmentDetails();
	}
	
	/**
	 * Outputs the enrollment as HTML. If the course has already happened returns 
	 * actual enrollment. If the course is in the future returns estimated enrollment 
	 * with an asterisk.
	 * @return string
	 */
	public function getEnrollmentEstimate()
	{
		$max = max($this->offering->enrollmentcurrent, $this->offering->enrollmentestimate, $this->offering->enrollmentlimit);
		$out = '<a class="enrollment-brief">'.(int)$max.'</a>';
		return $out . $this->getEnrollmentDetails();
	}

	/**
	 * Outputs various enrollment values as a hidden HTML list.
	 * @return string
	 */
	public function getEnrollmentDetails()
	{
		$out = '<ul class="enrollment-details" style="display:none;">';
		if ($this->offering->getTimeframe() < 0) {
			$out .= '<li>Actual past enrollment: <span>'.(int)$this->offering->enrollmentcurrent.' A</span></li>';
		} else {
			$out .= '<li>Actual current enrollment: <span>'.(int)$this->offering->enrollmentcurrent.' A</span></li>';
		}
		if ($this->offering->enrollmentlimit) {
			$out .= '<li>Enrollment limit: <span>'.(int)$this->offering->enrollmentlimit.' L</span></li>';
		} else {
			$out .= '<li>Enrollment estimate: <span>'.(int)$this->offering->enrollmentestimate.' E</span></li>';
		}
		$out .= '</ul>';
		return $out;
	}
	
	/**
	 * Outputs a brief enrollment notifier based on enrollment level of the offering. 
	 * If the course has already happened flag is based on actual enrollment. If the 
	 * course is in the future flag is based on estimated enrollment.
	 * 
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getEnrollmentFlags($linkto = null)
	{
		$out = '';
		if ($this->offering->getTimeframe() < 1) { // current or previous quarter
			if ($this->offering->enrollmentcurrent < 15) $out = ' <span title="Actual enrollment less than 15">E-</span> ';
			if ($this->offering->enrollmentcurrent > 39) $out = ' <span title="Actual enrollment greater than 39">E+</span> ';
		} else {
			$compare = max($this->offering->enrollmentestimate, $this->offering->enrollmentlimit);
			if ($compare < 15) $out = ' <span title="Estimated enrollment less than 15">E-</span> ';
			if ($compare > 39) $out = ' <span title="Estimated enrollment greater than 39">E+</span> ';
		}
		if (!$out) {
			return '';
		}
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}

    /**
     * Returns a flag indicating the offering has status = 'expected'
     * Expected status means the offering record was generated automatically by a repetition rule and may need further
     * review before being added to UW time schedule
     * @param null $linkto
     * @return string
     */
    public function getExpectedFlag($linkto = null)
    {
        $out = '';
        if ($this->offering->status == 'expected') {
            $out = ' <img src="/courses/images/expected_bug.gif" title="Offering was generated by repetition rule" />';
        }
        if (empty($out) || is_null($linkto)) {
            return $out;
        } else {
            return $this->addLink($out, $linkto);
        }
    }
	
	/**
	 * Outputs the description of the funding strategy for this course, either 
	 * "State funded" or "Self sustaining"
	 * 
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getFunding($linkto = null)
	{
		$out = e($this->offering->fundingname);
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}

	/**
	 * Returns a $$ flag with an explanatory hover title if the target offering is
	 * self sustaining funding.
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getInstitutionFlag($linkto = null)
	{
		if ($this->offering->institution == 'uweo') {
			$out = ' <img src="/courses/images/uweo_bug.gif" title="Offered through UWEO (self-sustaining)" />';
		} else {
			return '';
		}
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}

	/**
	 * Returns the name of the primary instructor for meeting 1 of this offering
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getInstructor($linkto = null)
	{

		if ($this->offering->instructor) {
			$out = e(View_Person::FirstLast($this->offering->instructor));
		} else {
			$out = '<span style="color:#999;">to be determined</span>';
		}
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}

	/**
	 * Returns the latest instructor approval setting
	 * @return string
	 */
	public function getInstructorApproval($linkto = null)
	{
		$log = $this->offering->getInstructorApprovalLog();
		if ($log) {
			if ($log->data->approval == 'removed') {
				$message = 'Removed '.eDate($log->entered);
			} else {
				$message = eFirstLast($log->uwnetid).' '.eDate($log->entered);
			}
		} else {
			$message = '<span class="empty-value">not entered</span>';
		}
		if (is_null($linkto)) {
			return $message;
		} else {
			return $this->addLink($message, $linkto);
		}
	}

	/**
	 * Returns the name of the primary instructor for meeting 1 of this offering
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getInstructorLinked($linkto = null)
	{
		if ($this->offering->instructor) {
			$out = ePersonDetailLink(View_Person::FirstLast($this->offering->instructor), $this->offering->instructor->personid, $this->offering->offeringid);
		} else {
			$out = '<span style="color:#999;">to be determined</span>';
		}
		return $out;
	}

	/**
	 * Returns the last name of the primary instructor for meeting 1 of this offering
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getInstructorLastname($linkto = null)
	{

		if ($this->offering->instructor) {
			$out = e($this->offering->instructor->lastname);
		} else {
			$out = '<span style="color:#999;">to be determined</span>';
		}
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}

	/**
	 * Returns a string summarizing the meetings for this offering using UWTS abbreviations
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getMeetingSummary($linkto = null)
	{
		if ($this->offering->meetingsummary) {
			$out = e($this->offering->meetingsummary);
		} else {
			$out = '<span style="color:#999;">to be arranged</span>';
		}
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}
	
	/**
	 * Outputs the year and quarter of this course offering
	 * 
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getQuarter($linkto = null)
	{
		$out = eQuarter($this->offering->year, $this->offering->quarter);
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}
	
	/**
	 * Outputs the room schedule status of this course offering
	 * 
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getRoomRequest($linkto = null)
	{
		if ($this->offering->getTimeframe() < 1) { // current or previous quarter
			return '<span style="color:#666;">Complete</span>';
		}
		if ($this->offering->hasRoomRequest()) {
			$out = 'Submitted';
		} else {
			$out = 'none';
		}
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}
	
	/**
	 * Outputs the room schedule status of this course offering
	 * 
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getRoomStatus($linkto = null)
	{
		if (is_null($this->vrs)) {
			$this->vrs = new View_Roomstatus();
		}
		$out = e($this->vrs->getText($this->offering->roomstatus));
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}
	
	/**
	 * Outputs the room schedule status of this course offering. The 
	 * OSS version includes more specific information.
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getRoomStatusOSS($linkto = null)
	{
		if (is_null($this->vrs)) {
			$this->vrs = new View_Roomstatus();
		}
		$out = e($this->vrs->getOssText($this->offering->roomstatus));
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}
	
	/**
	 * Outputs the section type code of this course offering
	 * 
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getSectionType($linkto = null)
	{
		$out = e($this->offering->sectiontype);
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}
	
	/**
	 * Outputs the UW time schedule section line number of this course offering
	 * 
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getSln($linkto = null)
	{
		if ($this->offering->sln) {
			$out = $this->offering->sln;
		} else {
			$out = 'TBD';
		}
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}
	
	/**
	 * Outputs the workflow status of this course offering
	 * 
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getStatus($linkto = null)
	{
		$out = e(ucfirst($this->offering->status));
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}
	
	/**
	 * Returns a status flag for offerings that have "hold" or "canceled"
	 * status.
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getStatusFlag($linkto = null)
	{
		if ($this->offering->status == 'hold') {
			$out = '<span class="status hold">On Hold</span>';
		} elseif ($this->offering->status == 'canceled') {
			$out = '<span class="status canceled">Canceled</span>';
		} else {
			return '';
		}
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}

	/**
	 * Returns the title of a course. If the course has a wildcard title, returns 
	 * the wildcard title with hover title explanation of wildcard.
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getTitle($linkto = null)
	{
		if ($this->offering->wildcardtitle) {
			if (strlen($this->offering->wildcardtitle) > 70) {
				$title = substr($this->offering->wildcardtitle,0,70);
			} else {
				$title = $this->offering->wildcardtitle;
			}
			$out = '<span title="* COE wildcard title. Listed in UW Time Schedule as '.e($this->offering->title).'">'.e($title).'*</span>';
		} else {
			if (strlen($this->offering->title) > 60) {
				$title = substr($this->offering->title,0,60);
			} else {
				$title = $this->offering->title;
			}
			$out = e($title);
		}
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}

	/**
	 * Returns the title (or wildcard title) of a course annotated with any 
	 * exceptional status and funding flag.
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getTitleAnnotated($linkto = null)
	{
		return $this->getStatusFlag().' '.$this->getTitle($linkto).' '.$this->getInstitutionFlag();
	}
	
	/**
	 * Outputs the UW time schedule status of this course offering
	 * 
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getUwtsStatus($linkto = null)
	{
		if ($this->offering->uwtsstatus == 0 && $this->offering->sectionstatus == 'V') {
			$out = 'Entered, not linked';
		} else {
			$out = e(ucfirst($this->offering->getUwtsstatusName()));
		}
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}
	
	/**
	 * Assign an offering object who's values will be displayed by this object
	 * @param Db_Offering $offering
	 */
	public function setOffering(Db_Offering $offering)
	{
		$this->offering = $offering;
	}

}
