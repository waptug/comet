<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Generate view output of a Db_Offering record. Allows for flexible configuration
 * of view parameters such as showing or hiding various fields, linking to flexible
 * detail views, and modifying output based on the state of the data.
 * @author hanisko
 */

class View_OfferingStudentView extends View_Offering
{

	/**
	 * Returns a $$ flag with an explanatory hover title if the target offering is
	 * self sustaining funding.
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getInstitutionFlag($linkto = null)
	{
		if ($this->offering->institution == 'uweo') {
			$out = ' <img src="/courseinfo/images/uwpce_bug.gif" title="Offered through UW Professional &amp; Continuing Education" />';
		} else {
			return '';
		}
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}
	
}