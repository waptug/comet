<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Provides display values and formatting methods for the roomstatus code
 * property of Db_Offering objects.
 * @author hanisko
 */

class View_Roomstatus
{

	private static $_oss_statuses = array(
		0  => 'No instructor room request',
		1  => 'Need further instructor input',
		10 => 'Needs OSS action',
		11 => 'Instructor updated room request',
		12 => 'Class size changed',
		13 => 'Meetings changed',
		14 => 'Offering canceled',
		15 => 'Offering reinstated',
		92 => 'Request sent to UWTS',
		93 => 'Room assigned in time schedule',
		94 => 'No meetings',
		95 => 'To be arranged'
	);

	private static $_general_statuses = array(
		0  => 'No instructor room request',
		1  => 'Need further instructor input',
		10 => 'Being processed by OSS', // 'Needs OSS action',
		11 => 'Being processed by OSS', // 'Instructor updated room request',
		12 => 'Being processed by OSS', // 'Class size changed',
		13 => 'Being processed by OSS', // 'Meetings changed',
		14 => 'Being processed by OSS', // 'Offering canceled',
		15 => 'Being processed by OSS', // 'Offering reinstated',
		92 => 'Request sent to UWTS',
		93 => 'Room assigned in time schedule',
		94 => 'No meetings',
		95 => 'To be arranged'
	);

	private static $_cssclasses = array(
		0  => 'instructor', // 'No instructor room request',
		1  => 'instructor', // 'Need further instructor input',
		10 => 'oss-action', // 'Needs OSS action',
		11 => 'oss-action', // 'Instructor updated room request',
		12 => 'oss-action', // 'Class size changed',
		13 => 'oss-action', // 'Meetings changed',
		14 => 'oss-action', // 'Offering canceled',
		15 => 'oss-action', // 'Offering reinstated',
		92 => 'uptodate',   // 'Room request submitted to UW CSS',
		93 => 'uptodate',   // 'Room assigned in time schedule',
		94 => 'instructor', // 'No meetings',
		95 => 'instructor'  // 'To be arranged'
	);

	/**
	 * Returns CSS class name that will trigger appropriate formatting
	 * for this room status.
	 * @param integer $code
	 * @return string
	 */
	public function getCssClassName($code)
	{
		if (!array_key_exists($code, self::$_cssclasses)) {
			return 'roomstatus_'.$code;
		}
		return self::$_cssclasses[$code];
	}
	
	/**
	 * Returns the display value for this room status.
	 * @param integer $code
	 * @return string
	 */
	public function getText($code)
	{
		if (!array_key_exists($code, self::$_general_statuses)) {
			return 'Room status '.$code;
		}
		return self::$_general_statuses[$code];
	}
	
	/**
	 * Returns the display value for this room status. This display value
	 * is specific to actions required by OSS.
	 * @param integer $code
	 * @return string
	 */
	public function getOssText($code)
	{
		if (!array_key_exists($code, self::$_oss_statuses)) {
			return 'Room status '.$code;
		}
		return self::$_oss_statuses[$code];
	}

	/**
	 * Test whether a value provides is defined code in the system.
	 * @return string
	 */
	public function isValidStatus($code)
	{
		return array_key_exists($code, self::$_general_statuses);
	}
	
} 