<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Translate an offering's workflow status, UWTS status, and historical status 
 * into an accurate and useful description for users.
 * @author hanisko
 */

class View_OfferingStatus
{
	const STATUS_UNKNOWN = 0;
	const STATUS_CANCELED = 1;
	const STATUS_CURRENT = 2;
	const STATUS_EXPECTED = 3;
	const STATUS_HISTORICAL = 4;
	const STATUS_HOLD = 5;
	const STATUS_NEVER_SCHEDULED = 6;
	const STATUS_NOT_IN_UWTS = 7;
	const STATUS_PLANNED = 8;
	
	private $_code;
	private $_offering;
	
	private static $_status_data = array(
		self::STATUS_UNKNOWN => array(
			'title'       => 'Unknown Status',
			'lettercode'  => 'X',
			'description' => 'This course offering has an unexpected status in the database. Contact the system administrator about this error.',
			'cssclass'    => 'canceled'
		),
		self::STATUS_CANCELED => array(
			'title'       => 'Canceled',
			'lettercode'  => 'X',
			'description' => 'This course offering has been canceled.',
			'cssclass'    => 'canceled'
		),
		self::STATUS_CURRENT => array(
			'title'       => 'Current Quarter',
			'lettercode'  => 'C',
			'description' => 'This course offering has been scheduled and is happening this quarter.',
			'cssclass'    => 'current'
		),
		self::STATUS_EXPECTED => array(
			'title'       => 'Expected',
			'lettercode'  => 'E',
			'description' => 'This course offering is listed based on recurring rules for this course. Based on history we expect this course to be offered during this quarter.',
			'cssclass'    => 'expected'
		),
		self::STATUS_HISTORICAL => array(
			'title'       => 'Historical',
			'lettercode'  => 'H',
			'description' => 'This course offering happened in a past quarter.',
			'cssclass'    => 'historical'
		),
		self::STATUS_HOLD => array(
			'title'       => 'Temporary Hold',
			'lettercode'  => 'X',
			'description' => 'This course offering is under review by the College of Education\'s Administrative Cabinet.',
			'cssclass'    => 'canceled'
		),
		self::STATUS_NEVER_SCHEDULED => array(
			'title'       => 'Never Scheduled',
			'lettercode'  => 'X',
			'description' => 'This course offering was planned for a past quarter, but was never entered into the UW time schedule.',
			'cssclass'    => 'canceled'
		),
		self::STATUS_NOT_IN_UWTS => array(
			'title'       => 'Not In UW Time Schedule',
			'lettercode'  => 'X',
			'description' => 'This course offering was planned for the current quarter, but is not entered in the UW time schedule.',
			'cssclass'    => 'canceled'
		),
		self::STATUS_PLANNED => array(
			'title'       => 'Planned',
			'lettercode'  => 'P',
			'description' => 'This course offering is planned for a future quarter.',
			'cssclass'    => 'planned'
		)
	);
	
	public function __construct(Db_Offering $offering)
	{
		$this->_offering = $offering;
	}
	
	/**
	 * Calculate a status code for the subject course offering based on workflow
	 * status, UW time schedule status, and past/future time frame.
	 * @return integer
	 */
	public function getViewStatusCode()
	{
		if (!is_null($this->_code)) {
			return $this->_code;
		}
		if ($this->_offering->getTimeframe() < 0) { // happened in the past
			switch ($this->_offering->status) {
				case 'historical':
				case 'planned':
				case 'expected':
					$this->_code = ($this->_offering->uwtsstatus) ? self::STATUS_HISTORICAL : self::STATUS_NEVER_SCHEDULED;
					break;
				case 'hold':
				case 'canceled':
					$this->_code = self::STATUS_CANCELED;
					break;
				default:
					$this->_code = self::STATUS_UNKNOWN;
					break;
			}
		} elseif ($this->_offering->getTimeframe() == 0) { // happening in current quarter
			switch ($this->_offering->status) {
				case 'historical':
				case 'planned':
				case 'expected':
					$this->_code = ($this->_offering->uwtsstatus) ? self::STATUS_CURRENT : self::STATUS_NOT_IN_UWTS;
					break;
				case 'hold':
				case 'canceled':
					$this->_code = self::STATUS_CANCELED;
					break;
				default:
					$this->_code = self::STATUS_UNKNOWN;
					break;
			}
		} else { // future quarter
			switch ($this->_offering->status) {
				case 'historical': $this->_code = self::STATUS_HISTORICAL; break;
				case 'planned':    $this->_code = self::STATUS_PLANNED; break;
				case 'expected':   $this->_code = self::STATUS_EXPECTED; break;
				case 'hold':       $this->_code = self::STATUS_HOLD; break;
				case 'canceled':   $this->_code = self::STATUS_CANCELED; break;
				default:           $this->_code = self::STATUS_UNKNOWN; break;
			}
		}
		return $this->_code;
	}
	
	public function getCssClassname()
	{
		return self::$_status_data[$this->getViewStatusCode()]['cssclass'];
	}
	
	public function getDesciption()
	{
		if ($this->getViewStatusCode() == self::STATUS_UNKNOWN) {
			return self::$_status_data[$this->getViewStatusCode()]['description'].' ('.$this->_offering->status.')';
		} else {
			return self::$_status_data[$this->getViewStatusCode()]['description'];
		}
	}
	
	public function getLetterCode()
	{
		return self::$_status_data[$this->getViewStatusCode()]['lettercode'];
	}
	
	public function getTitle()
	{
		return self::$_status_data[$this->getViewStatusCode()]['title'];
	}
	
}