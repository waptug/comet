<?php
/**
 * Provide formatting methods for objects that implement the 
 * Interface_Person (have a first and last name).
 * @author Paul Hanisko
 * @package UW_COE_Framework
 */

class View_Person 
{

	public static function FirstLast($person)
	{
		if (!$person instanceof Interface_Person) {
			$person = Cache_Person::Locate($person);
		}
		$first = $person->getFirstname();
		$last = $person->getLastname();
		return trim($first.' '.$last);
	}
	
	public static function LastFirst($person)
	{
		if (!$person instanceof Interface_Person) {
			$person = Cache_Person::Locate($person);
		}
		$first = $person->getFirstname();
		$last = $person->getLastname();
		if ($first && $last) {
			return "$last, $first";
		} else {
			return "$last$first";
		}
	}

	public static function FirstInitialLast($person)
	{
		if (!$person instanceof Interface_Person) {
			$person = Cache_Person::Locate($person);
		}
		$first = substr($person->getFirstname(), 0, 1);
		if(!is_null($first) && trim($first) != "")
			$first .= ".";
		$last = $person->getLastname();
		return trim($first.' '.$last);
	}
	
} 