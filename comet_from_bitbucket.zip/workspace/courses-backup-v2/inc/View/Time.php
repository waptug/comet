<?php
/**
 * Collection methods for formatting course times in 
 * human readable formats.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class View_Time
{
	private static $dayshort = array('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat');
	private static $daylong = array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
	
	/**
	 * Translate and integer day of week to a human readable
	 * value. Returns "Sun" for 0 through "Sat" for 6
	 * @param integer $dow
	 * @return string
	 */
	public static function DayOfWeek($dow)
	{
		if (array_key_exists($dow, self::$dayshort)) {
			return self::$dayshort[$dow];
		} else {
			return $dow;
		}
	}
	
	/**
	 * Translate and integer day of week to a human readable
	 * value. Returns "Sunday" for 0 through "Saturday" for 6
	 * @param integer $dow
	 * @return string
	 */
	public static function DayOfWeekLong($dow)
	{
		if (array_key_exists($dow, self::$daylong)) {
			return self::$daylong[$dow];
		} else {
			return $dow;
		}
	}
	
}