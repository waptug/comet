<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Provides global access to the page title value
 * @author hanisko
 */
 
class View_PageTitle
{
	private static $_quarters = array(
		1 => 'Win',
		2 => 'Spr',
		3 => 'Sum',
		4 => 'Aut'	
	);
	private static $_instance;
	private $_title;
	
	private function __construct()
	{
		
	}
	
	/**
	 * Return the application instance of the singleton class View_PageTitle
	 * @return View_PageTitle
	 */
	public static function GetInstance()
	{
		if (!self::$_instance instanceof View_PageTitle) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	
	/**
	 * Get the title of the current page
	 * @return string
	 */
	public function get()
	{
		if (is_null($this->_title)) {
			return $this->getDefaultTitle();
		} else {
			return $this->_title;
		}
	}

	/**
	 * Get a default title to be used for pages where no title is specified
	 * and to be appended for context to page specific titles.
	 * @return string
	 */
	public function getDefaultTitle()
	{
		return 'Courses - College of Education - UW';
	}

	/**
	 * Set a title to be used for the next page render, optionally suppress
	 * the context suffix
	 * @param string $title
	 * @param boolean $add_suffix
	 */
	public function set($title, $add_suffix = true)
	{
		if ($add_suffix) {
			$this->_title = $title.' - '.$this->getDefaultTitle();
		} else {
			$this->_title = $title;
		}
	}

	/**
	 * Set a title to be used for the next page render, optionally suppress
	 * the context suffix
	 * @param Db_Offering $offering
	 * @param string $title
	 * @param boolean $add_suffix
	 */
	public function setOffering(Db_Offering $offering, $title, $add_suffix = true)
	{
		$off_string = $offering->year.' '.self::$_quarters[$offering->quarter].' '.$offering->curriculum.' '.$offering->courseno.' '.$offering->section;
		if ($add_suffix) {
			$this->_title = $title.' '.$off_string.' - '.$this->getDefaultTitle();
		} else {
			$this->_title = $title.' '.$off_string;
		}
	}
	
}