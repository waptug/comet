<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Generate view output of a Db_Offering record. Allows for flexible configuration
 * of view parameters such as showing or hiding various fields, linking to flexible
 * detail views, and modifying output based on the state of the data.
 * @author hanisko
 */

class View_OfferingSummary extends View_Offering
{


	/**
	 * Returns the name of the primary instructor for meeting 1 of this offering
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getInstructor($linkto = null)
	{
	
		if ($this->offering->instructor) {
			$out = e(View_Person::FirstLast($this->offering->instructor));
		} else {
			$out = '<span style="color:#999;">Instructor to be determined</span>';
		}
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}

	/**
	 * Returns a string summarizing the meetings for this offering using UWTS abbreviations
	 * @param Html_Anchor $linkto optional link to wrap value in
	 * @return string
	 */
	public function getMeetingSummary($linkto = null)
	{
		if ($this->offering->meetingsummary) {
			$out = e($this->offering->meetingsummary);
		} else {
			$out = '<span style="color:#999;">meetings to be arranged</span>';
		}
		if (is_null($linkto)) {
			return $out;
		} else {
			return $this->addLink($out, $linkto);
		}
	}
	
}