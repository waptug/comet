<?php
/**
 * Functions that support formatting of output for inclusion
 * in views. Generally these functions support XHTML views for 
 * consumption by a human using a web browser.
 * 
 * @package UW_COE_Techsupport
 * @author Paul Hanisko
 */

/**
 * Create a link within the application. Appends the application directory to
 * the provided url. Builds an escaped query string from the associative array
 * $query argument. The $more_query argument provides a contained method for 
 * combining query parameters from multiple sources.
 * @param string $app_relative_url
 * @param array $query
 * @param array $more_query
 * @return string
 */
function buildUrl($app_relative_url = null, $query = null, $more_query = null)
{
	if (is_null($app_relative_url)) {
		$out = Request::Phpself();
	} elseif (strpos('http://', $app_relative_url) === 0 || strpos('https://', $app_relative_url) === 0) {
		$out = $app_relative_url;
	} else {
		if ($app_relative_url) {
			$out = Environment::AppBase().'/'.ltrim($app_relative_url, '/');
		} else {
			$out = Environment::AppBase();
		}	
	}
	$out = e($out);
	if (is_array($more_query)) {
		if (is_array($query)) {
			$query = array_merge($query, $more_query);
		} else {
			$query = $more_query;
		}
	}
	if (is_array($query)) {
		$escaped = array();
		foreach ($query as $key => $value) {
			$escaped[] = urlencode($key).'='.urlencode($value);
		}
		$out .= '?'.implode('&',$escaped);
	}
	return $out;
}

/**
 * Escape special HTML characters (notably < and &).
 * 
 * (While I am a firm believer in clear naming of functions, this one is
 * used so often in views that giving it a very concise name increases 
 * overall code readability - paul.)
 *
 * @param string $value a string to be escaped and echoed
 */
function e($value)
{
	return htmlspecialchars($value, ENT_COMPAT, 'ISO-8859-1');
}

/**
 * Escape, Echo. Escape special HTML characters (notably < and &)
 * and then echo the escaped string.
 * 
 * (While I am a firm believer in clear naming of functions, this one is
 * used so often in views that giving it a very concise name increases 
 * overall code readability - paul.)
 *
 * @param string $value a string to be escaped and echoed
 */
function ee($value)
{
	echo e($value);
}

/**
 * Locate, format and return an application message stored in the session.
 * Presents view-once messages that were stored based on the results of a
 * previous script. This function partners with storeAppMessage() and
 * fetchAppMessage() functions.
 *
 * App messages receive a div wrapper with specific class names for errors,
 * successes, and warnings. These classes are triggered by E~, S~, or W~
 * prefixes on the application messages.
 *
 * @return string
 */
function eAppMessage()
{
	$message = AppMessage::Fetch();
	$bits = explode('~', $message);
	if (count($bits) == 2) {
		$messagetype = $bits[0];
		$message = $bits[1];
	} else {
		$messagetype = 'unknown';
	}
	switch ($messagetype) {
		case 'E': // error
			$class = ' class="error"';
			break;
		case 'S': // success
			$class = ' class="success"';
			break;
		case 'W': // warning
			$class = ' class="warning"';
			break;
		default:
			$class = '';
			break;
	}
	if (strlen($message) > 0) {
		$display = '';
	} else {
		$display = ' style="display:none;"';
	}
	return '<div class="message_box"'. $display .'><div class="msg_wrapper"><p'. $class .'>'. e($message) .'</p></div><div class="msg_bottom"></div></div>';
}

/**
 * Locate, format, and echo a stored applicantion message. If the message
 * does not exist an empty hidden application message container is created
 * to be available for client side use.
 */
function eeAppMessage()
{
	echo eAppMessage();
}

/**
 * Escape with html break elements. Performs escaping of HTML
 * special characters and then substitutes new line characters with
 * HTML <br /> entities. (BR's in the original input will be escaped
 * and appear literally to the client.) 
 *
 * @param string $value
 * @param bool $use_paragraphs change multiple consecutive line breaks into paragraph close/open
 * @return string
 */
function eBreaks($value, $use_paragraphs = false)
{
	$out = e($value);
	// $use_paragraph option changes two or three consecutive newlines into a paragraph break
	if ($use_paragraphs) {
		$paragraph_breaks = array("\r\n\r\n\r\n", "\n\n\n", "\r\r\r", "\r\n\r\n", "\n\n", "\r\r");
		$out = str_replace($paragraph_breaks, '</p></p>', $out);
	}
	$newlines = array("\r\n", "\n", "\r");
	$out = str_replace($newlines, '<br />', $out);
	return $out;
}

/**
 * Escape, echo, with html break elements. Performs escaping of HTML
 * special characters and then substitutes new line characters with
 * HTML <br /> entities. (BR's in the original input will be escaped
 * and appear literally to the client.)
 *
 * @param string $value
 * @param bool $use_paragraphs change multiple consecutive line breaks into paragraph close/open
 */
function eeBreaks($value, $use_paragraphs = false)
{
	echo ebreaks($value);
}

/**
 * Translate a date/time in a Unix integer timestamp format
 * into a user readable string.
 *
 * @param int $timestamp the timestamp to be transformed
 * @param string $format a format pattern compatible with date()
 * @return string
 */
function eDate($timestamp, $format = 'm/d/Y')
{
	if (!is_numeric($timestamp)) { 
		$newts = strtotime($timestamp);
		if ($newts === false) {
			return e($timestamp);
		} else {
			$timestamp = $newts;
		}
	}
	if ($timestamp == 0) { return ''; }
	return e(date($format, $timestamp));
}

/**
 * Format and echo a date/time in a Unix integer timestamp format
 * into a user readable string.
 *
 * @param int $timestamp the timestamp to be transformed
 * @param string $format a format pattern compatible with date()
 * @return string
 */
function eeDate($timestamp, $format = 'm/d/Y')
{
	echo edate($timestamp, $format);
}

/**
 * Returns the first and last name of a person. Accepts as input any object that
 * implements Interface_Person, or a personid, or a UW NetID. 
 * @param mixed $person
 * @return string
 */
function eFirstLast($person)
{
	if (!$person instanceof Interface_Person) {
		$personid = (int)$person;
		if ($personid > 0) {
			$person = Db_Person::Get($personid);
		} else {
			$person = Db_Person::FetchByUwnetid($person);
		}
		if (!$person instanceof Interface_Person) {
			throw new Exception('Invalid argument for '.__FUNCTION__);
		}
	}
	return View_Person::FirstLast($person);
}

/**
 * Outputs the first and last name of a person. Accepts as input any object that
 * implements Interface_Person, or a personid, or a UW NetID.
 * @param mixed $person
 * @return string
 */
function eeFirstLast($person)
{
	echo eFirstLast($person);
}

/**
 * Returns the first and last name of a person. Accepts as input any object that
 * implements Interface_Person, or a personid, or a UW NetID.
 * @param mixed $person
 * @return string
 */
function eLastFirst($person)
{
	if (!$person instanceof Interface_Person) {
		$personid = (int)$person;
		if ($personid > 0) {
			$person = Db_Person::Get($personid);
		} else {
			$person = Db_Person::FetchByUwnetid($person);
		}
		if (!$person instanceof Interface_Person) {
			throw new Exception('Invalid argument for '.__FUNCTION__);
		}
	}
	return View_Person::LastFirst($person);
}

/**
 * Outputs the first and last name of a person. Accepts as input any object that
 * implements Interface_Person, or a personid, or a UW NetID.
 * @param mixed $person
 * @return string
 */
function eeLastFirst($person)
{
	echo eLastFirst($person);
}

function ePersonDetailLink($text, $personid, $offeringid = null) {
	if ($offeringid) {
		$link = buildUrl('/person/detail', array('p'=>$personid,'o'=>$offeringid));
	} else {
		$link = buildUrl('/person/detail?p='.$personid);
	}
	return '<a href="'.$link.'" class="ajax-window">'.e($text).'</a>';
}

/**
 * Format a string consisting of only the digits of a 
 * phone number in a user readable format.
 *
 * @param string $phone phone number, digits only
 * @return string
 */
function ePhone($phone)
{
	$m = array();
	preg_match('/(.*)(...)(...)(....)/', $phone, $m);
	$newphone = '';
	if (count($m) == 5){
		if (strlen($m[1]) > 1) 
			$newphone .= $m[1] . ' ';
		$newphone =  $newphone .= '('. $m[2] .') '. $m[3] .'-' .$m[4];
	} else {
		$newphone = $phone;
	}
	return e($newphone);
}

/**
 * Format a phone number, HTML escape it and echo the results.
 * @param string $phone phone number, digits only
 */
function eePhone($phone)
{
	echo ePhone($phone);
}


/**
 * Translate a machine friendly version of a quarter into a
 * human readable version
 * 
 * @param string $quarter academic quarter in YEAR-quarter format
 * @param string $quarter optional quarter identifier, in which case $year should contain only the year value
 * @return string
 */
function eQuarter($year, $quarter = null)
{
	if (is_null($quarter)) {
		if (strpos($year, '-')) list($year, $quarter) = explode('-', $year);
	}
	$quarter = eQuarterName($quarter);
	if ($quarter) {
		$out = $year.' '.$quarter;
	} else {
		$out = $year .'-'. ($year + 1) .' Academic Year';
	}
	return $out;
}

/**
 * Format, HTML escape, and echo a quarter provided in YYYY-qq
 * syntax
 */
function eeQuarter($year, $quarter = null)
{
	echo eQuarter($year, $quarter);
}

/**
 * Translate various quarter descriptions into a consistent string name
 * @param string $quarter
 * @return string
 */
function eQuarterName($quarter)
{
	$quarter = strtolower($quarter);
	switch ($quarter)
	{
		case 1:
		case 'winter':
			$out = 'Winter';
			break;
		case 2:
		case 'spring':
			$out = 'Spring';
			break;
		case 3:
		case 'summer':
			$out = 'Summer';
			break;
		case 4:
		case 'fall':
		case 'autumn':
			$out = 'Autumn';
			break;
		default: 
			$out = $quarter;
			break;
	}
	return $out;
}

/**
 * Format the separate fields of an address into a standard address text
 * block. Gracefully deal with missing fields. HTML escape data where 
 * needed.
 * 
 * @param string $line1 street address main or only line
 * @param string $line2 street address second line
 * @param string $city  city
 * @param string $state state
 * @param string $zip   zip code
 * @return string
 */
function eAddress($line1, $line2, $city, $state, $zip)
{
	$out = e($line1);
	if ($out) { 
		$out .= '<br />'; 
	}
	if ($line2) { 
		$out .= e($line2) . '<br />'; 
	}
	if ($city && $state) {
		// if we have city and state, we need a comma
		$out .= e($city .', '. $state .' '. $zip);
	} else { 
		// otherwise we can put spaces between each field use the 
		// browser's normal behavior to ignore extra whitespace.
		$out .= e($city .' '. $state .' '. $zip);
	}
	return $out;
}

/**
 * Format, escape, then echo and address.
 * 
 * @param string $line1 street address main or only line
 * @param string $line2 street address second line
 * @param string $city  city
 * @param string $state state
 * @param string $zip   zip code
 * @return string
 */
function eeAddress($line1, $line2, $city, $state, $zip)
{
	echo eAddress($line1, $line2, $city, $state, $zip);
}

/**
 * Escape a value to be safely included in a Comma Separated Variable
 * text file. Values that include commas are enclosed in double quotes.
 * When a quoted value contains a double quote character it is escaped
 * by changing it to two sequential double quote characters.
 * 
 * @param $value
 * @return string
 */
function csvQuote($value) 
{
	// can't have new lines in output	
	$newlines = array("\r\n", "\n", "\r");
	$value = str_replace($newlines, ' ', $value);
	// if it has a comma in it, it needs help
	if (strpos($value,',') !== false) {
		// first escape " with and extra "
		$value = str_replace('"', '""', $value);
		return '"' . $value . '"';
	} else {
		// the string is safe as is
		return $value;
	}
}

/**
 * Outputs the HTML property class="oddrow" every other time it is
 * called. Requires a reference to a variable that will be used to 
 * track the alternation.
 * 
 * @param reference $toggle variable that will contain alternately true/false 
 */
function eeOddRow(&$toggle)
{
	if ($toggle) {
		echo ' class="oddrow"';
		$toggle = false;
	} else {
		$toggle = true;
	}
}

/**
 * Prefix an application relative path with this application's base URL
 * and escape HTML special characters.
 * 
 * @param $value href URL value
 * @param $relative true if this is a relative link
 * @return string
 */
function eHref($value, $relative = false)
{
	// if this is an absolute url make sure it starts with the application URL
	if (!$relative && (strpos($value, Environment::AppBase()) !== 0)) {
		$value = ltrim($value, '/');
		$value = Environment::AppBase().'/'.$value;
	}
	return e($value);
}

/**
 * Prefix an application relative path with this application's base URL
 * and escape HTML special characters.
 * 
 * @param $value href URL value
 * @param $relative true if this is a relative link
 * @return string
 */
function eeHref($value, $relative = false)
{
	echo eHref($value, $relative);
}

/**
 * Convert variable format time value into a standard user friendly format
 * @param $value some value that can be deciphered as a time
 * @return string
 */
function eTime($value)
{
	if (is_null($value)) {
		return '';
	}
	$time = new Time();
	if ($time->parse($value)) {
		return $time->getPrettyTime();
	} else {
		return e($value);
	}
}

/**
 * Convert variable format time value into a standard user friendly format
 * and echo
 */
function eeTime($value)
{
	echo eTime($value);
}

/**
 * Converts a value to the string Yes or No based on a boolean conversion. 
 * Null values return the empty string.
 * @param $value some value that can be type juggled to a boolean
 * @return string
 */
function eYesNo($value)
{
	if (is_null($value)) {
		return '';
	}
	if ($value) {
		return 'Yes';
	} else {
		return 'No';
	}
}

/**
 * Convert boolean to Yes or No and echo result.
 */
function eeYesNo($value)
{
	echo eYesNo($value);
}

/**
 * Provides a shortcut to the logger. Use only for short term debug 
 * messages as this function is not reliably available.
 */
function debug($message) 
{
	Logger::GetInstance()->debug($message);
}

