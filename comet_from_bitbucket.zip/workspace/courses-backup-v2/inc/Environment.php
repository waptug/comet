<?php
/**
 * Provide information about the server environment where
 * this PHP script is being executed.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Tech
 */
class Environment
{
	private static $_appbase = null;

	/**
	 * Detect the current server environment
	 */
	public static function GetEnv()
	{
		if (isset($_SERVER) && array_key_exists('SERVER_NAME', $_SERVER)) {
			$server = $_SERVER['SERVER_NAME'];
		} else {
			$server = exec('hostname');
		}
		switch ($server) {
			case 'test.education.washington.edu':
			case 'jocasta.education.washington.edu':
				$environment = 'TEST';
				break;
			case 'www.education.washington.edu':
			case 'phaedra.education.washington.edu':
			case 'orestes.education.washington.edu':
			case 'education.uw.edu':
			case 'v0009.host.s.uw.edu':
				$environment = 'PROD';
				break;
			default:
                $environment = 'DEV';
				break;
		}
		return $environment;
	}
	
	/**
	 * Returns a string representing the local server operating system
	 * @return string
	 */
	public static function OS()
	{
		return php_uname('s');
	}
	
	/**
	 * Returns a string describing how the script was requested.
	 *  'http' - script was run through web server
	 *  'cli'  - script was run via command line interface
	 * @return string
	 */
	public static function ScriptType()
	{
		if (PHP_SAPI == 'cli' && array_key_exists('SHELL', $_SERVER)) {
			return 'cli';
		} else {
			return 'http';
		}
	}
	
	/**
	 * Return the base part of a URL that specifies this application.
	 */
	public static function AppBase()
	{
		return self::$_appbase;
	}
	
	/**
	 * Specify the base part of a URL that specifies this application.
	 * @param string $url_path
	 */
	public static function SetAppBase($url_path)
	{
		self::$_appbase = rtrim($url_path, '/');
	}
	
}