<?php
/**
 * @namespace UW_COE_Courses
 */
/**
 * 
 * @author hanisko
 */

class Application
{
	protected $environment;
	protected $request;
	protected $view;
	protected $user;
	
	public static function Bootstrap()
	{
		$a = new self();
		// inject dependencies
		
		return $a;
	}
	
	public function environment()
	{
		return $this->environment;
	}
	
	public function request()
	{
		return $this->request;
	}
	
	public function run()
	{
		// locate controller
		
		// authorize
		
		// create view object
		
		// get content
		
		// include template
	}
	
	public function view()
	{
		return $this->view;
	}
	
}