<?php
/**
 * Provides short term persistent storage of variables (session)
 * to support bulk creation of course offering records.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Builder
{
	private static $_instance;
	private static $_prefix = 'crs_bldr_';
	
	protected function __construct()
	{
	
	}
	
	public function __get($name)
	{
		if (array_key_exists($this->getIndex($name), $_SESSION)) {
			return $_SESSION[$this->getIndex($name)];
		} else {
			return null;
		}
	}
	
	public function __set($name, $value)
	{
		$_SESSION[$this->getIndex($name)] = $value;
	}
	
	public function __isset($name)
	{
		return (array_key_exists($this->getIndex($name), $_SESSION));
	}
	
	public function __unset($name)
	{
		unset($_SESSION[$this->getIndex($name)]);
	}
	
	public function getIndex($name)
	{
		return self::$_prefix . $name;
	}
	
	public static function GetInstance()
	{
		if (is_null(self::$_instance)) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

}