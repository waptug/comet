<?php
/**
 * Supports abstraction of a data source for importing data into a 
 * local data store.
 * 
 * @author Paul
 */

abstract class DataReader
{
	
	/**
	 * Begin processing the next record (or set of fields) in the data
	 * feed. Return true if the next record exist, false at the end 
	 * of the data feed.
	 * 
	 * @param string $field
	 * @return boolean
	 */
	abstract public function next();
	
	/**
	 * Return the internal pointer to the first record in the data feed.
	 */
	abstract public function reset();
	
}