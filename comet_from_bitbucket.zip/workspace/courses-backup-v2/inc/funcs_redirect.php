<?php

/**
 * Generate a full absolute URL including protocol, hostname
 * and path based on any full or partial URL
 * 
 * @param string $targeturl  a url to base the full url on
 * @return string
 */ 
function makeFullUrl ($targeturl) 
{
	$server = $_SERVER["HTTP_HOST"];
	$protocol = 'http://';
	if ($_SERVER['SERVER_PORT'] == '443') { $protocol = 'https://'; }
	$url = '';
	// It's a full URL including http protocol
	if (eregi('^https?://', $targeturl)) {
		$url = $targeturl;
	}
	// It's a server relative URL beginning with a slash
	elseif (eregi('^/', $targeturl)) {
		$url = $protocol . $server . $targeturl;
	}
	// It's a relative URL based on current page path
	else {
		$currentdir = $_SERVER['PHP_SELF'];
		$bits = array();
		eregi('^.*/', $currentdir, $bits); // match everything up to last slash and store in $bits
		$currentdir = $bits[0];
		$url = $protocol . $server . $currentdir . $targeturl;
	}
	return $url;
}


/**
 * Send a redirect header back to the client to a new page location. 
 * $target must be an application relative path, it should not 
 * include the Environment::AppBase. Optionally include an application
 * message to be displayed on the subsequent page.
 * 
 * @param string $target application relative path to destination page
 * @param string $target  new page client should view
 */ 
function redirect($target, $appmessage = null, $httpstatus = 200) 
{
	if ($appmessage) {
		AppMessage::Store($appmessage);
	}
	// word on street is Chrome won't redirect without a status
    header ('Status: '.$httpstatus);
	header ('Location: '. htmlspecialchars_decode(eHref($target)));
	exit;
}
