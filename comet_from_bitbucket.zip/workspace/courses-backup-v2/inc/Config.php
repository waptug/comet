<?php
/**
 * Locates and loads an appropriate database configuration.
 * 
 * @package UW_COE_Framework
 */

class Config
{
	private static $_config;

	/**
	 * Returns an object holding all of the config details or if optionally
	 * set, only a subset based on the $setting parameter
	 * @param string $setting the name of a first-level property of the config object
	 * @return null|stdClass
	 */
	public static function GetConfig($setting = null) {
		if(is_null(self::$_config))
			self::$_config = self::array_to_object(include __DIR__.'/../config/merged_config.php');

		if(is_null($setting))
			return self::$_config;
		
		if(property_exists(self::$_config, $setting))
			return self::$_config->{$setting};
		else
			return null;
	}

	private static function array_to_object($array) {
	  $obj = new stdClass;
	  foreach($array as $k => $v) {
	     if(strlen($k)) {
	        if(is_array($v)) {
	           $obj->{$k} = self::array_to_object($v); //RECURSION
	        } else {
	           $obj->{$k} = $v;
	        }
	     }
	  }
	  return $obj;
	} 

}