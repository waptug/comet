<?php
/**
 * Store PHP session data in a databases. Depends on a table in the 
 * default database with the following name and structure.
 *  
 * mysql> describe phpsession;
 * +-----------+----------+------+-----+---------+-------+
 * | Field     | Type     | Null | Key | Default | Extra |
 * +-----------+----------+------+-----+---------+-------+
 * | sessionid | char(32) | NO   | PRI |         |       |
 * | data      | text     | YES  |     | NULL    |       |
 * | accessed  | datetime | YES  |     | NULL    |       |
 * +-----------+----------+------+-----+---------+-------+
 */

class SessionDb extends DbObject 
{
	private $_deleted = false;

	/**
	 * Create or fetch the instance of this class. This class is a singleton, 
	 * but cannot implement the typical pattern (private constructor) because
	 * of its inheritance from DbObject.
	 *
	 * @param string $sessionid PHP's session identifier hash
	 * @return SessionDb
	 */
	public function __construct()
	{	
		parent::__construct(DbConnection::GetInstance(), 'phpsession');
		$this->addPrimaryKeyField('sessionid', 0, 0);
		$this->addField('data');
		$this->addField('accessed', DbObject::TYPE_DATETIME);
	}
	
	public function open($savepath, $sessionname)
	{
		return true;
	}
	
	public function close()
	{
		if ($this->_deleted) { return true; }
		// record that we accessed the session
		$this->accessed = time();
		$this->save();
		session_write_close();
		return true;
	}
	
	public function lazyload($sessionid)
	{
		if ($sessionid != $this->sessionid) {
			$this->sessionid = $sessionid;
			$this->load();
		}
	}
	
	public function read($sessionid)
	{
		$this->lazyload($sessionid);
		return $this->data;
	}
	
	public function write($sessionid, $sess_data)
	{
		$this->lazyload($sessionid);
		$this->data = $sess_data;
		$this->accessed = time();
		$this->save();
		return;
	}

	public function destroy($sessionid)
	{
		$this->delete();
		$this->_deleted = true;
		return;
	}
	
	public function gc($maxlifetime)
	{
		$deletefrom = date('Y-m-d H:i:s', time() - $maxlifetime);
		$sql = "DELETE FROM phpsession WHERE accessed < '$deletefrom'";
		DbConnection::GetInstance()->query($sql, 'SessionDb::gc');
	}
	
}

$SessionDb_instance = new SessionDb();
/**
 * Tell PHP how to use the methods defined in the class above
 * to maintain session information in the database.
 */
session_set_save_handler(
	array($SessionDb_instance, 'open'),
	array($SessionDb_instance, 'close'),
	array($SessionDb_instance, 'read'),
	array($SessionDb_instance, 'write'),
	array($SessionDb_instance, 'destroy'),
	array($SessionDb_instance, 'gc')
);