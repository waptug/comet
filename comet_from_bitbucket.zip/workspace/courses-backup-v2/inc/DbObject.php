<?php
/**
 * Class to manage interaction with a single database
 * record on a single table
 */
abstract class DbObject 
{
	const TYPE_CHAR      = 0;
	const TYPE_DATETIME  = 1;
	const TYPE_BOOLEAN   = 2;
	const TYPE_INT       = 3;
	const TYPE_NUMERIC   = 4;
	const TYPE_TIMESTAMP = 1;
	
	const PK_IS_SERIAL  = true;
		
	private $_table;
	private $_primarykey = array();
	private $_fields = array();
	private $_exists = null;
	private $_serialfield = false;
	protected $db = null;
		
	public function __construct($db, $table)
	{
		$this->db = $db;
		$this->_table = $table;
	}
	
	/**
	 * Add a name/value pair to the list of primary key fields and values
	 * 
	 * @param string $fieldname the name of a primary key member field from the database
	 * @param string $value the value of that field to match the target row
	 * @param int $datatype whether that data is character, integer, or numeric for quoting
	 * @param bool $serial whether this field is an int serial number assigned by the database
	 */
	public function addPrimaryKeyField($fieldname, $value, $datatype = self::TYPE_CHAR, $serial = false)
	{
		// if this field is a db incremented serial number
		if ($serial) {
			// and a serial field is not already defined
			if (!$this->_serialfield) {
				// store this as the serialfield 
				$this->_serialfield = $fieldname;
				// override the datatype
				$datatype = self::TYPE_INT;
			} else {
				Logger::GetInstance()->debug('DbObject::addPrimaryKeyField() cannot define multiple serial number primary keys '. $fieldname);
				throw new Exception('Bad data definition');
			}
		}
		$this->_primarykey[$fieldname] = $value;
		$this->addField($fieldname, $datatype, $value);
	}
	
	/**
	 * Add a database field to the object
	 * 
	 * @param string $fieldname name of a member field from the database
	 * @param int $datatype whether that data is character, integer, or numeric for quoting
	 * @param string $default default value to assign immediately
	 */
	public function addField($fieldname, $datatype = self::TYPE_CHAR, $default = null)
	{
		$this->_fields[$fieldname] = array(
			'value'   => $default,
			'type'    => $datatype,
		    'changed' => false
		);
	}

	// Check for unknown variable names in the fields list
	public function __get($name)
	{
		return array_key_exists($name, $this->_fields) ? $this->_fields[$name]['value'] : null;
	}
	
	// Check for unknown variable names in the fields list
	public function __set($name, $value)
	{
		// this method is only available for defined database fields
		if (!array_key_exists($name, $this->_fields)) {
			Logger::GetInstance()->debug('DbObject::__set() undefined field '. $name);
			throw new Exception('Undefined field '. $name);
		}
		// don't allow serial primary keys to be updated
		if ($name == $this->_serialfield) {
			Logger::GetInstance()->debug('DbObject::__set() tried to change value of serial primary key '. $name);
			throw new Exception('Cannot change serial primary key '. $name);
		}
		// make a friendly attempt to convert string dates to their int values
		if ($this->_fields[$name]['type'] == self::TYPE_TIMESTAMP) {
			if (!is_int($value)) {
				$ts = strtotime($value);
				if ($ts !== false) {
					$value = $ts;
				}
			}
		}
		// only trigger an update if this is actually a new value
		if ($this->_fields[$name]['value'] === $value) {
			return;
		}
		$this->_fields[$name]['value'] = $value;
		$this->_fields[$name]['changed'] = true;
	}
	
	/**
	 * Load the data for this object from the database
	 */
	public function load()
	{
		if (count($this->_primarykey) == 0) {
			Logger::GetInstance()->debug('Primary Key fields must be defined before loading a record');
			throw new Exception('Insufficient information to load');
		}
		// if this object has a serial pk
		if ($this->_serialfield && count($this->_primarykey) ==  1) {
			// and the value is null or 0
			if ($this->_primarykey[$this->_serialfield] == 0) {
				// we don't have to check database for it
				return;
			}
		}
		$sql = 'SELECT '. $this->getSelectFields() . ' '
		     . 'FROM `'  . $this->_table . '` '
		     . 'WHERE ' . $this->getPrimaryKeyWhereClause();
     
		$row = $this->db->fetchRow($sql);
		
		if (is_null($row)) {
			// Since we just tried to load it and it wasn't there
			$this->_exists = false;
		} else {
			// Since we found a record we know its in the database
			$this->_exists = true;
			// Store loaded values in the object
			$this->init($row);
		}
		// Fire any post load tasks
		$this->postLoad();
	}
	
	/**
	 * Assign an array of values back to the object. Use to take an
	 * associative array from a single row of a database query and
	 * populate the object
	 *
	 * @param array $row 
	 */
	public function init($row)
	{
		// $field get the database fieldname
		// $a gets an array of this field's attributes
		foreach ($this->_fields as $field => $a) {
			if (array_key_exists($field, $row)) {
				$val = $row[$field];
			} else {
				$val = null;
			}
			switch ($a['type']) {
				case self::TYPE_TIMESTAMP:
					// for date time fields we'll convert to integer values
					if (!is_null($val))
						$val = strtotime($val);
					break;
				case self::TYPE_BOOLEAN:
					// for boolean fields convert to PHP literal true/false
					$val = (bool) $val;
					break;
				default:
					break;
			}
			// store the cleaned up value
			$this->_fields[$field]['value']   = $val;
			// update changed, since we just got this from database
			$this->_fields[$field]['changed'] = false;
		}
		$this->postInit();
	}
	
	/**
	 * Write the data in the object to the database. Implements
	 * insert or update as appropriate.
	 */
	public function save()
	{
		if (count($this->_primarykey) == 0) {
			Logger::GetInstance()->debug('Primary Key fields must be defined before saving a record');
			throw new Exception('Insufficient information to save');
		}

		$this->preSave();
		
		if ($this->recordExists()) {
			$this->dbUpdate();
		} else {
			$this->dbInsert();
		}
		
		// store the fact that our object data is now the same as the db data
		foreach ($this->_fields as $f) {
			$f['changed'] = false;
		}
		
		// copy values saved to db back to the primary key array
		foreach (array_keys($this->_primarykey) as $field) {
			$this->_primarykey[$field] = $this->_fields[$field]['value'];
		}
		
		// we just wrote the record to the database so we know it exists
		$this->_exists = true;
		
		$this->postSave();
	}
	
	public function getValuesAsArray()
	{
		$out = array();
		foreach ($this->_fields as $name => $f) {
			$out[$name] = $f['value'];
		}
		return $out;
	}
	
	private function dbInsert()
	{
		$this->preInsert();

		// create an array of all the fields and their db safe values
		$data = array();
		foreach (array_keys($this->_fields) as $field) {
			if ($field != $this->_serialfield) { // don't try to insert a serial number field
				$data['`'. $field .'`'] = $this->getQuotedValue($field);
			}
		}
		// use those pairs to build an sql statement
		$columns = implode(', ', array_keys($data));
		$values  = implode(', ', $data);
	
		// and stick it all together
		$sql = 'INSERT INTO `'. $this->_table .'`('. $columns .') VALUES('. $values .')';
		
		// handle an insert
		$this->db->query($sql);
				
		// if our primary key is a serial number, find out what it is
		if ($this->_serialfield) {
			$this->_primarykey[$this->_serialfield] = $this->db->getLastInsertId();
			$this->_fields[$this->_serialfield]['value'] = $this->_primarykey[$this->_serialfield];
		}
		
		// successful insert means
		$this->_exists = true;
		
		$this->postInsert();
	}
	
	private function dbUpdate()
	{
		$this->preUpdate();
		
		// create an array of all the fields with new values
		$data = array();
		foreach ($this->_fields as $field => $a) {
			if ($a['changed']) {
				$data[] = '`'. $field .'` = '. $this->getQuotedValue($field);
			}
		}
		
		// only do this if we have one or more fields to save
		if (count($data) > 0) {
			// and stick it all together
			$sql = 'UPDATE `'. $this->_table .'` SET '. implode(', ', $data) .' WHERE '. $this->getPrimaryKeyWhereClause();
						
			// handle an insert
			$this->db->query($sql);
		}
		
		// if an update didnt throw an error
		$this->_exists = true;
		
		$this->postUpdate();
	}

	/**
	 * Delete this record from the database.
	 */
	public function delete()
	{
		if (count($this->_primarykey) == 0) {
			Logger::GetInstance()->debug('Primary Key fields must be defined before deleting a record');
			throw new Exception('Insufficient information to delete');
		}
		
		// don't bother if it's not in the database
		if (!$this->recordExists()) return;
		
		$this->preDelete();
		
		$sql = 'DELETE FROM '. $this->_table .' WHERE '. $this->getPrimaryKeyWhereClause();
		$this->db->query($sql);
		
		$this->postDelete();
		
		$this->_exists = false;
	}
		
	protected function preInsert()
	{
		return true;
	}

	protected function postInsert()
	{
		return true;
	}

	protected function preUpdate()
	{
		return true;
	}

	protected function postUpdate()
	{
		return true;
	}
	
	protected function preSave()
	{
		return true;
	}
	
	protected function postSave()
	{
		return true;
	}

	protected function preDelete()
	{
		return true;
	}

	protected function postDelete()
	{
		return true;
	}

	protected function postInit()
	{
		return true;
	}

	protected function postLoad()
	{
		return true;
	}
	
	/**
	 * Check if the record as a whole is stored and updated in 
	 * the database based on the defined primary key fields
	 * 
	 * @return bool
	 */
	public function isSaved()
	{
		// if this record is not in the database at all, it is not saved
		if (!$this->_exists) {
			return false;
		}
		// check each field to see if the data in it has changed
		$saved = true;
		foreach ($this->_fields as $a) {
			if ($a['changed']) {
				$saved = false;
				break;
			}
		}
		return $saved;
	}
	
	/**
	 * Check if the record already exists in the database
	 * based on the defined primary key fields
	 * 
	 * @return bool
	 */
	public function recordExists()
	{
		// if we have done this calculation before, return the stored value
		if (!is_null($this->_exists)) {
			return $this->_exists;
		}
			
		// we can figure out if records with serial pk's are new w/o hitting database
		if ($this->_serialfield && count($this->_primarykey) ==  1) {
			// we are using an artificial serial number pk
			if ($this->_primarykey[$this->_serialfield] > 0) {
				$this->_exists = true;
			} else {
				$this->_exists = false;
			}
		} else {
			// natural primary keys we have to look up
			$sql = 'SELECT COUNT(*) AS howmany FROM '. $this->_table .' WHERE '. $this->getPrimaryKeyWhereClause();
			$howmany = $this->db->fetchOne($sql);
			// translates a count of 0 to false other to true
			$this->_exists = (bool) $howmany;
		}
		return $this->_exists;
	}
	
	/**
	 * Explicitly state whether this record exists in the database. In most
	 * cases this is better left calculated by internal class logic. This
	 * is provided for occasional edge cases where external code knows the
	 * state of this data in the database and knows it will be tested.
	 * 
	 * @param boolean $exists
	 */
	public function setRecordExists($exists)
	{
		$this->_exists = $exists;	
	}
		
	/**
	 * Get a string containing a comma separated list of the
	 * fields defined in the object.
	 *
	 * @return string
	 */
	protected function getSelectFields() 
	{
		$quoted = array_keys($this->_fields);
		// quote field names with back quotes for the database
		@array_walk($quoted, 'DbObject::AddBackTicks');
		return implode(', ', $quoted);
	}

	/**
	 * Function to support array walk and quote database object names
	 * (e.g. tables or columns) with back quotes.
	 *
	 * @param string $value the string to be quoted
	 */
	protected static function AddBackTicks(&$value)
	{
		$value = '`'. $value .'`';
	}
	
	/**
	 * Generate the conditional phrases of a WHERE clause based on the 
	 * primary key fields. String returned does not include the WHERE 
	 * keyword itself.
	 *
	 * @return string
	 */
	protected function getPrimaryKeyWhereClause()
	{
		$where = array();
		foreach (array_keys($this->_primarykey) as $field) {
			// when making a where clause we have to use the _primarykey array, because the 
			// _fields array may have an updated value in it
			$where[] = '`'. $field .'` = '. $this->getQuotedValue($field, $this->_primarykey[$field]);
		}
		return implode(' AND ', $where);
	}
	
	/**
	 * Build a WHERE clause by joining together a list of conditional 
	 * phrases with AND statements. Accepts a string or an array list 
	 * of phrases. If the argument is empty returns an the empty string.
	 * 
	 * @param mixed $filters one or more conditional phrases
	 * @return string
	 */
	public static function MakeWhereClause($filters)
	{
		if (is_array($filters)) {
			$filters = implode(' AND ', $filters);
		}
		if (strlen($filters) > 0) {
			$filters = ' WHERE '.$filters.' ';
		}
		return $filters;
	}
	
	
	/**
	 * Escape and quote a value based on its datatype in preparation
	 * for passing it to a MySQL database
	 *
	 * @param string $field name of the database and object field
	 * @param string $value optionally override the current value (e.g. for primary key updates)
	 * @return string
	 */
	protected function getQuotedValue($field, $value = null)
	{
		// if we didn't get a value as the second argument, use the field value
		if (is_null($value)) {
			$value = $this->_fields[$field]['value'];
		}
		
		// if this field's value is null in object return the db null literal
		if (is_null($value)) { return 'null'; }
		$quoted = '';
		switch ($this->_fields[$field]['type']) {
			case self::TYPE_TIMESTAMP:
				$quoted = $this->db->quote($value, 'datetime');
				break;
			case self::TYPE_CHAR:
				$quoted = $this->db->quote($value, 'char');
				break;
			case self::TYPE_INT:
				$quoted = $this->db->quote($value, 'int');
				break;
			case self::TYPE_NUMERIC:
				$quoted = $this->db->quote($value, 'float');
				break;
			case self::TYPE_BOOLEAN:
				$quoted = $this->db->quote($value, 'bool');
				break;
			default:
				Logger::GetInstance()->debug('DbObject::getQuotedValue() unknown data type '. $this->_fields[$field]['type'] .' for field '. $field);
				throw new Exception('Invalid datatype');
				break;
		}
		return $quoted;
	}
		
}