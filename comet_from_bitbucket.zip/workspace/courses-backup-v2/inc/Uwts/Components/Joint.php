<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Provides a list of Joint offerings. Joint offerings can be of the type
 * Db_Offering (for local college course offerings) or Db_Joint External
 * for Joint sections in other units on campus.
 * @author hanisko
 */
namespace Uwts\Components;
 
class Joint implements \Iterator , \Countable 
{
	private $items;
	private $position;
	private $uwts;
	
	public function __construct(\Db_UwtsOffering $uwts)
	{
		$this->uwts = $uwts;
	}

	public function addSwsJointItem($data)
	{
		if (!$data instanceof \stdClass || !property_exists($data, 'CurriculumAbbreviation')) {
			throw new \Exception('Not valid data for UWTS joint offering record');
		}
		$this->lazyload();
		$item = new \stdClass();
		$item->curriculum = $data->CurriculumAbbreviation;
		$item->courseno = $data->CourseNumber;
		$item->section = $data->SectionID;
		$this->items[] = $item;
	}
	
	public function clear()
	{
		$this->items = array();
	}
	
	public function debug()
	{
		debug(print_r($this->items, true));
	}
	

	/**
	 * Returns true if the provided curriculm abbreviation, course number and section
	 * identify a joint section for this uwts offering
	 * @param string $curriculum
	 * @param integer $courseno
	 * @param string $section
	 * @return boolean
	 */	public function hasJoint($curriculum, $courseno, $section)
	{
		$this->lazyload();
		foreach ($this->items as $joint) {
			if ($joint->curriculum == $curriculum && $joint->courseno == $courseno && $joint->section == $section) {
				return true;
			}
		}
		return false;
	}
	
	private function lazyload()
	{
		if (is_null($this->items)) {
			$this->load();
		}
	}
	
	public function load()
	{
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT jointlist_json FROM uwtsjoint WHERE uwtsofferingid = '.$this->uwts->uwtsofferingid;
		$json = $db->fetchOne($sql);
		if ($json) {
			$this->items = json_decode($db->fetchOne($sql));
		} else {
			$this->items = array();
		}
	}
	
	public function save()
	{
		$db = \DbFactory::GetConnection();
		if ($this->items) {
			$items = $db->quote(json_encode($this->items));
			$sql = 'INSERT INTO uwtsjoint '
			     . 'VALUES('.$this->uwts->uwtsofferingid.','.$items.') '
			     . 'ON DUPLICATE KEY UPDATE jointlist_json = '.$items;
			$db->query($sql);
		} else {
			$db->query('DELETE FROM uwtsjoint WHERE uwtsofferingid = '.$this->uwts->uwtsofferingid);
		}
	}
	
	/**
	 * Iterator::current � Return the current element
	 * @return Db_Quarter
	 */
	function current()
	{
		return $this->items[$this->position];
	}
	
	/**
	 * Iterator::key � Return the key of the current element
	 * @return scalar
	 */
	function key()
	{
		return $this->position;
	}
	
	/**
	 * Iterator::next � Move forward to next element
	 * @return void
	 */
	function next()
	{
		++$this->position;
	}
	
	/**
	 * Iterator::rewind � Rewind the Iterator to the first element
	 * @return void
	 */
	function rewind()
	{
		$this->lazyload();
		$this->position = 0;
	}
	
	/**
	 * Iterator::valid � Checks if current position is valid
	 * @return boolean
	 */
	function valid()
	{
		return ($this->position < count($this->items));
	}
	
	/**
	 * Countable::count � returns number of entities in iterable list
	 * @return boolean
	 */
	public function count()
	{
		$this->lazyload();
		return count($this->items);
	}
	
}
