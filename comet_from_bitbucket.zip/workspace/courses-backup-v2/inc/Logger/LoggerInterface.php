<?php
/**
 * @package UW_COE_Framework
 */
/**
 * An interface for objects that can write log output
 * @author hanisko
 */

interface Logger_LoggerInterface
{
	public function write($message);
}