<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Writes log messages to standard output
 * @author hanisko
 */
 
class Logger_Stdout implements Logger_LoggerInterface
{
	
	public function write($message)
	{
		echo $message.PHP_EOL;	
	}
	
}