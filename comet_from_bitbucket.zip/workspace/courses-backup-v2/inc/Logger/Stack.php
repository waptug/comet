<?php
/**
 * @package UW_COE_Framework
 */
/**
 * A Logger Stack maintains a collection of zero or more Logger objects and
 * writes messages to the entire stack.
 * @author hanisko
 */
namespace Logger;

class Stack
{
	protected $loggers;
	
	public function __construct()
	{
		$this->clearLoggers();
	}
	
	public function addLogger($logger)
	{
		$this->loggers[] = $logger;
	}
	
	public function clearLoggers()
	{
		$this->loggers[] = array();
	}
	
	public function write($message)
	{
		foreach ($this->loggers as $logger) {
			$logger->write($message);
		}
	}
	
}