<?php
/**
 * @package UW_COE_Framework
 */
/**
 * An interface for objects that can log changes in objects. The before
 * method makes a snapshot of the state of an object. The after method
 * compares the snapshot to the current state and logs changes.
 * @author hanisko
 */

interface Logger_ChangeLogInterface
{
	/**
	 * Record a snapshot of the state of an object. This method cannot simply
	 * store a reference to the object, it needs to store values since the
	 * provided object is likely to be modified.
	 * @param mixed $object
	 */
	public function before($object);
	
	/**
	 * Compare the values of the 
	 * @param mixed $object
	 */
	public function after($object);
}