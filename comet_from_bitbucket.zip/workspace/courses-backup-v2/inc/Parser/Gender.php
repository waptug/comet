<?php
/**
 * This parser converts known identifiers of Male and Female to 
 * the single characters M or F.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */


class Parser_Gender
{
	public static $gender_map = array(
		'female' => 'F',
		'male' => 'M'
	);
	
	public function getValue($input)
	{
		$item = trim($input);
		if (array_key_exists($item, self::$gender_map)) {
			return self::$gender_map[$item];
		} else {
			return null;
		}
	}

}