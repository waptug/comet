<?php
/**
 * This parser extracts a name value. It converts all upper case words to 
 * camel case.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Parser_Name
{
	protected static $name_word_delimiters = array(
		' ',
		'-'
	);
	public function getValue($input)
	{
		$name = trim($input);
		// Check if they typed name in all upper or all lower
		$lcname = strtolower($name);
		$ucname = strtoupper($name);
		if ($name == $lcname || $name == $ucname) {
			$name = ucwords($lcname);
		}
		return $name;
	}
	
	/**
	 * Converts name values to proper case. Similar to ucwords but
	 * also adds upper case after hyphens.
	 * @param string $value
	 * @return string
	 */
	public static function FixCase($value)
	{
		$value = strtolower($value);
		foreach (self::$name_word_delimiters as $delimiter) {
			if (strpos($value, $delimiter) !== false) {
				$bits = explode($delimiter, $value);
				$end = count($bits);
				for($i = 0; $i < $end; ++$i) {
					$bits[$i] = ucfirst($bits[$i]);
				}
				return implode($delimiter,$bits);
			}
		}
		return ucfirst($value);
	}

}
