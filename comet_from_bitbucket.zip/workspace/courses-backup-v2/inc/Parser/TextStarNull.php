<?php
/**
 * Parse a text value. Trims leading and trailing whitespace. In this input a value
 * of a single asterisk indicates an empty value.
 *
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */
class Parser_TextStarNull
{
	
	public function getValue($input)
	{
		// Whitespace padding
		$value = trim($input);
		
		if ($value == '*' || $value === '') {
			return null;
		}
		return $value;
	}
	
}
