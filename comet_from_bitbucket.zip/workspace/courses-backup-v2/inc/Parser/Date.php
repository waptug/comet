<?php
/**
 * This parser attempts convert the text input to a unix timestamp
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Parser_Date
{
	
	public function getValue($input)
	{
		$val = trim($input);
		if (!$val) {
			return null;
		}
		$ts = strtotime($val);
		if ($ts === false) {
			throw new Exception('Failed to parse date value from '. $val);
		}
		return $ts;
	}

}
