<?php
/**
 * Parse a time value.
 * @author Paul
 *
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */
class Parser_Time
{
	
	public function getValue($input)
	{
		$parts = str_split(trim($input));
		$length = count($parts);
		if ($length == 4) {
			$hour = $parts[0].$parts[1];
			$min = $parts[2].$parts[3];
			if ($hour < 8) {
				$hour = $hour + 12;
			}
			$out = sprintf('%02d:%02d', $hour, $min);
		} elseif ($length == 3) {
			$hour = $parts[0];
			$min = $parts[1].$parts[2];
			if ($hour < 8) {
				$hour = $hour + 12;
			}
			$out = sprintf('%02d:%02d', $hour, $min);
		} else {
			$out = null;
		}
		return $out;
	}
	
}

