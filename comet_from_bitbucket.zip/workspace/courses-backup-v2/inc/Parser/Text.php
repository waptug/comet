<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Parse a text value. Trims leading and trailing whitespace.
 * @author hanisko
 * @package UW_COE_Courses
 */
class Parser_Text
{
	
	public function getValue($input)
	{
		// Whitespace padding
		return trim($input);
	}
	
}
