<?php
/**
 * This parser attempts convert the text input to a PHP boolean
 * true/false value
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Parser_Boolean
{
	
	protected static $false_values = array(
		'FALSE',
		'NO',
		'N',
		'0'
	);
	
	public function getValue($input)
	{
		$val = strtoupper(trim($input));
		if (in_array($val, self::$false_values) || $val === 0) {
			return false;
		} elseif (strlen($val) > 0) {
			return true;
		} else {
			return null;
		}
	}

}
