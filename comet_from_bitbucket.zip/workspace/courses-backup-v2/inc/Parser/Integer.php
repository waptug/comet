<?php
/**
 * This parser converts the value to an integer using PHP type juggling.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Parser_Integer
{
	
	public function getValue($input)
	{
		return (int) trim($input);
	}

}
