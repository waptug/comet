<?php
/**
 * This parser converts the value to an float using PHP type juggling.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Parser_Number
{
	
	public function getValue($input)
	{
		return (float) trim($input);
	}

}
