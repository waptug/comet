<?php
/**
 * Parses a title value. Translates the UWSDB all caps to upper
 * case word format.
 *
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */
class Parser_Title
{
	/**
	 * List of abbreviations commonly used in course names that 
	 * should remain all capital letters.
	 * @var array
	 */
	private static $uc_abbrev = array(
		'Esl',
		'Ii',
		'Iii',
		'Iv'
	);
	
	/**
	 * List small words commonly used in course names that 
	 * should remain all lower case letters.
	 * @var array
	 */
	private static $lc_words = array(
		'A',
		'And',
		'As',
		'At',
		'For',
		'In',
		'Of',
		'On',
		'Or',
		'The',
		'To',
		'With'
	);
	
	public function getValue($input)
	{
		// trim whitespace and convert to mixed case
		return self::FixCase(trim($input));
	}

	/**
	 * Converts course title values to proper case. Similar to ucwords but
	 * also adds upper case after hyphens, commas, and dots. Also respects
	 * specified upper case abbreviations and lower case minor words.
	 * @param string $value
	 * @return string
	 */
	public static function FixCase($value)
	{
		$value = strtolower($value);
		$value = preg_replace_callback('/[ \-\.\/,&:][^ \-\.\/,&:]/', 'self::UpperMatch', $value);
		$pattern = '/\b'.implode('\b|\b', self::$lc_words).'\b/';
		$value = preg_replace_callback($pattern, 'self::LowerMatch', $value);
		$pattern = '/\b'.implode('\b|\b', self::$uc_abbrev).'\b/';
		$value = preg_replace_callback($pattern, 'self::UpperMatch', $value);
		return ucfirst($value);
	}
	
	/**
	 * Method compatible with preg_replace_callback that converts the
	 * matched pattern to lower case.
	 * @param array $matches
	 */
	private static function LowerMatch($matches)
	{
		return strtolower($matches[0]);
	}
	
	/**
	 * Method compatible with preg_replace_callback that converts the
	 * matched pattern to upper case.
	 * @param array $matches
	 */
	private static function UpperMatch($matches)
	{
		return strtoupper($matches[0]);
	}
	
}
