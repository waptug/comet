<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Locate a curriculum abbreviation, an integer course number and
 * a section letter in a user input string.
 * @author hanisko
 */
class Parser_CourseNumber
{
	const REG_EX = '/([A-Za-z][A-Za-z &]?[A-Za-z &]?[A-Za-z &]?[A-Za-z &]?[A-Za-z])\s*([1-9][0-9][0-9])\s*([A-Za-z]?)/';
	
	public static $fixes = array(
		'TEP'  => 'EDTEP',
		'EDCI' => 'EDC&I'		
	);
	
	public $curriculum;
	public $courseno;
	public $section;
	
	public function getValue($input)
	{
		$matches = array();
		$r = preg_match(self::REG_EX, $input, $matches);
		if ($r) {
			$this->curriculum = trim(strtoupper($matches[1]));
			if (array_key_exists($this->curriculum, self::$fixes)) $this->curriculum = self::$fixes[$this->curriculum];
			$this->courseno = $matches[2];
			$this->section = trim(strtoupper($matches[3]));
			return $this->curriculum.' '.$this->courseno.' '.$this->section;
		} else {
			$this->curriculum = null;
			$this->courseno = null;
			$this->section = null;
			return null;
		}
	}
	
}
