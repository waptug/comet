<?php
/**
 * This parser attempts to locate the first name part
 * of a name input.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Parser_FirstOnly extends Parser
{

	/**
	 * Return the processed value based on the input provided scrubbed
	 * and converted to local format
	 * @params string $input raw data to be parsed and scrubbed for a value in the expected format
	 * @return mixed
	 */
	public function getValue($input)
	{
		// Look for a comma first
		if (strpos($input, ',') !== false) {
			$bits = explode(',', $input);
			$out = trim(end($bits));
		} else {
			$input = trim($input);
			// Alternately look for spaces 
			if (strpos($input, ' ') !== false) {
				$lastspace = strrpos($input, ' ');
				$out = substr($input, 0, $lastspace);
			} else {
				// no delimiters return the whole thing
				$out = trim($input);
			}
		}
		// Check for and strip middle initial/names
		$bits = explode(' ', $out);
		if (strlen($bits[0]) > 2) {
			$out = $bits[0];
		} elseif (count($bits) > 1 && strlen($bits[1]) > 2){
			$out = $bits[1];
		} else {
			$out = $bits[0];
		}
		// Convert the name to proper case
		$out = Parser_Name::FixCase($out);
		return $out;
	}
	
}