<?php
/**
 * This parser attempts to locate the last name part
 * of a name input.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Parser_LastOnly extends Parser
{

	/**
	 * Return the processed value based on the input provided scrubbed
	 * and converted to local format
	 * @params string $input raw data to be parsed and scrubbed for a value in the expected format
	 * @return mixed
	 */
	public function getValue($input)
	{
		// Look for a comma first
		if (strpos($input, ',') !== false) {
			$lastcomma = strrpos($input, ',');
			// return everything before the last comma
			$out = trim(substr($input, 0, $lastcomma));
		} else {
			$input = trim($input);
			// Alternately look for spaces 
			if (strpos($input, ' ') !== false) {
				$lastspace = strrpos($input, ' ');
				// return everything from the last space to the end
				$out = trim(substr($input, $lastspace));
			} else {
				// no delimiters return the whole thing
				$out = trim($input);
			}
		}
		// Convert the name to proper case
		$out = Parser_Name::FixCase($out);
		return $out;
	}

}