<?php
/**
 * This parser attempts convert the text input to a PHP boolean
 * true/false value
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Parser_Summerterm
{
	
	protected static $legal_values = array(
		'A',
		'B'
	);
	
	public function getValue($input)
	{
		$val = strtoupper(trim($input));
		if (in_array($val, self::$legal_values)) {
			return $val;
		} else {
			return null;
		}
	}

}
