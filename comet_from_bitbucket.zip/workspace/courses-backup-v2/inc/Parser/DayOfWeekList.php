<?php
/**
 * Parse a string representing day of week flags from a UW time schedule
 * and returns and array on integer representations of selected days where
 * 0 = Sunday, 1 = Monday etc.
 *
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */
class Parser_DayOfWeekList
{
	public static $map = array(
		'M' => 1,
		'T' => 2,
		'W' => 3,
		'R' => 4,
		'F' => 5,
		'S' => 6,
		'U' => 0
	);
	public function getValue($input)
	{
		$days = str_split($input);
		array_walk($days, 'self::Upper');
		$length = count($days);
		$out = array();
		foreach ($days as $dow) {
			if (array_key_exists($dow, self::$map)) {
				$out[] = self::$map[$dow];
			}
		}
		return $out;
	}
	
	/**
	 * Convert a value to uppercase. Compatible with array_walk callback
	 * @param string $item passed as reference
	 * @param integer $key
	 */
	private static function upper(&$item, $key)
	{
		$item = strtoupper($item);
	}
	
}

