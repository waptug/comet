<?php
/**
 * Return the untouched value. Debugging tool for Importer
 *
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */
class Parser_RawData
{
	
	public function getValue($input)
	{
		return $input;
	}
	
}
