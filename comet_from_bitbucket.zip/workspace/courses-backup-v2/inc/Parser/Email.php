<?php
/**
 * This parser handles email addresses. Currently it trims whitespace
 * and converts to lower case.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Parser_Email
{
	
	public function getValue($input)
	{
		return strtolower(trim($input));
	}

}

