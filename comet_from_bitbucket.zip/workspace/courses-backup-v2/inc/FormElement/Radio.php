<?php
/**
 * An HTML form input element. Programmatically generates form
 * element HTML to produce consistent, functional, and scriptable
 * page elements.
 *  
 * @author Paul
 */
class FormElement_Radio extends FormElement_List
{
		
	public function __construct($name, $label, $value = '')
	{
		parent::__construct($name, $label, $value);
	}
	
	/**
	 * Render list of HTML form radio elements
	 * @return string
	 */
	public function getInputElement()
	{
		$n = "\n";
		$t = "\t";
		// need a list of possible values to render a set of radio check boxes
		if (!isset($this->valuelist)) {
			throw new Exception('FormElement::valuelist must be defined before rendering a radio element');
		}
		$formatter = $this->getFormatter();
		
		// prevent putting the same id in multiple places
		$attribs = $this->renderAttributes(array('id'));
		
		// give id a local shortname
		$id = $this->_attributes['id'];
				
		// if liststart is a simple element with no attributes
		$matches = array();
		if (preg_match('/^<([a-zA-Z]+)>$/', $this->liststart, $matches)) {
			// add the generic element id here
			$out = '<' . $matches[1] .' id="'. $id .'">';
		} else {
			// otherwise trust that the user provided whatever hooks they needed
			$out = $this->liststart;
		}
		foreach ($this->valuelist as $value => $display) {
			$thisid = $id . preg_replace('/[^a-zA-Z0-9]/', '', $value);
			$out .= $n . $t . $t . $t . $this->listitemstart;
			if ($value == $this->value) {
				$out .= '<input type="radio" value="'. htmlspecialchars($value) .'" id="'. $thisid
				     .  '" checked="checked"'. $attribs .' /> <label for="'. $thisid .'">'
				     .  $formatter($display) .'</label>'. $this->listitemend;
			} else {
				$out .= '<input type="radio" value="'. htmlspecialchars($value) .'" id="'. $thisid
				     .  '"'. $attribs .' /> <label for="'. $thisid .'">'
				     .  $formatter($display) .'</label>'. $this->listitemend;
			}
		}
		return $out . $n . $t . $t . $this->listend;
	}
	
	/**
	 * Returns an HTML element representing a single, specific value in
	 * the value list.
	 * @param unknown_type $value
	 */
	public function getInputOption($value)
	{
		if (!array_key_exists($value, $this->valuelist)) {
			return null;
		}
		$attribs = $this->renderAttributes(array('id'));
		$thisid = $this->_attributes['id'] . preg_replace('/[^a-zA-Z0-9]/', '', $value);
		if ($value == $this->value) {
			$out = '<input type="radio" value="'. htmlspecialchars($value) .'" id="'. $thisid
			     . '" checked="checked"'. $attribs .' />';
		} else {
			$out = '<input type="radio" value="'. htmlspecialchars($value) .'" id="'. $thisid
			     . '"'. $attribs .' />';
		}
		return $out;
	}
	
}