<?php
/**
 * An HTML form input element. Programmatically generates form
 * element HTML to produce consistent, functional, and scriptable
 * page elements.
 *  
 * @author Paul
 */
class FormElement_Readonly extends FormElement
{
		
	public function __construct($name, $label, $value = '')
	{
		parent::__construct($name, $label, $value);
		$this->class = 'form_readonly';
	}
	
	/**
	 * Render an HTML form text element
	 * @return string
	 */
	public function getInputElement()
	{
		$formatter = $this->getFormatter();
		$attribs = $this->renderAttributes(array('class'));
		if (array_key_exists('class', $this->_attributes)) {
			$class = 'read-only-input '.$this->_attributes['class'];
		} else {
			$class = 'read-only-input';
		}
		$out = '<p class="'.$class.'" '. $attribs .'>'. $formatter($this->value) .'</p>';
		return $out;
	}
	
}
