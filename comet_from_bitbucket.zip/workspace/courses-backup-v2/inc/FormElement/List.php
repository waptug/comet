<?php
/**
 * An HTML form input element that contains a known list of values. 
 * Examples of list form elements include selects, checkboxes, and
 * radio boxes. Programmatically generates form element HTML to 
 * produce consistent, functional, and scriptable page elements.
 *  
 * @author Paul Hanisko
 * @package UW_COE_Framework
 * @version 1.0
 */
abstract class FormElement_List extends FormElement
{
	public $valuelist;
	
	public $liststart = '<ul>';
	public $listend   = '</ul>';
	public $listitemstart = '<li>';
	public $listitemend   = '</li>';
		
	public function __construct($name, $label, $value = '', $valuelist = null)
	{
		parent::__construct($name, $label, $value);
		if (is_array($valuelist)) {
			$this->valuelist = $valuelist;
		}
	}
	
	/**
	 * Add an item to the front of a value list. This is the value that will be displayed
	 * intially to users when no value is selected.
	 * 
	 * @param $display text that gets displayed in select box element
	 * @param $value value that gets returned to the server when this option is selected
	 */
	public function addDefault($display, $value = '')
	{
		$this->valuelist = array($value => $display) + $this->valuelist;
	}
	
	/**
	 * Checks if the current $value of this FormElement is one of the 
	 * values in the array $valuelist. 
	 * 
	 * @return boolean
	 */
	public function valueInList()
	{
		return array_key_exists($this->value, $this->valuelist);
	}
	
}