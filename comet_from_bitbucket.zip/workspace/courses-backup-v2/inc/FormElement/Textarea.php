<?php
/**
 * An HTML form input element. Programmatically generates form
 * element HTML to produce consistent, functional, and scriptable
 * page elements.
 *  
 * @author Paul
 */
class FormElement_Textarea extends FormElement
{
		
	public function __construct($name, $label, $value = '')
	{
		parent::__construct($name, $label, $value);
	}
	
	/**
	 * Render an HTML form textarea element
	 * @return string
	 */
	public function getInputElement()
	{
		$formatter = $this->getFormatter();
		$out = '<textarea'. $this->renderAttributes() .'>'. $formatter($this->value) .'</textarea>';
		return $out;
	}
	
}