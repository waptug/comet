<?php
/**
 * An HTML form input element. Programmatically generates form
 * element HTML to produce consistent, functional, and scriptable
 * page elements.
 *  
 * @author Paul
 */
class FormElement_File extends FormElement
{
		
	public function __construct($name, $label, $value = '')
	{
		parent::__construct($name, $label, $value);
	}
	
	/**
	 * Render an HTML form submit element
	 * @return string
	 */
	public function getInputElement()
	{
		$out = '<input type="file"'. $this->renderAttributes() .' />';
		return $out;
	}
	
} // end of class FormElement