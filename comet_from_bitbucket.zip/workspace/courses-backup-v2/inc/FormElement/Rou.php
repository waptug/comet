<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Select list for ROUs
 * @author hanisko
 */
class FormElement_Rou extends FormElement_List
{
	public $emptyLabel = 'Scheduled by Any';
	
	public function __construct($name, $label, $value = '')
	{
		parent::__construct($name, $label, $value);
		$this->valuelist = array();
	}

	/**
	 * Render an HTML form submit element
	 * @return string
	 */
	public function getInputElement()
	{
		$tab3 = PHP_EOL."\t\t\t";
		$tab4 = PHP_EOL."\t\t\t\t";
		if (!isset($this->valuelist)) {
			throw new Exception('FormElement::valuelist must be defined before rendering a select element');
		}
		if (is_array($this->value)) {
			$values = $this->value;
		} else {
			$values = array($this->value);
		}
		$formatter = $this->getFormatter();
		$out = '<select'. $this->renderAttributes() .'>';
		$out .= $tab3.'<option value="0">'.$formatter($this->emptyLabel).'</option>';
		$rouReport = new \Reports\Rous();
		foreach ($rouReport->getReport() as $rou) {
		
			$out .= $tab3.'<optgroup label="'.e($rou->rou_name).'">';
			if (in_array($rou->rouid, $values)) {
				$selected = ' selected="selected"';
			} else {
				$selected = '';
			}
			$out .= $tab4.'<option value="'.$rou->rouid.'"'.$selected.'>All '.$formatter($rou->rou_name).'</option>';
		
			foreach ($rou->getChildRous() as $child_rou) {
				if (in_array($child_rou->rouid, $values)) {
					$selected = ' selected="selected"';
				} else {
					$selected = '';
				}
				$out .= $tab4.'<option value="'.$child_rou->rouid.'"'.$selected.'>'.$formatter($child_rou->rou_name).'</option>';
			}
			$out .= $tab3.'</optgroup>';
			
		}
		return $out . PHP_EOL."\t\t".'</select>';	
	}
	
}