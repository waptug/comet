<?php
/**
 * The FormElement_Boolean class generates a single checkbox that can
 * be checked or not. Programmatically generates form element HTML to 
 * produce consistent, functional, and scriptable page elements.
 *  
 * @author Paul
 */
class FormElement_Boolean extends FormElement
{
	public $checkboxDescription;
		
	public function __construct($name, $label, $value = '')
	{
		parent::__construct($name, $label, $value);
		$this->class = 'text';
	}
	
	/**
	 * Render an HTML form text element
	 * @return string
	 */
	public function getInputElement()
	{
		$formatter = $this->getFormatter();
		if ($this->value) {
			$checked = ' checked="checked"';
		} else {
			$checked = '';
		}
		$out = '<input type="checkbox" value="1" '. $this->renderAttributes() . $checked .' />';
		if ($this->checkboxDescription) {
			$out .= ' <label for="'.$this->id.'" class="value-lable">'.e($this->checkboxDescription).'</label>';
		}
		return $out;
	}

	/**
	 * Check _GET and _POST for user input that matches this form element
	 * name. Load the value using standard Request::UserInput scrub methods.
	 * 
	 * @param array $scrub_options list of input scrub rules compatible with Request::UserInput
	 */
	public function getUserInput($scrub_options = null)
	{
		if (is_null($scrub_options)) {
			$scrub_options = array();
		}
		if (!is_array($scrub_options)) {
			throw new Exception('$scrub_options must be null or an array');
		}
		// if no checkboxes are checked, the index is not set so default must be the unchecked value
		$scrub_options['default'] = 0;
		$this->value = Request::UserInput($this->name, $scrub_options);
	}
	
}