<?php
/**
 * An HTML form input element. Programmatically generates form
 * element HTML to produce consistent, functional, and scriptable
 * page elements.
 *  
 * @author Paul
 */
class FormElement_SelectMultiple extends FormElement_Multiple
{
		
	public function __construct($name, $label, $value = '')
	{
		parent::__construct($name, $label, $value);
	}
	
	/**
	 * Render an HTML form submit element
	 * @return string
	 */
	public function getInputElement()
	{
		$n = "\n";
		$t = "\t";
		if (!isset($this->valuelist)) {
			throw new Exception('FormElement::valuelist must be defined before rendering a select element');
		}
		if (is_array($this->value)) {
			$values = $this->value;
		} else {
			$values = array($this->value);
		}
		$formatter = $this->getFormatter();
		$out = '<select multiple="multiple" name="'.$this->name.'[]" '. $this->renderAttributes(array('name')) .'>';
		foreach ($this->valuelist as $value => $display) {
			$out .= $n . $t . $t . $t;
			if (in_array($value, $values)) {
				$out .= '<option value="'. htmlspecialchars($value) .'" selected="selected">'. $formatter($display) .'</option>';
			} else {
				$out .= '<option value="'. htmlspecialchars($value) .'">'. $formatter($display) .'</option>';
			}
		}
		return $out . $n . $t . $t . '</select>';
	}
		
}