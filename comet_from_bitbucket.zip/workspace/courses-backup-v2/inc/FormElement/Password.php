<?php
/**
 * An HTML form input element. Programmatically generates form
 * element HTML to produce consistent, functional, and scriptable
 * page elements.
 *  
 * @author Paul
 */
class FormElement_Password extends FormElement
{
		
	public function __construct($name, $label, $value = '')
	{
		parent::__construct($name, $label, $value);
	}
	
	/**
	 * Render an HTML form submit element
	 * @return string
	 */
	public function getInputElement()
	{
		$formatter = $this->getFormatter();
		$out = '<input type="password" value="'. $formatter($this->value) .'"'. $this->renderAttributes() .' />';
		return $out;
	}
	
}