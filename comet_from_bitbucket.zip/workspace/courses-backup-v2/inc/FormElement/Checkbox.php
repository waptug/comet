<?php
/**
 * An HTML form input element. Programmatically generates form
 * element HTML to produce consistent, functional, and scriptable
 * page elements.
 *  
 * @author Paul Hanisko
 * @package UW_COE_Framework
 * @version 1.0
 */
class FormElement_Checkbox extends FormElement_Multiple
{
		
	public function __construct($name, $label, $value = '')
	{
		parent::__construct($name, $label, $value);
	}
	
	/**
	 * Render a list of HTML form checkbox elements
	 * @return string
	 */
	public function getInputElement()
	{
		$n = "\n";
		$t = "\t";
		if (!isset($this->valuelist)) {
			throw new Exception('FormElement::valuelist must be defined before rendering a checkbox element');
		}
	
		// checkbox implies multiple select so we need current value 
		// in an array
		if (is_array($this->value)) {
			$values = $this->value;
		} else {
			$values = array($this->value);
		}
		
		$formatter = $this->getFormatter();
		
		// prevent putting the same id in multiple places, handling name manually to add []
		$attribs = $this->renderAttributes(array('id', 'name'));
		
		// give id a local shortname (strip out dangerous characters)
		$id = preg_replace('/[^a-zA-Z0-9_]/', '', $this->_attributes['id']);
				
		// if liststart is a simple element with no attributes
		$matches = array();
		if (preg_match('/^<([a-zA-Z]+)>$/', $this->liststart, $matches)) {
			// add the generic element id here
			$out = '<' . $matches[1] .' id="'. $id .'">';
		} else {
			// otherwise trust that the user provided whatever hooks they needed
			$out = $this->liststart;
		}
		foreach ($this->valuelist as $value => $display) {
			$thisid = $id . preg_replace('/[^a-zA-Z0-9]/', '', $value);
			$out .= $n . $t . $t . $t . $this->listitemstart;
			if (strpos($value, '-') === 0) {
				// this is a section label, not a selectable value
				$bits = explode('-', $value);
				$element = (count($bits) == 3) ? $bits[2] : 'p';
				$out .= '<'. $element .'>'. $formatter($display) .'</'. $element .'>'. $this->listitemend;
			} elseif (in_array($value, $values)) {
				$out .= '<input type="checkbox" name= "'. e($this->name) .'[]" value="'. e($value) .'" id="'. $thisid
				     .  '" checked="checked"'. $attribs .' /> <label for="'. $thisid .'">'
				     .  $formatter($display) .'</label>'. $this->listitemend;
			} else {
				$out .= '<input type="checkbox" name= "'. e($this->name) .'[]" value="'. e($value) .'" id="'. $thisid
				     .  '"'. $attribs .' /> <label for="'. $thisid .'">'
				     .  $formatter($display) .'</label>'. $this->listitemend;
			}
		}
		return $out . $n . $t . $t . $this->listend;
	}
	
}