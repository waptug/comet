<?php
/**
 * @package UW_COE_Courses
 */
/**
 * This object monitors a specific Db_Offering object and its related components
 * and runs system processes based on changes detected in the object.
 */
namespace Offering;
 
class Snapshot
{
	protected $snapshot;
	
	public function __construct(\Db_Offering $offering)
	{
		
	}
	
	public function __get($name)
	{
		if (array_key_exists($name, $this->snapshot)) {
			return $this->snapshot[$name];
		} else {
			return null;
		}
	}
	
	public function snapshot(\Db_Offering $offering)
	{
		
	}
	
	public function addMeeting(\Db_Meeting $meeting)
	{
		
	}
	
	public function addStaff(\Db_Staff $staff)
	{
		
	}
	
	public function getMeeting($meetingnumber)
	{
		
	}
	
	public function getStaff($meetingnumber, $personid)
	{
		
	}
	
	public function getJoint($curriculum, $courseno, $section)
	{
		
	}
	
}
