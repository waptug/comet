<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Strategies for locating offerings that match specified parameters
 * @author hanisko
 */
namespace Offering;

class LocateOffering
{
	
	public function __construct()
	{
		
	}
	
	/**
	 * Returs the offeringid of a Db_Offering object that matches the specified
	 * courseid. Prioritizes the current quarter, most recent historical quarter,
	 * then earliest future quarter
	 * @param integer $courseid
	 * @return integer|NULL
	 */
	public function byCourseid($courseid) 
	{
		$db = \DbFactory::GetConnection();
		$cq = \Db_Quarter::FetchCurrentQuarter();
		// search for the most recent offering that has happened
		$sql = 'SELECT offeringid '
		     . 'FROM offering '
		     . 'WHERE courseid = '.$courseid.' '
		     . 'AND (year < '.$db->quote($cq->year).' '
		     . 'OR (year = '.$db->quote($cq->year).' '
		     . 'AND quarter <= '.$cq->quarter.')) '
		     . 'ORDER BY year DESC, quarter DESC, section';
		$found = $db->fetchOne($sql);
		if ($found) return $found;
		// search for the earliest future offering
		$sql = 'SELECT offeringid '
		     . 'FROM offering '
		     . 'WHERE courseid = '.$courseid.' '
		     . 'AND (year > '.$db->quote($cq->year).' '
		     . 'OR (year = '.$db->quote($cq->year).' '
		     . 'AND quarter > '.$cq->quarter.')) '
		     . 'ORDER BY year, quarter, section';
		$found = $db->fetchOne($sql);
		if ($found) return $found;
		return null;
	}
	
}