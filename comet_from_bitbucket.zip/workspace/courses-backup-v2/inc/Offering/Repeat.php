<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Handles the creation and updating of repeat offerings based on repetition rules
 * @author hanisko
 */
namespace Offering;
 
class Repeat
{
	const PLAN_YEARS_OUT = 3; // how far out to create offerings based on repetition rules
	const REPETITION_STATUS = 'expected';
	const EACH_QUARTER = 0;
	const WINTER_ONLY = 1;
	const SPRING_ONLY = 2;
	const SUMMER_ONLY = 3;
	const AUTUMN_ONLY = 4;
	const AUTUMN_WINTER_SPRING = 5;
	
	private static $autumn_winter_spring = array(4,1,2);
	private $count;
	private $course;
	private $mismatch_reason;
	private $offerings;
	private $rule;
	
	public function __construct(\Db_Repetition $rule)
	{
		$this->rule = $rule;
	}

	/**
	 * Loop through the quarters that match this rule and create new offering records in 
	 * appropriate quarters that don't have the number of sections specified.
	 */
	private function addOfferings()
	{
		// Calculate year and quarter it is right now
		$cq = \Db_Quarter::FetchCurrentQuarter();
		$year_stop = $cq->year + self::PLAN_YEARS_OUT;
		for ($year = $this->rule->firstyear; $year <= $year_stop; $year = $year + $this->rule->yearfreq) {
			for ($quarter = 1; $quarter < 5; ++$quarter) {
				// make sure this is a future quarter
				if ($cq->compareYearQuarter($year, $quarter) < 1) continue;
				// make sure this quarter match the rule
				if (!$this->quarterMatchesRule($quarter)) continue;
				$existing = $this->countOfferings($year, $quarter);
				for ($i = $existing; $i < $this->rule->sections; ++$i) {
					$this->createOffering($year, $quarter);
				}
			}
		}
	}
	
	/**
	 * Returns true if business rules allow this offering to be updated by a
	 * repetition rule.
	 * @param \Db_Offering $offering
	 * @return boolean
	 */
	private function canUpdate(\Db_Offering $offering)
	{
		if ($offering->status != self::REPETITION_STATUS) {
			return false;
		}
		$cq = \Db_Quarter::FetchCurrentQuarter();
		if ($cq->compareYearQuarter($offering->year, $offering->quarter) < 0) {
			// can't update historical records
			return false;
		}
		return true;
	}

	/**
	 * Create a new Db_Offering record for this rule in the specified quarter
	 */
	private function createOffering($year, $quarter)
	{
		$new = new \Db_Offering(0);
		$new->courseid = $this->rule->courseid;
		$new->year = $year;
		$new->quarter = $quarter;
		$new->status = self::REPETITION_STATUS;
		$new->uwtsstatus = 0;
		$new->roomstatus = 0;
		$new->sectionstatus = 'P';
		if ($new->quarter == 3) {
			$new->summerterm = 'F';
		}
		$new->funding = 'St';
		$new->institution = 'state';
		$new->gradingsystem = 'standard';
		$new->sectiontype = 'LC';
		$new->repetitionid = $this->rule->repetitionid;
		$new->useAvailableSection(explode(',',$this->rule->sectionpref));
		$new->enrollmentestimate = \Db_Offering::EstimateEnrollment($new->courseid);
		$new->save();
		\Db_ActivityLog_Expected::Write($new->offeringid);
	}

	/**
	 * Count the number of Db_Offering records that already exist for the rule course 
	 * in a specific quarter
	 */
	private function countOfferings($year, $quarter)
	{
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT COUNT(offeringid) '
		     . 'FROM offering '
		     . 'WHERE courseid = '.$this->rule->courseid.' '
		     . 'AND year = '.$db->quote($year).' '
		     . 'AND quarter = '.$quarter;
		return $db->fetchOne($sql);
	}
	
	/**
	 * Delete all offerings created by this rule. If offerings are no longer updatable
	 * they are unlinked from this repetition rule.
	 */
	public function deleteAll()
	{
		$this->lazyload();
		foreach ($this->offerings as $offering) {
			$this->deleteOffering($offering);
		}
	}
	
	/**
	 * Deletes a Db_Offering. If the offering is not in an updatable state the reference
	 * to this repetition rule is removed.
	 * @param \Db_Offering $offering
	 */
	private function deleteOffering(\Db_Offering $offering)
	{
		if ($this->canUpdate($offering)) {
			$offering->delete();
		} else {
			// if this offering is no longer writable, break link to repetition rule
			$offering->repetitionid = null;
			if ($offering->status == self::REPETITION_STATUS) {
				$offering->status = 'planned';
			}
			$offering->save();
		}
	}

	/**
	 * Increments the internal counter of sections per quarter. If this offering 
	 * increments the counter beyond the count specified by the rule, returns trues.
	 * @param \Db_Offering $offering
	 */
	private function exceedsCount(\Db_Offering $offering)
	{
		$key = $offering->year.'-'.$offering->quarter;
		if (!array_key_exists($key, $this->count)) {
			// initialize with count of sections that exist, but are not based on this rule
			$db = \DbFactory::GetConnection();
			$filters = array(
				'year = '.$db->quote($offering->year),
				'quarter = '.$offering->quarter,
				'courseid = '.$offering->courseid,
				'repetitionid <> '.$offering->repetitionid,
			);
			$this->count[$key] = \Db_Offering::FetchCount($filters);
		}
		++$this->count[$key];
		return ($this->count[$key] > $this->rule->sections);
	}
	
	/**
	 * Load the offerings that were created by this rule
	 */
	private function lazyload()
	{
		if (!is_array($this->offerings)) {
			$this->offerings = \Db_Offering::FetchMultiple('repetitionid = '.$this->rule->repetitionid);
		}
	}
	
	/**
	 * Tests if the provide Db_Offering object matches the rule timing parameters 
	 * and returns true if it does. If there is a mismatch returns false and stores
	 * $mismatch_reason
	 * @param \Db_Offering $offering
	 * @return boolean
	 */
	private function matchesTiming(\Db_Offering $offering)
	{
		if ($offering->year < $this->rule->firstyear) {
			$this->mismatch_reason = 'Offering year before start year of rule';
			return false;
		}
		// make sure year matches the frequency
		if ((($offering->year - $this->rule->firstyear) % $this->rule->yearfreq) != 0) {
			$this->mismatch_reason = 'Offering year does not match start year + frequency';
			return false;
		}
		if (!$this->quarterMatchesRule($offering->quarter)) {
			$this->mismatch_reason = 'Offering quarter does not match the rule quarter';
			return false;
		}
		return true;
	}
	
	/**
	 * Check all existing offerings based on this rule and delete any that no longer match
	 * the rule properties.
	 */
	private function purge()
	{
		$this->resetCount();
		$existing = \Db_Offering::FetchMultiple('repetitionid = '.$this->rule->repetitionid);
		foreach ($existing as $offering) {
			if (!$this->matchesTiming($offering)) {
				$this->deleteOffering($offering);
				continue;
			}
			if ($this->exceedsCount($offering)) {
				$this->deleteOffering($offering);
			}
		}
	}
	
	/**
	 * Returns true if the specified quarter matches the rule
	 * @param integer $quarter
	 * @return boolean
	 */
	private function quarterMatchesRule($quarter)
	{
		if ($this->rule->quarter == self::EACH_QUARTER) 
			return true;
		if ($quarter == $this->rule->quarter) 
			return true;
		if ($this->rule->quarter == self::AUTUMN_WINTER_SPRING && in_array($quarter, self::$autumn_winter_spring)) 
			return true;
		return false;
	}

	/**
	 * Reset the counter used by exceedsCount() method
	 */
	private function resetCount()
	{
		$this->count = array();
	}
	
	/**
	 * Runs full reconciliation with the rules and offerings in the system. Deletes
	 * any existing records based on the rule that no longer match the rule properties,
	 * updates offering fields, meetings, and staff.
	 */
	public function update()
	{
		$this->purge();
		$this->addOfferings();
		$this->updateOfferings();
		//$this->updateJoint();
		$this->updateMeetings();
		$this->updateStaff();
	}

	/**
	 * Update the local properties of offerings generated by and editable by 
	 * this repetition rule.
	 */
	private function updateOfferings()
	{
		$this->lazyload();
		foreach ($this->offerings as $offering) {
			if (!$this->canUpdate($offering)) continue;
			$offering->summerterm = $this->rule->summerterm;
			$offering->sectiontype = $this->rule->sectiontype;
			$offering->institution = $this->rule->institution;
			$offering->gradingsystem = $this->rule->gradingsystem;
			$offering->save();
		}
	}

	/**
	 * Update the offering joint section properties generated by and editable 
	 * by this repetition rule.
	 */
	public function updateJoint()
	{
		$this->lazyload();
		foreach ($this->offerings as $offering) {
			if (!$this->canUpdate($offering)) continue;
			
		}
	}

	/**
	 * Update the offering meeting properties generated by and editable 
	 * by this repetition rule.
	 */
	public function updateMeetings()
	{
		$this->lazyload();
		foreach ($this->offerings as $offering) {
			if (!$this->canUpdate($offering)) continue;
			for ($index = 0; $index < 3; ++$index) {
				$meetingnumber = $index + 1;
				$meeting = $offering->meetings->getMeetingByNumber($meetingnumber);
				if (array_key_exists($index, $this->rule->meetings)) {
					if (!$meeting) {
						$meeting = new \Db_Meeting(0);
					}
					$meeting->offeringid = $offering->offeringid;
					$meeting->meetingnumber = $meetingnumber;
					$meeting->daylist = $this->rule->meetings[$index]->daylist;
					$meeting->start = $this->rule->meetings[$index]->start;
					$meeting->end = $this->rule->meetings[$index]->end;
					$meeting->save();
				} else {
					if ($meeting) {
						$meeting->delete();
					}
				}
			}
		}
	}

	/**
	 * Update the offering staff properties generated by and editable 
	 * by this repetition rule.
	 */
	public function updateStaff()
	{
		$this->lazyload();
		foreach ($this->offerings as $offering) {
			if (!$this->canUpdate($offering)) continue;
			$off_stafflist = $offering->meetings->getStaff();
			$off_map = array();
			// loop through existing offering staff
			foreach ($off_stafflist as $off_staff) {
				// if the staff from the offering exists in the repetition, create a reference in the map
				if (array_key_exists($off_staff->repetitionindex, $this->rule->staff)) {
					$off_map[$off_staff->repetitionindex] = $off_staff;
				} else {
					// if they don't exist in repetition list delete the staff record
					$off_staff->delete();
				}
			}
			// loop through the repetition rule staff
			foreach ($this->rule->staff as $index => $rep_staff) {
				if (array_key_exists($index, $off_map)) {
					// if this staff record exists in the offering, update fields in the Db_Staff record
					$off_map[$index]->role = $rep_staff->role;
					$off_map[$index]->personid = $rep_staff->personid;
					$off_map[$index]->buyoutreason = $rep_staff->buyoutreason;
					$off_map[$index]->timesched = $rep_staff->timesched;
					$off_map[$index]->repetitionindex = $index;
					
					$off_map[$index]->save();
				} else {
					// otherwise create the staff record
					$newstaff = new \Db_Staff(0);
					$newstaff->offeringid = $offering->offeringid;
					$newstaff->meetingnumber = 1;
					$newstaff->role = $rep_staff->role;
					$newstaff->personid = $rep_staff->personid;
					$newstaff->buyoutreason = $rep_staff->buyoutreason;
					$newstaff->timesched = $rep_staff->timesched;
					$newstaff->repetitionindex = $index;
					$newstaff->save();
				}
			}
		}
	}
	
}

