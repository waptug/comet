<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Copies values of a Db_Offering object to a second Db_Offering object
 * @author hanisko
 */
namespace Offering;
 
class Copy
{
	protected $properties = array(
		'courseid',
		'year',
		'quarter',
		'section',
		'summerterm',
		'sectiontype',
		'institution',
		'funding',
		'creditcontrol',
		'creditmin',
		'creditmax',
		'enrollmentestimate',
		'enrollmentlimit',
		'gradingsystem',
	);
	protected $exclude;

	public function __construct($exclude = array())
	{
		$this->exclude = $exclude;
	}
	
	public function addExclude($exclude)
	{
		$this->exclude[] = $exclude;
	}
	
	public function copy(\Db_Offering $source, \Db_Offering $target)
	{
		$this->copyOffering($source, $target);
		$this->copyJoint($source, $target);
		$this->copyMeetings($source, $target);
		$this->copyStaff($source, $target);
	}
	
	public function copyOffering(\Db_Offering $source, \Db_Offering $target)
	{
		foreach ($this->properties as $property) {
			if (!in_array($property, $this->exclude)) {
				$target->$property = $source->$property;
			}
		}
	}
	
	public function copyJoint(\Db_Offering $source, \Db_Offering $target)
	{
		if (in_array('joint', $this->exclude)) {
			return;
		}
	}
	
	public function copyMeetings(\Db_Offering $source, \Db_Offering $target)
	{
		if (in_array('meetings', $this->exclude)) {
			return;
		}	
	}
	
	public function copyStaff(\Db_Offering $source, \Db_Offering $target)
	{
		if (in_array('staff', $this->exclude)) {
			return;
		}	
		
	}

}
