<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Stores a staff record for use in an offering Repetition rule
 * @author hanisko
 */
namespace Offering\Repetition;

class Staff implements \Interface_Person
{	
	public $personid;
	public $role;
	public $timesched;
	public $buyoutreason;
	public $repetitionindex;
	
	private $_person;
	
	public function __construct($data = null)
	{
		if ($data instanceof \stdClass) {
			$this->personid = $data->personid;
			$this->role = $data->role;
			$this->timesched = $data->timesched;
			if (property_exists($data, 'buyoutreason'))	$this->buyoutreason = $data->buyoutreason;
			$this->repetitionindex = $data->repetitionindex;
		}
	}
	
	public function __get($name)
	{
		switch($name) {
			case 'person':
				return $this->getPerson();
				break;
			case 'rolename':
				return $this->getRolename();
				break;
			default:
				return null;
				break;
		}
	}
	
	protected function getPerson()
	{
		if (is_null($this->_person)) {
			$this->_person = \Db_Person::Get($this->personid);
		}
		return $this->_person;
	}
	
	/**
	 * Return the contents of the firstname property. Satisfies the
	 * Interface_Person requirement.
	 * @return string
	 */
	public function getFirstname()
	{
		return $this->person->getFirstname();
	}
	
	/**
	 * Return the contents of the lastname property. Satisfies the
	 * Interface_Person requirement.
	 * @return string
	 */
	public function getLastname()
	{
		return $this->person->getLastname();
	}
	
	/**
	 * Return a decoded human readable version of the staff role property
	 * @return string
	 */
	protected function getRoleName()
	{
        $roles = \Db_Staff::getRoles();
        if (array_key_exists($this->role, $roles)) {
			return $roles[$this->role];
		} else {
			return $this->role;
		}
	}
	
	public function getValuesHash()
	{
		return array(
			'personid' => $this->personid,
			'role' => $this->role,
			'timesched' => $this->timesched,
			'buyoutreason' => $this->buyoutreason,
			'repetitionindex' => $this->repetitionindex
		);
	}
	
}
