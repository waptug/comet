<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Stores a meeting record for use in an offering Repetition rule
 * @author hanisko
 */
namespace Offering\Repetition;

class Meeting
{
	public $start;
	public $end;
	public $daylist;
	
	public function __construct($data = null)
	{
		if ($data instanceof \stdClass) {
			$this->start = $data->start;
			$this->end = $data->end;
			$this->daylist = $data->daylist;
		} else {
			$this->daylist = array();
		}
	}
	
	/**
	 * Returns the brief string used in the UW Time Schedule to describe the days
	 * and time of this meeting
	 * @return string
	 */
	public function getUwtsSummary()
	{
		if (!$this->start || !$this->end) {
			return null;
		}
		$start = new \Time($this->start);
		$end = new \Time($this->end);
		$daysummary = '';
		foreach ($this->daylist as $d) {
			switch ($d) {
				case 0: $daysummary .= 'Su'; break;
				case 1: $daysummary .= 'M'; break;
				case 2: $daysummary .= 'T'; break;
				case 3: $daysummary .= 'W'; break;
				case 4: $daysummary .= 'Th'; break;
				case 5: $daysummary .= 'F'; break;
				case 6: $daysummary .= 'S'; break;
				default: break;
			}
		}
		return $daysummary.' '.$start->getUwtsBrief().'-'.$end->getUwtsBrief(true);
	}
	
	public function getValuesHash()
	{
		return array(
			'start' => $this->start,
			'end' => $this->end,
			'daylist' => $this->daylist
		);
	}
	
}