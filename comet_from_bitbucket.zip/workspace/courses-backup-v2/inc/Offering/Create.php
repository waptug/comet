<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Stores the parameters for a new offering until all the required input
 * is collected
 * @author hanisko
 * 
 * @TODO - this should be two classes, the input collector and the new offering
 * builder. It should accept a UWTS offering as a template. UWTS offering and
 * plan offering should be sibling classes. The class should properly detect
 * (or accept) creation situation and make log entries. Heartbreaking example of
 * choosing between doing things elegantly and getting things done.
 */
namespace Offering;
 
class Create
{
	const SESSION_INDEX = 'crs_create_offering';
	public $clone;
	public $cloneid;
	public $courseid;
	public $course;
	public $quarter;
	public $section;
	public $year;
	public $useClone = true;
	
	public function __construct()
	{
		$this->load();
		$this->getUserInput();
		$this->store();
	}

	/**
	 * Clear create offering parameters from the session
	 */
	public function clear()
	{
		unset($this->course);
		unset($this->courseid);
		unset($this->clone);
		unset($this->cloneid);
		unset($this->year);
		unset($this->quarter);
		if (array_key_exists(self::SESSION_INDEX, $_SESSION)) {
			unset($_SESSION[self::SESSION_INDEX]);
		}
	}
	
	/**
	 * Creates and stores a new Db_Offering record based on valid 
	 * settings and returns the new Db_Offering.
	 * @throws Exception
	 * @return Db_Offering
	 */
	public function create()
	{
		if (!$this->validCourse()) {
			throw new \Exception('No valid course set');
		}
		if (!$this->validClone()) {
			throw new \Exception('No valid template offering set');
		}
		if (!$this->validQuarter()) {
			throw new \Exception('No valid quarter set');
		}
		// 1. Create new record and set basic fields
		$new = new \Db_Offering(0);
		$new->year = $this->year;
		$new->quarter = $this->quarter;
		$new->gradingsystem = 'standard';
		$new->status = 'planned';
		$new->uwtsstatus = 0;
		$new->roomstatus = 0;
		$new->sectionstatus = 'P';
		if ($this->useClone) {
			// 2A. Copy fields from template
			$new->courseid = $this->clone->courseid;
			$new->useAvailableSection(array($this->clone->section));
			$new->summerterm = $this->clone->summerterm;
			$new->funding = ($this->clone->funding) ? $this->clone->funding : 'St';
			$new->institution = ($this->clone->institution) ? $this->clone->institution : 'state';
			$new->gradingsystem = ($this->clone->gradingsystem) ? $this->clone->gradingsystem : 'standard';
			$new->sectiontype = ($this->clone->sectiontype) ? $this->clone->sectiontype : 'LC';
			$new->sectiontype = ($this->clone->sectiontype) ? $this->clone->sectiontype : 'LC';
			$new->sectiontype = ($this->clone->sectiontype) ? $this->clone->sectiontype : 'LC';
			$new->sectiontype = ($this->clone->sectiontype) ? $this->clone->sectiontype : 'LC';
			$new->creditcontrol = $this->clone->creditcontrol;
			$new->creditmin = $this->clone->creditmin;
			$new->creditmax = $this->clone->creditmax;
			if ($this->clone->enrollmentlimit) {
				$new->enrollmentlimit = $this->clone->enrollmentlimit;
			} else {
				if ($this->clone->enrollmentcurrent) {
					$new->enrollmentestimate = $this->clone->enrollmentcurrent;
				} else {
					$new->enrollmentestimate = $this->clone->enrollmentestimate;
				}
			}
		} else {
			// 2B. Set course and default values
			$new->courseid = $this->courseid;
			$new->useAvailableSection(array('A'));
			if ($new->quarter == 3) {
				$new->summerterm = 'F';
			}
			$new->funding = 'St';
			$new->institution = 'state';
			$new->gradingsystem = 'standard';
			$new->sectiontype = 'LC';
			$new->creditcontrol = $new->course->coursecreditcontrol;
			$new->creditmin = $new->course->coursecreditmin;
			$new->creditmax = $new->course->coursecreditmax;
			$new->setEnrollmentEstimate(\Db_Offering::EstimateEnrollment($this->courseid));
		}
		// 3. make sure we have a non-colliding section
		// ** this logic was moved to offering object
		// 4. store the new offering record and generate 
		$new->save();

		if ($this->useClone) {
			// 5. add meetings
			foreach ($this->clone->meetings as $clone_m) {
				$new_m = $new->getMeetingByNumber($clone_m->meetingnumber);
				if (!$new_m) {
					$new_m = new \Db_Meeting(0);
					$new_m->offeringid = $new->offeringid;
					$new_m->meetingnumber = $clone_m->meetingnumber;
				}
				$new_m->setDays($clone_m->dows);
				$new_m->start = $clone_m->start;
				$new_m->end = $clone_m->end;
				$new_m->save();
			}
			// 6. add staff
			foreach ($this->clone->staff as $clone_s) {
				$new_s = $new->getStaffByRegid($clone_s->meetingnumber, $clone_s->regid);
				if (!$new_s) {
					$new_s = new \Db_Staff(0);
					$new_s->offeringid = $new->offeringid;
					$new_s->meetingnumber = $clone_s->meetingnumber;
					$new_s->personid = $clone_s->personid;
				}
				$new_s->role = $clone_s->role;
				$new_s->timesched = $clone_s->timesched;
				$new_s->buyoutreason = $clone_s->buyoutreason;
				$new_s->save();
			}
			$new->meetingsummary = $new->getMeetingSummary(true);
			$new->save();
		}
		$this->clear();
		return $new;
	}
	
	/**
	 * Return the Db_Offering record to be used to populate the new offering's
	 * fields 
	 * @return Db_Offering|null
	 */
	public function getCloneSource()
	{	
		if ($this->useClone && $this->validClone()) {
			return $this->clone;
		} else {
			return null;
		}
	}

	/**
	 * Return the Db_Course record to be used to populate the new offering's
	 * fields
	 * @return Db_Course|null
	 */
	public function getCourse()
	{
		if ($this->validCourse()) {
			return $this->course;
		} else {
			return null;
		}
	}
	
	/** 
	 * Returns a Db_Quarter object representing the quarter the new course
	 * will be created in.
	 * @return Db_Quarter|null
	 */
	public function getQuarter()
	{
		if ($this->validQuarter()) {
			return new \Db_Quarter($this->year, $this->quarter, false);
		} else {
			return null;
		}
	}
	
	/**
	 * Search user input for create offering parameters
	 */
	public function getUserInput()
	{
		$request = \Request::GetInstance();
		if ($request->getUserInput('cancel', 'Integer') == 1) {
			$this->clear();
		}
		if ($request->getUserInput('noclone', 'Integer') == 1) {
			$this->useClone = false;
		}
		$this->courseid = $request->getUserInput('c', 'Integer', $this->courseid);
		$this->cloneid = $request->getUserInput('clone', 'Integer', $this->cloneid);
		$this->year = $request->getUserInput('y', 'Integer', $this->year);
		$this->quarter = $request->getUserInput('q', 'Integer', $this->quarter);
	}

	/**
	 * Search session for create offering parameters
	 */
	public function load()
	{
		if (array_key_exists(self::SESSION_INDEX, $_SESSION)) {
			$data = json_decode($_SESSION[self::SESSION_INDEX]);
			$this->courseid = $data->courseid;
			$this->cloneid  = $data->cloneid;
			$this->year     = $data->year;
			$this->quarter  = $data->quarter;
		}
	}
	
	protected function loadSourceObjects()
	{
		if ($this->useClone) {
			if (!$this->clone || $this->clone->offeringid != $this->cloneid) {
				$this->clone = new \Db_Offering($this->cloneid);
			}
			if ($this->clone->recordExists()) {
				$this->course = $this->clone->course;
			} else {
				$this->clone = null;
			}
		} else {
			$this->clone = null;
		}
		if ($this->courseid) {
			if (!$this->course || $this->course->courseid != $this->courseid) {
				$this->course = new \Db_Course($this->courseid);
			}
			if (!$this->course->recordExists()) {
				$this->course = null;
			}
		}
	}
	
	/**
	 * Specify a Db_Offering object to use as the clone template when creating 
	 * a new Db_Offering record.
	 * @param \Db_Offering $offering
	 */
	public function setClone(\Db_Offering $offering)
	{
		$this->clone = $offering;
		$this->cloneid = $offering->offeringid;
	}

	/**
	 * Store create offering parameters in the session
	 */
	public function store()
	{
		$data = array(
			'courseid' => $this->courseid,
			'cloneid'  => $this->cloneid,
			'year'     => $this->year,
			'quarter'  => $this->quarter
		);
		$_SESSION[self::SESSION_INDEX] = json_encode($data);
	}

	/**
	 * Returns true if cloning an existing offering and that source Db_Offering
	 * exists or if not using a clone and the relevant Db_Course record 
	 * exists
	 * @return boolean
	 */
	public function validCourse()
	{
		$this->loadSourceObjects();
		if ($this->course instanceof \Db_Course) {
			return $this->course->recordExists();
		} else {
			return false;
		}
	}

	/**
	 * Returns true if a valid year and quarter are provided and that year/quarter
	 * represent the current or a future quarter.
	 * @return boolean
	 */
	public function validQuarter()
	{
		if (!$this->year || !$this->quarter) {
			return false;
		}
		$now = \Db_Quarter::FetchCurrentQuarter();
		return ($now->compareYearQuarter($this->year, $this->quarter) >= 0);
	}
	
	/**
	 * Returns true if cloning an existing offering and that source Db_Offering
	 * exists or if not using a clone and the relevant Db_Course record 
	 * exists
	 * @return boolean
	 */
	public function validClone()
	{
		$this->loadSourceObjects();
		if ($this->useClone) {
			if ($this->clone instanceof \Db_Offering) {
				return $this->clone->recordExists();
			} else {
				return false;
			}
		} else {
			return $this->validCourse();	
		}
	}
	
}