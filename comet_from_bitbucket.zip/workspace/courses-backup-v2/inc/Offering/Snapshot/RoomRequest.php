<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Snapshot of monitored fields in an offering record. Snapshots store a 
 * brief point in time version of the data, useful for identifying and 
 * logging changes.
 * @author hanisko
 */
namespace Offering\Snapshot;
 
class RoomRequest
{
	private static $_fields = array(
		'roompref1' => array(
				'display'     => 'roompref1',
				'description' => 'Building pref 1'),
		'roompref2' => array(
				'display'     => 'roompref2',
				'description' => 'Building pref 2'),
		'roompref3' => array(
				'display'     => 'roompref3',
				'description' => 'Building pref 3')
	);
	
	private $_offeringid;
	private $_roomneed;
	private $_comments;
	
	public function __construct($offeringid)
	{
		$this->_offeringid = (int)$offeringid;
		$this->takeSnapshot();
	}
	
	/**
	 * Load staff information for a specific offering into a searchable
	 * data structure. Snapshot structure for staff takes the form
	 */
	public function takeSnapshot()
	{
		$db = \DbFactory::GetConnection();
		$this->_roomneed = new \Db_RoomNeed($this->_offeringid);
		$this->_comments = $db->fetchPairs('SELECT roomcommentid, comment FROM roomcomment WHERE offeringid = '.$this->_offeringid);
	}
	
	/**
	 * Returns the snapshot value for a specified offering field
	 * @return string
	 */
	public function getValue($field)
	{
		return $this->_roomneed->$field;
	}
	
	/**
	 * Compares the comments from one snapshot to this snapshots comments. Returns a
	 * stdClass summarizing any changes with the following properties.
	 *  $out->changed = number of comments where text is different after
	 *  $out->added = additional comments that exist in argument version
	 *  $out->removed = fewer comments exist in argument version
	 * @param array $after_comments hash with roomcommentid index and comment text as value
	 * @return stdClass
	 */
	public function getCommentDifference($after_comments)
	{
		$difference = new \stdClass();
		$difference->changed = 0;
		foreach ($this->_comments as $id => $this_comment) {
			if (array_key_exists($id, $after_comments)) {
				if ($this_comment != $after_comments[$id]) {
					// comment exists before and after with different text
					$difference->changed += 1;
					break;
				}
			}
		}
		$difference->added = count($after_comments) - count($this->_comments);
		$difference->removed = 0;
		if ($difference->added < 0) {
			$difference->removed = -$difference->added;
			$difference->added = 0;
		}
		return $difference;
	}

	/**
	 * Compares the comments from one snapshot to this snapshots comments. Returns a
	 * stdClass summarizing any changes with the following properties.
	 *  $out->added = list of feature codes that exist only in argument version
	 *  $out->removed = list of feature codes that exist only in instance version
	 * @param array $after_features array list of feature codes
	 * @return stdClass
	 */
	public function getFeatureDifference($after_features)
	{
		$difference = new \stdClass();
		$difference->added = array();
		foreach ($after_features as $feature) {
			if (!in_array($feature, $this->_roomneed->roomfeatures)) {
				$difference->added[] = $feature;
			}
		}
		$difference->removed = array();
		foreach ($this->_roomneed->roomfeatures as $feature) {
			if (!in_array($feature, $after_features)) {
				$difference->removed[] = $feature;
			}
		}
		return $difference;
	}
	
	/**
	 * Compares $this Snapshot object to a previous $before Snapshot object and
	 * writes log entries documenting the changes between the two. Returns true
	 * if changes were detected.
	 * @param RoomRequest $before
	 * @return boolean
	 */
	public function logChanges(RoomRequest $before)
	{
		$changes = array();
		foreach (self::$_fields as $field => $info) {
			if ($before->getValue($field) != $this->_roomneed->$field) {
				$displayvalue = $info['display'];
				$changes[] = 'set '.$info['description'].' to '.$this->_roomneed->$displayvalue;
			}
		}
		$feature_diff = $before->getFeatureDifference($this->_roomneed->roomfeatures);
		if ($feature_diff->added) {
			$changes[] = 'added '.implode(', ',$feature_diff->added).' to features';
		}
		if ($feature_diff->removed) {
			$changes[] = 'removed '.implode(', ',$feature_diff->removed).' from features';
		}
		$comment_diff = $before->getCommentDifference($this->_comments);
		if ($comment_diff->changed) {
			$changes[] = 'changed a comment about room needs';
		} 
		if ($comment_diff->added) {
			$changes[] = 'added comment about room needs';
		} 
		if ($comment_diff->removed) {
			$changes[] = 'removed a comment about room needs';
		}
		if (count($changes)) {
			\Db_ActivityLog_Roomrequest::Write($this->_offeringid, implode(', ', $changes));
			$offering = new \Db_Offering($this->_offeringid);
			$offering->roomstatus = 11; //'Instructor updated room request'
			$offering->save();
		}
	}
	
}