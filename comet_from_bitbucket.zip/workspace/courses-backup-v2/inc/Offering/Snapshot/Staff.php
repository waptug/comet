<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Snapshot of staff records for a specific offering. Snapshots store a brief 
 * point in time version of the data, useful for identifying and logging
 * changes.
 * @author hanisko
 */
namespace Offering\Snapshot;
 
class Staff
{
	private $_offeringid;
	private $_uwts;
	
	public $staff;
	
	public function __construct($offeringid)
	{
		$this->_offeringid = (int)$offeringid;
		$this->takeSnapshot();
	}
	
	/**
	 * Load staff information for a specific offering into a searchable
	 * data structure. Snapshot structure for staff takes the form
	 */
	public function takeSnapshot()
	{
		$this->staff = array();
		$this->_uwts = array();
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT personid, meetingnumber, timesched '
		     . 'FROM staff '
		     . 'WHERE offeringid = '.$this->_offeringid;
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			if (!array_key_exists($row['meetingnumber'], $this->staff)) {
				$this->staff[$row['meetingnumber']] = array();
			}
			$this->staff[$row['meetingnumber']][] = $row['personid'];
			if ($row['timesched']) {
				$this->_uwts[$row['meetingnumber']] = $row['personid'];
			}
		}
	}
	
	/**
	 * Returns the personid of the staff listed as the primary instructor for
	 * the specified meeting.
	 * @param integer $meetingnumber
	 * @return integer
	 */
	public function getUwts($meetingnumber)
	{
		if (array_key_exists($meetingnumber, $this->_uwts)) {
			return $this->_uwts[$meetingnumber];
		} else {
			return null;
		}
	}
	
	/**
	 * Returns true if the specified personid is on the staff list for the specified
	 * meeting number.
	 * @param integer $meetingnumber
	 * @param integer $personid
	 * @return boolean
	 */
	public function hasStaff($meetingnumber, $personid)
	{
		if (array_key_exists($meetingnumber, $this->staff)) {
			if (in_array($personid, $this->staff[$meetingnumber])) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Compares $this Snapshot object to a previous $before Snapshot object and
	 * writes log entries documenting the changes between the two. Returns true
	 * if changes were detected.
	 * @param \Offering\Snapshot\Staff $before
	 * @return boolean
	 */
	public function logChanges(\Offering\Snapshot\Staff $before)
	{
		$has_changes = false;
		foreach ($before->staff as $meetingnumber => $stafflist) {
			foreach ($stafflist as $personid) {
				if (!$this->hasStaff($meetingnumber, $personid)) {
					// Staff removed
					\Db_ActivityLog_Staff::Write($this->_offeringid, 'remove', $personid, $meetingnumber);
					$has_changes = true;
				}
			}
		}
		foreach ($this->staff as $meetingnumber => $stafflist) {
			foreach ($stafflist as $personid) {
				if (!$before->hasStaff($meetingnumber, $personid)) {
					// Staff added
					\Db_ActivityLog_Staff::Write($this->_offeringid, 'add', $personid, $meetingnumber);
					$has_changes = true;
				}
			}
			if ($this->_uwts[$meetingnumber] && ($this->_uwts[$meetingnumber] != $before->getUwts($meetingnumber))) {
				// primary instructor changed
				\Db_ActivityLog_Staff::Write($this->_offeringid, 'uwts', $this->_uwts[$meetingnumber], $meetingnumber);
				$has_changes = true;
			}
		}
		return $has_changes;
	}
	
}