<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Stores the collection of meetings and staff related to a specific 
 * Db_Offering record. Keeps mappings of objects by meeting number,
 * personid and regid so specific objects can be addressed.
 * @author hanisko
 */
namespace Offering\Components;
 
class Meetings implements \Iterator , \Countable 
{
	private $instructor;
	private $indices;
	private $offering;
	private $map_by_personid;
	private $map_by_regid;
	private $meetings;
	private $position = 0;
	private $staff;
	
	public function __construct(\Db_Offering $offering)
	{
		$this->offering = $offering;
	}
	
	public function addMeeting(\Db_Meeting $meeting)
	{
		$this->lazyload();
		$this->meetings[$meeting->meetingnumber] = $meeting;
	}
	
	public function addStaff(\Db_Staff $staff)
	{
		$this->lazyload();
		$this->staff[$staff->staffid] = $staff;
		// map to specific staff records by meeting,regid
		if ($staff->regid) {
			if (!array_key_exists($staff->meetingnumber, $this->map_by_regid)) {
				$this->map_by_regid[$staff->meetingnumber] = array();
			}
			$this->map_by_regid[$staff->meetingnumber][$staff->regid] = $staff;
		}
		// to specific staff records by meeting,personid
		if (!array_key_exists($staff->meetingnumber, $this->map_by_personid)) {
			$this->map_by_personid[$staff->meetingnumber] = array();
		}
		$this->map_by_personid[$staff->meetingnumber][$staff->personid] = $staff;
		// register staff objects with their meetings
		if (array_key_exists($staff->meetingnumber, $this->meetings)) {
			$this->meetings[$staff->meetingnumber]->addStaff($staff);
		}
		// identify a primary instructor
		if ($staff->timesched && $staff->meetingnumber == 1) {
			$this->instructor = $staff;
		}
	}
	
	public function getInstructor()
	{
		$this->lazyload();
		return $this->instructor;
	}
	
	public function getMeetings()
	{
		$this->lazyload();
		return $this->meetings;
	}
	
	public function getMeetingByNumber($meetingnumber)
	{
		$this->lazyload();
		if (array_key_exists($meetingnumber, $this->meetings)) {
			return $this->meetings[$meetingnumber];
		}
		return null;
	}
	
	public function getMeetingSummary($reload_meetings = false)
	{
		if ($reload_meetings) {
			$this->load();
		}
		$out = array();
		foreach ($this->meetings as $meeting) {
			$summary = $meeting->getUwtsSummary();
			if ($summary) $out[] = $summary;
		}
		if ($out) {
			return implode(', ',$out);
		} else {
			return null;
		}
	}
	
	public function getStaff()
	{
		$this->lazyload();
		return $this->staff;
	}
	
	public function getStaffByMeeting($meetingnumber)
	{
		$this->lazyload();
		if (array_key_exists($meetingnumber, $this->map_by_personid)) {
			$this->map_by_personid[$meetingnumber];
		} else {
			return array();
		}
	}
	
	public function hasStaff(\Db_Person $person)
	{
		// $this->meetings[$meeting->meetingnumber] = $meeting;
		// $this->map_by_regid[$staff->meetingnumber][$staff->regid] = $staff;
		$this->lazyload();
		foreach ($this->meetings as $meetingnumber => $m) {
			if (isset($this->map_by_regid[$meetingnumber][$person->regid])) {
				return true;
			}
		}
		return false;
	}
	
	private function lazyload()
	{
		if (!is_array($this->meetings)) {
			$this->load();
		}
	}
	
	public function load()
	{
		$this->instructor = null;
		$this->map_by_personid = array();
		$this->map_by_regid = array();
		$this->meetings = array();
		$this->staff = array();
		// load meetings
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT * '
		     . 'FROM meeting '
		     . 'WHERE offeringid = '.$this->offering->offeringid.' '
		     . 'ORDER BY meetingnumber, dows, start, end';
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			$meeting = new \Db_Meeting($row['meetingid'], false);
			$meeting->init($row);
			$this->addMeeting($meeting);
		}
		// load staff
		$sql = 'SELECT s.*, p.* '
		     . 'FROM staff s '
		     . 'INNER JOIN person p '
		     . 'ON s.personid = p.personid '
		     . 'WHERE offeringid = '.$this->offering->offeringid.' '
		     . 'ORDER BY s.meetingnumber, s.timesched DESC, p.lastname, p.firstname';
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			$staff = \Db_Staff::Register($row);
			$staff->setPerson(\Db_Person::Register($row));
			$this->addStaff($staff);
		}
	}
	
	public function locateStaff($meetingnumber, $personid)
	{
		$this->lazyload();
		if (array_key_exists($meetingnumber, $this->map_by_personid)) {
			if (array_key_exists($personid, $this->map_by_personid[$meetingnumber])) {
				return $this->map_by_personid[$meetingnumber][$personid];
			}
		}
		return null;
	}
	
	public function locateStaffByRegid($meetingnumber, $regid)
	{
		$this->lazyload();
		if (array_key_exists($meetingnumber, $this->map_by_regid)) {
			if (array_key_exists($regid, $this->map_by_regid[$meetingnumber])) {
				return $this->map_by_regid[$meetingnumber][$regid];
			}
		}
		return null;
	}
	
	/**
	 * Returns true if there are no meeting records with days planned for this
	 * offering.
	 * @return boolean
	 */
	public function meetingsToBeArranged()
	{
		$this->lazyload();
		// some array gymnastics because this array is indexed by meeting number
		$keys = array_keys($this->meetings);
		if (count($keys) == 0 || (count($keys) == 1 && $this->meetings[$keys[0]]->dows == '')) {
			return true;
		} else {
			return false;
		}
	}
	
	public function removeMeeting(\Db_Meeting $meeting)
	{
		if (!is_array($this->meetings)) return;
		if (array_key_exists($meeting->meetingnumber, $this->meetings)) {
			unset($this->meetings[$meeting->meetingnumber]);
		}
	}
	
	public function removeStaff(\Db_Staff $staff)
	{
		if (!is_array($this->meetings)) return;
		// remove from staff list
		if (array_key_exists($staff->staffid, $this->staff)) {
			unset($this->staff[$staff->staffid]);
		}
		// remove from meeting,regid map
		if ($staff->regid) {
			if (array_key_exists($staff->meetingnumber, $this->map_by_regid)) {
				if (array_key_exists($staff->regid, $this->map_by_regid[$staff->meetingnumber])) {
					unset($this->map_by_regid[$staff->meetingnumber][$staff->regid]);
				}
			}
		}
		// remove from meeting,personid map
		if (array_key_exists($staff->meetingnumber, $this->map_by_personid)) {
			if (array_key_exists($staff->personid, $this->map_by_personid[$staff->meetingnumber])) {
				unset($this->map_by_personid[$staff->meetingnumber][$staff->personid]);
			}
		}
		// register staff objects with their meetings
		// @TODO, still have a reference to this staff record in the Db_Meeting::$staff array
		
		// identify a primary instructor
		if ($this->instructor && $this->instructor->staffid == $staff->staffid) {
			$this->instructor = null;
		}
	}
	
	/**
	 * Iterator::current � Return the current element
	 * @return Db_Quarter
	 */
	function current()
	{
		return $this->meetings[$this->indices[$this->position]];
	}

	/**
	 * Iterator::key � Return the key of the current element
	 * @return scalar
	 */
	function key()
	{
		return $this->position;
	}

	/**
	 * Iterator::next � Move forward to next element
	 * @return void
	 */
	function next()
	{
		++$this->position;
	}

	/**
	 * Iterator::rewind � Rewind the Iterator to the first element
	 * @return void
	 */
	function rewind()
	{
		$this->lazyload();
		$this->indices = array_keys($this->meetings);
		$this->position = 0;
	}

	/**
	 * Iterator::valid � Checks if current position is valid
	 * @return boolean
	 */
	function valid()
	{
		return ($this->position < count($this->meetings));
	}

	/**
	 * Countable::count � returns number of entities in iterable list
	 * @return boolean
	 */
	public function count()
	{
		$this->lazyload();
		return count($this->meetings);
	}
	
}