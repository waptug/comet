<?php
/**
 * @package UW_COE_Courses
 */
/**
 * This object encapsulate a list of change requests associated with a specific
 * Db_Offering object.
 * @author hanisko
 */
namespace Offering\Components;
 
class ChangeRequests implements \Iterator, \Countable 
{
	private $offering;
	private $requests;
	private $position;
	private $indices;
	
	public function __construct(\Db_Offering $offering)
	{
		$this->offering = $offering;
	}
	
	private function lazyload()
	{
		if (!is_array($this->requests)) $this->load();	
	}
	
	public function load()
	{
		$this->requests = array();
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT * FROM changes WHERE parent_changeid IS NULL AND offeringid = '.$this->offering->offeringid.' ORDER BY entered_date DESC';
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			$this->requests[$row['changeid']] = \Db_ChangeRequest::Register($row);
		}	
		$sql = 'SELECT * FROM changes WHERE parent_changeid IS NOT NULL AND offeringid = '.$this->offering->offeringid.' ORDER BY entered_date';
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			$message = \Db_ChangeMessage::Register($row);
			if (array_key_exists($message->parent_changeid, $this->requests)) {
				$this->requests[$message->parent_changeid]->addMessage($message);
			} else {
				debug(__METHOD__.' orphaned ChangeMessage changeid:'.$message->changeid);
			}
		}	
		$this->indices = array_keys($this->requests);
	}

	/**
	 * Iterator::current � Return the current element
	 * @return Db_ChangeRequest
	 */
	function current()
	{
		return $this->requests[$this->indices[$this->position]];
	}
	
	/**
	 * Iterator::key � Return the key of the current element
	 * @return scalar
	 */
	function key()
	{
		return $this->position;
	}
	
	/**
	 * Iterator::next � Move forward to next element
	 * @return void
	 */
	function next()
	{
		++$this->position;
	}
	
	/**
	 * Iterator::rewind � Rewind the Iterator to the first element
	 * @return void
	 */
	function rewind()
	{
		$this->lazyload();
		$this->position = 0;
	}
	
	/**
	 * Iterator::valid � Checks if current position is valid
	 * @return boolean
	 */
	function valid()
	{
		return ($this->position < count($this->indices));
	}
	
	/**
	 * Countable::count � returns number of entities in iterable list
	 * @return boolean
	 */
	public function count()
	{
		$this->lazyload();
		return count($this->requests);
	}
	
} 