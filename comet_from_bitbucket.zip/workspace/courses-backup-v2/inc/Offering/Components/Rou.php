<?php
/**
 * @package UW_COE_Courses
 */
/**
 * This object encapsulate a list of change requests associated with a specific
 * Db_Offering object.
 * @author hanisko
 */
namespace Offering\Components;

class Rou
{
	private $offering;
	private $rou;

	public function __construct(\Db_Offering $offering)
	{
		$this->offering = $offering;
	}

	private function lazyload()
	{
		if (is_null($this->rou)) $this->load();
	}
	
	private function load()
	{
		$this->rou = \Db_Rou::Get($this->offering->course->rouid); 
	}
	
	public function getSubject()
	{
		$this->lazyload();
		return $this->rou;
	}
	
}