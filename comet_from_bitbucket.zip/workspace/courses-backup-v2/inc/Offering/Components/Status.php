<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Manages changes in Db_Offering status field. Changes in offering status
 * field have unique business logic, require customized logging, and may 
 * trigger other flags and notifications.
 * @author hanisko
 */
namespace Offering\Components;
 
class Status
{
	private static $_valid_statuses = array(
		'historical',
		'planned',
		'canceled',
		'expected',
		'hold'
	);
	
	private $_offering;
	
	public function __construct(\Db_Offering $offering)
	{
		$this->_offering = $offering;	
	}
	
	/**
	 * Set the status property on Db_Offering record and update appropriate
	 * logs and flags. This method supports user input that changes an offering's
	 * status.
	 * @param string $status
	 * @throws Exception
	 */
	public function setStatus($status)
	{
		if (!in_array($status, self::$_valid_statuses)) {
			throw new \Exception('Cannot set offering to unexpected status '.$status);
		}
		if ($status == $this->_offering->status) {
			return;
		}
		if ($status == 'canceled') {
			$this->_offering->status = 'canceled';
			if ($this->_offering->getTimeframe() >= 0) { // current quarter or future
				$this->_offering->roomstatus = 14; // 'Offering canceled',
			}
			$this->_offering->save();
			\Db_ActivityLog_Cancel::Write($this->_offering->offeringid, \Db_ActivityLog_Cancel::ACTION_CANCEL_USER);
		} else {
			if ($this->_offering->status == 'canceled') {
				$this->_offering->status = $status;
				if ($this->_offering->getTimeframe() >= 0) { // current quarter or future
					$this->_offering->roomstatus = 15; // 'Offering reinstated'
				}
				$this->_offering->save();
				\Db_ActivityLog_Cancel::Write($this->_offering->offeringid, \Db_ActivityLog_Cancel::ACTION_UNCANCEL_USER);
			} else {
				// we are setting status to something other than canceled
				// and it was not previously canceled 
				$this->_offering->status = $status;
				$this->_offering->save();
				\Db_ActivityLog_Status::Write($this->_offering->offeringid, $status);
			}
		}
	}
	
	/**
	 * Set offering status to canceled because no matching UWTS record 
	 * exists. This is called during automated updates of UWTS cache data
	 * and should only be applied to historical data.
	 */
	public function cancelByUwts()
	{
		if ($this->_offering->status != 'canceled') {
			$this->_offering->status = 'canceled';
			$this->_offering->save();
			\Db_ActivityLog_Cancel::Write($this->_offering->offeringid, \Db_ActivityLog_Cancel::ACTION_CANCEL_UWTS);
		}
	}

	/**
	 * Change offering status from canceled because matching UWTS record 
	 * exists. This is called during automated updates of UWTS cache data
	 * and should only be applied to historical data.
	 */
	public function unCancelByUwts()
	{
		if ($this->_offering->status == 'canceled') {
			$this->_offering->status = 'planned';
			$this->_offering->save();
			\Db_ActivityLog_Cancel::Write($this->_offering->offeringid, \Db_ActivityLog_Cancel::ACTION_UNCANCEL_UWTS);
		}
	}
	
}