<?php
/**
 * @package UW_COE_Courses
 */
/**
 * This factory instantiates components related to a course offering object
 * @author hanisko
 */
namespace Offering\Components;

class ComponentManager
{
	protected $config = array(
		'rou'            => 'Rou',
		/*
		'changemanager'  => 'ChangeManager',
		'changerequest'  => 'ChangeRequests',
		'jointofferings' => 'JointOfferings',
		'meetings'       => 'Meetings',
		'status'         => 'Status',
		*/
	);
	
	protected $instances;
	protected $offering;
	
	public function __construct(\Db_Offering $offering)
	{
		$this->offering = $offering;
	}
	
	public function has($name)
	{
		return array_key_exists($name, $this->config);
	}
	
	public function get($name)
	{
		if (!$this->has($name)) {
			return null;
		}
		if (!is_array($this->instances)) {
			$this->instances = array();
		}
		if (!array_key_exists($name, $this->instances)) {
			$classname = __NAMESPACE__.'\\'.$this->config[$name];
			$this->instances[$name] = new $classname($this->offering);
		}
		if (method_exists($this->instances[$name], 'getSubject')) {
			return $this->instances[$name]->getSubject();
		} else {
			return $this->instances[$name];
		}
	}
	
}