<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Provides a list of Joint offerings. Joint offerings can be of the type
 * Db_Offering (for local college course offerings) or Db_Joint External
 * for Joint sections in other units on campus.
 * @author hanisko
 */
namespace Offering\Components;
 
class JointOfferings implements \Iterator , \Countable 
{
	private $joints;
	private $offering;
	private $position = 0;
	
	public function __construct(\Db_Offering $offering)
	{
		$this->offering = $offering;
	}
	
	/**
	 * Record a new joint offering in the database. Takes arguments of type Db_Offering for 
	 * local records or Db_JointExternal for offerings outside the unit.
	 * @param mixed $joint
	 */
	public function addJoint($joint)
	{
		// Don't re-add the same record
		if ($this->isJoint($joint)) {
			return;
		}
		$db = \DbFactory::GetConnection();
		
		// Check if the reference offering is part of a group and if the added joint is part of a group 
		$groupid = $db->fetchOne('SELECT jointgroupid FROM jointgroup WHERE offeringid ='.$this->offering->offeringid);
		if ($joint instanceof \Db_JointExternal) {
			$merge_groupid = $db->fetchOne('SELECT jointgroupid FROM jointgroup WHERE jointexternalid ='.$joint->jointexternalid);
		} else {
			$merge_groupid = $db->fetchOne('SELECT jointgroupid FROM jointgroup WHERE offeringid ='.$joint->offeringid);
		}
		
		// if the added joint was part of a group add that entire group to joints list
		if ($merge_groupid) {
			$this->loadGroup($merge_groupid);
		} else {
			// if the added joint is not already part of a group add it to joints list
			$this->joints[] = $joint;
		}
		
		// Snapshot each joint section
		foreach ($this->joints as $joint) {
			if ($joint instanceof \Db_Offering) {
				$joint->changemanager->snapshot();
			}
		}
		
		// Delete existing records
		$groupid_list = array();
		if ($groupid) {
			$groupid_list[] = $groupid;
		}
		if ($merge_groupid) {
			$groupid_list[] = $merge_groupid;
		}
		if (count($groupid_list) > 0) {
			$db->fetchOne('DELETE FROM jointgroup WHERE jointgroupid IN('.implode(',',$groupid_list).')');
		}

		// Choose a groupid
		if (count($groupid_list) > 0) {
			$jointgroupid = $groupid_list[0];
		} else {
			$jointgroupid = $db->fetchOne('SELECT MAX(jointgroupid) FROM jointgroup') + 1;
		}
		
		// Write reference offering to group
		$values = array('('.$jointgroupid.',0,'.$this->offering->offeringid.')');
		
		// Write each joint section to group
		foreach ($this->joints as $joint) {
			if ($joint instanceof \Db_JointExternal) {
				$values[] = '('.$jointgroupid.','.$joint->jointexternalid.',0)';
			} else {
				$values[] = '('.$jointgroupid.',0,'.$joint->offeringid.')';
			}
		}
		$db->query('INSERT INTO jointgroup VALUES'.implode(',',$values));
		
		// Reload joint sections
		foreach ($this->joints as $joint) {
			if ($joint instanceof \Db_Offering) {
				$joint->joint->load();
			}
		}
	}
	
	/**
	 * Returns a count of the joint offerings for this section, not counting the reference
	 * offering itself.
	 * @param mixed $joint
	 * @return integer
	 */
	public function getCount()
	{
		$this->lazyload();
		return count($this->joints);
	}
	
	/**
	 * Returns a single string describing all sections this offering is joint with
	 * @return string
	 */
	public function getSummary()
	{
		$this->lazyload();
		$out = array();
		foreach ($this->joints as $joint) {
			$out[] = $joint->curriculum.' '.$joint->courseno.' '.$joint->section;
		}
		if ($out) {
			return implode(', ',$out);
		} else {
			return null;
		}
	}
	
	/**
	 * Locates or creates an appropriate sibling record (Db_Offering or Db_JointExternal) and
	 * returns the object. The returned object is not yet joint with the reference offering, 
	 * addJoint() must be called once the returned object is validated.
	 * @param string $curriculum
	 * @param integer $courseno
	 * @param string $section
	 * @return \Db_Offering|\Db_JointExternal
	 */
	public function importJoint($curriculum, $courseno, $section)
	{
		if (array_key_exists($curriculum, \Db_Curriculum::$curricula)) {
			// handle local sections
			// search for an existing course offering
			return \Db_Offering::FetchMatchBySection(
				$this->offering->year,
				$this->offering->quarter,
				$curriculum,
				$courseno,
				$section
			);
		} else {
			// handle external sections
			$joint = \Db_JointExternal::ImportJoint($this->offering->year, $this->offering->quarter, $curriculum, $courseno, $section);
			if (!$joint->recordExists()) {
				$sws = new \Update\JointExternal\FromSws($joint);
				$sws->updateAll();
				// @TODO is this save neccessary? does not match behavior of Db_Offering
				$joint->save();
			}
			return $joint;
		}
	}
	
	/**
	 * Returns true if the provided curriculm abbreviation, course number and section
	 * identify a joint section for this offering
	 * @param string $curriculum
	 * @param integer $courseno
	 * @param string $section
	 * @return boolean
	 */
	public function hasJoint($curriculum, $courseno, $section)
	{
		$this->lazyload();
		foreach ($this->joints as $joint) {
			if ($joint->curriculum == $curriculum && $joint->courseno == $courseno && $joint->section == $section) {
				return true;
			}
		}
		if ($this->offering->curriculum == $curriculum && $this->offering->courseno == $courseno && $this->offering->section == $section) {
			return true;
		}
		return false;
	}

	/**
	 * Returns true if the provided object is currently a joint offering of the reference 
	 * offering. Takes arguments of type Db_Offering for local records or Db_JointExternal 
	 * for offerings outside the unit.
	 * @param mixed $joint
	 * @return boolean
	 */
	public function isJoint($joint)
	{
		return $this->hasJoint($joint->curriculum, $joint->courseno, $joint->section);
	}

	/**
	 * Load joint offering records from the database if they have no been loaded
	 */
	public function lazyload()
	{
		if (!is_array($this->joints)) $this->load();
	}

	/**
	 * Load joint offering records from the database
	 */
	public function load()
	{
		$this->joints = array();
		$db = \DbFactory::GetConnection();
		$jointgroupid = $db->fetchOne('SELECT jointgroupid FROM jointgroup WHERE offeringid = '.$this->offering->offeringid);
		if ($jointgroupid) {
			$this->loadGroup($jointgroupid);
		}
	}
	
	/**
	 * Load all joint offering objects in specified jointgroup and add them to
	 * the internal registers. Supports initial loading of joint offerings and
	 * merging joint groups.
	 * @param integer $jointgroupid
	 */
	private function loadGroup($jointgroupid)
	{
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT o.*, c.* '
		     . 'FROM jointgroup '
		     . 'INNER JOIN offering o '
		     . 'ON jointgroup.offeringid = o.offeringid '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'WHERE jointgroup.jointgroupid = '.$jointgroupid.' '
		     . 'ORDER BY c.curriculum, c.courseno, o.section';
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			// dont add the Db_Offering that is the point of reference to the list
			if ($row['offeringid'] == $this->offering->offeringid) continue;
			$offering = \Db_Offering::Register($row);
			$offering->setCourse(\Db_Course::Register($row));
			$this->joints[] = $offering;
		}
		$sql = 'SELECT j.* '
		     . 'FROM jointgroup '
		     . 'INNER JOIN jointexternal j '
		     . 'ON jointgroup.jointexternalid = j.jointexternalid '
		     . 'WHERE jointgroup.jointgroupid = '.$jointgroupid.' '
		     . 'ORDER BY j.curriculum, j.courseno, j.section';
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			$this->joints[] = \Db_JointExternal::Register($row);
		}
	}
	
	/**
	 * Remove the provided joint offering from the joint group of the reference offering. 
	 * Takes arguments of type Db_Offering for local records or Db_JointExternal for 
	 * offerings outside the unit.
	 * @param mixed $remove
	 */
	public function removeJoint($joint)
	{
		$this->removeJointByMatch($joint->curriculum, $joint->courseno, $joint->section);
	}

	/**
	 * Search joint offerings for an item matching the specified curriculum, course number
	 * and section and remove it.
	 * @param string $curriculum
	 * @param integer $courseno
	 * @param string $section
	 */
	public function removeJointByMatch($curriculum, $courseno, $section)
	{
		$this->lazyload();
		$newjoints = array();
		// Snapshot each joint section
		foreach ($this->joints as $joint) {
			if ($joint instanceof \Db_Offering) {
				$joint->changemanager->snapshot();
			}
		}
		foreach ($this->joints as $joint) {
			if ($joint->curriculum == $curriculum && $joint->courseno == $courseno && $joint->section == $section) {
				$db = \DbFactory::GetConnection();
				$jointgroupid = $db->fetchOne('SELECT jointgroupid FROM jointgroup WHERE offeringid = '.$this->offering->offeringid);
				if ($joint instanceof \Db_JointExternal) {
					$sql = 'DELETE FROM jointgroup '
					     . 'WHERE jointgroupid = '.$jointgroupid.' '
					     . 'AND jointexternalid = '.$joint->jointexternalid.' '
					     . 'AND offeringid = 0';
				} else {
					$sql = 'DELETE FROM jointgroup '
					     . 'WHERE jointgroupid = '.$jointgroupid.' '
					     . 'AND jointexternalid = 0 '
					     . 'AND offeringid = '.$joint->offeringid;
				}
				$db->query($sql);
				if ($joint instanceof \Db_Offering) {
					$joint->joint->load();
					$joint->changemanager->processChanges();
				}
			} else {
				$newjoints[] = $joint;
			}
		}
		$this->joints = $newjoints;
		// @TODO if joint list is empty delete group

		// Reload joint sections
		foreach ($this->joints as $joint) {
			if ($joint instanceof \Db_Offering) {
				$joint->joint->load();
			}
		}
	}

	/**
	 * Copies inheritable values from the reference offering to any local joint 
	 * offerings (Db_Offering).
	 */
	public function updateJointOfferings()
	{
		$this->lazyload();
		$updater = null;
		foreach ($this->joints as $joint) {
			if ($joint instanceof \Db_Offering) {
				$joint->changemanager->snapshot();
				$joint->changemanager->skipStep('joint'); // dont update joint offerings recursively
				if (is_null($updater)) $updater = new \Update\Offering\FromJoint();
				$updater->updateAll($this->offering, $joint);
				$joint->changemanager->processChanges();
			}
		}
	}

	/**
	 * Iterator::current � Return the current element
	 * @return Db_Quarter
	 */
	function current() 
	{
		return $this->joints[$this->position];
	}

	/**
	 * Iterator::key � Return the key of the current element
	 * @return scalar
	 */
	function key() 
	{
		return $this->position;
	}

	/**
	 * Iterator::next � Move forward to next element
	 * @return void
	 */
	function next() 
	{
		++$this->position;
	}

	/**
	 * Iterator::rewind � Rewind the Iterator to the first element
	 * @return void
	 */
	function rewind() 
	{
		$this->lazyload();
		$this->position = 0;
	}

	/**
	 * Iterator::valid � Checks if current position is valid
	 * @return boolean
	 */
	function valid() 
	{
		return ($this->position < count($this->joints));
	}

	/**
	 * Countable::count � returns number of entities in iterable list
	 * @return boolean
	 */
	public function count()
	{
		$this->lazyload();
		return count($this->joints);
	}
	
}