<?php
/**
 * @package UW_COE_Courses
 */
/**
 * This interface is implemented when a component is not the actual object 
 * of interest, instead it is a factory that can generate an instance of 
 * an object. The interface defines a method for extracting the target 
 * object.
 * @author hanisko
 */
interface ComponentFactoryInterface
{
	public function getSubject();
}
