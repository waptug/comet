<?php
/**
 * @package UW_COE_Courses
 */
/**
 * This object monitors a specific Db_Offering object and its related components
 * and runs system processes based on changes detected in the object.
 */
namespace Offering\Components;
 
class ChangeManager
{
	private static $config = array(
		'section' => array(
				'display'     => 'section',
				'description' => 'Section ID',
				'integer'     => false),
		'summerterm' => array(
				'display'     => 'summertermname',
				'description' => 'Summer term',
				'integer'     => false),
		'sectiontype' => array(
				'display'     => 'sectiontypename',
				'description' => 'Section type',
				'integer'     => false),
		'gradingsystem' => array(
				'display'     => 'gradingsystemname',
				'description' => 'Grading system',
				'integer'     => false),
		'institution' => array(
				'display'     => 'institutionname',
				'description' => 'Offered through',
				'integer'     => false),
		'enrollmentestimate' => array(
				'display'     => 'enrollmentestimate',
				'description' => 'Enrollment estimate',
				'integer'     => true),
		'enrollmentlimit' => array(
				'display'     => 'enrollmentlimit',
				'description' => 'Enrollment limit',
				'integer'     => true),
		'studentcredithoursestimate' => array(
				'display'     => 'studentcredithoursestimate',
				'description' => 'Student credit hour estimate',
				'integer'     => true),
		'meetingsummary' => array(
				'display'     => 'meetingsummary',
				'description' => 'Meetings',
				'integer'     => false)
	);
	
	protected $offering;
	protected $snapshot;
	protected $skip;
	
	public function __construct(\Db_Offering $offering)
	{
		$this->skip = array();
		$this->offering = $offering;
	}
	
	public function skipStep($name)
	{
		$this->skip[] = $name;
	}

	/**
	 * Make a point in time capture of the values of the focus Db_Offering object. This 
	 * method will overwrite a snapshot that was previously captured.
	 * @param Db_Offering $offering
	 */
	public function retakeSnapshot()
	{
		$this->snapshot = array();
		foreach (self::$config as $field => $info) {
			$this->snapshot[$field] = $this->offering->$field;
		}
		$this->snapshot['credits'] = $this->offering->getCreditDescription();
		$this->snapshot['staff'] = array();
		foreach ($this->offering->staff as $staff) {
			$this->snapshot['staff'][$staff->meetingnumber.'-'.$staff->personid] = $staff;
		}
		$this->snapshot['joint'] = array();
		foreach ($this->offering->joint as $joint) {
			$this->snapshot['joint'][] = $joint->curriculum.'-'.$joint->courseno.'-'.$joint->section;
		}
	}
	
	/**
	 * Make a point in time capture of the values of the focus Db_Offering object. Only
	 * takes snapshot if one has not yet been taken.
	 * @param Db_Offering $offering
	 */
	public function snapshot() 
	{
		if (!is_array($this->snapshot)) {
			$this->retakeSnapshot();
		}
	}

	/**
	 * Returns the stored value of the specified field from the snapshot
	 * @param string $field
	 * @return string
	 */
	public function snapshotValue($field)
	{
		if (array_key_exists($field, $this->snapshot)) {
			return $this->snapshot[$field];
		} else {
			return null;
		}
	}

	/**
	 * Compares the current values of the Db_Offering object to those stored in the 
	 * snapshot and acts on detected changes.
	 * @param Db_Offering $offering
	 */
	public function processChanges()
	{
		if (!is_array($this->snapshot)) {
			return;
		} 
		$changes = array();
		foreach (self::$config as $field => $info) {
			if ($this->snapshotValue($field) != $this->offering->$field) {
				$displayvalue = $info['display'];
				if ($info['integer']) {
					$changes[] = 'set '.$info['description'].' to '.(int)$this->offering->$displayvalue;
				} else {
					$changes[] = 'set '.$info['description'].' to '.$this->offering->$displayvalue;
				}
			}
		}
		if ($this->snapshot['credits'] != $this->offering->getCreditDescription()) {
			$changes[] = 'set credits to '.$this->offering->getCreditDescription();
		}
		foreach ($this->snapshot['staff'] as $staff) {
			if (!$this->offering->meetings->locateStaff($staff->meetingnumber, $staff->personid)) {
				$changes[] = 'removed '.\eFirstLast($staff).' ('.$staff->meetingnumber.') as '.$staff->role;
			}
		}
		foreach ($this->offering->staff as $staff) {
			if (!$this->locateStaff($staff->meetingnumber, $staff->personid)) {
				$changes[] = 'added '.\eFirstLast($staff).' ('.$staff->meetingnumber.') as '.$staff->role;
			}
		}
		foreach ($this->snapshot['joint'] as $id) {
			$id = explode('-',$id);
			if (!$this->offering->joint->hasJoint($id[0], $id[1], $id[2])) {
				$changes[] = 'removed joint with '.$id[0].' '.$id[1].' '.$id[2];
			}
		}
		foreach ($this->offering->joint as $joint) {
			if (!in_array($joint->curriculum.'-'.$joint->courseno.'-'.$joint->section, $this->snapshot['joint'])) {
				$changes[] = 'added joint with '.$joint->curriculum.' '.$joint->courseno.' '.$joint->section;
			}
		}
		if ($this->offering->jointsummary != $this->offering->joint->getSummary()) {
			$this->offering->jointsummary = $this->offering->joint->getSummary();
		}
		if (count($changes)) {
			if ($this->offering->status == 'expected') {
				$this->offering->status = 'planned';
				$changes[] = 'changed from expected to planned';
			}
			\Db_ActivityLog_Edit::Write($this->offering->offeringid, implode(', ', $changes));
		}
		// for current qtr and future offerings, watch fields that affect roomstatus
		if ($this->offering->getTimeframe() >= 0) { // current quarter or future
			if ($this->snapshotValue('meetingsummary') != $this->offering->meetingsummary) {
				$this->offering->roomstatus = 13; // 'Meetings changed'
			}
			if ($this->snapshotValue('enrollmentestimate') != $this->offering->enrollmentestimate) {
				$this->offering->roomstatus = 12; // 'Class size changed'
			}
			if ($this->snapshotValue('enrollmentlimit') != $this->offering->enrollmentlimit) {
				$this->offering->roomstatus = 12; // 'Class size changed'
			}
		}
		// propogate changes to joint offerings
		if (!in_array('joint',$this->skip)) {
			$this->offering->joint->updateJointOfferings();
		}
		// recalculate up-to-date-ness of this record
		if ($this->offering->uwts) {
			$updater = new \Update\Offering\FromUwts();
			$updater->update($this->offering->uwts, $this->offering);
		}
		$this->offering->save();
	}
	
	/**
	 * Returns a Db_Staff object if the specified meeting number and personid identify a staff 
	 * record in the snapshot, null otherwise
	 * @param integer $meetingnumber
	 * @param integer $personid
	 * @return Db_Staff|null
	 */
	public function locateStaff($meetingnumber, $personid)
	{
		$key = $meetingnumber.'-'.$personid;
		if (array_key_exists($key, $this->snapshot['staff'])) {
			return $this->snapshot['staff'][$key];
		}
		return null;
	}
	
}