<?php
/**
 * An HTML form input element. Programmatically generates form
 * element HTML to produce consistent, functional, and scriptable
 * page elements.
 *  
 * @author Paul
 */
abstract class FormElement
{
	// constants to make getUserInput() args more readable
	const IS_STRING = 0;
	const IS_INTEGER = 1;
	const STRIP_TAGS = 0;
	const DONT_STRIP_TAGS = 2;
	const GET_LIST_VALUE = 4;
	
	public $value;
	public $datacolumn;
	
	public $label;
	public $helptext;
	public $error;
		
	protected $_attributes = null;
	protected $_formatter;
	protected $_viewscript;
		
	public function __construct($name, $label, $value = '')
	{
		$this->name = $name;
		$this->label = $label;
		$this->value = $value;
		// list fields have names with [] so PHP gets list value, but they are not legal ids
		$this->id = str_replace(array('[',']'), '', $name);
		$this->datacolumn = $name;
		$this->_viewscript = 'formelement.phtml';
	}
	
	public function __set($name, $value)
	{
		$this->_attributes[$name] = $value;
	}
	
	public function __get($name)
	{
		if (isset($this->_attributes[$name])) {
			return $this->_attributes[$name];
		} else {
			return null;
		}
	}
	
	public function __isset($name)
	{
		return (bool) isset($this->_attributes[$name]);
	}
	
	public function __unset($name)
	{
		if (in_array($name, $this->_attributes)) {
			unset($this->_attributes[$name]);
		}
	}
	
	//	public function __toString()
	//{
	//	return $this->value;
	//}
	
	/**
	 * Specify a function to be called to format the value for display.
	 * The formatter must take one argument (the form element value) and
	 * return a string (the value formatted for display to the user).
	 * 
	 * @param string $formatter 
	 */
	public function setFormatter($formatter)
	{
		if (!function_exists($formatter)) {
			throw new Exception('Form element formatter function '. $formatter .' is not defined');
		}
		$this->_formatter = $formatter;
	}
	
	/** 
	 * Return the name of the formatting function set for this object.
	 * @return string
	 */
	public function getFormatter()
	{
		if (isset($this->_formatter)) { 
			$formatter = $this->_formatter; 
		} else {
			$formatter = 'e';
		}
		return $formatter;
	}
	
	/**
	 * Set a .phtml file that provides a wrapper layout for HTML form 
	 * elements. The view script will be included when $this->render() 
	 * or $this->__tostring() is called. The viewscript should included 
	 * at minimum a call to $this->renderInputElement(). Other standard
	 * display members are $this->helptext and $this->error. The view
	 * script should be available on the PHP include path.
	 * 
	 * @param $viewscript
	 */
	public function setViewScript($viewscript)
	{
		$this->_viewscript = $viewscript;	
	}
	
	/**
	 * Create the output of defined attributes on this object. Attributes
	 * are set through virtual properties (ex. $formelement->width = "50px").
	 * The optional $skip argument provides an array list of HTML attributes
	 * that should not be rendered. 
	 * 
	 * @param $skip
	 * @return string
	 */
	protected function renderAttributes($skip = false)
	{
		if (!$skip) { $skip = array(); }
		$out = '';
		foreach ($this->_attributes as $attrib => $value) {
			if (!in_array($attrib, $skip)) 
				$out .=  ' '. $attrib .'="'. $value .'"';
		}
		return $out;
	}
	
	/**
	 * This method builds an HTML form element based on the object values
	 * all unknown values in $_attributes are included in the element as 
	 * HTML attribute="value" properties.
	 */
	abstract public function getInputElement();
	
	/**
	 * This method outputs (echo) the result of FormElement::getInputElement()
	 */
	public function renderInputElement()
	{
		echo $this->getInputElement();
	}
	
	/**
	 * Output the form element wrapped in HTML markup. The form wrapper
	 * is specified in the FormElement::setViewScript() template file.
	 * By default that file is "formelement.phtml"
	 */
	public function render()
	{
		include $this->_viewscript;
	}
	
	/**
	 * Check _GET and _POST for user input that matches this form element
	 * name. Load the value using standard Request::UserInput scrub methods.
	 * 
	 * @param string $scrub_strategy
	 */
	public function getUserInput($scrub_strategy = null)
	{
		$this->value = Request::GetInstance()->getUserInput($this->name, $scrub_strategy, $this->value);
	}
	
	/**
	 * Checks user input on this element for a string recognizable as date
	 * and time. If a valid date/time string is found it is stored as a 
	 * Unix timestamp in the value property and the method returns true. If
	 * parsing fails this method returns false, the input is left as is in
	 * the value so it can be re-presented to the user for correction.
	 * 
	 * @return boolean
	 */
	public function parseDate()
	{
		$input = Form::GetUserInputList($this->name);
		$ts = strtotime($input);
		if ($ts === false) {
			return false;
		}
		$this->value = $ts;
		return true;
	}
	
	/**
	 * Input validation checks if the current value of the form input
	 * is null or the empty string.
	 */
	public function isEmpty()
	{
		return (strlen($this->value) == 0 || is_null($this->value));
	}
	
} // end of class FormElement