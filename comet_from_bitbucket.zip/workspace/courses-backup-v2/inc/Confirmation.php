<?php
/**
 * Provides a confirmation routine to combat cross site scripting forgeries. The
 * confirmation ensures that the user was actually looking at a prompt page before
 * making the request to complete an action.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */
class Confirmation 
{
	CONST INPUT_FIELD_NAME = 'crs_confirm_code';
	CONST EXPIRES = 600; // 10 minutes in seconds
	
	protected $_confirmed = false;
	protected $_dbconf;
	protected $_uwnetid;
	
	public function __construct($uwnetid = null)
	{
		if ($uwnetid) {
			$this->_uwnetid = $uwnetid;
		} else {
			$this->_uwnetid = User::GetLoggedInUser()->uwnetid;
		}
		$code = Request::UserInput(self::INPUT_FIELD_NAME);
		if ($code) {
			$this->_dbconf = $this->load($code);
		} else {
			$this->_dbconf = $this->create();
		}
	}
		
	/**
	 * Create a new confirmation object, store it to the database, and
	 * return the new confirmation code.
	 * @return Db_Confirmation
	 */
	protected function create()
	{
		$seed = mt_rand() . date('S l u D a Z ');
		$c= New Db_Confirmation(md5($seed), $this->_uwnetid);
		$c->created = time();
		$c->save();
		
		// since we just created a new code, it can't be valid on this iteration
		// it can become valid once a user has reviewed a form and re-submitted this code
		$this->_confirmed = false;
		
		return $c;
	}
	
	/**
	 * Returns true if this transaction has been confirmed. Confirmed means a 
	 * confirmation was generated within the last self::EXPIRE seconds and was
	 * sent to the client and returned to application on a subsequent request
	 * by the same user.
	 * @return boolean
	 */
	public function confirmed()
	{
		return $this->_confirmed;
	}
	
	/**
	 * Return the string confirmation code to be passed to the client and used
	 * as validation of a subsequent request.
	 * @return string
	 */
	public function getCode()
	{
		return $this->_dbconf->code;
	}
	
	/**
	 * Delete the confirmation code from the database to prevent reuse.
	 */
	public function delete()
	{
		$this->_confirmed = false;
		$this->_dbconf->delete();
	}
	
	/**
	 * Search the database for the specified confirmation code. Sets the
	 * internal _confirmed field.
	 * @param string $code
	 * @return Db_Confirmation
	 */
	protected function load($code)
	{
		$this->purgeExpired();
		$c = new Db_Confirmation($code, $this->_uwnetid);
		if ($c->recordExists()) {
			// the provided code was matched in the database, this is fresh/valid confirmation code
			$this->_confirmed = true;
		} else {
			// the provided code was either invalid or expired, but since someone is trying to use it we can recycle it
			$c->created = time();
			$c->save();
			$this->_confirmed = false;
		}
	}
	
	/**
	 * Delete confirmation records from the database that are older than the 
	 * expiration limit.
	 */
	protected function purgeExpired()
	{
		$cutoff = date('Y-m-d H:i:s', time() - self::EXPIRES);
		DbFactory::GetConnection()->query('DELETE FROM confirmation WHERE created < \''. $cutoff .'\'');
	}
	
}