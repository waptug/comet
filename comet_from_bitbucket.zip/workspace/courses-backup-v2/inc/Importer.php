<?php
/**
 * Supports import of data from an external source (example: a CSV text
 * file) into a local data store (example: web application database). A
 * specific Importer implementation is required for each source ->
 * destination combination.
 */

abstract class Importer
{
	/**
	 * Will contain a DataReader object. A DataReader provide the functionality
	 * to read a text file and break each line into an array of raw values.
	 * @var DataReader
	 */
	protected $datareader;
	
	/**
	 * Will contain an integer count of the number of defined fields
	 * based on the parsers array. Any query for a column outside of
	 * this count will return null.
	 * @var integer
	 */
	protected $fieldcount;
	
	/**
	 * Will contain an associative array with column labels mapped to
	 * column numbers. Column lables are unique descriptive strings 
	 * appropriate to the import job. Column numbers are the location
	 * of the column in the source data file starting with 0 on the
	 * far left.
	 * @var array
	 */
	protected $map;
	
	/**
	 * Will contain an associative array with column labels mapped to
	 * names of Parser classes. The parser class will be instantiated
	 * and used to read and scrub the input data.
	 * @var array
	 */
	protected $parsers;
	
	/**
	 * Will contain an associative array parser class names as the indices
	 * and parser instances as the value. Saves the overhead of instantiating
	 * multiple parsers.
	 * @var array
	 */
	protected $parser_instances = array();
	
	/**
	 * Array of raw values. The readRecord() method will populate this variable
	 * with one line from the import file each time it is called.
	 * @var array
	 */
	protected $record = array();
	
	/**
	 * Do import scrub and conversion routines on one record, but
	 * do not trigger save routines.
	 * Enter description here ...
	 */
	abstract public function readRecord();
	
	/**
	 * Store the last record tested in the target data store.
	 */
	abstract public function saveRecord();
	
	/**
	 * Get a scrubbed value from the current row 
	 *
	 * @param string $field
	 * @return string
	 * @throws Exception
	 */
	protected function getValue($field)
	{
		if (!array_key_exists($field, $this->map)) {
			throw new Exception('No column number is set in field map for ' . $field);
		}
		if (!array_key_exists($field, $this->parsers)) {
			throw new Exception('No parser is defined for ' . $field);
		}
		if ($this->map[$field] >= $this->fieldcount) {
			return null;
		}
		$rawvalue = $this->record[$this->map[$field]];
		$classname = $this->parsers[$field];
		if (!array_key_exists($classname, $this->parser_instances)) {
			$this->parser_instances[$classname] = new $classname();
		}
		return $this->parser_instances[$classname]->getValue($rawvalue);
	}

	/**
	 * Loop through all input records and store them in the
	 * target data store.
	 */
	public function saveAll()
	{
		while ($this->readRecord()) {
			$this->saveRecord();
		}
	}
	
}