<?php


class DataReader_Commadelimited
{
	protected $fp;
	protected $filename;
	
	public function __construct($filename)
	{	
		$this->filename = $filename;
		$this->fp = self::Open($filename);
	}
	
	/**
	 * Open a local file and return a file handle
	 * 
	 * @param string $filename path and filename of target file
	 * @return object
	 */
	protected static function Open($filename)
	{
		// get a file pointer
		$fp = fopen($filename, 'r');
		if ($fp === false) {
			throw new Exception('Failed to open file ' . $filename);
		}
		return $fp;
	}
	
	/**
	 * Begin processing the next record (or set of fields) in the data
	 * feed. Return an array of values if the next record exists. Returns
	 * false at the end of the file.
	 * 
	 * @param string $field
	 * @return array
	 */
	public function next()
	{
		return fgetcsv($this->fp);
	}
	
	/**
	 * Return the internal pointer to the first record in the data feed.
	 */
	public function reset()
	{
		fclose($this->fp);
		$this->fp = self::Open($this->filename);
	}

}
