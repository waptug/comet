<?php


class DataReader_Pipedelimited
{
	const MAX_DECODE_LEVELS = 99;
	const PLACEHOLDER = '~P~H~';
	protected $fp;
	protected $filename;
	
	public function __construct($filename)
	{	
		$this->filename = $filename;
		$this->fp = self::Open($filename);
	}
	
	/**
	 * Open a local file and return a file handle
	 * 
	 * @param string $filename path and filename of target file
	 * @return object
	 */
	protected static function Open($filename)
	{
		// get a file pointer
		$fp = fopen($filename, 'r');
		if ($fp === false) {
			throw new Exception('Failed to open file ' . $filename);
		}
		return $fp;
	}
	
	/**
	 * Begin processing the next record (or set of fields) in the data
	 * feed. Return true if the next record exist, false at the end 
	 * of the data feed.
	 * 
	 * @param string $field
	 * @return boolean
	 */
	public function next()
	{
		$line = fgets($this->fp);
		if ($line === false) {
			return false;
		}
		$line = self::MakeASCII($line);
		$line = trim($line);
		$placeholder = false;
		// deal with escaped backslashes
		if (strpos($line, '\|') !== false) {
			//Logger::GetInstance()->debug('found escaped backslash in: '. $line);
			// find a safe placeholder
			$placeholder = self::PLACEHOLDER; 
			$index = 0;
			while (strpos($line, $placeholder) !== false) {
				$placeholder = self::PLACEHOLDER . ++$index;
			}
			//Logger::GetInstance()->debug('using '. $placeholder .' as placeholder');
			$line = str_replace('\|', $placeholder, $line);
		}
		$fields = explode('|', $line);
		// if we replaced escaped backslashes, put them back
		if ($placeholder) {
			for ($i = 0; $i < count($fields); ++$i) {
				$fields[$i] = str_replace($placeholder, '|', $fields[$i]);
			}
		}
		return $fields;
	}
	
	/**
	 * Return the internal pointer to the first record in the data feed.
	 */
	public function reset()
	{
		fclose($this->fp);
		$this->fp = self::Open($this->filename);
	}

	/**
	 * Change the encoding of a string to UTF-8. Attempts the decoding
	 * recursively until the resulting string tests as ASCII or UTF-8.
	 *
	 * @param string $input
	 * @return string
	 */
	private static function MakeASCII($input) 
	{
		$tries = 0;
		$enc = mb_detect_encoding($input);
		mb_substitute_character('none');
	
		while ($enc != 'ASCII' && $enc !== false && !is_null($enc)) {
			$input = mb_convert_encoding($input, 'ASCII', $enc);
			$enc = mb_detect_encoding($input);
			++$tries;
			if ($tries > self::MAX_DECODE_LEVELS) {
				//Logger::GetInstance()->debug('Failed converting input to ASCII after '. $tries .' tries. Input detected as '. $enc);
				throw new Exception('Failed converting input to ASCII');
			}
		}
		return $input;
	}

}