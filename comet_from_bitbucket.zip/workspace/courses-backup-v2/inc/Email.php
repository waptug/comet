<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Object wrapper for the PHPMailer class. Builds appropriate headers to 
 * identify message and minimize spam false positives. Translates message
 * to plaintext and send multipart messages.
 * @author hanisko
 */
require_once '../libraries/PHPMailer_v5.1/class.phpmailer.php';

class Email
{
	const EMAIL_SMTP_HOST = 'smtp.washington.edu';
	const EMAIL_SMTP_USERNAME = 'uweduc';
	const EMAIL_SMTP_PASSWORD = 'smart-miller-215';
	const EMAIL_SMTP_PORT = 587;
	const EMAIL_SMTP_ENCRYPT = 'tls';
	const EMAIL_FROM_EMAIL = 'uweduc@uw.edu';
	const EMAIL_FROM_NAME = 'UW College of Education';
	
	private $phpmailer;
	private $testmode;
	private $hold;
	
	public function __construct()
	{
		$this->phpmailer = new PHPMailer(true);
		$this->phpmailer->IsSMTP();
		$this->phpmailer->SMTPAuth = true;                      // enable SMTP authentication
		$this->phpmailer->Host     = self::EMAIL_SMTP_HOST;     // sets the SMTP server
		$this->phpmailer->Port     = self::EMAIL_SMTP_PORT;     // set the SMTP port for the GMAIL server
		$this->phpmailer->Username = self::EMAIL_SMTP_USERNAME; // SMTP account username
		$this->phpmailer->Password = self::EMAIL_SMTP_PASSWORD; // SMTP account password
		
		$this->setTestMode(true);
		if (Environment::GetEnv() == 'PROD') {
			$this->setTestMode(false);
		}
		if ($this->testmode) {
			$this->phpmailer->AddAddress($this->getTestmodeAddress());
		}
	}
	
	public function __call($name, $args)
	{
		if (method_exists($this->phpmailer, $name)) {
			switch (count($args)) {
				case '1':
					return $this->phpmailer->$name($args[0]);
					break;
				case '2':
					return $this->phpmailer->$name($args[0],$args[1]);
					break;
				case '3':
					return $this->phpmailer->$name($args[0],$args[1],$args[2]);
					break;
				case '4':
					return $this->phpmailer->$name($args[0],$args[1],$args[2],$args[3]);
					break;
				case '5':
					return $this->phpmailer->$name($args[0],$args[1],$args[2],$args[3],$args[4]);
					break;
				default: 
					return $this->phpmailer->$name();
					break;
			}
		}
	}

	public function addAddress($email, $name = null)
	{
		if ($this->testmode) {
			$this->addHoldAddress($email, $name);
			return;
		}
		$this->phpmailer->AddAddress($email, $name);
	}

	public function addBCC($email, $name = null)
	{
		if ($this->testmode) {
			$this->addHoldAddress($email, $name);
			return;
		}
		$this->phpmailer->AddBCC($email, $name);
	}
	
	public function addCC($email, $name = null)
	{
		if ($this->testmode) {
			$this->addHoldAddress($email, $name);
			return;
		}
		$this->phpmailer->AddCC($email, $name);
	}
	
	public function addHoldAddress($email, $name = null)
	{
		if (!is_array($this->hold)) {
			$this->hold = array();
		}
		$this->hold[] = array('email' => $email, 'name' => $name);
	}
	
	/**
	 * Returns an explanatory message to be inserted into e-mails that are 
	 * sent to testing email address instead of the actual "to" and "cc"
	 * addresses. This happens when email is sent from a dev or testing 
	 * environment.
	 * 
	 * @return string
	 */
	protected function getTestMessage()
	{
		$out = array();
		foreach ($this->hold as $address) {
			if ($address['name']) {
				$out[] = '"'.$address['name'].'" <'.$address['email'].'>';
			} else {
				$out[] = $address['email'];
			}
		}
		if ($out) {
			$list = implode(', '.$out);
		} else {
			$list = '(no adresses specified)';
		}
		return '<p style="color:#c00;font-style:italic;">(TEST MODE: This messages is being '
			. 'redirected to you because it was sent from a testing environment. If this email '
			. 'had been generated on the production site it would have been sent to <strong>'
			. htmlspecialchars($list) .'</strong>)</p>';
	}
	
	/**
	 * Insert a test message notifier into an email message. Used when
	 * mail sent from a dev or test environment is redirected to a test 
	 * email address. This message explains the redirection to the test 
	 * recipient.
	 */
	protected function insertTestMessage()
	{
		$this->message = $this->getTestMessage() . self::$newline . self::$newline . $this->message;
	}
	
	/**
	 * Detect whether we should be in test mode when sending emails. 
	 * In test mode email "to" and "cc" addresses are overridden with
	 * a test email address and a test mode header is inserted into the 
	 * message body.
	 * 
	 * @return boolean
	 */
	protected function setTestMode($mode = true)
	{
		$this->testmode = (boolean)$mode;
		return $this->testmode;
	}
	
	/**
	 * Come up with a safe e-mail address to send this message to when
	 * we are in test mode. Returns the logged in user's email, or the
	 * developer email defined in config, or a hardcoded email.
	 * 
	 * @return string
	 */
	protected function getTestmodeAddress()
	{
		// provide a hard coded fall back
		$safe_email = 'hanisko@uw.edu';

		global $fw_noauth;
		if ($fw_noauth) { return $safe_email; }
		
		$user = User::GetLoggedInUser();
		if ($user->uwnetid) {
			// if we have a logged in user send to them
			$safe_email = $user->uwnetid . '@uw.edu';
		} else {
			// use the developer address
			$config = Configuration::GetInstance();
			if ($config->email_developer)
				$safe_email = $config->email_developer;
		}
		return $safe_email;
	}

}