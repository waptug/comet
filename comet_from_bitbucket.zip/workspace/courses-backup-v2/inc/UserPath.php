<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Stores data about the path the user takes through the application. Provides
 * functionality including sticky filters on report views, breadcrumb trails,
 * and where to return the user after they complete sub tasks.
 * @author hanisko
 */
 
class UserPath
{
	const SESSION_INDEX = 'crs_user_path_data';
	protected static $_instance;
	protected $_data;
	
	protected function __construct()
	{
		$this->load();
	}
	
	/**
	 * Replace current breadcrumbs stored in the UserPath with the array
	 * of breadcrumbs provided as an argument.
	 * @param array $breadcrumbs
	 */
	public function setBreadcrumbs($breadcrumbs)
	{
		$this->_data->breadcrumbs = $breadcrumbs;
	}

	/**
	 * Returns stored breadcrumb trail as an array of StdClass objects 
	 * @param array $breadcrumbs
	 */
	public function getBreadcrumbs()
	{
		if (property_exists($this->_data, 'breadcrumbs')) {
			return $this->_data->breadcrumbs;
		} else {
			return array();
		}
	}

	/**
	 * Add a single breadcrumb to the end of the trail
	 * @param StdClass $breadcrumb
	 */
	public function addBreadcrumb($breadcrumb)
	{
		if (property_exists($this->_data, 'breadcrumbs')) {
			$this->_data->breadcrumbs[] = $breadcrumb;
		} else {
			$this->_data->breadcrumbs = array($breadcrumb);
		}
	}

	/**
	 * Sets an application relative URL that the user should be directed
	 * to when a sub task has been completed.
	 * @param string $url
	 */
	public function setTaskComplete($url)
	{
		$this->_data->taskcomplete = $url;
	}

	/**
	 * Returns an application relative URL that the user should be directed
	 * to when a sub task has been completed.
	 * @return string
	 */
	public function getTaskComplete()
	{
		
		if (property_exists($this->_data, 'taskcomplete')) {
			return $this->_data->taskcomplete;
		} else {
			return '';
		}
	}
	
	/**
	 * Returns an instance of the singleton class UserPath
	 * @return UserPath
	 */
	public static function GetInstance()
	{
		if (is_null(self::$_instance)) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Write the UserPath object's internal data to the sesssion.
	 */
	protected function save()
	{
		$_SESSION[self::SESSION_INDEX] = json_encode($this->_data);
	}

	/**
	 * Load the UserPath object's internal data from the sesssion.
	 */
	protected function load()
	{
		if (array_key_exists(self::SESSION_INDEX, $_SESSION)) {
			$this->_data = json_decode($_SESSION[self::SESSION_INDEX]);
		} else {
			$this->_data = new StdClass();
		}
	}
	
	/**
	 * Triggers save routine when http request is resolve and php process ends
	 */
	function __destruct()
	{
		$this->save();
	}
	
}