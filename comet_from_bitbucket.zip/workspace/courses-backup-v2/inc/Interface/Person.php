<?php
/**
 * @package UW_COE_Framework
 */
/**
 * An interface for objects that have person name fields.
 */

interface Interface_Person
{
    public function getFirstname();
    public function getLastname();
}
