<?php
/**
 * This class manages user information and is dependant on authentication
 * provided by UWNetID and pubcookie. For this class to work the application
 * must be protected by pubcookie so that users are forced to log in and
 * the apache REMOTE_USER environment variable is set.
 * 
 * Once pubcookie is compiled and configured in apache it can be activated
 * per directory with an .htaccess file like this...
 * 
 * AuthType UWNetID
 * AuthName coe_YOUR_APP_NAME
 * PubcookieAppID coe_YOUR_APP_NAME
 * Require valid-user
 */

class User implements Interface_Person
{
	// reduces chance of collisions between multiple application session variables
	CONST SESSION_PREFIX = 'crs_';
	
	/**
	 * Role that gets assigned to unknown users
	 * @var string
	 */
	private static $_defaultRole = 'noauth';
	
	/**
	 * Role that inherits all other roles. Users with this role will
	 * always pass authorization tests.
	 * @var string
	 */
	private static $_superRole = 'super';
	
	/**
	 * List of all roles used by system. The number ranks define
	 * inheritance. Higher ranks will inherit the permissions of
	 * lower ranks.
	 * @var array
	 */
	private static $_roleranks = array(
		'super'   => 4,
		'dean'    => 3, 
		'admin'   => 2, 
		'adcab'   => 2,
		'faculty' => 1, 
		'staff'   => 1,  
		'user'    => 1,  
		'noauth'  => 0
	);
	
	private static $_loggedin = null;
	
	public $uwnetid = '';
	public $role = '';
	
	private $_person;
	private $_firstname;
	private $_lastname;
	private $_tags;
		
	public function __construct($uwnetid, $autoload = false)
	{
		$this->uwnetid = $uwnetid;
		$this->role = null;
	}
	
	public function __get($name)
	{
		switch ($name) 
		{
			case 'person':
				return $this->getPerson();
				break;
			case 'firstname':
				return $this->getFirstname();
				break;
			case 'lastname':
				return $this->getLastname();
				break;
			case 'personid':
				return $this->getPerson()->personid;
				break;
			default:
				return null;
				break;
		}
	}
	
	/**
	 * Provides access to the person record related to this user.
	 * Loads on first use.
	 * @return Db_Person
	 */
	public function getPerson()
	{
		if (is_null($this->_person)) {
			$this->_person = Db_Person::FetchByUwnetid($this->uwnetid);
			$this->_firstname = $this->_person->firstname;
			$this->_lastname = $this->_person->lastname;
			User::WriteSession('firstname', $this->_firstname);
			User::WriteSession('lastname', $this->_lastname);
		}
		if (is_null($this->_person)) throw new Exception('person still null');
		return $this->_person;
	}
	
	/**
	 * Provides access to the person record related to this user.
	 * Loads on first use. Supports the Person Interface.
	 * @return string
	 */
    public function getFirstname()
    {
		if (is_null($this->_firstname)) {
			$this->getPerson();
		}
		return $this->_firstname;
    }
    
	/**
	 * Provides access to the person record related to this user.
	 * Loads on first use. Supports the Person Interface.
	 * @return string
	 */
    public function getLastname()
    {
		if (is_null($this->_lastname)) {
			$this->getPerson();
		}
		return $this->_lastname;
    }
	
	/**
	 * Load user role from the data store
	 */
	public function load()
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT role FROM auth WHERE uwnetid = '.$db->quote($this->uwnetid);
		$this->role = $db->fetchOne($sql);
		if (is_null($this->role)) {
			$this->role = self::$_defaultRole;
		}
		User::WriteSession('role', $this->role);
	}
	
	/**
	 * Check if this user has the role specified by $required_role argument
	 * or a role that inherits permission from the $required_role.
	 * 
	 * @param string $requiredrole
	 */
	public function hasRole($required_role)
	{
		// short circuit to save some time on the easy ones
		if ($required_role == self::$_defaultRole) return true;
		if ($this->role == self::$_superRole) return true;
		
		// figure out the rank they need to have access
		if (array_key_exists($required_role, self::$_roleranks)) {
			$needs = self::$_roleranks[$required_role];
		} else {
			// give unexpected required roles rank higher than all but super user
			Logger::GetInstance()->debug('Unknown role "'. $required_role .'" provided in User::hasRole');
			$needs = 5;
		}
		
		// figure out the rank they have
		if (array_key_exists($this->role, self::$_roleranks)) {
			$has = self::$_roleranks[$this->role];
		} else {
			// give unexpected user roles noauth rank
			$has = 0;
		}
		//debug(__METHOD__.' $required_role:'.$required_role.' has:'.$has.' needs:'.$needs);
		return ($has >= $needs);
	}
	
	/**
	 * Loads the expected user values from the session persistant variable
	 * store. Returns true if the role variable was found, false otherwise.
	 * @return boolean
	 */
	protected function readSession()
	{
		if (User::GetSession('userrole')) {
			$this->role = User::GetSession('userrole');
			$this->_firstname = User::GetSession('firstname');
			$this->_lastname = User::GetSession('lastname');
			return true;
		}
		return false;
	}
	
	/**
	 * Searches expected location for an authenticated UW NetID 
	 * value returns the primary matched value.
	 * @return string
	 */
	public static function FindLoggedInUwnetid()
	{
		// if this is maintenance script run from shell or cronjob, return system
		if (Environment::ScriptType() == 'cli') {
			return 'system';
		}
		// check if this is a developer impersonating another user
		$uwnetid = User::GetSession('debuguwnetid');
		if ($uwnetid) {
			return $uwnetid;
		}
        // developer workstation override set in Apache config
        $uwnetid = getenv('PUBCOOKIE_STUB_UWNETID');
        if ($uwnetid) {
            return $uwnetid;
        }
		// next try to grab the User's UWNetId from pubcookie
		if (array_key_exists('REMOTE_USER', $_SERVER)) {
			return $_SERVER['REMOTE_USER'];
		}
		// next check the session for a userid stored for ajax requests
		$uwnetid = User::GetSession('ajaxuser');
		if ($uwnetid) {
			return $uwnetid;
		}
		// If apache is configured correctly for pubcookie protection of this dir, this is unreachable
		throw new Exception('You must be authenticated with a UWNetID to use this application');
	}
	
	/**
	 * Get a User object representing the user currently logged
	 * into the application.
	 * @return User
	 */
	public static function GetLoggedInUser()
	{
		if (is_null(self::$_loggedin)) {
			// find logged in identity
			$uwnetid = self::FindLoggedInUwnetid();
			
			$user = new self($uwnetid, false);
			$user->role = self::$_defaultRole;
			// check session, in case we've done this before
			$found = $user->readSession();	
	
			// if User info was not in the session, run load to find it elsewhere
			if (!$found) { 	
				$user->load();
			}
			self::$_loggedin = $user;
		}
		return self::$_loggedin;
	}
	
	/**
	 * Fetch a value from the session persistant variable store. 
	 * If the $key does not exist in the store returns null.
	 * @param string $key
	 * @return string
	 */
	public static function GetSession($key)
	{
		if (array_key_exists(self::SESSION_PREFIX.$key, $_SESSION)) {
			return $_SESSION[self::SESSION_PREFIX.$key];
		} else {
			return null;
		}
	}
	
	/**
	 * Write a value to the session persistant variable store.
	 * @param string $key
	 * @param string $value
	 */
	public static function WriteSession($key, $value)
	{
		$_SESSION[self::SESSION_PREFIX.$key] = $value;
	}	
	
	/**
	 * Returns an array list of course/course offering Db_Tag objects that
	 * this user is authorized to manipulate.
	 * 
	 * @param unknown_type $all
	 * @return array
	 */
	public function getTags()
	{
		if (is_null($this->_tags)) {
			$db = DbFactory::GetConnection();
			$this->_tags = Db_Tag::FetchEditable($this->uwnetid);
		}
		return $this->_tags;
	}	

}