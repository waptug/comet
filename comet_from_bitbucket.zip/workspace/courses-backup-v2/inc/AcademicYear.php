<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Stores an Academic Year. Validates input and adjusts it within
 * application specific parameters.
 * 
 * @author hanisko
 */
class AcademicYear
{
	private static $_instance;
	
	protected $_yearmin;
	protected $_yearmax;
	protected $_yeardefault = 2012;
	
	private function __construct()
	{
	}
	
	public static function GetInstance()
	{
		if (is_null(self::$_instance)) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}
	
	public function validate($value)
	{
		$value = (int) $value;
		if ($value < $this->getMinYear()) {
			if ($this->getDefaultYear()) {
				$value = $this->getDefaultYear();
			} else {
				$value = $this->getMinYear();
			}
		}
		if ($value > $this->getMaxYear()) {
			if ($this->getDefaultYear()) {
				$value = $this->getDefaultYear();
			} else {
				$value = $this->getMaxYear();
			}
		}
		return $value;
	}
	
	protected function getMinYear()
	{
		if (is_null($this->_yearmin)) {
			$db = DbFactory::GetConnection();
			$this->_yearmin = $db->fetchOne('SELECT MIN(year) FROM offering');
		}
		return $this->_yearmin;
	}
	
	protected function getMaxYear()
	{
		if (is_null($this->_yearmax)) {
			$this->_yearmax = date('Y') + 10;
		}
		return $this->_yearmax;
	}
	
	protected function getDefaultYear()
	{
		return $this->_yeardefault;
	}
	
}