<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Access control list. Calculates access to areas of application based on 
 * user role.
 * @author hanisko
 */

class Acl
{
	const APP_BASE_URI = '/courses';
	const INDEX_DOC_ID = '__INDEX__';
	const DEFAULT_REQUIRED_ROLE = 'faculty';
	
	private static $_acl = array(
		self::INDEX_DOC_ID   => 'noauth',
		'/error'   => 'noauth',
		'/help'    => 'noauth',
		'/logout'  => 'noauth',
		'/search'  => 'noauth',
		'/adcab'   => 'admin',
        '/plan'    => 'admin',
        '/admin/course' => 'admin',
		'/admin'   => 'super',
		'/workflow/person-toggle' => 'dean',
	);
	
	/**
	 * Checks whether a users is authorized to access a resources. Defaults
	 * to the currently requested resources and the currently logged in user.
	 * @param string $resource
	 * @param User $user
	 * @return boolean
	 */
	public static function HasAuth($resource = null, User $user = null)
	{
		$requiredrole = self::RequiredRole($resource);
		if (!$user) $user = User::GetLoggedInUser();
		return $user->hasRole($requiredrole);
	}
	
	/**
	 * Returns the application user role required for the specified resource
	 * expressed as an application URL.
	 * @param string $resource
	 * @param string
	 */
	public static function RequiredRole($resource = null)
	{
		if (is_null($resource)) {
			$resource = Request::Phpself();
		}
		if (strpos($resource, self::APP_BASE_URI) === 0) {
			$resource = substr_replace($resource, '', 0, strlen(self::APP_BASE_URI));
		}
		if ($resource == '' || $resource == '/') {
			if (array_key_exists(self::INDEX_DOC_ID, self::$_acl)) {
				return self::$_acl[self::INDEX_DOC_ID];
			} else {
				return self::DEFAULT_REQUIRED_ROLE;
			}
		}
		$requiredrole = self::DEFAULT_REQUIRED_ROLE;
		while (strlen($resource) > 1) {
			if (array_key_exists($resource, self::$_acl)) {
				$requiredrole = self::$_acl[$resource];
				break;
			} else {
				$resource = dirname($resource);
			}
		}
		return $requiredrole;
	}

}
