<?php
/**
 * Times events in microseconds.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Framework
 */
class Timer 
{

	private $_start;
	private $_splits;
	private $_end;
	
	/**
	 * Create a new timer and start the clock.
	 */
	public function __construct()
	{
		$this->start();
	}
	
	/**
	 * Restart the clock
	 */
	public function start()
	{
		$this->_end = 0;
		$this->_start = microtime();
	}
	
	/**
	 * Get the time passed between start and when stop was called or
	 * (if stop was not called) now.
	 */
	public function getTime()
	{
		if (!$this->_end) {
			$this->_end = microtime();
		}
		return (self::MicrotimeToFloat($this->_end) - self::MicrotimeToFloat($this->_start));
	}
	
	/**
	 * Stop the timer
	 */
	public function stop()
	{
		$this->_end = microtime();
	}
	
	/**
	 * Record the time between start and when this split was added.
	 * @param string $name create custom label for this split
	 */
	public function addSplit($name = '')
	{
		$split = microtime();
		if (!is_array($this->_splits)) {
			$this->_splits = array();
		}
		if (!$name) {
			$name = 'Split ' . (count($this->_splits) + 1);
		}
		$this->_splits[$name] = $split;
	}
	
	/**
	 * Return an associative array of split times. Names provided
	 * for the splits are the indices and times are the values.
	 */
	public function getSplits()
	{
		$prev = self::MicrotimeToFloat($this->_start);
		$out = array();
		foreach ($this->_splits as $name => $mtime) {
			$curr = self::MicrotimeToFloat($mtime);
			$out[$name] =  $curr - $prev;
			$prev = $curr;
		}
		return $out;
	}
	
	/**
	 * Convert the string returned by PHP microtime() to a decimal value
	 * 
	 * @param string $mtime
	 */
	private static function MicrotimeToFloat($mtime)
	{
		list($usec, $sec) = explode(' ', $mtime);
	    return ((float)$usec + (float)$sec);
	}

}
