<?php
/**
 * Stores a time value. Parses various input formats into
 * meaningful time data and provides output in standard
 * formats.
 * @author Paul Hanisko
 * @package UW_COE_Framework
 */

class Time
{
	const HOUR = 0;
	const MINUTE = 1;
	const SECOND = 2;
	const MERIDIAN = 3;
	const EXTRA = 4;
	
	public $hour;
	public $minute;
	public $second;
	public $meridian;
	public $extra;
	public $isValid;
	
	private $pointer;
	private $parsed;

	public function __construct($value=null)
	{
		$this->isValid = false; 
		if (!is_null($value)) {
			$this->isValid = $this->parse($value);
		}
	}
	
	/**
	 * Break a string representing a time down into its components
	 * and store those components internally. Returns true if a valid
	 * value was able to be parsed, false otherwise.
	 * 
	 * @param string $value
	 * @return boolean
	 */
	public function parse($value)
	{
		if (preg_match('/[0-9][0-9]:[0-9][0-9]:[0-9][0-9]/', $value)) {
			$this->dbParse($value);
			return true;
		}
		$goodparse = true;
		$this->parsed = array('', '', '', '', '');
		$bits = str_split(trim($value));
		$this->movePointer(self::HOUR);
		$length = count($bits);
		for ($i = 0; $i < $length; ++$i) {
			$c = $bits[$i];
			if ($c == ':') {
				$this->movePointer();
				continue;
			}
			if ($c == 'A' || $c == 'P' || $c == 'a' || $c == 'p') {
				if (++$i < $length) {
					$next = $bits[$i];
				} else {
					$next = '';
				}
				if ($next == 'M' || $next == 'm') {
					$this->parsed[self::MERIDIAN] = strtoupper($c).'M';
					$this->movePointer(self::EXTRA);
					$c = '';
				} else {
					$this->movePointer(self::EXTRA);
					$c .= $next;
				}
			}
			$this->append($c);
		}
		$this->hour = (int) $this->parsed[self::HOUR];
		$this->minute = (int) $this->parsed[self::MINUTE];
		$this->second = (int) $this->parsed[self::SECOND];
		$this->meridian = $this->parsed[self::MERIDIAN];
		$this->extra = $this->parsed[self::EXTRA];
		
		if (!$this->meridian) {
			$this->meridian = 'AM';
		}
		if ($this->hour == 12) {
			$this->meridian = 'PM';
		}
		if ($this->hour == 0) {
			$this->hour = 12;
			$this->meridian = 'AM';
		}
		if ($this->hour > 12) {
			$this->hour = $this->hour - 12;
			$this->meridian = 'PM';
		}
		if ($this->hour < 1 || $this->hour > 12) {
			$goodparse = false;
		}
		if ($this->minute < 0 || $this->minute > 59) {
			$goodparse = false;
		}
		if ($this->second == '') {
			$this->second = 0;
		}
		if ($this->second < 0 || $this->second > 59) {
			$goodparse = false;
		}
		
		return $this->isValid = $goodparse;
	}
	
	/**
	 * Parse a value in MySQL database time format into time 
	 * fields.
	 * @param string $value in the format HH:MM:SS
	 */
	public function dbParse($value) 
	{
		$bits = explode(':', $value);
		$this->hour = $bits[self::HOUR];
		$this->minute = $bits[self::MINUTE];
		$this->second = $bits[self::SECOND];
		if ($this->hour > 12) {
			$this->hour = $this->hour - 12;
			$this->meridian = 'PM';
		} elseif ($this->hour == 12) {
			$this->meridian = 'PM';
		} elseif ($this->hour == 0) {
			$this->hour = 12;
			$this->meridian = 'AM';
		} else {
			$this->meridian = 'AM';
		}
	}
	
	/**
	 * Move the value pointer to the next internal time field. Used 
	 * in character by character parsing.
	 */
	private function movePointer($pointer_position = null)
	{
		if (is_null($pointer_position)) {
			++$this->pointer;
		} else {
			$this->pointer = $pointer_position;
		} 
		if ($this->pointer > 4) {
			$this->pointer = 4;
		}
	}
	
	/**
	 * Append the specified character to the internal time field
	 * referred to by the pointer.
	 */
	private function append($char)
	{
		// if hour, minute, or second have two characters move to next field
		if ($this->pointer < 3 && strlen($this->parsed[$this->pointer]) > 1) {
			$this->movePointer();
		}
		$this->parsed[$this->pointer] .= $char;
	}
	
	/**
	 * Returns the stored time value in human readable formatting
	 * @return string
	 */
	public function getPrettyTime()
	{
		return sprintf('%d:%02d %s', $this->hour, $this->minute, $this->meridian);
	}
	
	/**
	 * Returns the stored time value in the concise formatting used by the
	 * UW Time Schedule
	 * @param $isendtime
	 * @return string
	 */
	public function getUwtsBrief($isendtime = false)
	{
		$evening_flag = ($isendtime && $this->meridian == 'PM' && $this->hour > 5) ? 'P' : '';
		return sprintf('%d%02d%s', $this->hour, $this->minute, $evening_flag);
	}
	
	/**
	 * Returns the stored time value in MySQL database format
	 * @return string
	 */
	public function getDbTime()
	{
		if ($this->meridian == 'AM') {
			if ($this->hour == 12) 
				$hour = 0; // 12AM = 12 Midnight = 00:00 hours
			else
				$hour = $this->hour;
		} else {
			if ($this->hour == 12) 
				$hour = 12; // 12PM = 12 Noon = 12:00 hours
			else
				$hour = $this->hour + 12;
		}
		return sprintf('%02d:%02d:%02d', $hour, $this->minute, $this->second);
	}
	
	public function dump()
	{
		return 'H:'.$this->hour.' M:'.$this->minute.' S:'.$this->second.' m:'.$this->meridian.' E:'.$this->extra;
	}
}