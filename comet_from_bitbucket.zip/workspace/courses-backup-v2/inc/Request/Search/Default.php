<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Provides a search strategy to look through various user input
 * mechanisms to find a value
 * @author hanisko
 */
 
class Request_Search_Default extends Request_Search_SearchAbstract
{
	
	public function get($fieldname)
	{
		// give first priority to query string
		if (array_key_exists($fieldname, $_GET)) {
			return $_GET[$fieldname];
		}
		// next check the post
		elseif (array_key_exists($fieldname, $_POST)) {
			return $_POST[$fieldname];
		}
		// use the field not found value
		else {
			return $this->not_found_value;
		}
	}
	
}