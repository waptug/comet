<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Provides a search strategy to look through various user input
 * mechanisms to find a value
 * @author hanisko
 */
 
abstract class Request_Search_SearchAbstract
{
	protected $not_found_value = NULL;
	
	abstract public function get($fieldname);
	
}