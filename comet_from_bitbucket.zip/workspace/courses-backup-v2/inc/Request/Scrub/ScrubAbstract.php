<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Cleanses user input by removing or changing unwanted characters or
 * values.
 * @author hanisko
 */
 
abstract class Request_Scrub_ScrubAbstract
{

	abstract public function scrub($value);
	
	protected function htmlbreaks($value)
	{
		return $this->removecrlf($value, '<br />');
	}
	
	protected function maxlength($value, $length)
	{
		return substr($value, 0, $length);
	}
	
	protected function removecrlf($value, $replacement = ' ')
	{
		$value = str_replace(chr(10), $replacement, $value); //newline
		$value = str_replace(chr(13), ' ', $value); //carriage return
		// make multiple spaces singles
		$value = preg_replace('/ +/', ' ', $value);
	}
	
	protected function striptags($value)
	{
		return strip_tags($value);
	}
	
	/**
	 * Remove leading and trailing whitespace
	 * @param string $value
	 * @return string
	 */
	protected function trim($value)
	{
		return trim($value);
	}

}