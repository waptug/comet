<?php 
/**
 * @package UW_COE_Framework
 */
/**
 * Provides a default user input scrub strategy for string input
 * @author hanisko
 */
 
class Request_Scrub_Default extends Request_Scrub_ScrubAbstract
{

	public function scrub($value)
	{
		$value = $this->trim($value);
		$value = $this->striptags($value);
		return $value;
	}

}
