<?php 
/**
 * @package UW_COE_Framework
 */
/**
 * Provides a default user input scrub strategy for string input
 * @author hanisko
 */
 
class Request_Scrub_Integer extends Request_Scrub_ScrubAbstract
{

	public function scrub($value)
	{
		if (is_null($value)) {
			return null;
		} else {
			return (int)$value;
		}
	}

}
