<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Course optional and narrative fields.
 * @author hanisko
 */

class Details_Course extends Details_Abstract
{
	
	public function __construct()
	{
		parent::__construct(DbFactory::GetConnection(), 'coursedetail', 'courseid', 'detailkey', 'detailvalue');	
	}
	
}