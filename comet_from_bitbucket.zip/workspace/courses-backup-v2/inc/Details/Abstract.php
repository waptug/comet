<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Details object manages a list of properties that are dynamically or 
 * irregularly assigned to an object. The data is persisted is a specially
 * structured detail table: primary key, detail key, detail value that 
 * allows for attributes defined at the application level. Supports lazy
 * loading.
 * @author hanisko
 */

class Details_Abstract
{
	const TYPE_CHAR      = 0;
	const TYPE_DATETIME  = 1;
	const TYPE_TIMESTAMP = 1;
	const TYPE_BOOLEAN   = 2;
	const TYPE_INT       = 3;
	const TYPE_NUMERIC   = 4;
	
	protected $_db;
	protected $_table;
	protected $_pkcolumn;
	protected $_pktype;
	protected $_dkcolumn;
	protected $_valuecolumn;
	protected $_details;

	public function __construct(DbConnection $db, $table, $primary_key_column, $detail_key_column, $detail_value_column, $primary_key_type = self::TYPE_INT)
	{
		$this->_db = $db;
		$this->_table = $table;
		$this->_pkcolumn = $primary_key_column;
		$this->_pktype = $primary_key_type;
		$this->_dkcolumn = $detail_key_column;
		$this->_valuecolumn = $detail_value_column;
	}
	
	/**
	 * Retrieve the current value for the specified detail key $name. 
	 * @param string $primaryKeyValue value of parent object's primary key
	 * @param string $name detail key being referred to
	 * @return string
	 */
	public function getValue($primaryKeyValue, $name)
	{
		if (is_null($this->_details)) $this->load($primaryKeyValue);
		if (array_key_exists($name, $this->_details)) {
			return $this->_details[$name];
		} else {
			return null;
		}
	}

	/**
	 * Assign a value to the specified detail key $name.
	 * @param string $primaryKeyValue value of parent object's primary key
	 * @param string $name detail key being referred to
	 * @param string $value value to store
	 */
	public function setValue($primaryKeyValue, $name, $value)
	{
		if (is_null($this->_details)) $this->load($primaryKeyValue);
		if (empty($value) || is_null($value) || (is_string($value) && strlen($value) == 0)) {
			if (array_key_exists($name, $this->_details)) {
				unset($this->_details[$name]);
			}
		} else {
			$this->_details[$name] = $value;
		}
	}

	/**
	 * Returns the associative array containing all detail key => value pairs
	 * @param string $primaryKeyValue value of parent object's primary key
	 * @return array
	 */
	public function getAllValues($primaryKeyValue)
	{
		if (is_null($this->_details)) $this->load($primaryKeyValue);
		return $this->_details;
	}

	/**
	 * Replaces all of the current detail fields and values with the provided 
	 * associative array containing all detail key => value pairs
	 * @param array $values associative array in format detail_key => value
	 */
	public function setAllValues($values)
	{
		$this->_details = $values;
	}

	/**
	 * Deletes all detail values from the database related to this parent object
	 * @param string $primaryKeyValue value of parent object's primary key
	 */
	public function deleteAll($primaryKeyValue)
	{
		$sql = 'DELETE FROM `'. $this->_table .'` '
		     . 'WHERE `'. $this->_pkcolumn .'` = '. $this->getPkQuoted($primaryKeyValue);
		$this->_db->query($sql);
		$this->_details = array();
	}

	/**
	 * Loads the current detail values stored in the database into the object.
	 * @param string $primaryKeyValue value of parent object's primary key
	 */
	public function load($primaryKeyValue)
	{
		$sql = 'SELECT `'. $this->_dkcolumn .'`, `'. $this->_valuecolumn .'` '
		     . 'FROM `'. $this->_table .'` '
		     . 'WHERE `'. $this->_pkcolumn .'` = '. $this->getPkQuoted($primaryKeyValue);
		$this->_details = $this->_db->fetchPairs($sql);
	}

	/**
	 * Saves the current values for all detail values to the database. Any detail
	 * keys not currently set are deleted from the database.
	 * @param string $primaryKeyValue value of parent object's primary key
	 */
	public function save($primaryKeyValue)
	{
		if (is_null($this->_details)) return;
		$sql = 'DELETE FROM `'. $this->_table .'` '
		     . 'WHERE `'. $this->_pkcolumn .'` = '. $this->getPkQuoted($primaryKeyValue);
		$this->_db->query($sql);
		$values = array();
		$pq = $this->getPkQuoted($primaryKeyValue);
		foreach ($this->_details as $dk => $val) {
			$values[] = '('.$pq.','.$this->_db->quote($dk).','.$this->_db->quote($val).')';
		}
		if ($values) {
			$this->_db->query('INSERT INTO `'. $this->_table .'` VALUES '.implode(',',$values));
		}
	}

	/**
	 * Returns the specified primary key value appropriately escaped and wrapped
	 * in quote for its data type.
	 * @param string $primaryKeyValue value of parent object's primary key
	 */
	protected function getPkQuoted($primaryKeyValue)
	{
		return $this->_db->quote($primaryKeyValue, $this->_pktype);
	}
}