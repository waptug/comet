<?php
/**
 * Specific implementation of system ActivityLog for creation of 
 * an offering record.
 * @author hanisko
 * @package UW_COE_Courses
 */

class Db_ActivityLog_Entered extends Db_ActivityLog_Abstract
{
	
	public function __construct($logid, $autoload = true)
	{
		parent::__construct($logid, $autoload);
		$this->action = 'entered';
	}
	
	/**
	 * Returns a human readable text description of the event this
	 * log entry represents
	 * @see Db_ActivityLog_Abstract::getMessage()
	 * @return string
	 */
	public function getMessage()
	{
		return 'created a new course offering';
	}
	
	/**
	 * Write a new Db_ActivityLog record to the database
	 * @param integer $offeringid
	 * @param integer $enrollment
	 */
	public static function Write($offeringid)
	{
		$log = new self(0, false);
		$log->offeringid = $offeringid;
		$log->save();
	}
	
}