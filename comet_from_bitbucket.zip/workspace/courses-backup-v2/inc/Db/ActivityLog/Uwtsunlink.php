<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Specific implementation of system ActivityLog for recording when
 * a plan record's link to UWTS data is removed.
 * @author hanisko
 */

class Db_ActivityLog_Uwtsunlink extends Db_ActivityLog_Abstract
{
	
	public function __construct($logid, $autoload = true)
	{
		parent::__construct($logid, $autoload);
		$this->action = 'uwtsunlink';
	}
	
	/**
	 * Returns a human readable text description of the event this
	 * log entry represents
	 * @see Db_ActivityLog_Abstract::getMessage()
	 * @return string
	 */
	public function getMessage()
	{
		return 'was linked to a UWTS record, but that record no longer exists, implies offering was canceled in UWTS';
	}
	
	/**
	 * Write a new Db_ActivityLog record to the database
	 * @param integer $offeringid
	 * @param string $status
	 */
	public static function Write($offeringid)
	{
		$log = new self(0, false);
		$log->offeringid = $offeringid;
		$log->save();
	}
	
}