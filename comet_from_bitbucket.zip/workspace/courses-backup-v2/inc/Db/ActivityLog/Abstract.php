<?php
/**
 * Interface to the activitylog database table. 
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

abstract class Db_ActivityLog_Abstract extends DbObject 
{
	public static $actions = array(
		'expected'   => 'Created based on repetition rule',
		'entered'    => 'Created a new offering',
		'meeting'    => 'Changed meeting schedule',
		'staff'      => 'Changed staff',
		'yellowcard' => 'Added a Yellow Card',
		'status'     => 'Change offering status',
		'enrollment' => 'Change enrolled estimate',
		'credits'    => 'Change credit hour estimate',
		'cancel'     => 'Canceled the offering',
		'edit'       => 'Edited offering fields'
	);
	
	public $data;
	
	public function __construct($logid, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'activitylog');
		
		$this->addPrimaryKeyField('logid', $logid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('uwnetid');
		$this->addField('entered', self::TYPE_DATETIME);
		$this->addField('action');
		$this->addField('courseid', self::TYPE_INT);
		$this->addField('offeringid', self::TYPE_INT);
		$this->addField('metadata');
		
		if ($autoload) { 
			$this->load(); 
		} else {
			$this->data = new stdClass();
		}	
	}
	
	/**
	 * Returns an array list of Db_ActivityLog objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters
	 * @return array
	 */
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT * FROM activitylog '.$where.' ORDER BY entered';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$classname = 'Db_ActivityLog_'.ucfirst($row['action']);
			$o = new $classname($row['logid'], false);
			$o->init($row);
			$o->postLoad();
			$out[] = $o;
		}
		return $out;
	}
	
	protected function preInsert()
	{
		$this->preSave();
	}
	
	protected function preUpdate()
	{
		$this->preSave();
	}
	
	protected function preSave()
	{
		// convert metadata to a JSON string
		$this->metadata = json_encode($this->data);
		// if entered date time was not specified use system clock
		if (!$this->entered) { 
			$this->entered = time(); 
		}
		// if user was not specified, search for logged in user
		if (!$this->uwnetid) {
			if (Request::IsCommandLine()) {
				$this->uwnetid = 'system';
			} else {
				$this->uwnetid = User::GetLoggedInUser()->uwnetid;
			}
		}
		// verify this entry is attached to something
		if (!$this->offeringid && !$this->courseid) {
			throw new Exception('ActivityLog entry must refer to an offering or course record');
		}
	}
	
	protected function postLoad()
	{
		if ($this->metadata) {
			$this->data = json_decode($this->metadata);
		} else {
			$this->data = new stdClass();
		}
	}
	
	abstract public function getMessage();
	
}