<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Specific implementation of system ActivityLog for changing the
 * Room schedule status of a course offering
 * @author hanisko
 */

class Db_ActivityLog_Roomrequest extends Db_ActivityLog_Abstract
{
	
	public function __construct($logid, $autoload = true)
	{
		parent::__construct($logid, $autoload);
		$this->action = 'roomrequest';
	}
	
	/**
	 * Returns a human readable text description of the event this
	 * log entry represents
	 * @see Db_ActivityLog_Abstract::getMessage()
	 * @return string
	 */
	public function getMessage()
	{
		return 'changed room request: '.$this->data->newvalue;
	}
	
	/**
	 * Write a new Db_ActivityLog record to the database
	 * @param integer $offeringid
	 * @param string $status
	 */
	public static function Write($offeringid, $status)
	{
		$log = new self(0, false);
		$log->offeringid = $offeringid;
		$log->data->newvalue = $status;
		$log->save();
	}
	
}