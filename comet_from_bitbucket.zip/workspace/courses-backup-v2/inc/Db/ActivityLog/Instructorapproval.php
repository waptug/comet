<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Specific implementation of system ActivityLog for an instructor
 * setting their approval of plan
 * @author hanisko
 */

class Db_ActivityLog_Instructorapproval extends Db_ActivityLog_Abstract
{
	
	public function __construct($logid, $autoload = true)
	{
		parent::__construct($logid, $autoload);
		$this->action = 'instructorapproval';
	}
	
	/**
	 * Returns a human readable text description of the event this
	 * log entry represents
	 * @see Db_ActivityLog_Abstract::getMessage()
	 * @return string
	 */
	public function getMessage()
	{
		return $this->data->approval.' approval for this offering as planned';
	}
	
	/**
	 * Write a new Db_ActivityLog record to the database
	 * @param integer $offeringid
	 * @param boolean $approved (default) true - add approval, false - remove approval
	 */
	public static function Write($offeringid, $approved = true)
	{
		$log = new self(0, false);
		$log->offeringid = $offeringid;
		if ($approved) {
			$log->data->approval = 'added';
		} else {
			$log->data->approval = 'removed';
		}
		$log->save();
	}
	
}