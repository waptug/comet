<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Specific implementation of system ActivityLog for changing the status
 * field to canceled or back to a planned/historical value from canceled.
 * @author hanisko
 */

class Db_ActivityLog_Cancel extends Db_ActivityLog_Abstract
{
	const ACTION_CANCEL_USER = 1;
	const ACTION_CANCEL_UWTS = 2;
	const ACTION_CANCEL_LINKED = 3;
	const ACTION_UNCANCEL_USER = 4;
	const ACTION_UNCANCEL_UWTS = 5;
	
	public function __construct($logid, $autoload = true)
	{
		parent::__construct($logid, $autoload);
		$this->action = 'cancel';
	}
	
	/**
	 * Returns a human readable text description of the event this
	 * log entry represents
	 * @see Db_ActivityLog_Abstract::getMessage()
	 * @return string
	 */
	public function getMessage()
	{
		switch ($this->data->action) {
			case self::ACTION_CANCEL_USER:
				$out = 'set status to Canceled';
				break;
			case self::ACTION_CANCEL_UWTS:
				$out = 'set to Canceled because this offering happened in a past quarter and is not in the UW time schedule';
				break;
			case self::ACTION_CANCEL_LINKED:
				$out = 'was linked to a UWTS record that no longer exists, implies offering was canceled in UWTS';
				break;
			case self::ACTION_UNCANCEL_USER:
				$out = 'changed status from Canceled to Planned';
				break;
			case self::ACTION_UNCANCEL_UWTS:
				$out = 'changed status from Canceled to Historical because this offering happened in a past quarter and is still in the UW time schedule';
				break;
			default:
				$out = 'undefined cancel action '.(int)$this->data->action;
		}
		return $out;
	}
	
	/**
	 * Write a new Db_ActivityLog record to the database
	 * @param integer $offeringid
	 * @param integer $action_code
	 * @param integer $credits
	 */
	public static function Write($offeringid, $action_code)
	{
		$log = new self(0, false);
		$log->offeringid = $offeringid;
		$log->data->action = $action_code;
		$log->save();
	}
	
}