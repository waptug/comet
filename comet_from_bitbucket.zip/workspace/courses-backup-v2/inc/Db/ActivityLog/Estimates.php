<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Specific implementation of system ActivityLog for creation of 
 * an offering record.
 * @author hanisko
 */

class Db_ActivityLog_Estimates extends Db_ActivityLog_Abstract
{
	
	public function __construct($logid, $autoload = true)
	{
		parent::__construct($logid, $autoload);
		$this->action = 'estimates';
	}
	
	/**
	 * Returns a human readable text description of the event this
	 * log entry represents
	 * @see Db_ActivityLog_Abstract::getMessage()
	 * @return string
	 */
	public function getMessage()
	{
		return 'changed offering estimates: '.$this->data->changes;
	}
	
	/**
	 * Write a new Db_ActivityLog record to the database
	 * @param integer $offeringid
	 */
	public static function Write($offeringid, $changes)
	{
		$log = new self(0, false);
		$log->offeringid = $offeringid;
		$log->data->changes = $changes;
		$log->save();
	}
	
}