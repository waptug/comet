<?php
/**
 * Specific implementation of system ActivityLog for updating 
 * meeting schedule.
 * @author hanisko
 * @package UW_COE_Courses
 */

class Db_ActivityLog_Meeting extends Db_ActivityLog_Abstract
{
	
	public function __construct($logid, $autoload = true)
	{
		parent::__construct($logid, $autoload);
		$this->action = 'meeting';
	}
	
	/**
	 * Returns a human readable text description of the event this
	 * log entry represents
	 * @see Db_ActivityLog_Abstract::getMessage()
	 * @return string
	 */
	public function getMessage()
	{
		return 'set meeting times to '.$this->data->newvalue;
	}
	
	/**
	 * Write a new Db_ActivityLog record to the database
	 * @param integer $offeringid
	 * @param string $meetingsummary
	 */
	public static function Write($offeringid, $meetingsummary)
	{
		$log = new self(0, false);
		$log->offeringid = $offeringid;
		$log->data->newvalue = $meetingsummary;
		$log->save();
	}
	
}