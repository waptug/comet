<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Specific implementation of system ActivityLog for adding a tag to a course
 * @author hanisko
 */

class Db_ActivityLog_Tagadd extends Db_ActivityLog_Abstract
{
	
	public function __construct($logid, $autoload = true)
	{
		parent::__construct($logid, $autoload);
		$this->action = 'tagadd';
	}
	
	/**
	 * Returns a human readable text description of the event this
	 * log entry represents
	 * @see Db_ActivityLog_Abstract::getMessage()
	 * @return string
	 */
	public function getMessage()
	{
		return 'added tag "'.$this->data->tagname.'"';
	}
	
	/**
	 * Write a new Db_ActivityLog record to the database
	 * @param integer $offeringid
	 * @param string $status
	 */
	public static function Write(Db_Course $course, Db_Tag $tag)
	{
		$log = new self(0, false);
		$log->courseid = $course->courseid;
		$log->data->tagid = $tag->tagid;
		$log->data->tagname = $tag->name;
		$log->save();
	}
	
}