<?php
/**
 * @package UW_COE_Courses
 */
/**
 * DEPRECATED - Use Db_ActivityLog_Staff. This was the old logging style
 * and needs to remain to display older log records.
 * 
 * Specific implementation of system ActivityLog for changing
 * staff assigned to a course.
 * @author hanisko
 */

class Db_ActivityLog_Staffchange extends Db_ActivityLog_Abstract
{
	
	public function __construct($logid, $autoload = true)
	{
		parent::__construct($logid, $autoload);
		$this->action = 'staffchange';
	}
	
	/**
	 * Returns a human readable text description of the event this
	 * log entry represents
	 * @see Db_ActivityLog_Abstract::getMessage()
	 * @return string
	 */
	public function getMessage()
	{
		return 'changed staff: '.$this->data->changes;
	}
	
	/**
	 * Write a new Db_ActivityLog record to the database
	 * @param integer $offeringid
	 * @param integer $enrollment
	 */
	public static function Write($offeringid, $changes)
	{
		throw new Exception('Logging format deprecated. Use Db_ActivityLog_Staff');
	}
	
}