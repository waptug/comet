<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Specific implementation of system ActivityLog for changing
 * staff assigned to a course.
 * @author hanisko
 */

class Db_ActivityLog_Staff extends Db_ActivityLog_Abstract
{
	
	public function __construct($logid, $autoload = true)
	{
		parent::__construct($logid, $autoload);
		$this->action = 'staff';
	}
	
	/**
	 * Returns a human readable text description of the event this
	 * log entry represents
	 * @see Db_ActivityLog_Abstract::getMessage()
	 * @return string
	 */
	public function getMessage()
	{
		$person = Db_Person::Get($this->data->personid);
		switch ($this->data->action) {
			case 'add':
				$out = 'added '.View_Person::FirstLast($person).' to meeting '.$this->data->meetingnumber;
				break;
			case 'remove':
				$out = 'removed '.View_Person::FirstLast($person).' from meeting '.$this->data->meetingnumber;
				break;
			case 'uwts':
				$out = 'set '.View_Person::FirstLast($person).' as listed in UW time schedule for meeting '.$this->data->meetingnumber;
				break;
			default: 
				$out = $this->data->action.' '.View_Person::FirstLast($person).' for meeting '.$this->data->meetingnumber;
				break;
		}
		return $out;
	}
	
	/**
	 * Write a new Db_ActivityLog record to the database
	 * @param integer $offeringid
	 * @param string $action
	 * @param integer $personid
	 * @param integer $meetingnumber
	 */
	public static function Write($offeringid, $action, $personid, $meetingnumber)
	{
		$log = new self(0, false);
		$log->offeringid = $offeringid;
		$log->data->action = $action;
		$log->data->personid = $personid;
		$log->data->meetingnumber = $meetingnumber;
		$log->save();
	}
	
}