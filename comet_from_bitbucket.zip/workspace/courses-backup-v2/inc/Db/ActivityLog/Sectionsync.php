<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Specific implementation of system ActivityLog for changing offering
 * section letters during sync with UWTS data
 * @author hanisko
 */

class Db_ActivityLog_Sectionsync extends Db_ActivityLog_Abstract
{
	
	public function __construct($logid, $autoload = true)
	{
		parent::__construct($logid, $autoload);
		$this->action = 'sectionsync';
	}
	
	/**
	 * Returns a human readable text description of the event this
	 * log entry represents
	 * @see Db_ActivityLog_Abstract::getMessage()
	 * @return string
	 */
	public function getMessage()
	{
		return 'changed section ID to '.$this->data->section.' while linking offerings to UWTS';
	}
	
	/**
	 * Write a new Db_ActivityLog record to the database
	 * @param integer $offeringid
	 * @param string $status
	 */
	public static function Write($offeringid, $section)
	{
		$log = new self(0, false);
		$log->offeringid = $offeringid;
		$log->data->section = $section;
		$log->save();
	}
	
}