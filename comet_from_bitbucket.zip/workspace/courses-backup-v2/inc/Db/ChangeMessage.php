<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface for Change message records stored in the `changes` database 
 * table. Change messages include original change request, comments, asks
 * for approval, responses to those asks, and resolution.
 * @author hanisko
 */
 
class Db_ChangeMessage extends DbObject
{
	private $_ask;
	private $_author;
	private $_changerequest;
	private $_editedby;
	private $_enteredby;
	private $_offering;
	private $_parent;
	private $_response;
	
	public static $responses = array(
		'approve'  => 'Approved',
		'declined' => 'Declined'	
	);

	public static $resolutions = array(
		'updated' => 'Updated',
		'closed'  => 'Closed',
		'uwts'    => 'Submitted to UW Time Schedule'
	);
	
	public function __construct($changeid, $autoload = true)
	{
		$db = DbConnection::GetInstance();
		parent::__construct($db, 'changes');

		$this->addPrimaryKeyField('changeid', $changeid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('offeringid', self::TYPE_INT);
		$this->addField('parent_changeid', self::TYPE_INT);
		$this->addField('author_personid', self::TYPE_INT);
		$this->addField('entered_date', self::TYPE_DATETIME);
		$this->addField('entered_personid', self::TYPE_INT);
		$this->addField('ask_personid', self::TYPE_INT);
		$this->addField('ask_response_changeid', self::TYPE_INT);
		$this->addField('response');
		$this->addField('resolution');
		$this->addField('resolution_changeid', self::TYPE_INT);
		$this->addField('message');
		$this->addField('message_edit_personid', self::TYPE_INT);
		$this->addField('message_edit_date', self::TYPE_DATETIME);

		if ($autoload) { $this->load(); }
	}
	
	public function __get($name)
	{
		switch ($name) {
			case 'ask':
			case 'author':
			case 'changerequest':
			case 'editedby':
			case 'enteredby':
			case 'offering':
			case 'parent':
				$accessor = 'get'.$name;
				return $this->$accessor();
				break;
			default:
				return parent::__get($name);
				break;
		}
	}
	
	/**
	 * Returns true if the provided user has permission to post messages on behalf
	 * of other users.
	 * @param User $user
	 * @return boolean
	 */
	public function canBehalf(User $user)
	{
		return $user->hasRole('admin');
	}
	
	/**
	 * Returns true if the provided user has permission to comment on this change message.
	 * @param User $user
	 * @return boolean
	 */
	public function canComment(User $user)
	{
		// comments need to be on Db_ChangeRequests, not Db_ChangeMessages
		return false;
	}
	
	/**
	 * Returns true if the provided user has permission to edit this change message.
	 * @param User $user
	 * @return boolean
	 */
	public function canEdit(User $user)
	{
		if ($user->personid && $user->personid == $this->author_personid) {
			return true;
		}
		if ($user->hasRole('admin')) {
			return true;
		}
		return false;
	}
	
	/**
	 * Returns true if the provided user has permission to respond to an
	 * Ask for Approval message.
	 * @param User $user
	 * @return boolean
	 */
	public function canRespond(User $user)
	{
		if ($user->personid && $user->personid == $this->ask_personid) {
			return true;
		}
		if ($user->hasRole('admin')) {
			return true;
		}
		return false;
	}
	
	/**
	 * Returns true if this object is resolvable and provided user has permission.
	 * @param User $user
	 * @return boolean
	 */
	public function canResolve(User $user)
	{
		// Only Db_ChangeRequest objects can be resolved
		return false;
	}

	/**
	 * Returns the Db_ChangeMessage object that this change message is a response to
	 * @return Db_ChangeMessage
	 */
	public function getAsk()
	{
		if (is_null($this->_ask) && $this->ask_personid && $this->ask_response_changeid) {
			$this->_ask = Db_ChangeMessage::Get($this->ask_response_changeid);
		}
		return $this->_ask;
	}

	/**
	 * Returns a Db_Person object that is the author of this change request
	 * @return Db_Person
	 */
	public function getAuthor()
	{
		if (is_null($this->_author)) {
			$this->_author = Db_Person::Get($this->author_personid);
		}
		return $this->_author;
	}

	/**
	 * Returns a Db_ChangeRequest object that is the parent change request
	 * @return Db_ChangeRequest
	 */
	public function getChangerequest()
	{
		if (is_null($this->_changerequest) && $this->parent_changeid) {
			$this->_changerequest = new Db_ChangeRequest($this->parent_changeid);
		}
		return $this->_changerequest;
	}
	
	/**
	 * Returns a human readable description of a message in cases where the message does
	 * not require the comment field (Ask, Respond, Resolution).
	 * @return string|NULL
	 */
	public function getDescription()
	{
		if ($this->isAsk()) {
			return 'Asked '.View_Person::FirstLast(Db_Person::Get($this->ask_personid)).' for approval.';
		}
		if ($this->isResolution() && array_key_exists($this->resolution, self::$resolutions)) {
			return self::$resolutions[$this->resolution].'.';
		}
		if ($this->isResponse() && array_key_exists($this->response, self::$responses)) {
			return self::$responses[$this->response].'.';
		}
		return null;
	}
	
	/**
	 * Returns a Db_Person object that last edited this change request
	 * @return Db_Person
	 */
	public function getEditedby()
	{
		if (is_null($this->_editedby)) {
			$this->_editedby = Db_Person::Get($this->message_edit_personid);
		}
		return $this->_editedby;
	}
	
	/**
	 * Returns a Db_Person object that originally entered this change request
	 * @return Db_Person
	 */
	public function getEnteredby()
	{
		if (is_null($this->_enteredby)) {
			$this->_enteredby = Db_Person::Get($this->entered_personid);
		}
		return $this->_enteredby;
	}

	/**
	 * Returns the Db_Offering object that this change request belongs to
	 * @return Db_Offering
	 */
	public function getOffering()
	{
		if (is_null($this->_offering) && $this->offeringid) {
			$this->_offering = Db_Offering::Get($this->offeringid);
		}
		return $this->_offering;
	}

	/**
	 * Returns the Db_ChangeRequest object that this change message belongs to
	 * @return Db_ChangeRequest
	 */
	public function getParent()
	{
		if (is_null($this->_parent) && $this->parent_changeid) {
			$this->_parent = Db_ChangeRequest::Get($this->parent_changeid);
		}
		return $this->_parent;
	}
	
	/**
	 * Return the Db_ChangeRequest that represents the matching response when
	 * this message is an ask for approval and it has a response.
	 * @return Db_ChangeMessage|NULL
	 */
	public function getResponse()
	{
	    if (is_null($this->_response) && $this->ask_response_changeid) {
	        $this->_response = Db_ChangeMessage::Get($this->ask_response_changeid);
	    }
	    return $this->_response;
	}
	
	/**
	 * Returns true if this message is an Ask for Approval message
	 * @return boolean
	 */
	public function isAsk()
	{
		return (boolean)$this->ask_personid;
	}
	
	/**
	 * Returns true if this message is a parent Change Request
	 * @return boolean
	 */
	public function isChangeRequest()
	{
		return is_null($this->parent_changeid);
	}
	
	/**
	 * Returns true if this message is a parent Change Request
	 * @return boolean
	 */
	public function isResolution()
	{
		return (boolean)$this->resolution;
	}
	
	/**
	 * Returns true if this message is a parent Change Request
	 * @return boolean
	 */
	public function isResponse()
	{
		return (boolean)$this->response;
	}
	
	/**
	 * Returns true if this message is and Ask for Approval, the response has not yet
	 * been entered and the parent change request is not resolved.
	 * @return boolean
	 */
	public function needsResponse()
	{
		if ($this->ask_personid && !$this->ask_response_changeid && !$this->changerequest->resolution_changeid) {
			return true;
		}
		return false;
	}

	/**
	 * Inject a Db_Person object that represents the author of this change message
	 * @param Db_Person $person
	 */
	public function setAuthor(Db_Person $person) 
	{
		$this->_author = $person;
	}
	
	/**
	 * Sets the author_personid and entered_personid fields on a message object.
	 * @param integer $user_personid
	 * @param integer $behalfof_personid
	 */
	public function setAuthorFields($user_personid, $behalfof_personid = null)
	{
		if ($behalfof_personid && $behalfof_personid != $user_personid) {
			$this->author_personid = $behalfof_personid;
			$this->entered_personid = $user_personid;
		} else {
			$this->author_personid = $user_personid;
			$this->entered_personid = null;
		}
	}

	/**
	 * Sets the Db_ChangeRequest object that is the parent change request
	 * @param Db_ChangeRequest
	 */
	public function setChangerequest(Db_ChangeRequest $changerequest)
	{
		$this->parent_changeid = $changerequest->changeid;
		$this->_changerequest = $changerequest;
	}

	/**
	 * Set the Db_ChangeMessage object that is the parent of this object
	 * @return Db_ChangeMessage
	 */
	public function setParent(Db_ChangeMessage $change)
	{
		$this->_parent = $change;
	}

	/**
	 * Sets the Db_Offering object that this change request belongs to
	 * @param Db_Offering
	 */
	public function setOffering(Db_Offering $offering)
	{
		$this->offeringid = $offering->offeringid;
		$this->_offering = $offering;
	}
	
	/**
	 * Specify the Db_ChangeMessage object that represents a response to an
	 * ask for approval.
	 * @param Db_ChangeMessage $response
	 */
	public function setResponse(Db_ChangeMessage $response) 
	{
		$this->_response = $response;
	    $this->ask_response_changeid = $response->changeid;
	}
	
	protected function preSave()
	{
		if (!$this->entered_date) {
			$this->entered_date = time();
		}
		if (!$this->author_personid) {
			$this->author_personid = User::GetLoggedInUser()->personid;
		}
	}
	
	protected function postSave()
	{
		// communicate changes from a message to the parent record
		if ($this->parent) {
			// If resolution has value and parent is not yet resolved, it should be
			if ($this->resolution) {
				if (!$this->parent->resolution_changeid) {
					$this->parent->resolution_changeid = $this->changeid;
					$this->parent->save();
				}
			} else {
				// If resolution is empty, and this was resolving message, parent is no longer resolved
				if ($this->parent->resolution_changeid == $this->changeid) {
					$this->parent->resolution_changeid = null;
					$this->parent->save();
				}
			}
		}
		// communicate changes from an ask response to the ask message
		if ($this->ask) {
			// If response has value and matching ask is not yet linked, it should be
			if ($this->getResponse()) {
				if (!$this->ask->ask_response_changeid) {
					$this->ask->ask_response_changeid = $this->changeid;
					$this->ask->save();
				}
			} else {
				// If response is empty, and this was response to an ask, unlink the ask
				if ($this->ask->ask_response_changeid == $this->changeid) {
					$this->ask->ask_response_changeid = null;
					$this->ask->save();
				}
			}
		}
	}
	
	protected function postDelete()
	{
		$db = DbFactory::GetConnection();
		$db->query('UPDATE changes SET ask_response_changeid = NULL WHERE ask_response_changeid = '.$this->changeid);
		$db->query('UPDATE changes SET resolution_changeid = NULL WHERE resolution_changeid = '.$this->changeid);
		$db->query('DELETE FROM changes WHERE parent_changeid = '.$this->changeid);
	}
	
	/**
	 * Get an instance of Db_ChangeMessage identified by $changeid. Utilizes
	 * the application ObjectRegistry to prevent multiple loading and 
	 * instances of the same record.
	 * @param integer $offeringid
	 * @return Db_ChangeMessage
	 */
	public static function Get($changeid)
	{
		$out = ObjectRegistry::Get(__CLASS__, $changeid);
		if (is_null($out)) {
			$out = new self($changeid);
			ObjectRegistry::Add(__CLASS__, $changeid, $out);
		}
		return $out;
	}
	
	/**
	 * Create an instance of Db_ChangeMessage from an associative array returned by
	 * a database query. Checks the ObjectRegistry before instantiating a new
	 * object.
	 * @param array $row
	 * @return Db_ChangeMessage
	 */
	public static function Register($row)
	{
		$out = ObjectRegistry::Get(__CLASS__, $row['changeid']);
		if (is_null($out)) {
			$out = new self($row['changeid'], false);
			$out->init($row);
			ObjectRegistry::Add(__CLASS__, $row['changeid'], $out);
		}
		return $out;
	}
	
}