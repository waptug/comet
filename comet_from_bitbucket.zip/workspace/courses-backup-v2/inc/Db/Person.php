<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to the person database table. An person represents
 * a system user as well as instructors and support staff assigned 
 * to course offerings.
 * @author hanisko
 */

/**
 * @property integer  $personid
 * @property string   $firstname
 * @property string   $lastname
 * @property string   $uwnetid
 * @property string   $ein
 * @property integer  $facultysequence
 * @property string   $regid
 * @property string   $email
 * @property string   $phone
 * @property string   $source
 * @property string   $area
 * @property integer  $faculty_rouid
 * @property integer  $isfaculty
 * @property integer  $isadjunct
 * @property integer  $isstudentstaff
 * @property integer  $issupport
 * @property integer  $workflow
 */
class Db_Person extends DbObject implements Interface_Person
{
	private $_auth;
	
	public static $areas = array(
		''      => '(Not tenure track faculty)',
		'und'   => 'Carol Davis',
		'grad'  => 'Joy Williamson-Lott',
		'pro'   => 'Cap Peck',
		'EDC&I' => 'EDC&I',
		'EDPSY' => 'EDPSY',
		'EDLPS' => 'EDLPS',
		'EDSPE' => 'EDSPE',
	);
	
	public function __construct($personid, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'person');
		
		$this->addPrimaryKeyField('personid', $personid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('firstname');
		$this->addField('lastname');
		$this->addField('uwnetid');
		$this->addField('ein');
		$this->addField('facultysequence', self::TYPE_INT);
		$this->addField('regid');
		$this->addField('email');
		$this->addField('phone');
		$this->addField('source');
		$this->addField('area');
		$this->addField('faculty_rouid', self::TYPE_INT);
		$this->addField('isfaculty', self::TYPE_BOOLEAN, false);
		$this->addField('isadjunct', self::TYPE_BOOLEAN, false);
		$this->addField('isstudentstaff', self::TYPE_BOOLEAN, false);
		$this->addField('issupport', self::TYPE_BOOLEAN, false);
		$this->addField('workflow', self::TYPE_BOOLEAN, false);
		
		if ($autoload) { $this->load(); }	
	}
	
	public function __get($name) 
	{
		switch ($name) {
			case 'auth':
				return $this->getAuth();
				break;
			case 'areaname':
				return $this->getAreaname();
				break;
			default:
				return parent::__get($name);
				break;
		}
	}

    public function __set($name, $value)
    {
        switch ($name) {
            case 'uwnetid':
                $this->setUwnetid($value);
                break;
            case 'ein':
                $this->setEin($value);
                break;
            default:
                parent::__set($name, $value);
                break;
        }
    }
	
	/**
	 * Load a Db_Person object by finding a matching UWNetID in the
	 * database. If no match is found returns a new Db_Person object
	 * with the uwnetid property set.
	 * @param string $uwnetid
	 * @return Db_Person
	 */
	public static function FetchByUwnetid($uwnetid)
	{
		if (!$uwnetid) return self::GetUnknownPerson();
		$db = DbFactory::GetConnection();
		$personid = $db->fetchOne('SELECT personid FROM person WHERE uwnetid = '.$db->quote($uwnetid));
		if ($personid) {
			$out = self::Get($personid);
		} else {
			$out = self::GetUnknownPerson($uwnetid);
		}
		return $out;
	}
	
	/**
	 * Load a Db_Person object by finding a matching an Employee ID
	 * number in the database. If no match is found returns a new 
	 * Db_Person object with the EIN property set.
	 * @param string $ein
	 * @return Db_Person
	 */
	public static function FetchByEin($ein)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM person WHERE ein = '.$db->quote($ein);
		$row = $db->fetchRow($sql);
		if ($row) {
			$out = new self($row['personid'], false);
			$out->init($row);
		} else {
			$out = self::GetUnknownPerson();
			$out->ein = $ein;
		}
		return $out;
	}
	
	/**
	 * Load a Db_Person object by finding a matching a SWS RegID identifier 
	 * in the database. If no match is found returns a new Db_Person object 
	 * with the regid property set.
	 * @param string $regid
	 * @return Db_Person
	 */
	public static function FetchByRegid($regid)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM person WHERE regid = '.$db->quote($regid);
		$row = $db->fetchRow($sql);
		if ($row) {
			$out = new self($row['personid'], false);
			$out->init($row);
		} else {
			$out = self::GetUnknownPerson();
			$out->regid = $regid;
		}
		return $out;
	}
	
	/**
	 * Load a Db_Person object by finding a matching a SWS RegID identifier 
	 * in the database. If no match is found creates a new person record in
	 * the database by looking up data in the Student Web Service
	 * @param string $regid
	 * @return Db_Person
	 */
	public static function FetchFromSws($regid)
	{
		$person = Db_Person::FetchByRegid($regid);
		if (!$person->recordExists()) {
			$sws = new \Update\Person\FromSws($person);
			$sws->updateAll();
			$person->save();
		}
		return $person;
	}
	
	/**
	 * Returns an array list of Db_Person objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters 
	 * @return array
	 */
	public static function FetchIndex($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT personid, CONCAT(lastname, \', \', firstname) AS name FROM person '.$where.' ORDER BY lastname, firstname';
		return $db->fetchPairs($sql);
	}
	
	/**
	 * Returns an array list of Db_Person objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters 
	 * @return array
	 */
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT * FROM person '.$where.' ORDER BY lastname, firstname';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$out[] = Db_Person::Register($row);
		}
		return $out;
	}
	
	public function getAreaname()
	{
		if ($this->area && array_key_exists($this->area, self::$areas)) {
			return self::$areas[$this->area];
		} else {
			return 'none';
		}
	}
	
	/**
	 * Returns the Db_Auth object associated with this record. If this person
	 * has no system authorization returns false;
	 * @return Db_Person
	 */
	public function getAuth()
	{
		if (!$this->uwnetid) {
			$this->_auth = false;
			return $this->_auth;
		}
		if (is_null($this->_auth)) {
			$auth = new Db_Auth($this->uwnetid);
			if ($auth->recordExists()) {
				$this->_auth = $auth;
			} else {
				$this->_auth = false;
			}
		}
		return $this->_auth;
	}
	
	/**
	 * Return the contents of the firstname property. Satisfies the
	 * Interface_Person requirement.
	 * @return string
	 */
	public function getFirstname()
	{
		return $this->firstname;
	}
	
	/**
	 * Return the contents of the lastname property. Satisfies the
	 * Interface_Person requirement.
	 * @return string
	 */
	public function getLastname()
	{
		return $this->lastname;
	}
	
	/**
	 * Returns an empty person object with default values.
	 * @return Db_Person
	 */
	public static function GetUnknownPerson($uwnetid = null)
	{
		$person = new self(0, false);
		$person->lastname = 'unknown';
		$person->uwnetid = $uwnetid;
		return $person;
	}

	/**
	 * Returns a Db_Person object based on variable search criteria. Implemented
	 * personid, uwnetid
	 * @return Db_Person
	 */
	public static function Locate($search)
	{
		if (is_numeric($search)) {
			return self::Get($search);
		}
		return self::FetchByUwnetid($search);
	}
	
	/**
	 * Create a new Db_Person object and populate the value based on
	 * values in an associative array.
	 * 
	 * @param array $values
	 * @return Db_Person
	 */
	public static function MakePerson($values)
	{
		$uwnetid = self::HashSearch($values, 'uwnetid');
		if ($uwnetid) {
			$person = self::FetchByUwnetid($uwnetid);
		} else {
			$person = self::GetUnknownPerson();
		}
		$person->firstname = self::HashSearch($values, 'firstname');
		$person->lastname = self::HashSearch($values, 'lastname');
		$person->email = self::HashSearch($values, 'email');
		$person->phone = self::HashSearch($values, 'phone');
		$person->source = self::HashSearch($values, 'source');
		if ($person->uwnetid && !$person->email) {
			$person->email = $person->uwnetid.'@uw.edu';
		}
		return $person;
	}
	
	/**
	 * Update this person's status as a system user
	 * @param string $role one of 'noauth', 'faculty', 'admin', 'dean', 'super'
	 */
	public function saveUser($role = null)
	{
		if (!$this->uwnetid) {
			return;
		}
		if ($role && isset(Db_Auth::$roles[$role])) {
			$setRole = $role;
		} else {
			$setRole = false;
		}
		$this->_auth = new Db_Auth($this->uwnetid);
		if ($setRole == 'noauth') {
			$this->_auth->delete();
			unset($this->_auth);
			return;
		} 
		if ($setRole) {
			$this->_auth->role = $setRole;
			$this->_auth->save();
			return;
		}
		// Faculty and adjuncts are made users to review their schedules
		if ((!$this->_auth->recordExists() || $this->_auth->role == 'noauth') && ($this->isfaculty || $this->isadjunct)) {
			$this->_auth->role = 'faculty';
			$this->_auth->save();
			return;
		}
	}

    public function setEin($ein)
    {
        $ein = str_replace('-', '', $ein);
        parent::__set('ein', $ein);
    }

    public function setUwnetid($uwnetid)
    {
        $atpos = strpos($uwnetid, '@');
        if ($atpos !== false) {
            $uwnetid = substr($uwnetid, 0, $atpos);
        }
        parent::__set('uwnetid', $uwnetid);
    }

    /**
     * Search an associative array for a value matching the specified
     * $index. If that value does not exist, return $default.
     * @param array $array
     * @param string $index
     * @param mixed $default
     * @return mixed|null
     */
	private static function HashSearch($array, $index, $default = null)
	{
		if (array_key_exists($index, $array)) {
			return $array[$index];
		} else {
			return $default;
		}
	}
	
	/**
	 * Get an instance of Db_Person identified by $personid. Utilizes
	 * the application ObjectRegistry to prevent multiple loading and 
	 * instances of the same record.
	 * @param integer $personid
	 * @return Db_Person
	 */
	public static function Get($personid)
	{
		$out = ObjectRegistry::Get(__CLASS__, $personid);
		if (is_null($out)) {
			$out = new self($personid);
			ObjectRegistry::Add(__CLASS__, $personid, $out);
		}
		return $out;
	}
	
	/**
	 * Create an instance of Db_Person from an associative array returned by
	 * a database query. Checks the ObjectRegistry before instantiating a new
	 * object.
	 * @param array $row
	 * @return Db_Person
	 */
	public static function Register($row)
	{
		$out = ObjectRegistry::Get(__CLASS__, $row['personid']);
		if (is_null($out)) {
			$out = new self($row['personid'], false);
			$out->init($row);
			ObjectRegistry::Add(__CLASS__, $row['personid'], $out);
		}
		return $out;
	}
	
}