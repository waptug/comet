<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to the staff database table. A staff object represents
 * a person assigned to a course offering such as an instructor or
 * TA.
 * @author Paul Hanisko
 */

/**
 * @property integer  $staffid
 * @property integer  $offeringid
 * @property integer  $meetingnumber
 * @property integer  $personid
 * @property string   $role
 * @property integer  $timesched
 * @property integer  $buyoutreason
 * @property integer  $repetitionindex
 */
class Db_Staff extends DbObject implements Interface_Person
{
    public static $roles = array(
        'faculty' => 'Faculty',
        'adjunct' => 'Adjunct'
    );

    public static $other_roles = array(
        'grader'  => 'Grader',
        'ta'      => 'Teaching Assistant',
        'buyout'  => 'Faculty buy out',
        'support' => 'Academic support team'
    );

	public static $buyout_reasons = array(
    	'0' => '(reason unknown)',
    	'1' => 'Administrative buy out',
    	'2' => 'Grant buy out',
        '3' => 'Retired faculty rehire',
    	'4'  => 'Sabbatical',
    	'5'  => 'Self-sustaining',
    	'6'  => 'Tenure-track vacancy',
    	'9'  => 'Tradition',
		'10' => 'No faculty expertise'
	);
	
	private $_offering;
	private $_person;
	
	public function __construct($staffid, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'staff');
		
		$this->addPrimaryKeyField('staffid', $staffid, self::TYPE_INT, true);
		$this->addField('offeringid', self::TYPE_INT);
		$this->addField('meetingnumber', self::TYPE_INT, 1);
		$this->addField('personid', self::TYPE_INT);
		$this->addField('role');
		$this->addField('timesched', self::TYPE_BOOLEAN, 0);
		$this->addField('buyoutreason', self::TYPE_INT);
		$this->addField('repetitionindex', self::TYPE_INT);
		
		if ($autoload) { $this->load(); }	
	}
	
	public function __get($name)
	{
		switch ($name) {
			case 'rolename':
			case 'offering':
			case 'person':
			case 'buyoutreasonname':
				$accessor = 'get'.$name;
				return $this->$accessor();
				break;
			case 'firstname':
			case 'lastname':
			case 'uwnetid':
			case 'ein':
			case 'regid':
			case 'email':
			case 'phone':
			case 'source':
				return $this->person->$name;
				break;
			default:
				return parent::__get($name);
				break;
		}
	}
	
	public function __set($name, $value)
	{
		switch ($name) {
			case 'personid':
				$this->setPersonid($value);
				break;
			default:
				parent::__set($name, $value);
				break;
		}
	}
	
	/**
	 * Search for a matching staff record using natural candidate key
	 * parameters. This function supports loading external data to 
	 * prevent generation of duplicate records.
	 * 
	 * @param integer $offeringid pk of the parent course offeringrecord
	 * @param integer $personid pk of the related person record
	 * @return Db_Offering
	 */
	public static function ImportStaff($offeringid, $meetingnumber, $personid)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM staff '
		     . 'WHERE offeringid = '.$offeringid.' '
		     . 'AND meetingnumber = '.$meetingnumber.' '
		     . 'AND personid = '.$personid;
		$row = $db->fetchRow($sql);
		if ($row) {
			$out = new self($row['staffid'], false);
			$out->init($row);
		} else {
			$out = new self(0, false);
			$out->offeringid = $offeringid;
			$out->meetingnumber = $meetingnumber;
			$out->personid = $personid;
		}
		return $out;
	}
	
	/**
	 * Returns true if business rules allow this staff record to be the primary instructor
	 * @return boolean
	 */
	public function canBePrimary()
	{
		if ($this->role == 'instructor' || $this->role == 'faculty' || $this->role == 'adjunct') {
			if (!$this->person->issupport) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Returns an array list of Db_Staff objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters 
	 * @return array
	 */
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT * FROM staff '.$where.' ORDER BY offeringid, meetingnumber, timesched DESC';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$o = ObjectRegistry::Get(__CLASS__, $row['staffid']);
			if (!$o) {
				$o = new self($row['staffid'], false);
				$o->init($row);
				ObjectRegistry::Add(__CLASS__, $row['staffid'], $o);
			}
			$out[] = $o;
		}
		return $out;
	}
	
	/**
	 * Returns a single personid of a faculty who is assigned to the same
	 * offering as a buyout. Used to populate the adjunct buy out for field
	 * on the add staff form.
	 * @return integer
	 */
	public function getBuyoutPersonid()
	{
		$db = DbFactory::GetConnection();
		return $db->fetchOne('SELECT personid FROM staff WHERE role = \'buyout\' AND offeringid = '.$this->offeringid);
	}
	
	/**
	 * Returns the Db_Person object related to this staff record. This
	 * method is exposed through the "offering" virtual property to support
	 * loading on first use.
	 * @return array
	 */
	protected function getOffering()
	{
		if (is_null($this->_offering)) {
			$this->_offering = new Db_Offering($this->offeringid);
		}
		return $this->_offering;
	}
	
	/**
	 * Returns the Db_Person object related to this staff record. This
	 * method is exposed through the "person" virtual property to support
	 * loading on first use.
	 * @return array
	 */
	protected function getPerson()
	{
		if (is_null($this->_person)) {
			$this->_person = Cache_Person::Locate($this->personid);
		}
		return $this->_person;
	}
	
	/**
	 * Translate the buy out reason code into human readable string.
	 * @return string
	 */
	protected function getBuyoutreasonname()
	{
		if (array_key_exists($this->buyoutreason, self::$buyout_reasons)) {
			return self::$buyout_reasons[$this->buyoutreason];
		} else {
			return $this->buyoutreason;
		}
	}
	
	/**
	 * Return a decoded human readable version of the staff role property
	 * @return string
	 */
	protected function getRolename()
	{
		if (array_key_exists($this->role, self::$roles)) {
			return self::$roles[$this->role];
		} else {
			return $this->role;
		}
    }

    /**
     * Return merged roles array
     * @return array
     */
    public static function getRoles()
    {
        return array_merge(self::$roles,self::$other_roles);
    }
	
	/**
	 * Return the contents of the firstname property. Satisfies the
	 * Interface_Person requirement.
	 * @return string
	 */
	public function getFirstname()
	{
		return $this->firstname;
	}
	
	/**
	 * Return the contents of the lastname property. Satisfies the
	 * Interface_Person requirement.
	 * @return string
	 */
	public function getLastname()
	{
		return $this->lastname;
	}
	
	/**
	 * Sets the Db_Offering object related to this staff record. Supports
	 * bulk loading of staff records.
	 * @param Db_Offering $person
	 */
	public function setOffering(Db_Offering $offering)
	{
		$this->_offering = $offering;
	}
	
	/**
	 * Sets the Db_Person object related to this staff record. Supports
	 * bulk loading of staff records.
	 * @param Db_Person $person
	 */
	public function setPerson(Db_Person $person)
	{
		$this->_person = $person;
	}
	
	/**
	 * Set the value of the personid property. If this is a change in personid
	 * unload the Db_Person object.
	 * @param integer $value
	 */
	public function setPersonid($value)
	{
		if ($value != $this->personid) {
			$this->_person = null;
		}
		parent::__set('personid', $value);
	}
	
	protected function preInsert()
	{
		$this->uniqueTimesched();
	}
	
	protected function preUpdate()
	{
		$this->uniqueTimesched();
	}
	
	protected function postDelete()
	{
		// make sure there is a UWTS instructor
		$db = DbFactory::GetConnection();
		$sql = 'SELECT s.staffid, s.timesched '
		     . 'FROM staff s '
		     . 'INNER JOIN person p '
		     . 'ON s.personid = p.personid '
		     . 'WHERE s.offeringid = '.$this->offeringid.' '
		     . 'AND s.meetingnumber = '.$this->meetingnumber.' '
		     . "AND s.role IN('faculty', 'adjunct', 'instructor')"
		     . 'AND p.issupport <> 1';
		$results = $db->fetchPairs($sql);
		$staffid = false;
		$hasuwts = false;
		foreach ($results as $staffid => $timesched) {
			if ($timesched) {
				$hasuwts = true;
				break;
			}
		}
		if (!$hasuwts && $staffid) {
			$db->query('UPDATE staff SET timesched = 1 WHERE staffid = '.$staffid);
		}
	}
	
	/**
	 * One and only one staff record per meeting must have the timesched flag set.
	 * If the record we are saving now has the flag set, change all other flags to 
	 * false. If no other records have the flag set, this one should.
	 */
	protected function uniqueTimesched()
	{
		$db = DbFactory::GetConnection();
		if ($this->timesched) {
			$sql = 'UPDATE staff SET timesched = 0 WHERE offeringid = '.$this->offeringid.' AND meetingnumber = '.$this->meetingnumber.' AND staffid <> '.$this->staffid;
			$db->query($sql);
		} else {
			if ($this->role == 'instructor' || $this->role == 'faculty' || $this->role == 'adjunct') {
				$sql = 'SELECT COUNT(staffid) AS qty '
				     . 'FROM staff '
				     . 'WHERE offeringid = '.$this->offeringid.' '
				     . 'AND meetingnumber = '.$this->meetingnumber.' '
				     . 'AND staffid <> '.$this->staffid.' '
				     . 'AND timesched = 1';
				$hasUwts = $db->fetchOne($sql);
				if (!$hasUwts) {
					if (!$this->person->issupport) $this->timesched = true;
				}
			}
		}
	}
	
	/**
	 * Get an instance of Db_Staff identified by $staffid. Utilizes
	 * the application ObjectRegistry to prevent multiple loading and 
	 * instances of the same record.
	 * @param integer $staffid
	 * @return Db_Staff
	 */
	public static function Get($staffid)
	{
		$out = ObjectRegistry::Get(__CLASS__, $staffid);
		if (is_null($out)) {
			$out = new self($staffid);
			ObjectRegistry::Add(__CLASS__, $staffid, $out);
		}
		return $out;
	}
	
	/**
	 * Create an instance of Db_Staff from an associative array returned by
	 * a database query. Checks the ObjectRegistry before instantiating a new
	 * object.
	 * @param array $row
	 * @return Db_Staff
	 */
	public static function Register($row)
	{
		$out = ObjectRegistry::Get(__CLASS__, $row['staffid']);
		if (is_null($out)) {
			$out = new self($row['staffid'], false);
			$out->init($row);
			ObjectRegistry::Add(__CLASS__, $row['staffid'], $out);
		}
		return $out;
	}
	
}
