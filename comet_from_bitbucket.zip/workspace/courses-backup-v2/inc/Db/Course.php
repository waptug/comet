<?php
/**
 * @package edu.uw.education.courses
 */
/**
 * Interface to the course database table. A course represents
 * a recurring teaching unit.
 */

/**
 * @property integer  $courseid
 * @property string   $curriculum
 * @property integer  $courseno
 * @property string   $title
 * @property string   $shorttitle
 * @property string   $wildcardtitle
 * @property string   $coursecreditcontrol
 * @property integer  $coursecreditmin
 * @property integer  $coursecreditmax
 * @property integer  $creditrepeatmax
 * @property integer  $creditestimate
 * @property string   $general_education
 * @property integer  $rouid
 * @property integer  $orgunitid
 * @property string   $firstquarter
 * @property string   $lastquarter
 * @property integer  $swslastupdate  Unix timestamp
 */
class Db_Course extends DbObject 
{
	//the full description text is case senseitive and should not be changed - for ease, it matches the name of the XML property returned by SWS [when the spaces are removed]
	public static $general_education_flags = array(
		'C' => "English Composition",
		'I&S' => "Individuals And Societies",
		'NW' => "Natural World",
		'QSR' => "Quantitative And Symbolic Reasoning",
		'VPLA' => "Visual, Literary And Performing Arts",
		'W' => "Writing",
		'DIV' => "Diversity"
	);

	private $_offerings;
	private $_history;
	private $_future;
	private $_repetitionrules;
	private $_rou;
	private $_ws;
	private $_details;
	
	public function __construct($courseid, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'course');
		
		$this->addPrimaryKeyField('courseid', $courseid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('curriculum');
		$this->addField('courseno', self::TYPE_INT);
		$this->addField('title');
		$this->addField('shorttitle');
		$this->addField('wildcardtitle');
		$this->addField('coursecreditcontrol');
		$this->addField('coursecreditmin', self::TYPE_INT);
		$this->addField('coursecreditmax', self::TYPE_INT);
		$this->addField('creditrepeatmax', self::TYPE_INT);
		$this->addField('creditestimate', self::TYPE_INT);
		$this->addField('general_education');
		/*$this->addField('writing', self::TYPE_BOOLEAN, 0);
		$this->addField('qsr', self::TYPE_BOOLEAN, 0);
		$this->addField('indivsociety', self::TYPE_BOOLEAN, 0);*/
		$this->addField('rouid', self::TYPE_INT, 999);
		$this->addField('firstquarter');
		$this->addField('lastquarter');
		$this->addField('swslastupdate', self::TYPE_DATETIME);
		
		if ($autoload) { $this->load(); }	
	}
	
	public function __get($name)
	{
		switch ($name) {
			case 'future':
			case 'history':
			case 'offerings':
			case 'repetitionrules':
			case 'rou':
			case 'summaryname':
				$accessor = 'get'.$name;
				return $this->$accessor();
				break;
			case 'description':
				return $this->getDetail($name);
				break;
			default:
				return parent::__get($name);
				break;
		}
	}
	
	public function __set($name, $value)
	{
		switch ($name) {
			case 'description':
				$this->setDetail($name, $value);
				break;
			default:
				parent::__set($name, $value);
				break;
		}
	}
	
	/**
	 * Returns the Db_Course object with same curriculum and courseno
	 * that has no wildcardtitle.
	 * @return Db_Course
	 */
	public function fetchBaseCourse()
	{
		$db = DbFactory::GetConnection();
		// find the base course record with no wildcard title
		$sql = 'SELECT * '
		     . 'FROM course '
		     . 'WHERE curriculum = '.$db->quote($this->curriculum).' '
		     . 'AND courseno = '.$this->courseno.' '
		     . 'AND wildcardtitle IS NULL '
		     . 'ORDER BY courseid';
		$row = $db->fetchRow($sql);
		if ($row) {
			$out = new Db_Course($row['courseid'], false);
			$out->init($row);
		} else {
			// if it is missing, recreate it from the web service
			$out = new Db_Course(0);
			$out->curriculum = $this->curriculum;
			$out->courseno = $this->courseno;
			$sws = new \Update\Course\FromSws($out->curriculum, $out->courseno);
			$sws->update($out);
			$out->save();
		}
		return $out;
	}

	/**
	 * Retrieve a list of courseids that match the specified curriculum and course number.
	 * @param string $curriculum
	 * @param integer $courseno
	 * @return array
	 */
	public static function FetchCourseids($curriculum, $courseno)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT courseid FROM course WHERE curriculum = '.$db->quote($curriculum).' AND courseno = '.$courseno.' ORDER BY wildcardtitle';
		return $db->fetchColumn($sql);
	}
	
	/**
	 * Returns an associative array of curriculum values that exist in
	 * the course table. This array has the UW six character curriculum
	 * code both as index and value. Usable as a select value list on a
	 * form.
	 * @param mixed $filters
	 * @return array
	 */
	public static function FetchCurriculumList($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT DISTINCT curriculum, curriculum FROM course '.$where.' ORDER BY curriculum';
		return $db->fetchPairs($sql);
	}
	
	/**
	 * Returns an associative array of courses in the system represented
	 * by courseid as the index and "Dept Number Title" as the value. If
	 * a course wildcardtitle exists it is used as title, otherwise short
	 * title is used.
	 * @param mixed $filters
	 * @return array
	 */
	public static function FetchIndex($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT courseid, curriculum, courseno, shorttitle, wildcardtitle FROM course '.$where.' ORDER BY curriculum, courseno, shorttitle, wildcardtitle';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			if ($row['wildcardtitle']) {
				$title = $row['curriculum'].' '.$row['courseno'].' '.$row['wildcardtitle'];
			} else {
				$title = $row['curriculum'].' '.$row['courseno'].' '.$row['shorttitle'];
			}
			$out[$row['courseid']] = $title;
		}
		return $out;
	}
	
	/**
	 * Search for a matching course record using natural candidate key
	 * parameters. This function supports loading external data to 
	 * prevent generation of duplicate records.
	 * 
	 * @param string $curriculum UW curriculum code like EDLPS or EDC&I
	 * @param integer $courseno course number like 200 or 526
	 * @param string $wildcardtitle internal title used for generic course numbers
	 * @return Db_Course
	 */
	public static function FetchMatch($curriculum, $courseno, $wildcardtitle)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM course '
		     . 'WHERE curriculum = '.$db->quote($curriculum).' '
		     . 'AND courseno = '.$courseno.' '
		     . 'AND wildcardtitle = '.$db->quote($wildcardtitle);
		$row = $db->fetchRow($sql);
		if ($row) {
			$out = new self($row['courseid'], false);
			$out->init($row);
		} else {
			$out = new self(0, false);
			$out->curriculum = $curriculum;
			$out->courseno = $courseno;
			$out->wildcardtitle = $wildcardtitle;
		}
		return $out;
	} 
	
	/**
	 * Returns an array list of Db_Course objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters 
	 * @return array
	 */
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT * FROM course '.$where.' ORDER BY curriculum, courseno, wildcardtitle';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$o = new self($row['courseid'], false);
			$o->init($row);
			$out[] = $o;
		}
		return $out;
	}
	
	/**
	 * Fetch an associative array list of Wildcard titles associated with the same
	 * course number as the provided offering. Courseid is the array index.
	 * @param Db_Offering $offering
	 * @return array
	 */
	public static function FetchWildcardtitles(Db_Offering $offering)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT courseid, wildcardtitle '
		     . 'FROM course '
		     . 'WHERE curriculum = '.$db->quote($offering->curriculum).' '
		     . 'AND courseno = '.$offering->courseno.' '
		     . 'AND wildcardtitle <>  \'\' '
		     . 'AND wildcardtitle IS NOT NULL '
		     . 'ORDER BY wildcardtitle';
		return $db->fetchPairs($sql);
	}
	
	/**
	 * Returns a new unsaved Db_Course record with a all the same values as this
	 * course record.
	 * @return Db_Course
	 */
	public function getClone()
	{
		$out = new Db_Course(0);
		$out->curriculum = $this->curriculum;
		$out->courseno = $this->courseno;
		$out->title = $this->title;
		$out->shorttitle = $this->shorttitle;
		$out->wildcardtitle = $this->wildcardtitle;
		$out->coursecreditcontrol = $this->coursecreditcontrol;
		$out->coursecreditmin = $this->coursecreditmin;
		$out->coursecreditmax = $this->coursecreditmax;
		$out->creditrepeatmax = $this->creditrepeatmax;
		$out->creditestimate = $this->creditestimate;
		$out->general_education = $this->general_education;
		$out->rouid = $this->rouid;
		$out->firstquarter = $this->firstquarter;
		$out->lastquarter = $this->lastquarter;
		return $out;
	}
	
	/**
	 * Merge the various credit description fields into a single human readable
	 * description of credit policy for this course.
	 * @return string
	 */
	public function getCreditDescription()
	{
		switch ($this->coursecreditcontrol) {
			case 'fixed':
				$out = $this->coursecreditmin.' credits';
				break;
			case 'variable': // variable credit - min to max credits':
				$out = $this->coursecreditmin.' to '.$this->coursecreditmax.' credits';
				break;
			case 'minormax': //'variable credit - min or max credits':
				$out = $this->coursecreditmin.' or '.$this->coursecreditmax.' credits';
				break;
			case 'open': //'variable credit 1 to 25 credits':
				$out = 'Variable credit';
				break;
			default:
				$out = null;
				break;
		}
		return $out;
	}
	
	/**
	 * Return a value from the details data structure
	 * @param string $name
	 * @return string
	 */
	protected function getDetail($name)
	{
		if (is_null($this->_details)) {
			$this->_details = new Details_Course();
		}
		return $this->_details->getValue($this->courseid, $name);
	}
	
	/**
	 * Returns an array of Db_Offering objects related to the course. This
	 * method is exposed through the "offerings" virtual property to support
	 * loading on first use.
	 * @return array
	 */
	protected function getOfferings()
	{
		if (is_null($this->_offerings)) {
			$this->_offerings = Db_Offering::FetchMultiple('courseid = '.$this->courseid);
		}
		return $this->_offerings;
	}
	
	/**
	 * Returns an array of Db_Offering objects related to the course that have
	 * already happened including the current quarter's offerings. This
	 * method is exposed through the "history" virtual property to support
	 * loading on first use.
	 * @return array
	 */
	protected function getHistory()
	{
		if (is_null($this->_history)) {
			$db = DbFactory::GetConnection();
			$cq = Db_Quarter::FetchCurrentQuarter();
			$year = $db->quote($cq->year);
			$filters = array(
				'courseid = '.$this->courseid,
				'(year < '.$year.' OR (year = '.$year.' AND quarter <= '.$cq->quarter.'))'
			);
			$this->_history = Db_Offering::FetchMultiple($filters);
		}
		return $this->_history;
	}
	
	/**
	 * Returns an array of Db_Offering objects related to the course that are
	 * planned to happen in future quarters. This method is exposed through 
	 * the "future" virtual property to support
	 * loading on first use.
	 * @return array
	 */
	protected function getFuture()
	{
		if (is_null($this->_future)) {
			$db = DbFactory::GetConnection();
			$cq = Db_Quarter::FetchCurrentQuarter();
			$year = $db->quote($cq->year);
			$filters = array(
				'courseid = '.$this->courseid,
				'(year > '.$year.' OR (year = '.$year.' AND quarter > '.$cq->quarter.'))'
			);
			$this->_future = Db_Offering::FetchMultiple($filters);
		}
		return $this->_future;
	}
	
	/**
	 * Returns and array of Db_OfferingRule objects related to the course. This
	 * method is exposed through the "offeringrules" virtual property to support
	 * loading on first use.
	 * @return array[Db_Repetition]
	 */
	protected function getRepetitionRules()
	{
		if (is_null($this->_repetitionrules)) {
			$this->_repetitionrules = Db_Repetition::FetchMultiple('courseid = '.$this->courseid);
		}
		return $this->_repetitionrules;
	}
	
	/**
	 * Returns the Db_Rou object for this course
	 * @return Db_Rou
	 */
	public function getRou()
	{
		if (is_null($this->_rou)) {
			$this->_rou = Db_Rou::Get($this->rouid);
		}
		return $this->_rou;
	}
	
	/**
	 * Return a string that gives an identifying description of a course 
	 * object. If the course has a wildcardtitle, that is returned. By default
	 * includes curriculum code and section, pass false as argument to supress
	 * course id.
	 * @param boolean $withnumber
     * @return string 
	 */
	public function getSummaryName($withnumber = true)
	{
		if ($withnumber) {
			$out = $this->curriculum.' '.$this->courseno.' ';
		} else {
			$out = '';
		}
		if ($this->wildcardtitle) {
			$out .= $this->wildcardtitle.'*';
		} else {
			$out .= $this->title;
		}
		return $out;
	}
	
	/**
	 * Returns true if this course record is valid for a specified quarter. Curriculum 
	 * changes over time and course numbers can be reused. Checks if the argument date
	 * is between this course's firstquarter and lastquarter.
	 * @param string $year
	 * @param integer $quarter
	 * @return boolean
	 */
	public function isValidForQuarter($year, $quarter)
	{
		$quarter_code = $year.'-'.$quarter;
		$in_range = true;
		if ($this->firstquarter && ($this->firstquarter > $quarter_code)) {
			$in_range = false;
		} elseif ($this->lastquarter && ($this->lastquarter < $quarter_code)) {
			$in_range = false;
		}
		return $in_range;
	}

	/**
	 * Sets a value from the details data structure
	 * @param string $name
	 * @return string
	 */	
	protected function setDetail($name, $value)
	{
		if (is_null($this->_details)) {
			$this->_details = new Details_Course();
		}
		$this->_details->setValue($this->courseid, $name, $value);
	}
	
	/**
	 * Sets the Db_Rou object for this course
	 * @param Db_Rou
	 */
	public function setRou(Db_Rou $rou)
	{
		$this->_rou = $rou;
	}
	
	/**
	 * Get an instance of Db_Course identified by $courseid. Utilizes
	 * the application ObjectRegistry to prevent multiple loading and 
	 * instances of the same record.
	 * @param integer $courseid
	 * @return Db_Course
	 */
	public static function Get($courseid)
	{
		$out = ObjectRegistry::Get(__CLASS__, $courseid);
		if (is_null($out)) {
			$out = new self($courseid);
			ObjectRegistry::Add(__CLASS__, $courseid, $out);
		}
		return $out;
	}
	
	/**
	 * Create an instance of Db_Course from an associative array returned by
	 * a database query. Checks the ObjectRegistry before instantiating a new
	 * object.
	 * @param array $row
	 * @return Db_Course
	 */
	public static function Register($row)
	{
		$out = ObjectRegistry::Get(__CLASS__, $row['courseid']);
		if (is_null($out)) {
			$out = new self($row['courseid'], false);
			$out->init($row);
			ObjectRegistry::Add(__CLASS__, $row['courseid'], $out);
		}
		return $out;
	}
	
	protected function postInsert()
	{
		$this->postSave();
	}
	
	protected function postUpdate()
	{
		$this->postSave();
	}
	
	protected function postSave()
	{
		if ($this->_details instanceof Details_Course) {
			$this->_details->save($this->courseid);
		}
	}
	
	protected function preDelete()
	{
		$this->_details = new Details_Course();
		$this->_details->deleteAll($this->courseid);
	}
	
}
