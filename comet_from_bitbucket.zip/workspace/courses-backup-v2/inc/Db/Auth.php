<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to the auth database table. An auth record represents
 * a known user that has special permissions in the system.
 * @author hanisko
 */

class Db_Auth extends DbObject
{
	public static $roles = array(
		'noauth'  => '(None) Access to public only',
		'faculty' => '(Faculty) View planning tools, make room and change requests', 
		'admin'   => '(Admin) Create and modify course plans', 
		'dean'    => '(Dean) Admin plus approve faculty course load', 
		'super'   => '(Super) Access to all tools, including system administration'
	);
	
	public function __construct($uwnetid, $autoload = true)
	{
		$db = DbConnection::GetInstance();
		parent::__construct($db, 'auth');

		$this->addPrimaryKeyField('uwnetid', $uwnetid, self::TYPE_CHAR);
		$this->addField('role');
		
		if ($autoload) { $this->load(); }
	}
		
}