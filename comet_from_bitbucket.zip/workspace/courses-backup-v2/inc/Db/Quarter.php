<?php
/**
 * Represents an academic quarter specified by a year and integer
 * indicator of a quarter. Interface for interacting with quarter 
 * records in the database.
 *  
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Db_Quarter extends DbObject 
{
	private static $_currentQuarter = null;
	private static $_allQuarters = null;
	public static $quarterNames = array(
		'1' => 'Winter',
		'2' => 'Spring',
		'3' => 'Summer',
		'4' => 'Autumn'
	);
	
	public function __construct($year, $quarter = false, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'quarter');
		
		if (!$quarter) {
			if (!strpos($year,'-')) {
				throw new Exception('Bad quarter format');
			}
			list($year, $quarter) = explode('-', $year);
		}
		
		$this->addPrimaryKeyField('year', $year, self::TYPE_INT);
		$this->addPrimaryKeyField('quarter', $quarter, self::TYPE_INT);
		$this->addField('description');
		$this->addField('start', self::TYPE_DATETIME);
		$this->addField('end', self::TYPE_DATETIME);
		$this->addField('swslastupdate', self::TYPE_DATETIME);
		
		if ($autoload) { $this->load(); }
	}

	public function __get($name)
	{
		switch ($name)
		{
			case 'quartername':  return $this->getQuarterName();  break;
			default:  return parent::__get($name);  break;
		}
	}
	
	/**
	 * Returns the text name of the integer quarter value of this object
	 * @return string
	 */
	protected function getQuarterName()
	{
		if (array_key_exists($this->quarter, self::$quarterNames)) {
			return self::$quarterNames[$this->quarter];
		} else {
			return $this->quarter;
		}
	}
	
	/**
	 * Compares this quarter object to the argument Db_Quarter object. Returns
	 * -1 if the argument is previous to the instance
	 *  0 if the argument is the same quarter as the instance
	 *  1 if the argument is after the instance 
	 * @param Db_Quarter $quarter
	 * @return integer
	 */
	public function compare(Db_Quarter $quarter)
	{
		return $this->compareYearQuarter($quarter->year, $quarter->quarter);
	}

	/**
	 * Compares this quarter object to the year and integer code representing 
	 * a quarter (1 = Winter ... 4 = Autumn)
	 * -1 if the argument is previous to the instance
	 *  0 if the argument is the same quarter as the instance
	 *  1 if the argument is after the instance
	 * @param integer $year
	 * @param integer $quarter
	 * @return integer
	 */
	public function compareYearQuarter($year, $quarter)
	{
		if ($year < $this->year) {
			return -1;
		} elseif ($year > $this->year) {
			return 1;
		} else {
			// years are equal
			if ($quarter < $this->quarter) {
				return -1;
			} elseif ($quarter == $this->quarter) {
				return 0;
			} else {
				// argument quarter is greater than instance quarter
				return 1;
			}
		}
	}
	
	/**
	 * Takes a quarter code in the format YYYY-Q quarter code (e.g. 2010-3) and
	 * returns a human readable string. Attempts to use a defined description 
	 * of the quarter stored in the database quarter table. If that value is 
	 * not available, systematically generates the display value.
	 * @param string $quarter
	 * @return string
	 */
	public static function Decode($quarter)
	{
		if (is_null(self::$_allQuarters)) {
			self::$_allQuarters = self::FetchMultiple();
		}
		if (array_key_exists($quarter, self::$_allQuarters)) {
			return self::$_allQuarters[$quarter]->description;
		}
		if (strpos($quarter, '-') === false) { return $quarter; }
		list($year, $qtr) = explode('-', $quarter);
		if (strlen($year) == 0 || strlen($qtr) == 0) { return $quarter; }
		$out = self::BuildDefaultDescription($year, $qtr);
		return $out;
	}

	/**
	 * Returns a collection of the start and end dates of quarters
	 * stored in the database. Outer array is indexed by Year-Quarter
	 * (example: 2009-4) and each value is a nested associative array 
	 * with indices of "start" and "end".
	 * 
	 * @param mixed $filters
	 * @return array
	 */
	public static function FetchDates($filters = '')
	{
		if (is_array($filters)) {
			$filters = implode(' AND ', $filters);
		}
		if (strlen($filters) > 0) {
			$filters = ' WHERE ' . $filters;
		}
		$db = DbFactory::GetConnection();
		$sql = 'SELECT year, quarter, ' 
		     . 'UNIX_TIMESTAMP(start) AS start, '
		     . 'UNIX_TIMESTAMP(end) AS end '
		     . 'FROM quarter '. $filters .' ORDER BY year, quarter';
		$results = $db->fetchAssoc($sql);
		$out = array();
		foreach ($results as $r) {
			$q = $r['year'] .'-'. $r['quarter'];
			$out[$q] = array(
				'start' => date('m/d/Y', $r['start']),
				'end'   => date('m/d/Y', $r['end'])
			); 
		}
		return $out;
	}
	
	/**
	 * Returns an array list of Db_Quarter objects indexed by the
	 * YYYY-Q quarter code (e.g. 2010-3).
	 * @param mixed $filters
	 * @return array
	 */
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT year, quarter, description, ' 
		     . 'UNIX_TIMESTAMP(start) AS start, '
		     . 'UNIX_TIMESTAMP(end) AS end '
		     . 'FROM quarter '. $where .' ORDER BY year, quarter';
		$results = $db->fetchAssoc($sql);
		$out = array();
		foreach ($results as $row) {
			$q = new Db_Quarter($row['year'], $row['quarter'], false);
			$q->init($row);
			$index = $row['year'] .'-'. $row['quarter'];
			$out[$index] = $q; 
		}
		return $out;
	}
	
	/**
	 * Fetch a list of quarters in an associative array. Indices are 
	 * year, hyphen, quarter (example: 2008-1 or 2010-4) and values
	 * are the display names of quarters. The range of quarters begins
	 * with Winter of the first year in the database through Autumn
	 * of this year + 3.
	 * 
	 * @return array
	 */
	public static function FetchIndex()
	{
		$db = DbFactory::GetConnection();
		$out = array();
		$startyear = $db->fetchOne('SELECT MIN(year) FROM offering');
		$endyear = date('Y') + 3;
		for ($y = $startyear; $y <= $endyear; ++$y) {
			$out[$y.'-1'] = eQuarter($y, 1);
			$out[$y.'-2'] = eQuarter($y, 2);
			$out[$y.'-3'] = eQuarter($y, 3);
			$out[$y.'-4'] = eQuarter($y, 4);
		}
		return $out;
	}
	
	/**
	 * Test whether the provided year and quarter happened before (or is)
	 * the current quarter. Returns true if arguments represent the current
	 * or a past quarter
	 * @param integer $year
	 * @param integer $quarter
	 */
	public static function IsPast($year, $quarter)
	{
		$now = self::FetchCurrentQuarter();
		return ($now->compareYearQuarter($year, $quarter) == -1);
	}
	
	/**
	 * Return the YYYY-Q representation of this quarter.
	 * @return string
	 */
	public function getCode()
	{
		return $this->year.'-'.$this->quarter;
	}

	/**
	 * Return the default description construction of the year and quarter.
	 * @return string
	 */
	public static function BuildDefaultDescription($year, $qtr)
	{
		$out = '';
		switch ($qtr)
		{
			case 1:
			case 'winter':
				$out = 'Winter ' . $year;
				break;
			case 2:
			case 'spring':
				$out = 'Spring ' . $year;
				break;
			case 3:
			case 'summer':
				$out = 'Summer ' . $year;
				break;
			case 4:
			case 'autumn':
				$out = 'Autumn ' . $year;
				break;
			case 0:
				$out = $year .'-'. ($year + 1) .' Academic Year';
				break;
			default: 
				$out = $quarter;
				break;
		}
		return $out;
	}
	
	/**
	 * Calculates and returns the current quarter based on system time as 
	 * Db_Quarter object. Current quarter is defined as the chronologically 
	 * last quarter who's dates of instruction have not ended. By this 
	 * definition, FetchCurrentQuarter() will return the next quarter during
	 * finals week and breaks.
	 * @return Db_Quarter
	 */
	public static function FetchCurrentQuarter()
	{
		if (is_null(self::$_currentQuarter)) {
			self::$_currentQuarter = self::FetchQuarterByDate(time());
		}
		return self::$_currentQuarter;
	}
	
	/**
	 * Calculated what UW academic quarter corresponds to the provided
	 * date. If no date argument is provided, calculates what quarter 
	 * it is now.
	 * 
	 * Current quarter is defined as the earliest quarter specified in 
	 * the database.quarter table whose end date is after the date
	 * argument. By this definition dates that fall during finals weeks 
	 * and breaks will return the next quarter.
	 * 
	 * @param int $date date value in Unix timestamp format
	 * @return Db_Quarter
	 */
	public static function FetchQuarterByDate($date)
	{
		if (!is_numeric($date)) {
			$date = strtotime($date);
		}
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * '
		     . 'FROM quarter '
		     . 'WHERE quarter <> 0 ' 
		     . 'AND end > '. $db->quote($date, 'date') .' ' 
		     . 'ORDER BY end '
		     . 'LIMIT 0,1';
		$row = $db->fetchRow($sql);
		if (!$row) {
			throw new Exception('Need to define more quarters in the quarters db table');
		}
		$out = new self($row['year'], $row['quarter'], false);
		$out->init($row);
		return $out;
	}
	
	/**
	 * Find an academic quarter value in the provided user input. If 
	 * the needed fields are located returns a Db_Quarter object, 
	 * otherwise returns false.
	 * @param string $input
	 * @return Db_Quarter
	 */
	public static function ParseQuarter($input)
	{
		if (!strpos($input, '-')) {
			return false;
		}
		list($year, $quarter) = explode('-', $input);
		$year = (int) $year;
		if ($year < 1900 || $year > 2100) {
			return false;
		}
		$quarter = strtolower($quarter);
		switch ($quarter) {
			case 'winter': $quarter = 1; break;
			case 'spring': $quarter = 2; break;
			case 'summer': $quarter = 3; break;
			case 'autumn': $quarter = 4; break;
			case 'fall': $quarter = 4; break;
		}
		$quarter = (int) $quarter;
		if ($quarter < 1 || $quarter > 4) {
			return false;
		}
		return new self($year, $quarter, false);
	}
	
	/**
	 * Return the proper name for a quarter that corresponds to the
	 * provided integer quarter code.
	 * @param integer $qtr
	 * @return string
	 */
	public static function IntToName($qtr)
	{
		switch($qtr) {
			case 1: $out = 'Winter'; break;
			case 2: $out = 'Spring'; break;
			case 3: $out = 'Summer'; break;
			case 4: $out = 'Autumn'; break;
			default: $out = $qtr; break;
		}
		return $out;
	}
		
}