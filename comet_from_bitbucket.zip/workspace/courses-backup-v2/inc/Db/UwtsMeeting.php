<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to the uwtsmeeting database table. A Db_UwtsMeeting record 
 * stores course section meeting data as currently represented in the 
 * official UW Time Schedule data store.
 *
 * @author Paul Hanisko
 */


class Db_UwtsMeeting extends DbObject
{
	public $daylist;
	public $deleteFlag = false;
	
	public function __construct($uwtsofferingid, $meetingnumber, $autoload = true)
	{
		parent::__construct(DbConnection::GetInstance(), 'uwtsmeeting');

		$this->addPrimaryKeyField('uwtsofferingid', $uwtsofferingid, self::TYPE_INT);
		$this->addPrimaryKeyField('meetingnumber', $meetingnumber, self::TYPE_INT);
		$this->addField('meetingid');
		$this->addField('meetingtype');
		$this->addField('dows');
		$this->addField('start');
		$this->addField('end');
		$this->addField('building');
		$this->addField('room');

		if ($autoload) {
			$this->load();
		}
	}

	/**
	 * Returns an array list of Db_UwtsMeeting objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters
	 * @return array
	 */
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT * FROM uwtsmeeting '.$where.' ORDER BY uwtsofferingid, meetingnumber';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$o = new self($row['uwtsofferingid'], $row['meetingnumber'], false);
			$o->init($row);
			$out[] = $o;
		}
		return $out;
	}

	/**
	 * Returns an array list of Db_UwtsMeeting objects loaded from the database. The list
	 * is limited to meetigns belonging to the specified Db_UwtsOffering and the output
	 * array is indexed by the meeting's meetingnumbers.
	 * @param mixed $filters
	 * @return array
	 */
	public static function FetchByUwtsOffering($uwtsofferingid)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM uwtsmeeting WHERE uwtsofferingid = '.$uwtsofferingid.' ORDER BY meetingnumber';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$o = new self($row['uwtsofferingid'], $row['meetingnumber'], false);
			$o->init($row);
			$out[$row['meetingnumber']] = $o;
		}
		return $out;
	}
	
	/**
	 * Returns the brief string used in the UW Time Schedule to describe the days
	 * and time of this meeting
	 * @return string
	 */
	public function getUwtsSummary()
	{
		if (!$this->start || !$this->end) {
			return null;
		}
		$start = new Time($this->start);
		$end = new Time($this->end);
		$daysummary = '';
		if (!is_array($this->daylist)) $this->setDaylist();
		foreach ($this->daylist as $d) {
			switch ($d) {
				case 0: $daysummary .= 'Su'; break;
				case 1: $daysummary .= 'M'; break;
				case 2: $daysummary .= 'T'; break;
				case 3: $daysummary .= 'W'; break;
				case 4: $daysummary .= 'Th'; break;
				case 5: $daysummary .= 'F'; break;
				case 6: $daysummary .= 'S'; break;
				default: break;
			}
		}
		return $daysummary.' '.$start->getUwtsBrief().'-'.$end->getUwtsBrief(true);
	}

	/**
	 * Returns true if meeting does not have the properties required for it to exist
	 * @return array
	 */
	public function isEmpty()
	{
		if (count($this->daylist) < 1) {
			return true;
		}
		if (!$this->start || !$this->end) {
			return true;
		}
		return false;
	}
	
	public function setDaylist()
	{
		if (!$this->dows) {
			$this->daylist = array();
		} else {
			$this->daylist = str_split($this->dows);
		}
	}
	
	public function setDows($daylist = null)
	{
		if (!is_null($daylist)) {
			$this->daylist = $daylist;
		}
		if (is_array($this->daylist)) {
			$this->dows = implode('', $this->daylist);
		}	
	}
	
	protected function preInsert()
	{
		$this->preSave();
	}
	
	protected function preUpdate()
	{
		$this->preSave();
	}
	
	protected function preSave()
	{
		$this->setDows();
	}

}