<?php
/**
 * Interface to the syllabus database table. A syllabus represents
 * and uploaded binary file.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Db_Syllabus extends DbObject implements Attachment_MetadataInterface
{
	private $_offering;
	
	public function __construct($syllabusid, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'syllabus');
		
		$this->addPrimaryKeyField('syllabusid', $syllabusid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('url');
		$this->addField('clientfilename');
		$this->addField('storagefilename');
		$this->addField('uploadedon', self::TYPE_DATETIME);
		$this->addField('uploadedby');
		$this->addField('mimetype');
		$this->addField('extension');
		
		if ($autoload) { $this->load(); }	
	}

	/**
	 * Returns the course offering record associated with this syllabus
	 * @return Db_Offering
	 */
	public function getOffering()
	{
		return $this->_offering;
	}
	
	/**
	 * Assigns a course offering record associated with this syllabus
	 * @param Db_Offering
	 */
	public function setOffering(Db_Offering $offering)
	{
		$this->_offering = $offering;
		$parts = array(
			'Syllabus',
			$offering->curriculum,
			$offering->courseno,
			$offering->section,
			$offering->year,
			Db_Quarter::IntToName($offering->quarter)
		);
		$this->clientfilename = implode('-',$parts);
	}
	
	/**
	 * Return the http Mime Type of the file attachment
	 * @return string
	 */
	public function getMimetype()
	{
		return $this->mimetype;
	}
	
	/**
	 * Return an arbitrary property value stored in the metadata and
	 * identified by $name
	 * @return string
	 */
	public function getValue($name)
	{
		return $this->$name;
	}
	
	/**
	 * Set an arbitrary property value stored in the metadata and
	 * identified by $name to $value
	 * @return string
	 */
	public function setValue($name, $value)
	{
		$this->$name = $value;
	}
	
	/**
	 * Return a unique primary key identifier that refers to this
	 * metadata (and by extension this attachment)
	 * @return string
	 */
	public function getId()
	{
		return $this->syllabusid;
	}
	
	/**
	 * Return a filename to name the file when it is downloaded by a client
	 * @return string
	 */
	public function getClientFilename()
	{
		return $this->clientfilename.'.'.$this->extension;
	}
	
	/**
	 * Return a filename to name to use when storing the file in the server
	 * side store. Storage filename must be unique (at least, within the
	 * getStoreagePath()) or stored files may be overwritten.
	 * @return string
	 */
	public function getStorageFilename()
	{
		return 'syllabusid_'.$this->syllabusid.'.'.$this->extension;
	}
	
	/**
	 * Returns a path (e.g. subdirectory that specifies where a server side
	 * file should be stored. getStoreagePath() +  getStorageFilename() should
	 * return unique values or stored files may be overwritten.
	 * @return string
	 */
	public function getStoragePath()
	{
		return '';
	}
	
	/**
	 * Pre deletion maintenance. Remove references to this syllabusid from the 
	 * offering table.
	 * @see DbObject::preDelete()
	 */
	protected function preDelete()
	{
		$db = DbFactory::GetConnection();
		$db->query('UPDATE offering SET syllabusid = NULL WHERE syllabusid = '.$this->syllabusid);
	}
	
}