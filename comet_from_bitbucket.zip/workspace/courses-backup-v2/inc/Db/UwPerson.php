<?php
/**
 * The UWPerson table includes a large list of people who have
 * been instructors at UW. We use this list to clean up imported
 * adjuct data. However this list is too large and unwieldly to
 * use as the basis for our select staff dialogs.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Db_UwPerson extends DbObject
{
	
	public function __construct($ein, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'uwperson');
		
		$this->addPrimaryKeyField('ein', $ein, self::TYPE_CHAR);
		$this->addField('firstname');
		$this->addField('lastname');
		$this->addField('uwnetid');
		
		if ($autoload) { $this->load(); }	
	}
	
	/**
	 * Load a Db_Person object by finding a matching UWNetID in the
	 * database. If no match is found returns a new Db_Person object
	 * with the uwnetid property set.
	 * @param string $uwnetid
	 * @return Db_Person
	 */
	public static function FetchByUwnetid($uwnetid)
	{
		if (!$uwnetid) return self::GetUnknownPerson();
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM uwperson WHERE uwnetid = '.$db->quote($uwnetid);
		$row = $db->fetchRow($sql);
		if ($row) {
			$out = new self($row['ein'], false);
			$out->init($row);
		} else {
			$out = self::GetUnknownPerson($uwnetid);
		}
		return $out;
	}
	
}