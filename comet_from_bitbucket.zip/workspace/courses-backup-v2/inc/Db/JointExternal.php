<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to the jointexternal database table. An auth record represents
 * a known user that has special permissions in the system.
 * @author hanisko
 */

class Db_JointExternal extends DbObject
{
	private static $uwts_quarters = array(
		1 => 'WIN',
		2 => 'SPR',
		3 => 'SUM',
		4 => 'AUT'
	);
	
	public function __construct($jointexternalid, $autoload = true)
	{
		$db = DbConnection::GetInstance();
		parent::__construct($db, 'jointexternal');

		$this->addPrimaryKeyField('jointexternalid', $jointexternalid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('year');
		$this->addField('quarter', self::TYPE_INT);
		$this->addField('curriculum');
		$this->addField('courseno', self::TYPE_INT);
		$this->addField('section');
		$this->addField('uwts_curriculum_abbrev');
		$this->addField('enrollmentcurrent', self::TYPE_INT);
		$this->addField('enrollmentestimate', self::TYPE_INT);
		$this->addField('enrollmentlimit', self::TYPE_INT);
		
		if ($autoload) { $this->load(); }
	}

	/**
	 * Returns an array list of Db_JointExternal objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters
	 * @return array[Db_JointExternal]
	 */
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT * FROM jointexternal '.$where.' ORDER BY year, quarter, curriculum, courseno, section';
		$results = $db->fetchAssoc($sql);
		$out = array();
		foreach ($results as $row) {
			$o = new self($row['jointexternalid'], false);
			$o->init($row);
			$out[] = $o;
		}
		return $out;
	}

	/**
	 * Returns a Db_JointExternal object with the specified parameters, either by 
	 * matching an existing record or (if needed) creating a new record.
	 * @param integer $year
	 * @param integer $quarter
	 * @param string $curriculum
	 * @param integer $courseno
	 * @param string $section
	 * @return Db_JointExternal
	 */
	public static function ImportJoint($year, $quarter, $curriculum, $courseno, $section)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * '
		     . 'FROM jointexternal '
		     . 'WHERE year = '.$db->quote($year).' '
		     . 'AND quarter = '.$quarter.' '
		     . 'AND curriculum = '.$db->quote($curriculum).' '
		     . 'AND courseno = '.$courseno.' '
		     . 'AND section = '.$db->quote($section);
		$row = $db->fetchRow($sql);
		if ($row) {
			$out = new self($row['jointexternalid'], false);
			$out->init($row);
		} else {
			$out = new self(0, false);
			$out->year = $year;
			$out->quarter = $quarter;
			$out->curriculum = $curriculum;
			$out->courseno = $courseno;
			$out->section = $section;
		}
		return $out;
	}
	
	/**
	 * Return a URL that referes to this courses entry in the HTML version
	 * of the UW Time Schedule
	 * @return NULL|string
	 */
	public function getUwTimeScheduleLink()
	{
		if (!$this->uwts_curriculum_abbrev) {
			return null;
		}
		//return 'http://www.washington.edu/students/timeschd/AUT2012/hist.html';
		$out = array(
			'http://www.washington.edu/students/timeschd/',
			self::$uwts_quarters[$this->quarter],
			$this->year,
			'/',
			$this->uwts_curriculum_abbrev,
			'.html#',
			strtolower($this->curriculum),
			$this->courseno
		);
		return implode('',$out);
	}
	
	/**
	 * Get an instance of Db_JointExternal identified by $jointexternalid. Utilizes
	 * the application ObjectRegistry to prevent multiple loading and 
	 * instances of the same record.
	 * @param integer $jointexternalid
	 * @return Db_JointExternal
	 */
	public static function Get($jointexternalid)
	{
		$out = ObjectRegistry::Get(__CLASS__, $jointexternalid);
		if (is_null($out)) {
			$out = new self($jointexternalid);
			ObjectRegistry::Add(__CLASS__, $jointexternalid, $out);
		}
		return $out;
	}
	
	/**
	 * Create an instance of Db_JointExternal from an associative array returned by
	 * a database query. Checks the ObjectRegistry before instantiating a new
	 * object.
	 * @param array $row
	 * @return Db_JointExternal
	 */
	public static function Register($row)
	{
		$out = ObjectRegistry::Get(__CLASS__, $row['jointexternalid']);
		if (is_null($out)) {
			$out = new self($row['jointexternalid'], false);
			$out->init($row);
			ObjectRegistry::Add(__CLASS__, $row['jointexternalid'], $out);
		}
		return $out;
	}
	
}