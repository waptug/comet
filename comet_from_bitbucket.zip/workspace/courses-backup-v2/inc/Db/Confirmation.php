<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface for storing input confirmation records in the database.
 * 
 * @author Paul Hanisko
 */

class Db_Confirmation extends DbObject 
{
	public function __construct($code, $uwnetid, $autoload = true)
	{
		parent::__construct(DbConnection::GetInstance(), 'confirmation');
		$this->addPrimaryKeyField('code', $code, self::TYPE_CHAR);
		$this->addPrimaryKeyField('uwnetid', $uwnetid, self::TYPE_CHAR);
		$this->addField('created', self::TYPE_DATETIME);
		if ($autoload) { $this->load(); }
	}
	
}
