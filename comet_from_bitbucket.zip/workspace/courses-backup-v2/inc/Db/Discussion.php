<?php
/**
 * Interface to the discussion database table. Discussion items are
 * comments that are visible only to COE faculty & staff.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Db_Discussion extends DbObject 
{
	
	public function __construct($discussionid, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'discussion');
		
		$this->addPrimaryKeyField('discussionid', $discussionid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('uwnetid');
		$this->addField('created', self::TYPE_DATETIME);
		$this->addField('courseid', self::TYPE_INT);
		$this->addField('offeringid', self::TYPE_INT);
		$this->addField('comment');
		
		if ($autoload) { $this->load(); }	
	}
	
	/**
	 * Returns an array of Db_Discussion objects that are related to the 
	 * specified Db_Offering or to its parent Db_Course record.
	 * 
	 * @param Db_Offering $offering
	 * @return array[Db_Discussion]
	 */
	public static function FetchByOffering(Db_Offering $offering)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM discussion WHERE offeringid = '.$offering->offeringid.' OR courseid = '.$offering->courseid.' ORDER BY created';
		$results = $db->fetchAssoc($sql);
		$out = array();
		foreach ($results as $row) {
			$o = new self($row['discussionid'], false);
			$o->init($row);
			$out[] = $o;
		}
		return $out;
	}
	
	protected function preInsert()
	{
		$this->preSave();
	}
	
	protected function preUpdate()
	{
		$this->preSave();
	}
	
	protected function preSave()
	{
		// if entered date time was not specified use system clock
		if (!$this->created) { 
			$this->created = time(); 
		}
		// if user was not specified, search for logged in user
		if (!$this->uwnetid) {
			if (Request::IsCommandLine()) {
				$this->uwnetid = 'system';
			} else {
				$this->uwnetid = User::GetLoggedInUser()->uwnetid;
			}
		}
		// verify this entry is attached to something
		if (!$this->offeringid && !$this->courseid) {
			throw new Exception('Db_Discussion entry must refer to an offering or course record');
		}
	}
	
}
