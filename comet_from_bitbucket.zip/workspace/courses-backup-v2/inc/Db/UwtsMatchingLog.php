<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to the uwtsmatchinglog database table. This table stores 
 * logging information for results and decisions made during the linking
 * of UW time schedule records to local plan records.
 * 
 * @author Paul Hanisko
 */

class Db_UwtsMatchingLog extends DbObject
{
	const NO_LINK_MATCH_SCORE_LOW = 1;
	const NO_LINK_MULTIPLE_POSSIBLE = 2;
	const NO_LINK_ON_SLN_OR_VERIFIED_SECTION = 3;
	const NO_LINK_PLAN_CANCELED = 4;
	const LINKED_ON_SLN = 21;
	const LINKED_ON_VERIFIED_SECTION = 22;
	const LINKED_ON_SECTION_AND_SCORE = 23;
	const LINKED_NEW_OFFERING = 24;
	const MANUAL_LINK = 75;
	const MANUAL_NEW_OFFERING = 76;
	const REMOVED_LINK = 86;
	const ERROR_SLN_MATCH_SECTION_MISMATCH = 91;
	const ERROR_SLN_MATCH_LINKED_TO_OTHER = 92;
	const ERROR_VERIFIED_SECTION_LINKED_TO_OTHER = 93;
	
	private static $_results = array(
		1  => 'not able to link, matching score too low',
		2  => 'not able to link, multiple possible sections',
		3  => 'not able to link on SLN or verified section',
		4  => 'plan offering is canceled, no UWTS to link',
		21 => 'linked on SLN',
		22 => 'linked on verified section',
		23 => 'linked on section match and matching score',
		24 => 'created new plan offering',
		75 => 'linked UWTS to plan manually',
		76 => 'created new plan offering manually',
		86 => 'removed link between UWTS and plan',
		91 => 'found SLN match with different section ids',
		92 => 'found SLN match already linked to different record',
		93 => 'found verified section match already linked to different record',			
	);
	
	public function __construct($logid, $autoload = true)
	{
		$db = DbConnection::GetInstance();
		parent::__construct($db, 'uwtsmatchinglog');

		$this->addPrimaryKeyField('id', $logid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('processed', self::TYPE_DATETIME);
		$this->addField('uwtsofferingid', self::TYPE_INT);
		$this->addField('offeringid', self::TYPE_INT);
		$this->addField('linkcreated', self::TYPE_BOOLEAN);
		$this->addField('error', self::TYPE_BOOLEAN);
		$this->addField('resultcode', self::TYPE_INT);
		$this->addField('matchingscore', self::TYPE_INT);
		$this->addField('uwnetid');

		if ($autoload) { $this->load(); }
	}
	
	/**
	 * Returns an array list of Db_UwtsMatchingLog objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters 
	 * @return array[Db_UwtsMatchingLog]
	 */
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT * FROM uwtsmatchinglog '.$where.' ORDER BY id';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$o = new self($row['id'], false);
			$o->init($row);
			$out[] = $o;
		}
		return $out;
	}
	
	/**
	 * Create a new log record and store in the database. Returns an instance of the
	 * log record.
	 * @param integer $message use class constants
	 * @param Db_UwtsOffering|null $uwts
	 * @param Db_Offering|null $plan
	 * @param integer $score
	 * @throws Exception
	 * @return Db_UwtsMatchingLog
	 */
	public static function Write($message, $uwts = null, $plan = null, $score = null)
	{
		$log = new self(0);
		$log->processed = time();
		$log->linkcreated = 0;
		$log->error = 0;
		switch ($message) {
			case self::NO_LINK_MATCH_SCORE_LOW:
			case self::NO_LINK_MULTIPLE_POSSIBLE:
			case self::NO_LINK_ON_SLN_OR_VERIFIED_SECTION:
			case self::NO_LINK_PLAN_CANCELED:
			case self::REMOVED_LINK:
				break;
			case self::LINKED_ON_SLN:
			case self::LINKED_ON_VERIFIED_SECTION:
			case self::LINKED_ON_SECTION_AND_SCORE:
			case self::LINKED_NEW_OFFERING:
			case self::MANUAL_LINK:
			case self::MANUAL_NEW_OFFERING:
				$log->linkcreated = 1;
				break;
			case self::ERROR_SLN_MATCH_SECTION_MISMATCH:
			case self::ERROR_SLN_MATCH_LINKED_TO_OTHER:
			case self::ERROR_VERIFIED_SECTION_LINKED_TO_OTHER:
				$log->error = 1;
				break;
			default:
				throw new Exception('Attempt to log unknown uwts matching code ('.$message.')');
				break;
		}
		$log->resultcode = $message;
		$log->uwtsofferingid = ($uwts instanceof Db_UwtsOffering) ? $uwts->uwtsofferingid : 'NULL';
		$log->offeringid = ($plan instanceof Db_Offering) ? $plan->offeringid : 'NULL';
		$log->matchingscore = (is_null($score)) ? 'NULL' : (int)$score;
		if (Request::IsCommandLine()) {
			$log->uwnetid = 'system';
		} else {
			$log->uwnetid = User::GetLoggedInUser()->uwnetid;
		}
		$log->save();
		return $log;
	}
	
	/**
	 * Returns a string summary of the log record.
	 * @param mixed $object optional reference to the UWTS or Plan record
	 */
	public function getSummary($object = null)
	{
		$out = date('Y-m-d H:i:s', $this->processed);
		if ($this->error) {
			$out .= ' [ERROR] ';
		} elseif ($this->linkcreated) {
			$out .= ' [LINKED] ';
		} else {
			$out .= ' [NO LINK] ';
		}
		$offering = null;
		if ($object instanceof Db_UwtsOffering && $object->uwtsofferingid == $this->uwtsofferingid) {
			$offering = $object;
		} elseif ($object instanceof Db_Offering && $object->offeringid == $this->offeringid) {
			$offering = $object;
		} else {
			if ($this->uwtsofferingid) {
				$offering = new Db_UwtsOffering($this->uwtsofferingid);
			} elseif ($this->offeringid) {
				$offering = new Db_Offering($this->offeringid);
			}
		}
		if ($offering) {
			$out .= $offering->year.'-'.$offering->quarter.' '.$offering->curriculum.' '.$offering->courseno.' '.$offering->section;
		} else {
			$out .= 'Unknown course offering';
		}
		$out .= ' '.$this->uwnetid.' '.self::$_results[$this->resultcode];
		if ($this->resultcode == 1 || $this->resultcode == 23) {
			$out .= ' '.$this->matchingscore;
		}
		$out .= ' {uwts:'.$this->uwtsofferingid.' -> plan:'.$this->offeringid.'}';
		return $out;
	}
		
}