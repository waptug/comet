<?php
/**
 * @package edu.uw.education.courses
 */
/**
 * Interface to the offering database table.
 * An offering represents a specific instance of a course, a course being offered in a given quarter and section.
 * @author hanisko
 */

/**
 * *************************************
 * @property integer  $offeringid
 * @property integer  $courseid
 * @property string   $year
 * @property integer  $quarter
 * @property string   $section
 * @property string   $summerterm
 * @property string   $sectiontype
 * @property string   $institution
 * @property string   $funding
 * @property integer  $sln
 * @property string   $creditcontrol
 * @property integer  $creditmin
 * @property integer  $creditmax
 * @property integer  $enrollmentcurrent
 * @property integer  $enrollmentestimate
 * @property integer  $enrollmentlimit
 * @property integer  $studentcredithours
 * @property integer  $studentcredithoursestimate
 * @property string   $gradingsystem
 * @property integer  $syllabusid
 * @property string   $meetingsummary
 * @property string   $jointsummary
 * @property string   $status
 * @property integer  $repetitionid
 * @property integer  $uwtsstatus
 * @property integer  $roomstatus
 * @property string   $sectionstatus
 * @property integer  $instructorapproval
 * @property integer  $instructorapproval_logid
 * *************************************
 * Accessed through Db_Course object
 * *************************************
 * @property string   $curriculum
 * @property integer  $courseno
 * @property string   $title
 * @property string   $shorttitle
 * @property string   $wildcardtitle
 * @property string   $coursecreditcontrol
 * @property integer  $creditrepeatmax
 * @property string   $general_education
 * @property integer  $orgunitid
 * @property string   $orgunitname
 * @property string   $firstquarter
 * @property string   $lastquarter
 * **********************************************
 * Lazy load object graph via __get magic method
 * **********************************************
 * @property mixed          $activitylog
 * @property mixed          $changemanager
 * @property mixed          $changerequests
 * @property Db_Comment[]   $comments
 * @property mixed          $constraints
 * @property Db_Course      $course
 * @property mixed          $discussion
 * @property mixed          $fundingname
 * @property mixed          $gradingsystemname
 * @property mixed          $institutionname
 * @property mixed          $instructor
 * @property mixed          $joint
 * @property mixed          $roomcomments
 * @property mixed          $roomneed
 * @property mixed          $sectiontypename
 * @property mixed          $selfsustainingname
 * @property mixed          $summaryname
 * @property mixed          $summertermname
 * @property mixed          $syllabus
 * @property mixed          $uwts
 */
class Db_Offering extends DbObject 
{
	private $_activitylog;
	private $_buyout;
	private $_change_section_error;
	private $_changemanager;
	private $_changerequests;
	private $_comments;
	private $componentManager;
	private $_constraints;
	private $_course;
	private $_discussion;
	private $_editable;
	private $_hasroomrequest;
	private $_instructor;
	private $_instructor_count = 1;
	private $_joint;
	private $_lastApproval;
	private $_meetings;
	private $_revisable;
	private $_roomcomments;
	private $_roomneed;
	private $_section_lock_reason;
	private $_syllabus;
	private $_tags;
	private $_timeframe;
	private $_usertags;
	private $_uwts;
	//private $_workflow;
	
	public static $change_section_error_codes = array(
		1 => 'Section ID is in use by another offering already linked to UW time schedule record',
		2 => 'Another offering has this section ID and all other section IDs (A-Z) are in use'
	);
	
	private static $editable_statuses = array(
		'entered',
		'expected',
		'revised',
		'deleted',
		'canceled'
	);
	
	public static $fundingtypes = array(
		'St' => 'State funding', 
		'SS' => 'Self sustaining'
	);
	
	public static $gradingsystems = array(
		'standard' => 'Standard grading',
		'credit'   => 'Credit/No-credit'		
	);
	
	public static $institutions = array(
		'state'  => 'State funding',
		'uweo'   => 'UWEO (self-sustaining)'		
	);
	
	public static $quarters = array(
		'1' => 'Winter',
		'2' => 'Spring',
		'3' => 'Summer',
		'4' => 'Autumn'
	);
	
	public static $sectionlockreasons = array(
		1 => 'offering is already linked to a UWTS record',
		2 => 'offering has section status Verified'
	);
	
	public static $sectionstatuses = array(
		'P' => 'Planned',
		'V' => 'Verified',
		'S' => 'SLN match'		
	);
	
	public static $sectiontypes = array(
		'LC' => 'Lecture',
		'IS' => 'Independent Study',
		'PR' => 'Practicum',
		'QZ' => 'Quiz',
		'SM' => 'Seminar'
	);
	
	public static $summerterms = array(
		'F' => 'Full-term',
		'A' => 'A-term',
		'B' => 'B-term',
	);
	
	public static $uwtsstatus_names = array(
		'Not entered',
		'Differs from UWTS',
		'Up to date',
        'No longer in UWTS',
        'Potential Duplicate Section'    
	);
	
	public function __construct($offeringid, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'offering');
		
		$this->addPrimaryKeyField('offeringid', $offeringid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('courseid', self::TYPE_INT);
		$this->addField('year');
		$this->addField('quarter', self::TYPE_INT);
		$this->addField('section');
		$this->addField('summerterm');
		$this->addField('sectiontype');
		$this->addField('institution', self::TYPE_CHAR, 'state');
		$this->addField('funding', self::TYPE_CHAR, 'St');
		$this->addField('sln', self::TYPE_INT);
		$this->addField('creditcontrol');
		$this->addField('creditmin', self::TYPE_INT);
		$this->addField('creditmax', self::TYPE_INT);
		$this->addField('enrollmentcurrent', self::TYPE_INT);
		$this->addField('enrollmentestimate', self::TYPE_INT);
		$this->addField('enrollmentlimit', self::TYPE_INT);
		$this->addField('studentcredithours', self::TYPE_INT);
		$this->addField('studentcredithoursestimate', self::TYPE_INT);
		$this->addField('gradingsystem');
		$this->addField('syllabusid', self::TYPE_INT);
		$this->addField('meetingsummary');
		//$this->addField('primary_staffid', self::TYPE_INT);
		$this->addField('jointsummary');
		$this->addField('status');
		$this->addField('repetitionid', self::TYPE_INT);
		$this->addField('uwtsstatus', self::TYPE_INT, 0);
		$this->addField('roomstatus', self::TYPE_INT, 0);
		$this->addField('sectionstatus', self::TYPE_CHAR, 'P');
		$this->addField('instructorapproval', self::TYPE_BOOLEAN, 0);
		$this->addField('instructorapproval_logid', self::TYPE_INT, 0);
		
		if ($autoload) { $this->load(); }
		
		$this->componentManager = new \Offering\Components\ComponentManager($this);
	}
	 
	public function __call($name, $parameters)
	{
		switch ($name) {
			// alias old meeting and staff methods
			case 'getMeetingByNumber':
				return $this->getMeetings()->getMeetingByNumber($parameters[0]);
				break;
			case 'addStaff':
				return $this->getMeetings()->addStaff($parameters[0]);
				break;
			case 'getStaff':
				return $this->getMeetings()->getStaff();
				break;
			case 'getStaffByRegid':
				return $this->getMeetings()->locateStaffByRegid($parameters[0],$parameters[1]);
				break;
			case 'meetingsToBeArranged':
				return $this->getMeetings()->meetingsToBeArranged();
				break;
			default:
				throw new Exception('Undefined method '.$name);
				break;
		}
	}
	
	
	public function __get($name)
	{
		if ($this->componentManager->has($name)) {
			return $this->componentManager->get($name);
		}
		switch ($name) {
			case 'course':
				return $this->getCourse();
				break;
			case 'curriculum':
			case 'courseno':
			case 'title':
			case 'shorttitle':
			case 'wildcardtitle':
			case 'creditrepeatmax':
			case 'general_education':
			/*case 'writing':
			case 'qsr':
			case 'indivsociety':*/
			case 'orgunitid':
			case 'orgunitname':
			case 'firstquarter':
			case 'lastquarter':
				return $this->course->$name;
				break;
			case 'activitylog':
			case 'changemanager':
			case 'changerequests':
            case 'comments':
			case 'constraints':
			case 'discussion':
			case 'fundingname':
			case 'gradingsystemname':
			case 'institutionname':
			case 'instructor':
			case 'joint':
			case 'roomcomments':
			case 'roomneed':
			case 'sectiontypename':
			case 'selfsustainingname':
			case 'summaryname':
			case 'summertermname':
			case 'syllabus':
			case 'uwts':
				$accessor = 'get'.$name;
				return $this->$accessor();
				break;
			case 'description':
				return $this->getSwsDescription();
				break;
			case 'meetings':
				return $this->getMeetings();
				break;
			case 'staff':
				return $this->getMeetings()->getStaff();
				break;
			default:
				return parent::__get($name);
				break;
		}
	}
	
	public function __set($name, $value)
	{
		switch ($name) {
			case 'enrollmentestimate':
				$this->setEnrollmentEstimate($value);
				break;
			case 'enrollmentlimit':
				$this->setEnrollmentLimit($value);
				break;
			case 'section':
				$this->setSection($value);
				break;
			case 'uwtsstatus':
				$this->setUwtsstatus($value);
				break;
			default:
				parent::__set($name, $value);
				break;
		}
	}

	/**
	 * Updates the roomstatus field to the best value based on other offering
	 * properties. Ideally the roomstatus is updated as specific system events
	 * happen (e.g. changing class size) this method plays catch up if that 
	 * data gets out of sync.
	 */
	public function calculateRoomStatus()
	{
		// anything with no meetings can get that status, regardless of time frame
		if ($this->meetingsToBeArranged()) {
			$this->roomstatus = 94; // 'No meetings'
			return;
		}
		// calculate whether there is a room assigned yet
		$hasroom = false;
		foreach ($this->meetings as $meeting) {
			if ($meeting->building) {
				$this->roomstatus = 93; // 'Room assigned in time schedule',
				return;
			}
		}
		// mark historical offerings with no room as TBA
		if ($this->getTimeframe() < 0) { // past quarter
			$this->roomstatus = 95; // 'To be arranged'
			return;
		}
		// current and future classes, if no room assigned, put ball in instructor or OSS's court
		if ($this->hasRoomRequest()) {
			$this->roomstatus = 11; // 'Instructor updated room request',
		} else {
			$this->roomstatus = 0; // 'No instructor room request',
		}
	}
	
	/**
	 * Changes the section letter of this offering object. Checks for other
	 * offerings with conflicting section letters. If the conflicting section 
	 * is already linked to UWTS cache (its section is locked in) method does 
	 * nothing and returns false.
	 * @param string $section
	 * @return boolean
	 */
	public function changeSection($section)
	{
		if (strlen($section) != 1) {
			throw new Exception('Cannot change section change to '.$section);
		}
		$section = strtoupper($section);
		if ($section == $this->section) {
			return true;
		}
		$db = DbFactory::GetConnection();
		// Deal with offerings that are using target section
		$sql = 'SELECT o.offeringid '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'WHERE c.curriculum = '.$db->quote($this->curriculum).' '
		     . 'AND c.courseno = '.$this->courseno.' '
		     . 'AND o.year = '.$db->quote($this->year).' '
		     . 'AND o.quarter = '.$this->quarter.' '
		     . 'AND o.section = '.$db->quote($section).' ';	
		$conflicts = $db->fetchColumn($sql);
		foreach ($conflicts as $offeringid) {
			$conflict = new Db_Offering($offeringid);
			// is the conflict already linked to UWTS cache?
			if ($conflict->isSectionLocked()) {
				Logger::GetInstance()->error(__METHOD__.' cannot change section on offeringid '.$conflict->offeringid.' '.$conflict->getSectionLockReason());
				$this->_change_section_error = new stdClass();
				$this->_change_section_error->code = 1;
				$this->_change_section_error->message = null;
				$this->_change_section_error->conflict = $conflict->offeringid;
				return false;
			}
			$inuse = Db_Offering::FetchInUseSections($this);
			$safesection = null;
			for ($i = 65; $i <= 90; ++$i) {
				$try = chr($i);
				if (!in_array($try, $inuse)) {
					$safesection = $try;
					break;
				}
			}
			if ($safesection) {
				$db->query('UPDATE offering SET section = '.$db->quote($safesection).' WHERE offeringid = '.$conflict->offeringid);
				Db_ActivityLog_Sectionsync::Write($conflict->offeringid, $safesection);
			} else {
				$this->_change_section_error = new stdClass();
				$this->_change_section_error->code = 2;
				$this->_change_section_error->message = null;
				$this->_change_section_error->conflict = $conflict->offeringid;
				Logger::GetInstance()->error(__METHOD__.' could not find available section to change offeringid: '.$this->offeringid);
				return false;
			}
		}
		// Target section is cleared, update $this offering to new section letter
		$db->query('UPDATE offering SET section = '.$db->quote($section).' WHERE offeringid = '.$this->offeringid);
		$this->section = $section;
		Db_ActivityLog_Sectionsync::Write($this->offeringid, $this->section);
		return true;
	}
	
	/**
	 * Count the number of offering records in the system that match the
	 * provide SQL filters.
	 * @param mixed $filters 
	 * @return integer
	 */
	public static function Count($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		return $db->fetchOne('SELECT COUNT(offeringid) FROM offering '.$where);
	}

	/**
	 * Count the number of offering records in the database that match the specified
	 * quarter and course number.
	 * @param integer $year
	 * @param integer $quarter
	 * @param string $curriculum
	 * @param integer $courseno
	 * @return Db_Offering
	 */
	public static function CountSections($year, $quarter, $curriculum, $courseno)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT COUNT(o.offeringid) AS qty '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'WHERE c.curriculum = '.$db->quote($curriculum).') ' 
		     . 'AND c.courseno = '.$courseno.') ' 
		     . 'AND o.year = '.$db->quote($year).' '
		     . 'AND o.quarter = '.(int)$quarter;
		return $db->fetchOne($sql);
	}
	
	/**
	 * Safely creates a new Db_Offering record. Method optionally generates the next 
	 * available section or checks for section collisions. Returns the new 
	 * Db_Offering record on success or false otherwise. Calculates estimated credits
	 * and enrollment values.
	 * 
	 * @param string $year
	 * @param integer $quarter
	 * @param integer $courseid
	 * @param string $section
	 * @return Db_Offering
	 */
	public static function Create($year, $quarter, $courseid, $section = null)
	{
		$offering = new self(0);
		$offering->courseid = $courseid;
		$offering->year = $year;
		$offering->quarter = $quarter;
		if ($section) {
			$offering->useAvailableSection(array($section));
		} else {
			$offering->useAvailableSection();
		}
		
		// Make sure there is not already a course offering with these properties
		if ($offering->isDuplicate()) {
			debug(__METHOD__.' collision for courseid:'.$courseid.' '.$section.' '.$year.'-'.$quarter);
			return false;
		}
		// Estimate enrollment based on previous quarter
		$offering->setEnrollmentEstimate(Db_Offering::EstimateEnrollment($offering->courseid));
		$offering->sectiontype = 'LC';
		$offering->status = 'planned';
		$offering->uwtsstatus = 0;
		$offering->roomstatus = 0;
		$offering->save();
		return $offering;
	}
	
	/**
	 * Calculate an estimate of offering enrollment based on 
	 * previous quarter's enrollment.
	 * @param integer $courseid
	 * @return integer
	 */
	public static function EstimateEnrollment($courseid)
	{
		$currquarter = Db_Quarter::FetchCurrentQuarter();
		$db = DbFactory::GetConnection();
		// find the most recent quarter with data for this course
		// that has happened (e.g. prior to the current academic quarter)
		$sql = 'SELECT DISTINCT year, quarter '
		     . 'FROM offering '
		     . 'WHERE courseid = '.$courseid.' '
		     . 'AND (year < '.$db->quote($currquarter->year).' '
		     . 'OR (year = '.$db->quote($currquarter->year).' AND quarter < '.$currquarter->quarter.')) '
		     .' ORDER BY year DESC, quarter DESC';
		$row = $db->fetchRow($sql);
		if (!$row) {
			return 0;
		}
		$sql = 'SELECT enrollmentcurrent '
		     . 'FROM offering '
		     . 'WHERE courseid = '.$courseid.' '
		     . 'AND year = '.$db->quote($row['year']).' '
		     . 'AND quarter = '.$row['quarter'];
		$enrollment = $db->fetchColumn($sql);
		$avg = (int) (array_sum($enrollment) / count($enrollment));
		return $avg;
	}
	
	/**
	 * Calculate an estimate of offering credit hours based on 
	 * previous quarter's credit hours.
	 * @param integer $courseid
	 * @return integer
	 */
	public static function EstimateCreditHours($courseid)
	{
		$currquarter = Db_Quarter::FetchCurrentQuarter();
		$db = DbFactory::GetConnection();
		// find the most recent quarter with data for this course
		// that has happened (e.g. prior to the current academic quarter)
		$sql = 'SELECT DISTINCT year, quarter '
		     . 'FROM offering '
		     . 'WHERE courseid = '.$courseid.' '
		     . 'AND (year < '.$db->quote($currquarter->year).' '
		     . 'OR (year = '.$db->quote($currquarter->year).' AND quarter < '.$currquarter->quarter.')) '
		     .' ORDER BY year DESC, quarter DESC';
		$row = $db->fetchRow($sql);
		if (!$row) {
			return 0;
		}
		$sql = 'SELECT studentcredithours '
		     . 'FROM offering '
		     . 'WHERE courseid = '.$courseid.' '
		     . 'AND year = '.$db->quote($row['year']).' '
		     . 'AND quarter = '.$row['quarter'];
		$credithours = $db->fetchColumn($sql);
		$avg = (int) (array_sum($credithours) / count($credithours));
		return $avg;
	}
	
	/**
	 * Search the offering table for a list of quarters for which offering
	 * records exist. Returns an associative array with quarter codes as 
	 * the index and pretty quarter names as the value.
	 * 
	 * @param mixed $filters
	 * @return array
	 */
	public static function FetchActiveQuarters($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT DISTINCT o.year, o.quarter '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . $where
		     .' ORDER BY o.year DESC, o.quarter DESC';
		$results = $db->fetchAssoc($sql);
		$out = array();
		foreach ($results as $row) {
			$index = $row['year'] .'-'. $row['quarter'];
			$out[$index] = eQuarter($row['year'], $row['quarter']); 
		}
		return $out;
	}
	
	/**
	 * Find a course offering record Db_Offering that matches on year, 
	 * quarter, and SLN. If there is no matching record returns null. 
	 * 
	 * @param integer $year year of offering
	 * @param integer $quarter quarter of offering
	 * @param integer $sln schedule line number of offering
	 * @return Db_Offering|null
	 */
	public static function FetchBySLN($year, $quarter, $sln)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM offering '
		     . 'WHERE year = '.$db->quote($year).' '
		     . 'AND quarter = '.$quarter.' '
		     . 'AND sln = '.$sln;
		$row = $db->fetchRow($sql);
		if ($row) {
			$out = new self($row['offeringid'], false);
			$out->init($row);
		} else {
			$out = null;
		}
		return $out;
	}
	
	/**
	 * Returns an array list of Db_Offering objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters 
	 * @return array[Db_Offering]
	 */
	public static function FetchCount($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT COUNT(offeringid) FROM offering '.$where;
		return $db->fetchOne($sql);
	}
	
	/**
	 * Search for a matching offering record using natural candidate key
	 * parameters. This function supports loading external data to 
	 * prevent generation of duplicate records.
	 * 
	 * @param integer $courseid pk of the parent course record
	 * @param integer $year year of offering
	 * @param integer $quarter quarter of offering
	 * @param integer $section quarter of offering
	 * @return Db_Offering
	 */
	public static function FetchMatch($courseid, $year, $quarter, $section)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM offering '
		     . 'WHERE courseid = '.$courseid.' '
		     . 'AND year = '.$db->quote($year).' '
		     . 'AND quarter = '.$quarter.' '
		     . 'AND section = '.$db->quote($section);
		$row = $db->fetchRow($sql);
		if ($row) {
			$out = new self($row['offeringid'], false);
			$out->init($row);
		} else {
			$out = new self(0, false);
			$out->courseid = $courseid;
			$out->year = $year;
			$out->quarter = $quarter;
			$out->section = $section;
		}
		return $out;
	}
	
	/**
	 * Match an existing Db_Offering by searching course section identifying fields. If
	 * no matching record is in the system creates, populates and returns an unsaved record.
	 * @param integer $year
	 * @param integer $quarter
	 * @param string $curriculum
	 * @param integer $courseno
	 * @return Db_Offering
	 */
	public static function FetchMatchBySection($year, $quarter, $curriculum, $courseno, $section)
	{
		$c = null;
		$courseids = Db_Course::FetchCourseids($curriculum, $courseno);
		if (!$courseids) { // no existing courses with this curriculum/courseno
			$c = \Update\Course\FromSws::CreateCourse($curriculum, $courseno, $year, $quarter);
			$courseids[0] = $c->courseid;
		}
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * '
		     . 'FROM offering '
		     . 'WHERE courseid IN('.implode(',',$courseids).') ' 
		     . 'AND year = '.$db->quote($year).' '
		     . 'AND quarter = '.(int)$quarter.' '
		     . 'AND section = '.$db->quote($section);
		$row = $db->fetchRow($sql);
		if ($row) {
			$out = new self($row['offeringid'], false);
			$out->init($row);
		} else {
			$out = new self(0);
			$out->courseid = $courseids[0]; // Null wildcard title will be first record
			$out->year = $year;
			$out->quarter = $quarter;
			$out->section = $section;
			$out->status = 'planned';
		}
		if ($c instanceof Db_Course) {
			$out->setCourse($c);
		}
		return $out;
	}
	
	/**
	 * Returns an array list of Db_Offering objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters 
	 * @return array[Db_Offering]
	 */
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT * FROM offering '.$where.' ORDER BY year DESC, quarter DESC';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$o = new self($row['offeringid'], false);
			$o->init($row);
			$out[] = $o;
		}
		return $out;
	}
	
	/**
	 * Returns an array list of Db_Offering objects loaded from the database
	 * with their Course information pre-loaded. Returned list is limited by 
	 * the provided SQL where clause filters.
	 * @param mixed $filters 
	 * @return array[Db_Offering]
	 */
	public static function FetchReport($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT c.*, o.*, s.staffid, s.personid, s.role, s.timesched, s.buyoutreason, p.* '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'LEFT OUTER JOIN staff s '
		     . 'ON o.offeringid = s.offeringid '
		     . 'AND s.timesched = 1 '
		     . 'LEFT OUTER JOIN person p '
		     . 'ON s.personid = p.personid '
		     . $where
		     .' ORDER BY year DESC, quarter DESC, c.curriculum, c.courseno, o.section, c.wildcardtitle, c.title';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$o = new self($row['offeringid'], false);
			$o->init($row);
			$course = new Db_Course($row['courseid'], false);
			$course->init($row);
			$o->setCourse($course);
			if ($row['personid']) {
				$staff = new Db_Staff($row['staffid'], false);
				$staff->init($row);
				$person = new Db_Person($row['personid'], false);
				$person->init($row);
				$staff->setPerson($person);
				$o->setInstructor($staff);
			} else {
				$o->noInstructor();
			}
			$out[$row['offeringid']] = $o;
		}
		return $out;
	}
	
	/**
	 * Returns an associative array of section ids (A-Z) appropriate for
	 * use as a select input option list. If a Db_Offering object is 
	 * provided marks the sections already in use by other sections of the
	 * same course and quarter;
	 * @param mixed $offering
	 * @return array
	 */
	public static function FetchSectionIndex($offering = null)
	{
		$inuse = self::FetchInUseSections($offering);
		$out = array();
		for ($i = 65; $i <= 90; ++$i) {
			$section = chr($i);
			if (in_array($section, $inuse)) {
				$out['x-'.$section] = '('.$section.' - used)';
			} else {
				$out[$section] = $section;
			}
		}
		return $out;
	}
	
	/**
	 * Returns an array of section ids (A-Z) that are in use by offerings of 
	 * the same course in the same quarter. If the offering argument is null
	 * or has missing course, year, quarter values returns an empty array.
	 * @param mixed $offering
	 * @return array
	 */
	public static function FetchInUseSections($offering)
	{
		/**
		 * @TODO this only deals with normal sections, not two letter quiz sections
		 */
		if ($offering instanceof Db_Offering && $offering->courseid && $offering->year && $offering->quarter) {
			$db = DbFactory::GetConnection();
			$filters = array(
				'c.curriculum = '.$db->quote($offering->curriculum),
				'c.courseno = '.$offering->courseno,
				'o.year = '.$db->quote($offering->year),
				'o.quarter = '.$offering->quarter,
				'o.sectiontype <> \'QZ\'',
				'o.offeringid <> '.$offering->offeringid
			);
			$where = DbObject::MakeWhereClause($filters);
			$sql = 'SELECT section '
			     . 'FROM offering o '
			     . 'INNER JOIN course c '
			     . 'ON o.courseid = c.courseid '
			     . $where;
			return $db->fetchColumn($sql);
		} else {
			return array();
		}
	}
	
	/**
	 * Returns an offeringid that exists in the database associated with the specified
	 * courseid. If the optional preferred_offeringid is provided and it exists, that
	 * value is returned.
	 * @param integer $courseid
	 * @param integer $preferred_offeringid
	 * @return integer
	 */
	public static function FetchValidOfferingid($courseid, $preferred_offeringid = 0)
	{
		$db = DbFactory::GetConnection();
		$matches = $db->fetchColumn('SELECT offeringid FROM offering WHERE courseid = '.$courseid);
		if ($preferred_offeringid && in_array($preferred_offeringid, $matches)) {
			return $preferred_offeringid;
		} else {
			return end($matches);
		}
	}
	
	/**
	 * Returns the offeringid that matches the specified SLN (schedule line number)
	 * or null if no record matches.
	 * @param integer $year
	 * @param integer $quarter
	 * @param integer $sln
	 * @return integer
	 */
	public static function FindSLN($year, $quarter, $sln)
	{
		if (!$sln) return null;
		$db = DbFactory::GetConnection();
		$sql = 'SELECT offeringid '
		     . 'FROM offering '
		     . 'WHERE year = '.$db->quote($year).' '
		     . 'AND quarter = '.(int)$quarter.' '
		     . 'AND sln = '.(int)$sln;
		return $db->fetchOne($sql);
	}
	
	/**
	 * Expose the ActivityLog items attached to this offering.
	 * @return Workflow_Offering
	 */
	protected function getActivityLog()
	{
		if (is_null($this->_activitylog)) {
			$this->_activitylog = Db_ActivityLog_Abstract::FetchMultiple('offeringid = '.$this->offeringid.' OR courseid = '.$this->courseid);
		}
		return $this->_activitylog;
	}
	
	/**
	 * Returns an array of Db_Constraint objects related to this offering
	 * @return array[Db_Constraint]
	 */
	protected function getConstraints()
	{
		if (is_null($this->_constraints)) {
			$this->_constraints = Db_Constraint::LoadContraintsByOffering($this);
		}
		return $this->_constraints;
	}
	
	/**
	 * Returns the Db_Course object related to this offering. This
	 * method is exposed through the "course" virtual property to support
	 * loading on first use.
	 * @return array
	 */
	protected function getCourse()
	{
		if (is_null($this->_course)) {
			$this->_course = Db_Course::Get($this->courseid);
		}
		return $this->_course;
	}
	
	/**
	 * Returns a Db_Staff object that corresponds with the COE faculty that 
	 * has bought out of teaching this course offering. Returns null if there
	 * is no buy out staff.
	 * @return Db_Staff|null
	 */
	public function getBuyout()
	{
		return $this->_buyout;
	}
	
	/**
	 * Returns a ChangeManager object that can be used to create point in time
	 * snapshots of an offering and handle changes to the offering.
	 * @return \Offering\Components\ChangeManager
	 */
	protected function getChangemanager()
	{
		if (is_null($this->_changemanager)) {
			$this->_changemanager = new \Offering\Components\ChangeManager($this);
		}
		return $this->_changemanager;
	}
	
	/**
	 * Returns a ChangeRequests object that contains change requests and related
	 * messages for this offering.
	 * @return \Offering\Components\ChangeRequests
	 */
	protected function getChangerequests()
	{
		if (is_null($this->_changerequests)) {
			$this->_changerequests = new \Offering\Components\ChangeRequests($this);
		}
		return $this->_changerequests;
	}

	/**
	 * Returns a stdClass object with details about error that occurred trying to 
	 * change this offering's section id. Returns null if no error has occured.
	 *  $out->code = integer code for condition
	 *  $out->message = human readable description of error condition
	 *  $out->conflict = offeringid of the offering that conflicted with change
	 * @return stdClass
	 */
	public function getChangeSectionError()
	{
		if (is_null($this->_change_section_error)) {
			return null;
		}
		$this->_change_section_error->message = self::$change_section_error_codes[$this->_change_section_error->code];
		return $this->_change_section_error;
	}

    /**
     * Returns array of Db_Comment related to this offering
     * @return Db_Comment[]
     */
    public function getComments()
    {
        if ($this->_comments === null) {
            $this->_comments = Db_Comment::FetchByOffering($this);
        }
        return $this->_comments;
    }
	
	/**
	 * Merge the various credit description fields into a single human readable
	 * description of credit policy for this course.
	 * @return string
	 */
	public function getCreditDescription()
	{
		switch ($this->creditcontrol) {
			case 'fixed':
				$out = $this->creditmin.' credits';
				break;
			case 'variable': // variable credit - min to max credits':
				$out = $this->creditmin.' to '.$this->creditmax.' credits';
				break;
			case 'minormax': //'variable credit - min or max credits':
				$out = $this->creditmin.' or '.$this->creditmax.' credits';
				break;
			case 'open': //'variable credit 1 to 25 credits':
				$out = 'Variable credit';
				break;
			default:
				$out = null;
				break;
		}
		return $out;
	}
	
	/**
	 * Returns an array of Db_Discussion objects related to this offering or
	 * to the parent Course. This method is exposed through the "discussion" 
	 * virtual property to support loading on first use.
	 * @return array
	 */
	protected function getDiscussion()
	{
		if (is_null($this->_discussion)) {
			$this->_discussion = Db_Discussion::FetchByOffering($this);
		}
		return $this->_discussion;
	}
	
	/**
	 * Returns a human readable description of the funding model for this
	 * course offering.
	 * @return string
	 */
	protected function getFundingName()
	{
		if (array_key_exists($this->funding, self::$fundingtypes)) {
			return self::$fundingtypes[$this->funding];
		} else {
			return $this->funding;
		}
	}
	
	/**
	 * Returns human readable string description of this offering's grading
	 * system.
	 * @return string
	 */
	protected function getGradingsystemname()
	{
		if (array_key_exists($this->gradingsystem, self::$gradingsystems)) {
			return self::$gradingsystems[$this->gradingsystem];
		} else {
			return $this->gradingsystem;
		}
	}
	
	/**
	 * Returns the Db_Staff object related to this offering that has its
	 * `timesched` flag set to true. This method is exposed through the 
	 * "instructor" virtual property to support loading on first use.
	 * @return array
	 */
	protected function getInstructor()
	{
		if (is_null($this->_instructor)) {
			$this->_instructor = $this->getMeetings()->getInstructor();
		}
		return $this->_instructor;
	}
	
	/**
	 * Returns a human readable description of the institution code
	 * @return string
	 */
	public function getInstitutionname()
	{
		if (array_key_exists($this->institution, self::$institutions)) {
			return self::$institutions[$this->institution];
		} else {
			return $this->institution;
		}
	}
	
	/**
	 * Returns log record describing the last change in instructor approval, null if 
	 * instructor approval has not been set at all
	 * @return Db_ActivityLog_Instructorapproval|null
	 */
	public function getInstructorApprovalLog()
	{
		if (is_null($this->_lastApproval) && $this->instructorapproval_logid) {
			$this->_lastApproval = new Db_ActivityLog_Instructorapproval($this->instructorapproval_logid);
		}
		return $this->_lastApproval;
	}
	
	/**
	 * Returns the number of Db_Staff with faculty, adunct, or instructor role
	 * @return integer
	 */
	public function getInstructorCount()
	{
		return $this->_instructor_count;
	}

	/**
	 * Returns a collection of joint offering objects.
	 * @return \Offering\Components\JointOfferings
	 */
	public function getJoint()
	{
		if (is_null($this->_joint)) {
			$this->_joint = new \Offering\Components\JointOfferings($this);
		}
		return $this->_joint;
	}
	
	/**
	 * Translate the UW Time Schedule status field to a human readable value
	 * @return string
	 */
	public function getUwtsstatusName()
	{
		if (array_key_exists($this->uwtsstatus, self::$uwtsstatus_names)) {
			return self::$uwtsstatus_names[$this->uwtsstatus];
		} elseif (is_null($this->uwtsstatus)) {
			return self::$uwtsstatus_names[0];
		} else {
			return $this->uwtsstatus;
		}
	}
	
	/**
	 * Return the Db_RoomNeed object related to this offering
	 * @return Db_RoomNeed
	 */
	public function getRoomneed()
	{
		if (is_null($this->_roomneed)) {
			$this->_roomneed = new Db_RoomNeed($this->offeringid);
		}
		return $this->_roomneed;
	}
	
	/**
	 * Returns an array of  Db_RoomComment object related to this offering
	 * @return array[Db_RoomComment]
	 */
	public function getRoomcomments()
	{
		if (is_null($this->_roomcomments)) {
			$this->_roomcomments = Db_RoomComment::FetchMultiple('offeringid = '.$this->offeringid);
		}
		return $this->_roomcomments;
	}
	
	/**
	 * Translate the Room Schedule status field to a human readable value
	 * @return string
	 */
	public function getRoomstatusName()
	{
		if (array_key_exists($this->roomstatus, self::$uwtsstatus_names)) {
			return self::$uwtsstatus_names[$this->roomstatus];
		} elseif (is_null($this->uwtsstatus)) {
			return self::$uwtsstatus_names[0];
		} else {
			return $this->roomstatus;
		}
	}
	
	/**
	 * If this section field on this offering cannot be changed returns a string
	 * description of the reason. If a section change is safe returns the empty 
	 * string.
	 * @return string
	 */
	public function getSectionLockReason()
	{
		$this->isSectionLocked();
		if (array_key_exists($this->_section_lock_reason, self::$sectionlockreasons)) {
			return self::$sectionlockreasons[$this->_section_lock_reason];
		} else {
			return '';
		}
	}
	
	/**
	 * Creates a REST client interface to the UW student web service
	 * course data.
	 * @return string
	 */
	protected function getSwsDescription()
	{
		return $this->getMapperSwsCourseSection()->getDescription();
	}
	
	/**
	 * Retreives a Db_Syllabus object linked to this course offering. Supports lazy
	 * loading.
	 * @return Db_Syllabus
	 */
	protected function getSyllabus()
	{
		if (is_null($this->_syllabus) && $this->syllabusid) {
			$this->_syllabus = new Db_Syllabus($this->syllabusid);
			$this->_syllabus->setOffering($this);
		}
		return $this->_syllabus;
	}
	
	/**
	 * Returns a Meetings offering component which is collection of meetings and
	 * staff related to this offering.
	 * @return array
	 */
	protected function getMeetings()
	{
		if (is_null($this->_meetings)) {
			$this->_meetings = new \Offering\Components\Meetings($this);
		}
		return $this->_meetings;
	}
	
	/**
	 * Calculate a time schedule string that summarizes the meeting times
	 * for this course.
	 * @return string
	 */
	public function getMeetingSummary($reload_meetings = false)
	{
		return $this->meetings->getMeetingSummary($reload_meetings);
	}
	
	/**
	 * Returns a human readable version of the section type code.
	 * @return string
	 */
	public function getSectionTypeName()
	{
		if (array_key_exists($this->sectiontype, self::$sectiontypes)) {
			return self::$sectiontypes[$this->sectiontype];
		} else {
			return $this->sectiontype;
		}
	}
	
	protected function getSelfSustainingName()
	{
		return $this->getFundingName();
	}
	
	/**
	 * Return a string that gives an identifying description of a
     * course object. Includes curriculum code, number and section and 
     * either a wildcard title or the long title
     * @return string 
	 */
	public function getSummaryName($shownumber = true)
	{
		$out = '';
		if ($shownumber) {
			$out .= $this->curriculum.' '.$this->courseno.' '.$this->section.' ';
		}
		if ($this->wildcardtitle) {
			$out .= $this->wildcardtitle.'*';
		} else {
			$out .= $this->title;
		}
		return $out;
	}

	/**
	 * Returns a human readable version of the summer term code.
	 * @return string
	 */
	public function getSummertermname()
	{
		if (array_key_exists($this->summerterm, self::$summerterms)) {
			return self::$summerterms[$this->summerterm];
		} else {
			return $this->summerterm;
		}
	}
	
	/**
	 * Returns an array list of the Db_Tag objects assigned to this offering.
	 * @return array
	 */
	public function getTags()
	{
		if (is_null($this->_tags)) {
			$db = DbFactory::GetConnection();
			$this->_tags = Db_Tag::FetchByOffering($this);
		}
		return $this->_tags;
	}
	
	/**
	 * Compares this offering's quarter to the current quarter and returns
	 *  -1 if the offering happened in a past quarter
	 *   0 if the offering is happening during the current quarter
	 *   1 if the offering is in the future
	 * @return integer
	 */
	public function getTimeframe()
	{
		if (is_null($this->_timeframe)) {
			$this->_timeframe = Db_Quarter::FetchCurrentQuarter()->compareYearQuarter($this->year, $this->quarter);
		}
		return $this->_timeframe;
	}
	
	/**
	 * Returns the Db_UwtsOffering record linked to this offering (which represents
	 * a local college plan record). If there is no linked record this method returns
	 * null.
	 * @return Db_UwtsOffering
	 */
	public function getUwts()
	{
		if (is_null($this->_uwts)) {
			$this->_uwts = Db_UwtsOffering::FetchByOfferingid($this->offeringid);
		}
		return $this->_uwts;
	}

	/**
	 * Returns true if the provide person has a staff role for this offering
	 * @return boolean
	 */
	public function hasStaff(Db_Person $person)
	{
		return $this->getMeetings()->hasStaff($person);
	}

	/**
	 * Returns true if there is a RoomRequest record matching this offering.
	 * @return boolean
	 */
	public function hasRoomRequest()
	{
		if (!is_null($this->_hasroomrequest)) {
			return $this->_hasroomrequest;
		}
		$db = DbFactory::GetConnection();
		$this->_hasroomrequest = (boolean) $db->fetchOne('SELECT COUNT(offeringid) AS qty FROM roomneed WHERE offeringid = '.$this->offeringid);
		if (!$this->_hasroomrequest) {
			$this->_hasroomrequest = (boolean) $db->fetchOne('SELECT COUNT(offeringid) AS qty FROM roomcomment WHERE offeringid = '.$this->offeringid);
		}
		return $this->_hasroomrequest;
	}

	/**
	 * Returns true if the most recent Instructor Approval action was Adding approval
	 * @return boolean
	 */
	public function isApprovedByInstructor()
	{
		$log = $this->getInstructorApprovalLog();
		if ($log) {
			if ($log->data->approval == 'added') {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Search for a matching offering record using natural candidate key
	 * parameters. Returns true if a record other than this one has the
	 * same values.
	 * @return boolean
	 */
	public function isDuplicate()
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT COUNT(offeringid) FROM offering '
		     . 'WHERE courseid = '.$this->courseid.' '
		     . 'AND year = '.$db->quote($this->year).' '
		     . 'AND quarter = '.$this->quarter.' '
		     . 'AND section = '.$db->quote($this->section).' ';
		if ($this->recordExists()) $sql .= 'AND offeringid <> '.$this->offeringid;
		return $db->fetchOne($sql);
	}
	
	/**
	 * Returns true if this course offering can be edited. Course offerings
	 * are editable when they are in the future or the current quarter.
	 * @return boolean
	 */
	public function isEditable()
	{
		return ($this->getTimeframe() >= 0);
	}
	
	/**
	 * Returns true if this Db_Offering record is in a state where the section id
	 * cannot be changed. 
	 * @return boolean
	 */
	public function isSectionLocked()
	{
		if (!is_null($this->uwts)) {
			$this->_section_lock_reason = 1; //'offering is already linked to a UWTS record'
		}
		if ($this->sectionstatus == 'V') {
			$this->_section_lock_reason = 2; //'offering has section status Verified'
		}
		return (bool)$this->_section_lock_reason;
	}

    /**
     * Returns true if this offering is linked to a UWTS offering record
     * @return bool
     */
    public function isUwtsLinked()
    {
        $this->getUwts();
        return ($this->_uwts !== null);
    }
	
	/**
	 * If this offering has was created by repetition rule and has expected
	 * status, change to planned and log reason. If offering status is not
	 * expected, does nothing.
	 * @param string $trigger action that causes this status change
	 */
	public function makePlanned($trigger)
	{
		if ($this->status == 'expected') {
			$this->status = 'planned';
			$this->save();
			Db_ActivityLog_Mkplanned::Write($this->offeringid, $trigger);
		}
	}
	
	/**
	 * Sets the instructor container to false, which prevents autoloading of
	 * data we know does not exist. Supports bulk loading offering records.
	 */
	public function noInstructor()
	{
		$this->_instructor = false;
	}
	
	/**
	 * Changes the uwtsstatus field when the link between this offering and a 
	 * UWTS record is removed. Logs changes.
	 */
	public function removeUwtsLink()
	{
		$this->uwtsstatus = 3;
		$this->save();
		Db_UwtsMatchingLog::Write(Db_UwtsMatchingLog::REMOVED_LINK, null, $this);
		Db_ActivityLog_Uwtsunlink::Write($this->offeringid);
	}
	
	/**
	 * Bookmarks this offering as the most recently viewed in the user session
	 * data.
	 */
	public function setAsLastViewed()
	{
		$_SESSION['crs_data_last_offeringid'] = $this->offeringid;
	}

	/**
	 * Sets a Db_Staff object that corresponds with the COE faculty that
	 * has bought out of teaching this course offering.
	 * @param Db_Staff $staff
	 */
	public function setBuyout(Db_Staff $staff)
	{
		$this->_buyout = $staff;
	}
	
	/**
	 * Set the internal reference to the Db_Course object related to this 
	 * offering. This method supports bulk loading.
	 * @param Db_Course
	 */
	public function setCourse(Db_Course $course)
	{
		$this->_course = $course;
		$this->courseid = $course->courseid;
	}
	
	/**
	 * Set the value of the enrollmentlimit property. This value also 
	 * affects the calculated studentcredithoursestimate.
	 * @param integer $value
	 */
	public function setEnrollmentLimit($value)
	{
		$value = (int)$value;
		if ($value > 0) {
			// offerings can have an Estimate OR Limit not both
			// if Limit is non zero Estimate must be zero
			$this->setEnrollmentEstimate(0);
			if ($this->course->creditfixed) {
				$this->studentcredithoursestimate = $value * $this->course->creditfixed;
			} elseif ($this->course->creditestimate) {
				$this->studentcredithoursestimate = $value * $this->course->creditestimate;
			}
		}
		parent::__set('enrollmentlimit', $value);
	}

	/**
	 * Set the value of the enrollmentestimate property. This value also 
	 * affects the calculated studentcredithoursestimate.
	 * @param integer $value
	 */
	public function setEnrollmentEstimate($value)
	{
		$value = (int)$value;
		if ($value > 0) {
			// offerings can have an Estimate OR Limit not both
			// if Estimate is non zero Limit must be zero
			$this->setEnrollmentLimit(0);
			if ($this->course->creditfixed) {
				$this->studentcredithoursestimate = $value * $this->course->creditfixed;
			} elseif ($this->course->creditestimate) {
				$this->studentcredithoursestimate = $value * $this->course->creditestimate;
			}
		}
		parent::__set('enrollmentestimate', $value);
	}
	
	/**
	 * Sets the Db_Staff object related to this offering that has its
	 * `timesched` flag set to true. Supports bulk loading of offering
	 * objects.
	 * @param Db_Staff $instructor
	 */
	public function setInstructor(Db_Staff $instructor)
	{
		$this->_instructor = $instructor;
	}
	
	/**
	 * Sets the number of Db_Staff with faculty, adunct, or instructor role
	 * @param integer
	 */
	public function setInstructorCount($count)
	{
		$this->_instructor_count = $count;
	}

	/**
	 * Enforce unique section letters
	 * @param string $section
	 */
	public function setSection($section)
	{
		if ($this->trySection($section)) {
			parent::__set('section', $section);
		} else {
			debug(__METHOD__.' section "'.$section.'" already exists for '.$this->year.'-'.$this->quarter.' '.$this->course->curriculum.' '.$this->course->courseno);
			throw new Exception('Duplicate section letter');
		}
	}
	
	/**
	 * Set the value of the uwtsstatus property. Uwtsstatus contains a
	 * numeric code that describes this section's state in the UW
	 * Time Schedule
	 * @param integer $status
	 */
	public function setUwtsstatus($status)
	{
		$status = (int)$status;
		if ($status < 0 || $status > 4) {
			throw new Exception('Unknown uwtsstatus code '.$status);
		}
		if ($status == 0 && $this->uwtsstatus == 3) {
			// dont replace 3 (was in UWTS, gone now) with 0 (was never in UWTS)
			return;
		}
		parent::__set('uwtsstatus', $status);
	}
	
	/**
	 * Verifies that the required fields have been set in order to check section conflicts
	 * @throws Exception
	 */
	protected function tryCheckSections()
	{
		if (!$this->courseid) {
			throw new Exception('You must set a courseid before setting section letter');
		}
		if (!$this->year) {
			throw new Exception('You must set a year before setting section letter');
		}
		if (!$this->quarter) {
			throw new Exception('You must set a quarter before setting section letter');
		}
	}
	
	/**
	 * Check if the specified section letter is available within this course and quarter
	 * @param unknown_type $section
	 * @throws Exception
	 * @return boolean
	 */
	public function trySection($section)
	{
		$this->tryCheckSections();
		if ($section != $this->section) {
			$db = DbFactory::GetConnection();
			$sql = 'SELECT COUNT(o.offeringid) '
			     . 'FROM offering o '
			     . 'INNER JOIN course c '
			     . 'ON o.courseid = c.courseid '
			     . 'WHERE c.curriculum = '.$db->quote($this->course->curriculum).' '
			     . 'AND c.courseno = '.$this->course->courseno.' '
			     . 'AND o.year = '.$db->quote($this->year).' '
			     . 'AND o.quarter = '.$this->quarter.' '
			     . 'AND o.section = '.$db->quote($section).' '
			     . 'AND o.offeringid <> '.$this->offeringid;
			 $found = $db->fetchOne($sql);
			 if ($found) {
			 	return false;
			 }
		}
		return true;
	}
	
	/**
	 * Pick the next available section letter to use for this offering. If the $prefer
	 * array is specified attempts to use those section letters first in order.
	 * @param array $prefer
	 * @throws \Exception
	 */
	public function useAvailableSection($prefer = array())
	{	
		// make sure we have the data we need to process this
		$this->tryCheckSections();
		// figure out which sections are already in use
		$db = DbFactory::GetConnection();
		$sql = 'SELECT section '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . 'WHERE c.curriculum = '.$db->quote($this->course->curriculum).' '
		     . 'AND c.courseno = '.$this->course->courseno.' '
		     . 'AND o.year = '.$db->quote($this->year).' '
		     . 'AND o.quarter = '.$this->quarter.' '
		     . 'AND o.sectiontype <> \'QZ\' '
		     . 'AND o.offeringid <> '.$this->offeringid;
		$in_use = $db->fetchColumn($sql);
		// add the entire ordered alphabet to $prefer list
		for ($a = 65; $a <= 90; ++$a) {
			$prefer[] = chr($a);
		}
		$found = false;
		foreach ($prefer as $s) {
			if (strlen($s) != 1) continue;
			if (!in_array($s, $in_use)) {
				$found = $s;
				break;
			}
		}
		if (!$found) {
			\Logger::GetInstance()->debug('No available sections for courseid '.$this->courseid.' quarter '.$this->year.'-'.$this->quarter);
			//debug(__METHOD__.PHP_EOL.'Attempted: '.implode(',',$prefer).PHP_EOL.'In use: '.implode(',',$in_use));
			throw new \Exception('No more sections available for this course/quarter');
		}
		parent::__set('section', $found);
	}
	
	/**
	 * Returns an array structure that includes the years and quarters in 
	 * the system and a count of course offerings that exist during that
	 * quarter. Years included begin with the earliest year in the system
	 * and continue for three years past this year.
	 * $out[$year] = array(
	 *     '1' => $count_of_winter_offerings,
	 *     '2' => $count_of_spring_offerings,
	 *     '3' => $count_of_summer_offerings,
	 *     '4' => $count_of_autumn_offerings
	 * );
	 * @return array
	 */
	public static function FetchQuarterCounts($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT o.year, o.quarter, count(o.offeringid) as count '
		     . 'FROM offering o '
		     . 'INNER JOIN course c '
		     . 'ON o.courseid = c.courseid '
		     . $where
		     . 'GROUP BY year, quarter '
		     . 'ORDER BY year, quarter';
		$results = $db->fetchAssoc($sql);
		$out = array();
		// Build a default structure for output
		$startyear = $results[0]['year'];
		$endyear = date('Y') + 3;
		for ($y = $startyear; $y <= $endyear; ++$y) {
			$out[$y] = array(
				'1' => 0,
				'2' => 0,
				'3' => 0,
				'4' => 0
			);
		}
		// Populate it with results found in database
		foreach ($results as $row) {
			if (array_key_exists($row['year'], $out)) {
				$out[$row['year']][$row['quarter']] = $row['count'];
			}
		}
		return $out;
	}
	
	protected function preSave()
	{
		if ($this->institution == 'uweo') {
			$this->funding = 'SS';
		} else {
			$this->funding = 'St';
		}
	}
	
	protected function preDelete()
	{
		if (!$this->offeringid) return true;
		$db = DbFactory::GetConnection();
		$db->query('DELETE FROM comment WHERE offeringid = '.$this->offeringid);
		$db->query('DELETE FROM meeting WHERE offeringid = '.$this->offeringid);
		$db->query('DELETE FROM staff WHERE offeringid = '.$this->offeringid);
		$db->query('DELETE FROM adcabnote WHERE offeringid = '.$this->offeringid);
		$db->query('DELETE FROM discussion WHERE offeringid = '.$this->offeringid);
		$db->query('DELETE FROM roomneed WHERE offeringid = '.$this->offeringid);
		$db->query('DELETE FROM roomcomment WHERE offeringid = '.$this->offeringid);
		$db->query('DELETE FROM offeringtag WHERE offeringid = '.$this->offeringid);
		$db->query('DELETE FROM offeringtag WHERE offeringid = '.$this->offeringid);
		$db->query('DELETE FROM changes WHERE offeringid = '.$this->offeringid);
		$db->query('UPDATE uwtsoffering SET offeringid = NULL WHERE offeringid = '.$this->offeringid);
		if ($this->syllabusid) {
			$db->query('DELETE FROM syllabus WHERE syllabusid = '.$this->syllabusid);
		}
		return true;
	}
	
	/**
	 * Get an instance of Db_Offering identified by $offeringid. Utilizes
	 * the application ObjectRegistry to prevent multiple loading and 
	 * instances of the same record.
	 * @param integer $offeringid
	 * @return Db_Offering
	 */
	public static function Get($offeringid)
	{
		$out = ObjectRegistry::Get(__CLASS__, $offeringid);
		if (is_null($out)) {
			$out = new self($offeringid);
			ObjectRegistry::Add(__CLASS__, $offeringid, $out);
		}
		return $out;
	}
	
	/**
	 * Returns a Db_Offering object who's detail page was last accessed in
	 * the user session. If no last offering is stored, returns null.
	 * @return Db_Offering
	 */
	public static function GetLastViewed()
	{
		if (array_key_exists('crs_data_last_offeringid', $_SESSION)) {
			return Db_Offering::Get($_SESSION['crs_data_last_offeringid']);
		} else {
			return null;
		}
	}
	
	/**
	 * Create an instance of Db_Offering from an associative array returned by
	 * a database query. Checks the ObjectRegistry before instantiating a new
	 * object.
	 * @param array $row
	 * @return Db_Offering
	 */
	public static function Register($row)
	{
		$out = ObjectRegistry::Get(__CLASS__, $row['offeringid']);
		if (is_null($out)) {
			$out = new self($row['offeringid'], false);
			$out->init($row);
			ObjectRegistry::Add(__CLASS__, $row['offeringid'], $out);
		}
		return $out;
	}
	
} 
