<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to the tag database table. A tag represents a user label
 * or grouping of course records.
 * 
 * @author Paul Hanisko
 */

class Db_Tag extends DbObject
{
	
	public function __construct($tagid, $autoload = true)
	{
		$db = DbConnection::GetInstance();
		parent::__construct($db, 'tag');

		$this->addPrimaryKeyField('tagid', $tagid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('name');
		
		if ($autoload) { $this->load(); }
	}
	
	/**
	 * Add this tag to the specified Db_Course
	 * @param Db_Course $course
	 */
	public function addToCourse(Db_Course $course)
	{
		if (!$course->recordExists()) return;
		if (!$this->recordExists()) return;
		$db = DbFactory::GetConnection();
		$exists = $db->fetchOne('SELECT COUNT(tagid) FROM tagcourse WHERE tagid = '.$this->tagid.' AND courseid = '.$course->courseid);
		if (!$exists) {
			$db->query('INSERT INTO tagcourse(tagid, courseid) VALUES('.$this->tagid.', '.$course->courseid.')');
		}
	}
	
	/**
	 * Returns an array list of Db_Tag objects that apply to a course
	 * offering.
	 * @param Db_Offering $offering 
	 * @return array
	 */
	public static function FetchByOffering(Db_Offering $offering)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT tag.tagid, tag.name '
		     . 'FROM tag '
		     . 'INNER JOIN tagcourse '
		     . 'ON tag.tagid = tagcourse.tagid '
		     . 'WHERE tagcourse.courseid = '.$offering->courseid.' '
		     . 'ORDER BY tag.name';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$o = new self($row['tagid'], false);
			$o->init($row);
			$out[] = $o;
		}
		return $out;
	}
	
	/**
	 * Returns an associative array list of tags with tagid as the index 
	 * and tag name as the value. Returned list is limited by the provided 
	 * SQL where clause filters.
	 * @param mixed $filters 
	 * @return array
	 */
	public static function FetchIndex($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT tagid, name FROM tag '.$where.' ORDER BY name';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$out[$row['tagid']] = $row['name'];
		}
		return $out;
	}
	
	/**
	 * Returns a Db_Tag object with the provided name. Attempts to return an existing
	 * tag with this name or creates a new unsaved object.
	 * @param string $name 
	 * @return Db_Tag
	 */
	public static function ImportTag($name)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM tag WHERE tag.name = '.$db->quote($name).' ORDER BY name';
		$row = $db->fetchRow($sql);
		if ($row) {
			$out = new self($row['tagid'], false);
			$out->init($row);
		} else {
			$out = new self(0);
			$out->name = $name;
		}
		return $out;
	}
		
	
	/**
	 * Returns an array list of Db_Tag objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters 
	 * @return array
	 */
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT * FROM tag '.$where.' ORDER BY name';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$o = new self($row['tagid'], false);
			$o->init($row);
			$out[] = $o;
		}
		return $out;
	}
	
	/**
	 * Remove this tag from the specified courseid.
	 * @param Db_Course $course
	 */
	public function removeFromCourse(Db_Course $course)
	{
		if (!$this->recordExists()) return;
		$db = DbFactory::GetConnection();
		$db->query('DELETE FROM tagcourse WHERE tagid = '.$this->tagid.' AND courseid = '.$course->courseid);
	}
	
	/**
	 * Return an array list of tagids that match the specified search terms
	 * @param array $terms
	 * @param boolean $quote whether the specified terms have previously been escaped for the database
	 * @return array
	 */
	public static function Search($terms, $terms_are_quoted = false)
	{
		if (!$terms) {
			return array();
		}
		$db = DbFactory::GetConnection();
		$filters = array();
		foreach ($terms as $t) {
			if (!$terms_are_quoted) {
				$t = $db->quote('%'.$t.'%');
			}
			$filters[] = 'name LIKE '.$t;
		}
		$sql = 'SELECT tagid FROM tag WHERE '.implode(' OR ',$filters);
		return $db->fetchColumn($sql);
	}
	
	public function preDelete()
	{
		$db = DbFactory::GetConnection();
		$db->query('DELETE FROM tagcourse WHERE tagid = '.$this->tagid);
	}
	
	/**
	 * Get an instance of Db_Tag identified by $tagid. Utilizes
	 * the application ObjectRegistry to prevent multiple loading and 
	 * instances of the same record.
	 * @param integer $tagid
	 * @return Db_Tag
	 */
	public static function Get($tagid)
	{
		$out = ObjectRegistry::Get(__CLASS__, $tagid);
		if (is_null($out)) {
			$out = new self($tagid);
			ObjectRegistry::Add(__CLASS__, $tagid, $out);
		}
		return $out;
	}
	
	/**
	 * Create an instance of Db_Tag from an associative array returned by
	 * a database query. Checks the ObjectRegistry before instantiating a new
	 * object.
	 * @param array $row
	 * @return Db_Tag
	 */
	public static function Register($row)
	{
		$out = ObjectRegistry::Get(__CLASS__, $row['tagid']);
		if (is_null($out)) {
			$out = new self($row['tagid'], false);
			$out->init($row);
			ObjectRegistry::Add(__CLASS__, $row['tagid'], $out);
		}
		return $out;
	}
		
}