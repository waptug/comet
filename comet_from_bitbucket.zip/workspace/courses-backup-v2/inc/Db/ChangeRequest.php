<?php
/**
 * @package UW_COE_Courses
 */
/**
 * This object encapsulate a specific change request and its messages
 * @author hanisko
 */
 
class Db_ChangeRequest extends Db_ChangeMessage 
{
	public $messages;
	/**
	 * The message that resolves this ChangeRequest
	 * @var Db_ChangeMessage
	 */
	private $resolution;

	public function __construct($changeid, $autoload = true)
	{
		parent::__construct($changeid, $autoload);
		$this->messages = array();
	}
	
	/**
	 * Add a Db_ChangeMessage object to the internal message store of this
	 * change request. Supports bulk loading of messages.
	 * @param Db_ChangeMessage $message
	 */
	public function addMessage(Db_ChangeMessage $message)
	{
	    if ($message->parent_changeid != $this->changeid) {
	        throw new Exception('Message '.$message->changeid.' does not belong to change request '.$this->changeid);
	    }
		$message->setChangerequest($this);
		$this->messages[] = $message;
	}
	
	/**
	 * Returns true if the provided user has permission to ask other users for
	 * approval of this change request.
	 * @param User $user
	 * @return boolean
	 */
	public function canAskForApproval(User $user)
	{
		if ($user->hasRole('admin')) {
			return true;
		}
		return false;
	}
	
	/**
	 * Returns true if the provided user has permission to comment on this change request.
	 * @param User $user
	 * @return boolean
	 */
	public function canComment(User $user)
	{
		// initially any authenticated user can comment on a change
		return true;
	}
	
	/**
	 * Returns true if the provided user has permission to send communication to UW 
	 * Time Schedule about this change.
	 * @param User $user
	 * @return boolean
	 */
	public function canContactUwts(User $user)
	{
		if ($user->hasRole('admin')) {
			return true;
		}
		return false;
	}
	
	/**
	 * Returns true if the provided user has permission to edit this change message.
	 * @param User $user
	 * @return boolean
	 */
	public function canResolve(User $user)
	{
		if ($user->hasRole('admin')) {
			return true;
		}
		return false;
	}
	
	/**
	 * Return the Db_ChangeMessage object representing the resolution of this
	 * change request.
	 * @return the $resolution
	 */
	public function getResolution() 
	{
	    if (is_null($this->resolution) && $this->resolution_changeid) {
	        $this->resolution = Db_ChangeMessage::Get($this->resolution_changeid);
	    }
		return $this->resolution;
	}

	/**
	 * Return a human readable string description of the status of this change request.
	 * @return string
	 */
	public function getStatus()
	{
		return 'Requested';
	}

	/**
	 * Return true when this change request has been resolved
	 * @return boolean
	 */
	public function isResolved()
	{
	    return ! $this->needsResolution();
	}

	/**
	 * Return true when this change request needs a resolution.
	 * @return boolean
	 */
	public function needsResolution()
	{
	    if ($this->resolution_changeid) {
	        return false;
	    } else {
	        return true;
	    }
	}

	/**
	 * Generate a new Db_ChangeMessage object that is a child of this change request, 
	 * set its inherited fields (parent_changeid, offeringid).
	 * @return Db_ChangeMessage
	 */
	public function newMessage()
	{
		$out = new Db_ChangeMessage(0);
		$out->setChangerequest($this);
		$out->setOffering($this->offering);
		return $out;
	}
	
	/**
	 * Set a Db_ChangeMessage object as the resolution for this change request
	 * @param Db_ChangeMessage $resolution
	 */
	public function setResolution(Db_ChangeMessage $resolution) 
	{
		$this->resolution = $resolution;
	    $this->resolution_changeid = $resolution->changeid;
	}
	
	/**
	 * Get an instance of Db_ChangeMessage identified by $changeid. Utilizes
	 * the application ObjectRegistry to prevent multiple loading and 
	 * instances of the same record.
	 * @param integer $offeringid
	 * @return Db_ChangeMessage
	 */
	public static function Get($changeid)
	{
		$out = ObjectRegistry::Get(__CLASS__, $changeid);
		if (is_null($out)) {
			$out = new self($changeid);
			ObjectRegistry::Add(__CLASS__, $changeid, $out);
		}
		return $out;
	}
	
	/**
	 * Create an instance of Db_ChangeMessage from an associative array returned by
	 * a database query. Checks the ObjectRegistry before instantiating a new
	 * object.
	 * @param array $row
	 * @return Db_ChangeMessage
	 */
	public static function Register($row)
	{
		$out = ObjectRegistry::Get(__CLASS__, $row['changeid']);
		if (is_null($out)) {
			$out = new self($row['changeid'], false);
			$out->init($row);
			ObjectRegistry::Add(__CLASS__, $row['changeid'], $out);
		}
		return $out;
	}
	
}