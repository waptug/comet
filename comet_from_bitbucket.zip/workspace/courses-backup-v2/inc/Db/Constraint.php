<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to the constraints database table. A constraint represents an issue
 * that must be considered when planning or changing a course offering.
 * @author hanisko
 */

class Db_Constraint extends DbObject
{
	private $_contact;
	private $_editedby;
	private $_enteredby;
	
	public function __construct($constraintid, $autoload = true)
	{
		$db = DbConnection::GetInstance();
		parent::__construct($db, 'constraints');
	
		$this->addPrimaryKeyField('constraintid', $constraintid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('courseid', self::TYPE_INT);
		$this->addField('offeringid', self::TYPE_INT);
		$this->addField('contact_personid', self::TYPE_INT);
		$this->addField('entered_date', self::TYPE_DATETIME);
		$this->addField('entered_personid', self::TYPE_INT);
		$this->addField('message');
		$this->addField('message_edit_personid', self::TYPE_INT);
		$this->addField('message_edit_date', self::TYPE_DATETIME);
	
		if ($autoload) { $this->load(); }
	}
	
	public function __get($name)
	{
		switch ($name) {
			case 'contact':
			case 'editedby':
			case 'enteredby':
				$accessor = 'get'.$name;
				return $this->$accessor();
				break;
			default:
				return parent::__get($name);
				break;
		}
	}
	
	/**
	 * Returns a Db_Person object that is the contact for this constraint.
	 * @return Db_Person
	 */
	public function getContact()
	{
		if (is_null($this->_contact)) {
			$this->_contact = Db_Person::Get($this->contact_personid);
		}
		return $this->_contact;
	}
	
	/**
	 * Returns a Db_Person object that last edited this constraint.
	 * @return Db_Person
	 */
	public function getEditedby()
	{
		if (is_null($this->_editedby)) {
			$this->_editedby = Db_Person::Get($this->message_edit_personid);
		}
		return $this->_editedby;
	}
	
	/**
	 * Returns a Db_Person object that originally entered this constraint.
	 * @return Db_Person
	 */
	public function getEnteredby()
	{
		if (is_null($this->_enteredby)) {
			$this->_enteredby = Db_Person::Get($this->entered_personid);
		}
		return $this->_enteredby;
	}
	
	/**
	 * Returns an array list of Db_Constraint objects related to the provided
	 * offering. Constraints may be linked directly to the offering or to the 
	 * related course record.
	 * @param Db_Offering $offering
	 * @return Db_Constraint
	 */
	public static function LoadContraintsByOffering(Db_Offering $offering)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM constraints WHERE courseid = '.$offering->courseid.' OR offeringid = '.$offering->offeringid.' ORDER BY entered_date';
		$results = $db->fetchAssoc($sql);
		$out = array();
		foreach ($results as $row) {
			$o = new Db_Constraint($row['constraintid']);
			$o->init($row);
			$out[] = $o;
		}
		return $out;
	}
	
}