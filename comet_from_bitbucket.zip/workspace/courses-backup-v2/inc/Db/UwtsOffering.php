<?php
/**
 * @package UW_COE_Courses
 */

/**
 * Interface to the uwtsoffering database table. A uwtsoffering record
 * stores offering (section) data as currently represented in the official
 * UW Time Schedule data store.
 *
 * @author Paul Hanisko
 */
class Db_UwtsOffering extends DbObject
{
    private static $_map_quarters_to_int = array(
        'winter' => 1,
        'spring' => 2,
        'summer' => 3,
        'autumn' => 4
    );

    public static $gradingsystems = array(
        'standard' => 'Standard grading',
        'credit' => 'Credit/No-credit'
    );

    public static $institutions = array(
        'state' => 'State funding',
        'uweo' => 'UWEO (self-sustaining)'
    );

    public static $sectiontypes = array(
        'LC' => 'Lecture',
        'IS' => 'Independent Study',
        'PR' => 'Practicum',
        'QZ' => 'Quiz',
        'SM' => 'Seminar'
    );

    public static $summerterms = array(
        '' => 'Full-term',
        'A' => 'A-term',
        'B' => 'B-term',
    );

    protected $_course;
    protected $_meetings;
    protected $_staff;
    protected $_staff_map;
    protected $_joint;

    public function __construct($uwtsofferingid, $autoload = true)
    {
        parent::__construct(DbConnection::GetInstance(), 'uwtsoffering');

        $this->addPrimaryKeyField('uwtsofferingid', $uwtsofferingid, self::TYPE_INT, DbObject::PK_IS_SERIAL);
        $this->addField('courseid', self::TYPE_INT);
        $this->addField('offeringid', self::TYPE_INT);
        $this->addField('sln', self::TYPE_INT);
        $this->addField('year');
        $this->addField('quarter', self::TYPE_INT);
        $this->addField('section');
        $this->addField('summerterm');
        $this->addField('sectiontype');
        $this->addField('institution', self::TYPE_CHAR, 'state');
        $this->addField('creditcontrol');
        $this->addField('creditmin', self::TYPE_INT);
        $this->addField('creditmax', self::TYPE_INT);
        $this->addField('enrollmentcurrent', self::TYPE_INT);
        $this->addField('enrollmentestimate', self::TYPE_INT);
        $this->addField('enrollmentlimit', self::TYPE_INT);
        $this->addField('studentcredithours', self::TYPE_INT);
        $this->addField('gradingsystem');
        $this->addField('deleteflag');
        $this->addField('swspath');
        $this->addField('swslastupdate', self::TYPE_DATETIME);
        $this->addField('importdate');

        if ($autoload) {
            $this->load();
        }
    }

    public function __get($name)
    {
        switch ($name) {
            case 'course':
                return $this->getCourse();
                break;
            case 'curriculum':
            case 'courseno':
                return $this->getCourse()->$name;
                break;
            case 'gradingsystemname':
            case 'institutionname':
            case 'joint':
            case 'meetings':
            case 'sectiontypename':
            case 'staff':
            case 'summertermname':
                $accessor = 'get' . $name;
                return $this->$accessor();
                break;
            default:
                return parent::__get($name);
                break;
        }
    }

    /**
     * Returns an array list of offeringids of local plan records that have the
     * same section as this record, but are not linked to this UWTS record.
     * @return array
     */
    public function fetchConflictingOfferingIds()
    {
        $db = DbFactory::GetConnection();
        $sql = 'SELECT o.offeringid '
            . 'FROM offering o '
            . 'INNER JOIN course c '
            . 'ON o.courseid = c.courseid '
            . 'WHERE c.curriculum = ' . $db->quote($this->curriculum) . ' '
            . 'AND c.courseno = ' . $this->courseno . ' '
            . 'AND o.year = ' . $db->quote($this->year) . ' '
            . 'AND o.quarter = ' . $this->quarter . ' '
            . 'AND o.offeringid <> ' . (int)$this->offeringid;
        return $db->fetchColumn($sql);
    }

    /**
     * Return a list of offeringids that are potential matches for this UWTS
     * record. Potential matches have same year, quarter, curriculum, courseno
     * and are not matched with another UWTS record.
     * @return array
     */
    public function fetchMatchingOfferingids()
    {
        $db = DbFactory::GetConnection();
        $sql = 'SELECT o.offeringid '
            . 'FROM offering o '
            . 'INNER JOIN course c '
            . 'ON o.courseid = c.courseid '
            . 'LEFT OUTER JOIN uwtsoffering u '
            . 'ON o.offeringid = u.offeringid '
            . 'WHERE c.curriculum = ' . $db->quote($this->curriculum) . ' '
            . 'AND c.courseno = ' . $this->courseno . ' '
            . 'AND o.year = ' . $db->quote($this->year) . ' '
            . 'AND o.quarter = ' . $this->quarter . ' '
            . 'AND u.offeringid IS NULL';
        return $db->fetchColumn($sql);
    }

    /**
     * Returns an array list of Db_UwtsOffering objects loaded from the database.
     * Returned list is limited by the provided SQL where clause filters.
     * @param mixed $filters
     * @return array[Db_UwtsOffering]
     */
    public static function FetchMultiple($filters = '')
    {
        $db = DbFactory::GetConnection();
        $where = DbObject::MakeWhereClause($filters);
        $sql = 'SELECT * FROM uwtsoffering ' . $where . ' ORDER BY year DESC, quarter DESC';
        $result = $db->fetchAssoc($sql);
        $out = array();
        foreach ($result as $row) {
            $o = new self($row['uwtsofferingid'], false);
            $o->init($row);
            $out[] = $o;
        }
        return $out;
    }

    /**
     * Match an existing Db_UwtsOffering by searching linked offeringid field. If
     * no matching record is in the system returns NULL.
     * @param integer $offeringid
     * @return Db_UwtsOffering
     */
    public static function FetchByOfferingid($offeringid)
    {
        $db = DbFactory::GetConnection();
        $sql = 'SELECT * FROM uwtsoffering WHERE offeringid = ' . $offeringid;
        $row = $db->fetchRow($sql);
        if ($row) {
            $out = new self($row['uwtsofferingid'], false);
            $out->init($row);
        } else {
            $out = null;
        }
        return $out;
    }

    /**
     * Match an existing Db_UwtsOffering by searching course section identifying fields. If
     * no matching record is in the system creates, populates and returns an unsaved record.
     * @param integer $year
     * @param mixed $quarter
     * @param string $curriculum
     * @param integer $courseno
     * @return Db_UwtsOffering
     */
    public static function FetchBySection($year, $quarter, $curriculum, $courseno, $section)
    {
        if (array_key_exists($quarter, self::$_map_quarters_to_int)) {
            $quarter = self::$_map_quarters_to_int[$quarter];
        } else {
            $quarter = (int)$quarter;
        }
        $c = null;
        $courseids = Db_Course::FetchCourseids($curriculum, $courseno);
        if (!$courseids) { // no existing courses with this curriculum/courseno
            $c = \Update\Course\FromSws::CreateCourse($curriculum, $courseno, $year, $quarter);
            $courseids[0] = $c->courseid;
        }
        $db = DbFactory::GetConnection();
        $sql = 'SELECT * '
            . 'FROM uwtsoffering '
            . 'WHERE courseid IN(' . implode(',', $courseids) . ') '
            . 'AND year = ' . $db->quote($year) . ' '
            . 'AND quarter = ' . (int)$quarter . ' '
            . 'AND section = ' . $db->quote($section);
        $row = $db->fetchRow($sql);
        if ($row) {
            $out = new self($row['uwtsofferingid'], false);
            $out->init($row);
        } else {
            $out = new self(0);
            $out->courseid = $courseids[0]; // Null wildcard title will be first record
            $out->year = $year;
            $out->quarter = $quarter;
            $out->section = $section;
        }
        if ($c instanceof Db_Course) {
            $out->setCourse($c);
        }
        return $out;
    }

    /**
     * Returns a Db_UwtsOffering object that matches the specified year, quarter, and
     * SLN. If no matching record is in the database returns null.
     * @param string $year
     * @param integer $quarter
     * @param integer $sln
     * @return Db_UwtsOffering
     */
    public static function FetchBySLN($year, $quarter, $sln)
    {
        $db = DbFactory::GetConnection();
        $sql = 'SELECT * '
            . 'FROM uwtsoffering '
            . 'WHERE year = ' . $db->quote($year) . ' '
            . 'AND quarter = ' . (int)$quarter . ' '
            . 'AND sln = ' . $sln;
        $row = $db->fetchRow($sql);
        if ($row) {
            $out = new self($row['uwtsofferingid'], false);
            $out->init($row);
        } else {
            $out = null;
        }
        return $out;
    }

    /**
     * Merge the various credit description fields into a single human readable
     * description of credit policy for this course.
     * @return string
     */
    public function getCreditDescription()
    {
        switch ($this->creditcontrol) {
            case 'fixed':
                $out = $this->creditmin . ' credits';
                break;
            case 'variable': // variable credit - min to max credits':
                $out = $this->creditmin . ' to ' . $this->creditmax . ' credits';
                break;
            case 'minormax': //'variable credit - min or max credits':
                $out = $this->creditmin . ' or ' . $this->creditmax . ' credits';
                break;
            case 'open': //'variable credit 1 to 25 credits':
                $out = 'Variable credit';
                break;
            default:
                $out = null;
                break;
        }
        return $out;
    }

    /**
     * Returns human readable string description of this offering's grading
     * system.
     * @return string
     */
    protected function getGradingsystemname()
    {
        if (array_key_exists($this->gradingsystem, self::$gradingsystems)) {
            return self::$gradingsystems[$this->gradingsystem];
        } else {
            return $this->gradingsystem;
        }
    }

    /**
     * Returns a human readable description of the institution code
     * @return string
     */
    public function getInstitutionname()
    {
        if (array_key_exists($this->institution, self::$institutions)) {
            return self::$institutions[$this->institution];
        } else {
            return $this->institution;
        }
    }

    /**
     * Returns a human readable version of the section type code.
     * @return string
     */
    public function getSectiontypename()
    {
        if (array_key_exists($this->sectiontype, self::$sectiontypes)) {
            return self::$sectiontypes[$this->sectiontype];
        } else {
            return $this->sectiontype;
        }
    }

    /**
     * Returns a human readable version of the summer term code.
     * @return string
     */
    public function getSummertermname()
    {
        if (array_key_exists($this->summerterm, self::$summerterms)) {
            return self::$summerterms[$this->summerterm];
        } else {
            return $this->summerterm;
        }
    }


    /**
     * Returns a Db_Course object that corresponds to this UwtsOffering object.
     * @return Db_Course
     */
    protected function getCourse()
    {
        if (is_null($this->_course)) {
            $this->_course = Db_Course::Get($this->courseid);
        }
        return $this->_course;
    }

    /**
     * Returns a \Uwts\Components\Joint collection that corresponds to this
     * UwtsOffering object.
     * @return \Uwts\Components\Joint
     */
    protected function getJoint()
    {
        if (is_null($this->_joint)) {
            $this->_joint = new \Uwts\Components\Joint($this);
        }
        return $this->_joint;
    }

    /**
     * Returns an array of Db_UwtsMeeting objects that belong to this offering. The
     * array is indexed by meetingnumber.
     * @return array[Db_UwtsMeeting]
     */
    protected function getMeetings()
    {
        if (is_null($this->_meetings)) {
            if (!$this->uwtsofferingid) {
                $this->_meetings = array();
            } else {
                $this->_meetings = Db_UwtsMeeting::FetchByUwtsOffering($this->uwtsofferingid);
            }
        }
        return $this->_meetings;
    }

    /**
     * Returns a Db_UwtsMeeting object that corresponds to the specified meeting
     * number. If there is not corresponding meeting object an new empty object
     * is created and returned.
     * @param integer $meetingnumber
     * @return Db_UwtsMeeting
     */
    public function getMeetingByNumber($meetingnumber)
    {
        $this->getMeetings();
        if (!array_key_exists($meetingnumber, $this->_meetings)) {
            return null;
        }
        return $this->_meetings[$meetingnumber];
    }

    /**
     * Returns an array of Db_UwtsStaff objects that belong to this offering.
     * @return array[Db_UwtsStaff]
     */
    protected function getStaff()
    {
        if (is_null($this->_staff)) {
            if (!$this->uwtsofferingid) {
                $this->_staff = array();
                $this->_staff_map = array();
            } else {
                $this->_staff = Db_UwtsStaff::FetchByUwOffering($this->uwtsofferingid);
                $this->_staff_map = array();
                // build a map so staff are addressable by meeting number and specifically
                foreach ($this->_staff as $staff) {
                    if (!array_key_exists($staff->meetingnumber, $this->_staff_map)) {
                        $this->_staff_map[$staff->meetingnumber] = array();
                    }
                    $this->_staff_map[$staff->meetingnumber][$staff->regid] = $staff;
                }
            }
        }
        return $this->_staff;
    }

    /**
     * Returns a specific Db_UwtsStaff record identified by a meeting number and RegID.
     * If the specified record does not exist, returns null.
     * @param integer $meetingnumber
     * @param string $regid
     * @return Db_UwtsStaff
     */
    public function getStaffByRegid($meetingnumber, $regid)
    {
        $this->getStaff();
        if (array_key_exists($meetingnumber, $this->_staff_map)) {
            if (array_key_exists($regid, $this->_staff_map[$meetingnumber])) {
                return $this->_staff_map[$meetingnumber][$regid];
            }
        }
        return null;
    }

    /**
     * Returns an array list of Db_UwtsStaff objects that belong to this offering and the
     * specified meeting number.
     * @param integer $meetingnumber
     * @return array[Db_UwtsStaff]
     */
    public function getStaffByMeeting($meetingnumber)
    {
        $this->getStaff();
        if (array_key_exists($meetingnumber, $this->_staff_map)) {
            return $this->_staff_map[$meetingnumber];
        } else {
            return array();
        }
    }

    /**
     * Returns a Db_UwtsMeeting object that corresponds to the specified meeting
     * number. If there is not corresponding meeting object an new empty object
     * is created and returned.
     * @param integer $meetingnumber
     * @return Db_UwtsMeeting
     */
    public function importMeeting($meetingnumber)
    {
        $this->getMeetings();
        if (!array_key_exists($meetingnumber, $this->_meetings)) {
            $this->_meetings[$meetingnumber] = new Db_UwtsMeeting($this->uwtsofferingid, $meetingnumber);
        }
        return $this->_meetings[$meetingnumber];
    }

    /**
     * Returns a Db_UwtsStaff object that corresponds to the specified meeting
     * number and regid. If there is not corresponding meeting object an new empty
     * object is created and returned.
     * @param integer $meetingnumber
     * @param string $regid
     * @return Db_UwtsMeeting
     */
    public function importStaff($meetingnumber, $regid)
    {
        $this->getStaff();
        if (!array_key_exists($meetingnumber, $this->_staff_map)) {
            $this->_staff_map[$meetingnumber] = array();
        }
        if (!array_key_exists($regid, $this->_staff_map[$meetingnumber])) {
            $o = new Db_UwtsStaff(0);
            $o->uwtsofferingid = $this->uwtsofferingid;
            $o->meetingnumber = $meetingnumber;
            $o->regid = $regid;
            $this->_staff[] = $o;
            $this->_staff_map[$meetingnumber][$regid] = $o;
        }
        return $this->_staff_map[$meetingnumber][$regid];
    }

    /**
     * Returns true if there are no meeting records with days planned for this
     * offering.
     * @return boolean
     */
    public function meetingsToBeArranged()
    {
        if (is_null($this->_meetings)) {
            $this->getMeetings();
        }
        // some array gymnastics because this array is indexed by meeting number
        $keys = array_keys($this->_meetings);
        if (count($this->_meetings) == 0 || (count($this->_meetings) == 1 && $this->_meetings[$keys[0]]->dows == '')) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Set the Db_Course object that corresponds to this UwtsOffering object.
     * @param Db_Course
     */
    protected function setCourse(Db_Course $course)
    {
        $this->_course = $course;
    }

    protected function postInsert()
    {
        $this->postSave();
    }

    protected function postUpdate()
    {
        $this->postSave();
    }

    protected function postSave()
    {
        if (is_array($this->_meetings)) {
            foreach ($this->_meetings as $meeting) {
                $meeting->uwtsofferingid = $this->uwtsofferingid;
                if ($meeting->deleteFlag) {
                    $meeting->delete();
                } else {
                    $meeting->save();
                }
            }
        }
        if (is_array($this->_staff)) {
            foreach ($this->_staff as $staff) {
                $staff->uwtsofferingid = $this->uwtsofferingid;
                if ($staff->deleteFlag) {
                    $staff->delete();
                } else {
                    $staff->save();
                }
            }
        }
        if (!is_null($this->_joint)) {
            $this->_joint->save();
        }
    }

    protected function preDelete()
    {
        $db = DbFactory::GetConnection();
        $db->query('DELETE FROM uwtsjoint WHERE uwtsofferingid = '.$this->uwtsofferingid);
        $db->query('DELETE FROM uwtsstaff WHERE uwtsofferingid = '.$this->uwtsofferingid);
        $db->query('DELETE FROM uwtsmeeting WHERE uwtsofferingid = '.$this->uwtsofferingid);
        $db->query('DELETE FROM uwtsmatchinglog WHERE uwtsofferingid = '.$this->uwtsofferingid);
        return true;
    }

}
