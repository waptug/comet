<?php
/**
 * @package edu.uw.education.courses
 */
/**
 * Interface for Comment record, storable in database.
 * @author hanisko
 */

/**
 * @property integer  $commentid
 * @property integer  $courseid
 * @property integer  $offeringid
 * @property integer  $created_on  Unix timestamp
 * @property integer  $created_personid
 * @property integer  $edited_on  Unix timestamp
 * @property integer  $edited_personid
 * @property integer  $commenttype
 * @property integer  $visibility
 * @property integer  $todoitem
 * @property string   $comment
 */
class Db_Comment extends DbObject
{

    public function __construct($commentid, $autoload = true)
    {
        parent::__construct(DbConnection::GetInstance(), 'comment');
        $this->addPrimaryKeyField('commentid', $commentid, self::TYPE_INT, self::PK_IS_SERIAL);
        $this->addField('courseid', self::TYPE_INT);
        $this->addField('offeringid', self::TYPE_INT);
        $this->addField('created_on', self::TYPE_DATETIME);
        $this->addField('created_personid', self::TYPE_INT);
        $this->addField('edited_on', self::TYPE_DATETIME);
        $this->addField('edited_personid', self::TYPE_INT);
        $this->addField('commenttype', self::TYPE_INT, 0);
        $this->addField('visibility', self::TYPE_INT, 0);
        $this->addField('todoitem', self::TYPE_INT, 0);
        $this->addField('comment');

        if ($autoload) {
            $this->load();
        }
    }

    /**
     * Returns array of Db_Comment related to the provided offering
     * Comments can be linked to the specific offering or the offering's course record
     * @param Db_Offering $offering
     * @return Db_Comment[]
     */
    public static function FetchByOffering(Db_Offering $offering)
    {
        $db = DbFactory::GetConnection();
        $sql = 'SELECT * FROM comment '
             . 'WHERE offeringid = '.$offering->offeringid.' '
             . 'OR courseid = '.$offering->courseid.' '
             . 'ORDER BY created_on DESC';
        $result = $db->fetchAssoc($sql);
        $out = array();
        foreach ($result as $row) {
            $o = new self($row['offeringid'], false);
            $o->init($row);
            $out[] = $o;
        }
        return $out;
    }

}
