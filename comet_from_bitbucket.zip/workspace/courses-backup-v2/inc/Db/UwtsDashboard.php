<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to the auth database table. An auth record represents
 * a known user that has special permissions in the system.
 * 
 * @author Paul Hanisko
 */

class Db_UwtsDashboard extends DbObject
{
	
	public function __construct($environment = 'PROD', $autoload = true)
	{
		$db = DbConnection::GetInstance();
		parent::__construct($db, 'uwtsdashboard');

		$this->addPrimaryKeyField('environment', $environment, self::TYPE_CHAR);
		$this->addField('updatetoyear');
		$this->addField('updatetoquarter');
		$this->addField('quarterupdatedby');
		$this->addField('quarterupdatedat', self::TYPE_DATETIME);
		$this->addField('lastupdate', self::TYPE_DATETIME);
		$this->addField('lastupdateduration', self::TYPE_INT);
		
		if ($autoload) { $this->load(); }
	}

	/**
	 * Returns a count of UWTS cache records that have no been linked
	 * to a local plan offering record.
	 * @return integer
	 */
	public function getUnlinkedUwtsCount()
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT COUNT(uwtsofferingid) AS qty FROM uwtsoffering WHERE offeringid IS NULL';
		return $db->fetchOne($sql);
	}
	
	/**
	 * Returns a count of local plan offering records that have not
	 * been linked to a UWTS record and have not been canceled.
	 * @return integer
	 */
	public function getUnlinkedPlanCount()
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT COUNT(o.offeringid) AS qty '
		     . 'FROM offering o '
		     . 'LEFT OUTER JOIN uwtsoffering u '
		     . 'ON o.offeringid = u.offeringid '
		     . 'WHERE u.offeringid IS NULL '
		     . 'AND o.status <> \'canceled\' '
		     . 'AND (o.year < '.$db->quote($this->updatetoyear).' OR (o.year = '.$db->quote($this->updatetoyear).' AND o.quarter <= '.$this->updatetoquarter.'))';
		return $db->fetchOne($sql);
	}
	
	/**
	 * Returns an array of Db_UwtsMatchingLog objects that correspond to the
	 * last UWTS update run.
	 * @return array[Db_UwtsMatchingLog]
	 */
	public function getLastUpdateLinkingLog()
	{
		
	}
	
	/**
	 * Returns true if provided $year and $quarter are equal to or previous to the
	 * current "Update To" setting of the dashboard and therefore safe to run SWS
	 * updates on.
	 * @param integer $year
	 * @param integer $quarter
	 * @return boolean
	 */
	public function isUpdateQuarter($year, $quarter)
	{
		$last = new Db_Quarter($this->updatetoyear, $this->updatetoquarter, false);
		// argument is before $last  -1 okay to update
		// argument is equal to $last 0 okay to update
		// argument is after $last    1 Do not update
		return ($last->compareYearQuarter($year, $quarter) < 1);
	}
	
}