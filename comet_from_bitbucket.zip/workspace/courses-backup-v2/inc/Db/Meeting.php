<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to the meeting database table. A meeting represents the
 * day and time that schedule course offering holds class. Each
 * offering can have multiple meeting records.
 * 
 * @author Paul Hanisko
 */

class Db_Meeting extends DbObject 
{
	private $_offering;
	private $_staff;
	private $_uwtsinstructor;
	
	public $daylist;
	
	public static $daymap = array('sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat');
	
	public function __construct($meetingid, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'meeting');
		
		$this->addPrimaryKeyField('meetingid', $meetingid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('offeringid', self::TYPE_INT);
		$this->addField('meetingnumber', self::TYPE_INT, 1);
		$this->addField('dows');
		$this->addField('start');
		$this->addField('end');
		$this->addField('building');
		$this->addField('room');
		
		$this->daylist = array();
		
		if ($autoload) { 
			$this->load();
		}
	}
	
	public function __get($name)
	{
		switch($name) {
			case 'offering':
				return $this->getOffering();
				break;
			case 'staff':
				return $this->getStaff();
				break;
			case 'uwtsinstructor':
				return $this->getUwtsInstructor();
				break;
			case 'sun':
			case 'mon':
			case 'tue':
			case 'wed':
			case 'thu':
			case 'fri':
			case 'sat':
				return $this->checkDay($name);
				break;
			default:
				return parent::__get($name);
				break;
		}
	}
	
	/**
	 * Search for a matching meeting record using natural candidate key
	 * parameters. This function supports loading external data to 
	 * prevent generation of duplicate records.
	 * 
	 * @param integer $offeringid pk of the parent offering record
	 * @param integer $meetingnumber meeting number (1-3) in UW Time schedule
	 * @return Db_Meeting
	 * 
	 * @TODO should be named ImportMeeting()
	 */
	public static function FetchMatch($offeringid, $meetingnumber)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM meeting '
		     . 'WHERE offeringid = '.$offeringid.' '
		     . 'AND meetingnumber = '.$meetingnumber;
		$row = $db->fetchRow($sql);
		if ($row) {
			$out = new self($row['meetingid'], false);
			$out->init($row);
		} else {
			$out = new self(0, false);
			$out->offeringid = $offeringid;
			$out->meetingnumber = $meetingnumber;
		}
		return $out;
	} 
	
	/**
	 * Returns an array list of Db_Meeting objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters 
	 * @return array
	 */
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT * FROM meeting '.$where.' ORDER BY start, end';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$o = new self($row['meetingid'], false);
			$o->init($row);
			$out[] = $o;
		}
		return $out;
	}
	
	/**
	 * Returns an associative array of integer UW Time Schedule meeting numbers useful
	 * for populating form select lists.
	 * @param mixed $filters
	 * @return array
	 */
	public static function FetchMeetingNumberIndex($filters = '')
	{
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT DISTINCT meetingnumber, meetingnumber FROM meeting '.$where.' ORDER BY meetingnumber';
		return DbFactory::GetConnection()->fetchPairs($sql);
	}
	
	/**
	 * Returns an array list of Db_Meeting objects loaded from the database that
	 * apply to the specified $offeringid. Returned list is indexed by the 
	 * meetingnumber (1,2,3) corresponding to the meeting position in the UW
	 * Time Schedule.
	 * @param mixed $filters 
	 * @return array
	 */
	public static function FetchByOffering($offeringid)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM meeting WHERE offeringid = '.$offeringid.' ORDER BY meetingnumber, start, end';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$o = new self($row['meetingid'], false);
			$o->init($row);
			if (!array_key_exists($row['meetingnumber'], $out)) {
				$out[$row['meetingnumber']] = array();
			}
			$out[$row['meetingnumber']] = $o;
		}
		return $out;
	}
		
	/**
	 * Returns true if the specified $day ('sun', 'mon', 'tue'...) is a scheduled
	 * day for this meeting.
	 * @param string $day
	 * @return boolean
	 */
	public function checkDay($day)
	{
		return (in_array(array_search($day, self::$daymap), $this->daylist));
	}
	
	/**
	 * Returns the brief string used in the UW Time Schedule to describe the days
	 * and time of this meeting
	 * @return string
	 */
	public function getUwtsSummary()
	{
		if (!$this->start || !$this->end) {
			return null;
		}
		$start = new Time($this->start);
		$end = new Time($this->end);
		$daysummary = '';
		foreach ($this->daylist as $d) {
			switch ($d) {
				case 0: $daysummary .= 'Su'; break;
				case 1: $daysummary .= 'M'; break;
				case 2: $daysummary .= 'T'; break;
				case 3: $daysummary .= 'W'; break;
				case 4: $daysummary .= 'Th'; break;
				case 5: $daysummary .= 'F'; break;
				case 6: $daysummary .= 'S'; break;
				default: break;
			}
		}
		return $daysummary.' '.$start->getUwtsBrief().'-'.$end->getUwtsBrief(true);
	}
	
	/**
	 * Get the Db_Offering object associated with this meeting. 
	 * @return Db_Offering
	 */
	protected function getOffering()
	{
		if (is_null($this->_offering) && $this->offeringid) {
			$this->_offering = Db_Offering::Get($this->offeringid);
		}
		return $this->_offering;
	}
	
	/**
	 * Set the Db_Offering object associated with this meeting.
	 * @return Db_Offering
	 */
	public function setOffering(Db_Offering $offering) 
	{
		$this->_offering = $offering;
	}
	
	/**
	 * Returns an array of Db_Staff objects representing the teaching staff
	 * associated with this meeting.
	 * @return array
	 */
	public function getStaff()
	{
		if (is_null($this->_staff)) {
			$stafflist = Db_Staff::FetchMultiple('offeringid = '.$this->offeringid.' AND meetingnumber = '.$this->meetingnumber);
			$this->setStaff($stafflist);
		}
		return $this->_staff;
	}

	/**
	 * Returns true if meeting does not have the properties required for it to exist
	 * @return array
	 */
	public function isEmpty()
	{
		if (count($this->daylist) < 1) {
			return true;
		}
		if (!$this->start || !$this->end) {
			return true;
		}
		return false;
	}
	
	/**
	 * Adds a Db_Staff object to the internal list of teaching staff associated
	 * with this meeting. Checks if the $staff is the listed instructor and sets
	 * that value as well.
	 * @param Db_Staff $staff
	 */
	public function addStaff(Db_Staff $staff)
	{
		if (!is_array($this->_staff)) {
			$this->_staff = array();
		}
		if ($staff->timesched) {
			$this->_uwtsinstructor = $staff;
		}
		$this->_staff[] = $staff;
	}
	
	/**
	 * Sets the internal list of teaching staff (Db_Staff) objects to the array
	 * provided as an argument. Checks the array for UWTS Instructor and sets
	 * that propery if it exists
	 * @param array[Db_Staff] $stafflist
	 */
	public function setStaff($stafflist)
	{
		$this->_staff = array();
		$this->_uwtsinstructor = false;
		foreach ($stafflist as $staff) {
			$this->addStaff($staff);
		}
	}
	
	/**
	 * Returns a Db_Staff object where the teaching staff is assigned to this 
	 * meeting as the person listed in the UW Time Schedule.
	 * @return Db_Staff 
	 */
	public function getUwtsInstructor()
	{
		if (is_null($this->_uwtsinstructor)) {
			$this->getStaff();
		}
		return $this->_uwtsinstructor;
	}
	
	/**
	 * Set the value for the internal day list array. This day list is a list
	 * of integers (0-6) corresponding with the days of the week. The argument
	 * can be either an array list of the integer values or string containg
	 * the integers.
	 * @param mixed $days
	 */
	public function setDays($days) 
	{
		if (is_array($days)) {
			$this->daylist = $days;
		} else {
			if ($days) {
				$this->daylist = str_split($days);
			} else {
				$this->daylist = array();
			}
		}
	}
	
	/**
	 * Find then next available meeting number for this offering and set the 
	 * meetingnumber property.
	 */
	public function setNextMeetingNumber()
	{
		$sql = 'SELECT MAX(meetingnumber) FROM meeting WHERE offeringid = '.$this->offeringid;
		$this->meetingnumber = (DbFactory::GetConnection()->fetchOne($sql) + 1);
	}
		
	protected function postInit()
	{
		$this->setDays($this->dows);
	}

	protected function preSave()
	{
		if (is_array($this->daylist)) {
			$this->dows = implode('', $this->daylist);
		}
	}
	
	protected function postSave()
	{
		$db = DbFactory::GetConnection();
		$db->query('DELETE FROM meetingday WHERE meetingid = '.$this->meetingid);
		$values = array();
		foreach ($this->daylist as $dow) {
			$values[] = '('.$this->meetingid.','.$dow.')';
		}
		if ($values) {
			$db->query('INSERT INTO meetingday VALUES '.implode(',',$values));
		}
		$this->offering->meetingsummary = $this->offering->meetings->getMeetingSummary(true);
		$this->offering->save();
	}
	
	protected function preDelete()
	{
		$db = DbFactory::GetConnection();
		$db->query('DELETE FROM meetingday WHERE meetingid = '.$this->meetingid);
	}
	
	protected function postDelete()
	{
		$this->offering->meetingsummary = $this->offering->meetings->getMeetingSummary(true);
		$this->offering->save();
	}
	
	/**
	 * Get an instance of Db_Meeting identified by $meetingid. Utilizes
	 * the application ObjectRegistry to prevent multiple loading and 
	 * instances of the same record.
	 * @param integer $meetingid
	 * @return Db_Meeting
	 */
	public static function Get($meetingid)
	{
		$out = ObjectRegistry::Get(__CLASS__, $meetingid);
		if (is_null($out)) {
			$out = new self($meetingid);
			ObjectRegistry::Add(__CLASS__, $meetingid, $out);
		}
		return $out;
	}
	
	/**
	 * Create an instance of Db_Meeting from an associative array returned by
	 * a database query. Checks the ObjectRegistry before instantiating a new
	 * object.
	 * @param array $row
	 * @return Db_Meeting
	 */
	public static function Register($row)
	{
		$out = ObjectRegistry::Get(__CLASS__, $row['meetingid']);
		if (is_null($out)) {
			$out = new self($row['meetingid'], false);
			$out->init($row);
			ObjectRegistry::Add(__CLASS__, $row['meetingid'], $out);
		}
		return $out;
	}
	
}