<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to the uwtsstaff database table. A Db_UwtsStaff record 
 * stores course section staff data as currently represented in the 
 * official UW Time Schedule data store.
 *
 * @author Paul Hanisko
 */


class Db_UwtsStaff extends DbObject implements Interface_Person
{
	private $_person;
	public $deleteFlag = false;
	
	public function __construct($uwtsstaffid, $autoload = true)
	{
		parent::__construct(DbConnection::GetInstance(), 'uwtsstaff');

		$this->addPrimaryKeyField('uwtsstaffid', $uwtsstaffid, self::TYPE_INT, DbObject::PK_IS_SERIAL);
		$this->addField('uwtsofferingid', self::TYPE_INT);
		$this->addField('meetingnumber', self::TYPE_INT, 1);
		$this->addField('regid');
		$this->addField('staffid', self::TYPE_INT);
		$this->addField('personid', self::TYPE_INT);

		if ($autoload) {
			$this->load();
		}
	}
	
	public function __get($name)
	{
		switch ($name) {
			case 'person':
				return $this->getPerson();
			default:
				return parent::__get($name);
				break;
		}
	}

	/**
	 * Returns an array list of Db_UwtsStaff objects loaded from the database. The list
	 * is limited to staff belonging to the specified Db_UwtsOffering.
	 * @param mixed $filters
	 * @return array
	 */
	public static function FetchByUwOffering($uwtsofferingid)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM uwtsstaff WHERE uwtsofferingid = '.$uwtsofferingid.' ORDER BY meetingnumber';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$o = new self($row['uwtsstaffid'], false);
			$o->init($row);
			$out[] = $o;
		}
		return $out;
	}
	
	/**
	 * Return the Db_Person object related to this object.
	 * @return Db_Person
	 */
	protected function getPerson()
	{
		$this->linkPerson();
		if (is_null($this->_person)) {
			$this->_person = Db_Person::Get($this->personid);
		}
		return $this->_person;
	}
	
	/**
	 * Return the contents of the firstname property. Satisfies the
	 * Interface_Person requirement.
	 * @return string
	 */
	public function getFirstname()
	{
		return $this->person->firstname;
	}
	
	/**
	 * Return the contents of the lastname property. Satisfies the
	 * Interface_Person requirement.
	 * @return string
	 */
	public function getLastname()
	{
		return $this->person->lastname;
	}
	
	/**
	 * Links this object to a Db_Person object. If needed will create a new
	 * person object and update it from the SWS person resource.
	 */
	protected function linkPerson()
	{
		if ($this->personid) return;
		$this->_person = Db_Person::FetchByRegid($this->regid);
		if (!$this->_person->recordExists()) {
			$sws = new \Update\Person\FromSws($this->_person);
			$r = $sws->updateAll();
			if ($r) {
				// creating people discovered in UWTS as adjuncts
				$this->_person->isadjunct = true;
				$this->_person->save();
			}
		}
		if ($this->_person->personid) {
			$this->personid = $this->_person->personid;
		}
	}
	
	protected function preInsert()
	{
		$this->linkPerson();
	}
	
	protected function preUpdate()
	{
		$this->linkPerson();
	}
	
}