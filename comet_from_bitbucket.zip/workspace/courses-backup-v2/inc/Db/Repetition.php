<?php
/**
 * Interface to the repetition database table. A repetition rule 
 * defines how a course is scheduled on a regular basis
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Db_Repetition extends DbObject 
{
	public static $frequencies = array(
		'1' => 'Every year',
		'2' => 'Every other year',
		'3' => 'Every third year',
		'4' => 'Every fourth year'
	);
	
	public static $quarters = array(
		'1' => 'Winter',
		'2' => 'Spring',
		'3' => 'Summer',
		'4' => 'Autumn',
		'0' => 'Each quarter',
		'5' => 'Autumn, Winter, and Spring'
	);
	
	private $_course;
	private $_updateable;
	
	public $staff = array();
	public $meetings = array();
	
	public function __construct($repetitionid, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'repetition');
		
		$this->addPrimaryKeyField('repetitionid', $repetitionid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('courseid', self::TYPE_INT);
		$this->addField('firstyear', self::TYPE_INT);
		$this->addField('yearfreq', self::TYPE_INT);
		$this->addField('quarter', self::TYPE_INT);
		$this->addField('sections', self::TYPE_INT);
		$this->addField('sectionpref');
		$this->addField('summerterm');
		$this->addField('sectiontype');
		$this->addField('institution');
		$this->addField('funding');
		$this->addField('gradingsystem');
		$this->addField('staffjson');
		$this->addField('meetingsjson');
		
		if ($autoload) { 
			$this->load(); 
		}	
	}
	
	public function __get($name)
	{
		switch ($name) {
			case 'course':
				return $this->getCourse();
				break;
			case 'frequencyname':
			case 'fundingname':
			case 'gradingsystemname':
			case 'institutionname':
			case 'quartername':
			case 'sectiontypename':
			case 'summertermname':
			case 'updateable':
				$accessor = 'get'.$name;
				return $this->$accessor();
				break;
			default:
				return parent::__get($name);
				break;
		}
	}
	
	/**
	 * Search for a matching offering rule record using natural candidate 
	 * key parameters. This function supports loading external data to 
	 * prevent generation of duplicate records.
	 * 
	 * @param integer $courseid pk of the parent course record
	 * @param integer $yearfreq year frequency of the rule
	 * @param integer $quarter quarter of the rule
	 * @return Db_Offering
	 */
	public static function FetchMatch($courseid, $yearfreq, $quarter)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM repetition '
		     . 'WHERE courseid = '.$courseid.' '
		     . 'AND yearfreq = '.$yearfreq.' '
		     . 'AND quarter = '.$quarter.' ';
		$row = $db->fetchRow($sql);
		if ($row) {
			$out = new self($row['repetitionid'], false);
			$out->init($row);
		} else {
			$out = new self(0, false);
			$out->courseid = $courseid;
			$out->yearfreq = $yearfreq;
			$out->quarter = $quarter;
		}
		return $out;
	} 
	
	/**
	 * Returns an array list of Db_Repetition objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters 
	 * @return array[Db_Repetition]
	 */
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT * FROM repetition '.$where.' ORDER BY firstyear, quarter';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$o = new self($row['repetitionid'], false);
			$o->init($row);
			$out[] = $o;
		}
		return $out;
	}
	
	/**
	 * Delete any offerings that were created by this repetition rule and
	 * are still updateable
	 */
	public function deleteOfferings()
	{
		$repeater = new \Offering\Repeat($this);
		$repeater->deleteAll();
	}
	
	/**
	 * Returns a human readable description of this rule's repetition
	 * frequency.
	 * @return string
	 */
	public function getFrequencyName()
	{
		if (array_key_exists($this->yearfreq, self::$frequencies)) {
			return self::$frequencies[$this->yearfreq];
		} else {
			return $this->yearfreq;
		}
	}
	
	/**
	 * Returns the Db_Course object related to this repetition rule. This
	 * method is exposed through the "course" virtual property to support
	 * loading on first use.
	 * @return array
	 */
	protected function getCourse()
	{
		if (is_null($this->_course)) {
			$this->_course = Db_Course::Get($this->courseid);
		}
		return $this->_course;
	}
	
	/**
	 * Returns a human readable description of the funding model for this
	 * repetition rule.
	 * @return string
	 */
	protected function getFundingName()
	{
		if (array_key_exists($this->funding, Db_Offering::$fundingtypes)) {
			return Db_Offering::$fundingtypes[$this->funding];
		} else {
			return $this->funding;
		}
	}
	
	/**
	 * Returns human readable string description of this repetition rule's 
	 * grading system.
	 * @return string
	 */
	protected function getGradingSystemName()
	{
		if (array_key_exists($this->gradingsystem, Db_Offering::$gradingsystems)) {
			return Db_Offering::$gradingsystems[$this->gradingsystem];
		} else {
			return $this->gradingsystem;
		}
	}
	
	/**
	 * Returns next highest unused index for uniquely identifying staff records
	 * within this repetition rule.
	 * @return integer
	 */
	public function getNextStaffIndex()
	{
		$highest = 0;
		foreach ($this->staff as $staff) {
			if ($staff->repetitionindex > $highest) $highest = $staff->repetitionindex;
		}
		return $highest + 1;
	}
	
	/**
	 * Returns a human readable description of this rule's selected
	 * quarters.
	 * @return string
	 */
	public function getQuarterName()
	{
		if (array_key_exists($this->quarter, self::$quarters)) {
			return self::$quarters[$this->quarter];
		} else {
			return $this->quarter;
		}
	}
	
	/**
	 * Returns a human readable description of the institution code
	 * @return string
	 */
	public function getInstitutionname()
	{
		if (array_key_exists($this->institution, Db_Offering::$institutions)) {
			return Db_Offering::$institutions[$this->institution];
		} else {
			return $this->institution;
		}
	}
	
	/**
	 * Returns human readable string description of this repetition rule's 
	 * section type.
	 * @return string
	 */
	protected function getSectionTypeName()
	{
		if (array_key_exists($this->sectiontype, Db_Offering::$sectiontypes)) {
			return Db_Offering::$sectiontypes[$this->sectiontype];
		} else {
			return $this->sectiontype;
		}
	}

	/**
	 * Returns a human readable version of the summer term code.
	 * @return string
	 */
	public function getSummerTermName()
	{
		if (array_key_exists($this->summerterm, Db_Offering::$summerterms)) {
			return Db_Offering::$summerterms[$this->summerterm];
		} else {
			return $this->summerterm;
		}
	}

	/**
	 * Return an array of Db_Offering objects created by this rule that are in an
	 * editable state.
	 * @return array[Db_Offering]
	 */
	public function getUpdateable()
	{
		if (is_null($this->_updateable)) {
			$report = new \Reports\RepetitionUpdateable();
			$report->getParam('repetition')->setValue($this->repetitionid);
			$this->_updateable = $report->getReport();
		}
		return $this->_updateable;
	}
	
	/**
	 * Return a specific Db_Staff record identified by personid. If no 
	 * matching record exists in rule, returns null.
	 * @param string $personid
	 * @return \Db_Staff|NULL
	 */
	public function locateStaff($personid)
	{
		if (array_key_exists($personid, $this->staff)) {
			return $this->staff[$personid];
		}
		return null;
	}
	
	/**
	 * Runs full reconciliation with the rules and offerings in the system. Deletes
	 * any existing records based on the rule that no longer match the rule properties,
	 * updates offering fields, meetings, and staff.
	 */
	public function update()
	{
		$repeater = new \Offering\Repeat($this);
		$repeater->update();
	}

	/**
	 * Update the offering meeting properties generated by and editable 
	 * by this repetition rule.
	 */
	public function updateMeetings()
	{
		$repeater = new \Offering\Repeat($this);
		$repeater->updateMeetings();
	}

	/**
	 * Update the offering staff properties generated by and editable 
	 * by this repetition rule.
	 */
	public function updateStaff()
	{
		$repeater = new \Offering\Repeat($this);
		$repeater->updateStaff();
	}
	
	protected function preDelete()
	{
		$repeater = new \Offering\Repeat($this);
		$repeater->deleteAll();
	}
	
	protected function preSave()
	{
		if ($this->institution == 'uweo') {
			$this->funding = 'SS';
		} else {
			$this->funding = 'St';
		}
		$meetings = array();
		foreach ($this->meetings as $meeting) {
			if ($meeting instanceof \Offering\Repetition\Meeting) {
				$meetings[] = $meeting->getValuesHash();
			}
		}
		$this->meetingsjson = json_encode($meetings);
		$stafflist = array();
		foreach ($this->staff as $staff) {
			if ($staff instanceof \Offering\Repetition\Staff) {
				$stafflist[] = $staff->getValuesHash();
			}
		}
		$this->staffjson = json_encode($stafflist);
	}
	
	protected function postInit()
	{
		$this->meetings = array();
		if ($this->meetingsjson) {
			$meetingvalues = json_decode($this->meetingsjson);
			foreach ($meetingvalues as $data) {
				$this->meetings[] = new \Offering\Repetition\Meeting($data);
			}
		}
		$this->staff = array();
		if ($this->staffjson) {
			$staffvalues = json_decode($this->staffjson);
			foreach ($staffvalues as $data) {
				//$this->staff[$data->personid] = new \Offering\Repetition\Staff($data);
				$this->staff[$data->repetitionindex] = new \Offering\Repetition\Staff($data);
			}
		}
	}
	
}
