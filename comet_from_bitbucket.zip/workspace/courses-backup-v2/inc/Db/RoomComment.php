<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to the roomcomment database table. Room comment contains
 * a comment related to room scheduling.
 * @author Paul Hanisko
 */


class Db_RoomComment extends DbObject
{
	
	public function __construct($roomcommentid, $autoload = true)
	{
		$db = DbConnection::GetInstance();
		parent::__construct($db, 'roomcomment');

		$this->addPrimaryKeyField('roomcommentid', $roomcommentid, self::TYPE_CHAR);
		$this->addField('offeringid', self::TYPE_INT);
		$this->addField('uwnetid');
		$this->addField('created', self::TYPE_DATETIME);
		$this->addField('comment');
		
		if ($autoload) { $this->load(); }
	}
	
	/**
	 * Returns an array list of Db_RoomComment objects limited by the
	 * provide $filters.
	 * @param mixed $filters
	 * @return array
	 */
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT * FROM roomcomment '. $where .' ORDER BY offeringid, created, uwnetid';
		$results = $db->fetchAssoc($sql);
		$out = array();
		foreach ($results as $row) {
			$o = new self($row['roomcommentid'], false);
			$o->init($row);
			$out[] = $o; 
		}
		return $out;
	}
	
	protected function preInsert()
	{
		$this->preSave();
	}
	
	protected function preUpdate()
	{
		$this->preSave();
	}
	
	protected function preSave()
	{
		// if entered date time was not specified use system clock
		if (!$this->created) { 
			$this->created = time(); 
		}
		// if user was not specified, search for logged in user
		if (!$this->uwnetid) {
			if (Request::IsCommandLine()) {
				$this->uwnetid = 'system';
			} else {
				$this->uwnetid = User::GetLoggedInUser()->uwnetid;
			}
		}
		// verify this entry is attached to something
		if (!$this->offeringid) {
			throw new Exception('Db_RoomComment entry must refer to an offering record');
		}
	}
		
}