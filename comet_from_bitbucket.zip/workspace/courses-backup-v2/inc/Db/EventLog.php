<?php
/**
 * Interface to the eventlog database table. The event log captures
 * changes to course offering records.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Db_EventLog extends DbObject 
{
	
	public function __construct($eventid, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'eventlog');
		
		$this->addPrimaryKeyField('eventid', $eventid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('type');
		$this->addField('actor');
		$this->addField('offeringid', self::TYPE_INT);
		$this->addField('sentto');
		$this->addField('orgunitid', self::TYPE_INT);
		$this->addField('created');
		$this->addField('description', self::TYPE_DATETIME);
		
		if ($autoload) { $this->load(); }	
	}
	
}
