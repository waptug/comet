<?php
/**
 * Interface to the orgunit database table. An organizational unit is
 * a group mechanism for people. The orgunit defines system permissions
 * workflow responsibilities, and notifications.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Db_OrgUnit extends DbObject 
{
	private $_members;
	private static $_orgunitnames;
	
	// An orgunitid that represents processes and responsibilities
	// handled automatically by the system
	const ORGUNITID_SYSTEM = 1;
	const ORGUNITID_DEAN = 101;
	const ORGUNITID_ACADEMIC_REVIEW = 102;
	const ORGUNITID_FISCAL_REVIEW = 103;
	const ORGUNITID_ROOM_SCHED = 104;
	// An area's orgunitid plus the following modifiers will give
	// you a subgroup's orgunitid
	const AREA_CHAIR_MODIFIER = 1;
	const AREA_ADMIN_MODIFIER = 2;
	const AREA_ALL_MODIFIER = 9;
	
	public static $dept_org_units = array(
		10 => 'EDC&I',
		20 => 'EDPSY',
		30 => 'EDLPS',
		40 => 'EDSPE',
		70 => 'ECFS',
		80 => 'TEP',
		90 => 'EDUC'
	);
	
	public function __construct($orgunitid, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'orgunit');
		
		$this->addPrimaryKeyField('orgunitid', $orgunitid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('name');
		$this->addField('description');
		
		if ($autoload) { $this->load(); }	
	}
	
	public function __get($name) 
	{
		switch ($name) {
			case 'members':
				return $this->getMembers();
				break;
			default:
				return parent::__get($name);
				break;
		}
	}
	
	/**
	 * Convert an orgunitid (number) into the human readable name
	 * of the oranizational unit. Checks the static dept table first
	 * then loads orgunits from the database.
	 * 
	 * @param integer $orgunitid
	 * @return string
	 */
	public static function DecodeOrgunit($orgunitid)
	{
		if (array_key_exists($orgunitid, self::$dept_org_units)) {
			return self::$dept_org_units[$orgunitid];
		}
		if (is_null(self::$_orgunitnames)) {
			$db = DbFactory::GetConnection();
			self::$_orgunitnames = $db->fetchPairs('SELECT orgunitid, name FROM orgunit ORDER BY name');
		}
		if (array_key_exists($orgunitid, self::$_orgunitnames)) {
			return self::$_orgunitnames[$orgunitid];
		}
		return $orgunitid;
	}
	
	/**
	 * Load a Db_OrgUnit object by finding a matching orgunit name
	 * in the database. If no match is found returns a new Db_OrgUnit 
	 * object with the name property set.
	 * @param string $name
	 * @return Db_OrgUnit
	 */
	public static function FetchByName($name)
	{
		$db = DbFactory::GetConnection();
		$sql = 'SELECT * FROM orgunit WHERE name = '.$db->quote($name);
		$row = $db->fetchRow($sql);
		if ($row) {
			$out = new self($row['orgunitid'], false);
			$out->init($row);
		} else {
			$out = new self(0);
			$out->name = $name;
		}
		return $out;
	}
	
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT * FROM orgunit '.$where.' ORDER BY name';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$o = new self($row['orgunitid'], false);
			$o->init($row);
			$out[$row['orgunitid']] = $o;
		}
		return $out;
	}
	
	/**
	 * Returns and array list of Db_Person objects that are members of this
	 * orgunit.
	 * @return array
	 */
	protected function getMembers()
	{
		if (is_null($this->_members)) {
			$this->_members = Db_Person::FetchMultiple('personid IN (SELECT personid FROM personorgunit WHERE orgunitid = '.$this->orgunitid.')');
		}
		return $this->_members;
	}
	
}