<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Curriculum is a UW organizational structure for courses. Courses
 * are identified by Curriculum abbreviation CHAR(6) plus a courese
 * number. Curriculum have loose correlation to College of Education
 * areas. 
 * 
 * Treating this as a DbObject, but it is currently a container for
 * static variables and methods. There is no Curriculum table in 
 * the database.
 */

class Db_Curriculum
{
	const ALL_DESCRIPTION = 'All College of Education';
	
	public static $curricula = array(
		'EDC&I' => 'EDC&I',
		'ECFS'  => 'ECFS',
		'EDLPS' => 'EDLPS',
		'EDPSY' => 'EDPSY',
		'EDSPE' => 'EDSPE',
		'EDTEP' => 'EDTEP',
		'EDUC'  => 'EDUC'
	);
	
	public static $uri_decode = array(
		'EDCI'  => 'EDC&I',
		'ECFS'  => 'ECFS',
		'EDLPS' => 'EDLPS',
		'EDPSY' => 'EDPSY',
		'EDSPE' => 'EDSPE',
		'EDTEP' => 'EDTEP',
		'EDUC'  => 'EDUC'
	);
	
	public static $uri_encode = array(
		'EDC&I' => 'EDCI'
	);
	
	public static $names = array(
		'EDUC'  => 'General College of Education',
		'EDC&I' => 'Curriculum & Instruction',
		'ECFS'  => 'Early Childhood & Family Studies',
		'EDLPS' => 'Educational Leadership & Policy Studies',
		'EDPSY' => 'Educational Psychology',
		'EDSPE' => 'Special Education',
		'EDTEP' => 'Teacher Education Program'
	);
	
	public $abbrev;
	
	public function __construct($curriculum)
	{
		$curriculum = strtoupper($curriculum);
		if (array_key_exists($curriculum, self::$uri_decode)) {
			$this->abbrev = self::$uri_decode[$curriculum];
		} else {
			$this->abbrev = $curriculum;
		}
	}
	
	public function __get($name)
	{
		switch ($name) {
			case 'name':
				return self::DecodeName($this->abbrev);
				break;
			case 'uri': 
				return self::EncodeUri($this->abbrev);
				break;
			default:
				return null;
				break;
		}
	}
	
	public function __toString()
	{
		return $this->abbrev;
	}
	
	/**
	 * Returns the curriculum abbreviation in a format appropriate for inclusion
	 * in a URL or URL query string
	 * @param string $department abbreviated UW name of department CHAR(6)
	 * @return string
	 */
	public static function EncodeUri($curriculum)
	{
		if (array_key_exists($curriculum, self::$uri_encode)) {
			return self::$uri_encode[$curriculum];
		} else {
			return $curriculum;
		}
	}
	
	/**
	 * Returns the long name of a curriculum associated with the provided
	 * $curriculum abbreviation argument.
	 * @param string $department abbreviated UW name of department CHAR(6)
	 * @return string
	 */
	public static function DecodeName($curriculum)
	{
		if (array_key_exists($curriculum, self::$names)) {
			return self::$names[$curriculum];
		} elseif ($curriculum == 'ALL') {
			return self::ALL_DESCRIPTION;
		} else {
			return $curriculum;
		}
	}
	
	/**
	 * Returns an associative array of curriculum abbreviations appropriate 
	 * for a select option list. The $withall flag will include an ALL =>
	 * All College of Education value at the beginning of the array.
	 * @param boolean $withall
	 * @return array
	 */
	public static function FetchIndex($withall = false) 
	{
		if ($withall) {
			return array_merge(array('ALL' => self::ALL_DESCRIPTION), self::$uri_decode);
		} else {
			return self::$uri_decode;
		}
	}

	/**
	 * Returns true if the $curriculum argument is on the internal list of
	 * know UW College of Education $curriculum abbreviations
	 * @param string $department abbreviated UW name of department CHAR(6)
	 * @return boolean
	 */
	public static function LocalCurriculum($curriculm)
	{
		return (boolean) array_key_exists($curriculm, self::$curricula);
	}
	
	/**
	 * Returns true if the $curriculum argument is on the internal list of
	 * know UW College of Education $curriculum abbreviations
	 * @param string $department abbreviated UW name of department CHAR(6)
	 * @return boolean
	 */
	public function isKnown()
	{
		return (boolean) array_key_exists($this->abbrev, self::$curricula);
	}

}