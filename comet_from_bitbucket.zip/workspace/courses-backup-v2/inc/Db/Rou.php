<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to the ROU database table. A Responsible Organizational
 * Unit (ROU) represents a group within the college that has responsibility
 * for scheduling and staffing course offerings.
 * @author hanisko
 */

class Db_Rou extends DbObject
{
	private $_approver;
	private $_persons;
	private $_childrous;
	private $_parent;
	
	public function __construct($rouid, $autoload = true)
	{
		parent::__construct(DbFactory::GetConnection(), 'rou');
		
		$this->addPrimaryKeyField('rouid', $rouid, self::TYPE_INT, self::PK_IS_SERIAL);
		$this->addField('rou_name');
		$this->addField('approver_personid', self::TYPE_INT);
		$this->addField('parent_rouid', self::TYPE_INT);
		$this->addField('description');
		
		if ($autoload) { $this->load(); }	
	}
	
	public function __get($name)
	{
		switch ($name) {
			case 'approver':
			case 'parent':
				$accessor = 'get'.$name;
				return $this->$accessor();
				break;
			default:
				return parent::__get($name);
				break;
		}
	}
	
	public function __set($name, $value)
	{
		switch ($name) {
			case 'approver_personid':
				$this->setApproverPersonid($value);
				break;
			default:
				parent::__set($name, $value);
				break;
		}
	}
	
	/**
	 * Add a Db_Rou object that is a child of this ROU
	 * @param Db_Rou $rou
	 */
	public function addChildRou(Db_Rou $rou)
	{
		if (!is_array($this->_childrous)) {
			$this->_childrous = array();
		}
		$this->_childrous[] = $rou;
	}
	
	/**
	 * Add a new person to the ROU
	 * @param Db_Person $person
	 */
	public function addPerson(Db_Person $person)
	{
		if (!is_array($this->_persons)) {
			$this->loadPersons();
		}
		$this->_persons[$person->personid] = $person;
	}
	
	/**
	 * Returns an array list of Db_Person objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters 
	 * @return array
	 */
	public static function FetchIndex($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT rouid, rou_name FROM rou '.$where.' ORDER BY parent_rouid = 0 DESC, rou_name';
		return $db->fetchPairs($sql);
	}
	
	/**
	 * Returns a nested array of ROUS. The outer array has three members representing the
	 * three divisions. The nested arrays are rouid => rou name pairs.
	 * @return array
	 */
	public static function FetchDivisionIndex()
	{
		$db = DbFactory::GetConnection();
		$out = array();
		$out[] = $db->fetchPairs('SELECT rouid, rou_name FROM rou WHERE parent_rouid = 3 ORDER BY rou_name');
		$out[] = $db->fetchPairs('SELECT rouid, rou_name FROM rou WHERE parent_rouid = 2 ORDER BY rou_name');
		$out[] = $db->fetchPairs('SELECT rouid, rou_name FROM rou WHERE parent_rouid = 1 ORDER BY rou_name');
		return $out;
	}
	
	/**
	 * Returns an array list of Db_Rou objects loaded from the database.
	 * Returned list is limited by the provided SQL where clause filters.
	 * @param mixed $filters 
	 * @return array
	 */
	public static function FetchMultiple($filters = '')
	{
		$db = DbFactory::GetConnection();
		$where = DbObject::MakeWhereClause($filters);
		$sql = 'SELECT * FROM rou '.$where.' ORDER BY parent_rouid = 0 DESC, rou_name';
		$result = $db->fetchAssoc($sql);
		$out = array();
		foreach ($result as $row) {
			$out[] = Db_Rou::Register($row);
		}
		return $out;
	}
	
	/**
	 * Return an array of Db_Person objects that have the admin role for 
	 * this ROU. Initial implementation, admin is the only row so this 
	 * method return the full persons array.
	 * @return array[Db_Person]
	 */
	public function getAdmins()
	{
		return $this->getPersons();
	}
	
	/**
	 * Return the Db_Person record representing the Approver for this ROU
	 * @return Db_Person|NULL
	 */
	public function getApprover()
	{
		if (is_null($this->_approver)) {
			$this->loadApprover();
		}
		return $this->_approver;
	}

	/**
	 * Return an array of Db_Person objects that have a role within
	 * this ROU.
	 * @return array[Db_Rou]
	 */
	public function getChildRous()
	{
		if (!is_array($this->_childrous)) {
			$this->_childrous = self::FetchMultiple('parent_rouid = '.$this->rouid);
		}
		return $this->_childrous;
	}

	/**
	 * Return the Db_Rou object representing the parent organizational unit of this
	 * ROU or null if this ROU has no parent
	 * @return Db_Rou|null
	 */
	public function getParent()
	{
		if ($this->parent_rouid && (is_null($this->_parent) || $this->_parent->rouid != $this->parent_rouid)) {
			$this->_parent = Db_Rou::Get($this->parent_rouid);
		}
		return $this->_parent;
	}
	
	/**
	 * Return an array of Db_Person objects that have a role within
	 * this ROU.
	 * @return array[Db_Person]
	 */
	public function getPersons()
	{
		if (!is_array($this->_persons)) {
			$this->loadPersons();
		}
		return $this->_persons;
	}
	
	/**
	 * Load the Db_Person record that represents the ROU approver
	 * from the database.
	 */
	public function loadApprover()
	{
		$this->_approver = null;
		if ($this->approver_personid) {
			$this->_approver = Db_Person::Get($this->approver_personid);
		}
	}

	/**
	 * Load the Db_Person records that represents the ROU admins
	 * from the database.
	 */
	public function loadPersons()
	{
		$this->_persons = array();
		if ($this->rouid) {
			$db = DbFactory::GetConnection();
			$sql = 'SELECT * FROM person INNER JOIN rouperson ON person.personid = rouperson.personid WHERE rouperson.rouid = '.$this->rouid;
			$results = $db->fetchAssoc($sql);
			foreach ($results as $row) {
				$this->addPerson(Db_Person::Register($row));
			}
		}
	}

	/**
	 * Remove the specified person from the admin list for this ROU
	 * @param Db_Person $person
	 */
	public function removePerson(Db_Person $person)
	{
		if (!is_array($this->_persons)) {
			$this->loadPersons();
		}
		if (array_key_exists($person->personid, $this->_persons)) {
			unset($this->_persons[$person->personid]);
		}
	}

	/**
	 * Assign a Db_Person record as the Approver for this ROU
	 */
	public function setApprover(Db_Person $person)
	{
		$this->_approver = $person;
		$this->approver_personid = $person->personid;
	}

	/**
	 * Assign a person by personid the Approver for this ROU
	 */
	public function setApproverPersonid($personid)
	{
		if ($this->_approver instanceof Db_Person && $personid != $this->_approver->personid) {
			$this->_approver = null;
		}
		parent::__set('approver_personid', $personid);
	}

	/**
	 * Set the Db_Rou object representing the parent organizational unit of this ROU
	 * @param Db_Rou
	 */
	public function setParent(Db_Rou $rou)
	{
		$this->_parent = $rou;
	}
	
	/**
	 * Set the person list for this object by providing an array of 
	 * Db_Person objects.
	 * @param array $persons
	 */
	public function setPersons($persons)
	{
		$this->_persons = $persons;
	}
	
	protected function preDelete()
	{
		$db = DbFactory::GetConnection();
		$db->query('DELETE FROM rouperson WHERE rouid = '.$this->rouid);
	}
	
	protected function postSave()
	{
		if (is_array($this->_persons)) {
			$db = DbFactory::GetConnection();
			$db->query('DELETE FROM rouperson WHERE rouid = '.$this->rouid);
			foreach ($this->_persons as $person) {
				$db->query('INSERT INTO rouperson VALUES('.$this->rouid.','.$person->personid.",'admin')");
			}
		}
	}
	
	/**
	 * Get an instance of Db_Rou identified by $rouid. Utilizes
	 * the application ObjectRegistry to prevent multiple loading and 
	 * instances of the same record.
	 * @param integer $rouid
	 * @return Db_Rou
	 */
	public static function Get($rouid)
	{
		$out = ObjectRegistry::Get(__CLASS__, $rouid);
		if (is_null($out)) {
			$out = new self($rouid);
			ObjectRegistry::Add(__CLASS__, $rouid, $out);
		}
		return $out;
	}
	
	/**
	 * Create an instance of Db_Rou from an associative array returned by
	 * a database query. Checks the ObjectRegistry before instantiating a new
	 * object.
	 * @param array $row
	 * @return Db_Rou
	 */
	public static function Register($row)
	{
		$out = ObjectRegistry::Get(__CLASS__, $row['rouid']);
		if (is_null($out)) {
			$out = new self($row['rouid'], false);
			$out->init($row);
			ObjectRegistry::Add(__CLASS__, $row['rouid'], $out);
		}
		return $out;
	}
	
}