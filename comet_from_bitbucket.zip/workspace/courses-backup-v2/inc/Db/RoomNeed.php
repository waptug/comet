<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to the roomneed database table. Room need contains the
 * instructor room request information for a specific offering;
 * @author Paul Hanisko
 */


class Db_RoomNeed extends DbObject
{
	public static $features = array(
		'chlk' => 'Chalkboard',
		'comp' => 'Computer/monitor',
		'eth0' => 'Ethernet connection',
		'movf' => 'Moveable furniture',
		'ovrh' => 'Overhead projector',
		'scre' => 'Screen',
		'smtb' => 'Seminar tables',
		'whtb' => 'Whiteboard',
		'wind' => 'Windows',
		'proj' => 'Video-data projector'
	);
	
	public $roomfeatures;
	
	public function __construct($offeringid, $autoload = true)
	{
		$db = DbConnection::GetInstance();
		parent::__construct($db, 'roomneed');

		$this->addPrimaryKeyField('offeringid', $offeringid, self::TYPE_CHAR);
		$this->addField('roompref1');
		$this->addField('roompref2');
		$this->addField('roompref3');
		$this->addField('features');
		$this->roomfeatures = array();
		if ($autoload) { $this->load(); }
	}
	
	public static function DecodeFeature($code)
	{
		if (array_key_exists($code, self::$features)) {
			return self::$features[$code];
		} else {
			return $code;
		}
	}
	
	protected function preInsert()
	{
		$this->__set('features', implode(',',$this->roomfeatures));
	}
	
	protected function preUpdate()
	{
		$this->__set('features', implode(',',$this->roomfeatures));
	}
	
	protected function postLoad()
	{
		if ($this->__get('features')) {
			$this->roomfeatures = explode(',',$this->__get('features'));
		} else {
			$this->roomfeatures = array();
		}
	}
		
}
