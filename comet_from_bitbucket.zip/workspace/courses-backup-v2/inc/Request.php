<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Provides data relating to the user request that initiated this
 * execution. Supports scripts running in an HTTP request context
 * and in a command line context.
 * 
 * @author hanisko
 * @package UW_COE_Technology
 */
class Request
{
	const BOOTSTRAP_FILE = '/bootstrap.php';
	
	protected $_scrubber_class_basename = 'Request_Scrub_';
	protected $_searcher_class_basename = 'Request_Search_';
	
	public static $default_scrub = 0;
	public static $integer_scrub = 1;
	
	protected static $_instance = null;
	
	protected $_phpself = null;
	protected $_scrub_strategies;
	protected $_search_strategies;

	protected function __construct()
	{
		$this->_scrub_strategies = array();
		$this->_search_strategies = array();
	}

	/**
	 * Clean up the PHP_SELF value to remove the bootstrap.php script from
	 * the path.
	 * @return string
	 */
	protected function calculatePhpself()
	{
		if (!array_key_exists('REQUEST_URI', $_SERVER)) {
			return '';
		}
		$phpself = $_SERVER['REQUEST_URI'];
		$b = strpos($phpself, '?');
		if ($b) {
			$phpself = substr_replace($phpself, '', $b);
		}
		return $phpself;
	}

	/**
	 * Closes the browser connection while processing continues
	 */
	public static function closeConnection() {
		header("Connection: Close");
		ignore_user_abort(true);
		header("HTTP/1.1 200 OK");
		$size = ob_get_length();
		header("Content-Length: $size");
		ob_end_flush();
		flush();
	}

	/**
	 * Return the single instance of the Request object.
	 * @return Request
	 */
	public static function GetInstance()
	{
		if (is_null(self::$_instance)) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Returns a server relative path to the called script matching the clien
	 * URI. Strips reference to the bootstrap script.
	 * @return string
	 */
	public function getPhpSelf()
	{
		if (is_null($this->_phpself)) {
			$this->_phpself = $this->calculatePhpself();
		}
		return $this->_phpself;
	}
	
	/**
	 * Returns a specific scrub strategy identified by $name
	 * @param string $name
	 * @return Request_Search_SearchAbstract
	 */
	public function getScrubber($name)
	{
		if (!array_key_exists($name, $this->_scrub_strategies)) {
			$class = $this->_scrubber_class_basename.$name;
			$this->_scrub_strategies[$name] = new $class;
		}
		return $this->_scrub_strategies[$name];
	}
	
	/**
	 * Returns a specific search strategy identified by $name
	 * @param string $name
	 * @return Request_Search_SearchAbstract
	 */
	public function getSearcher($name)
	{
		if (!array_key_exists($name, $this->_search_strategies)) {
			$class = $this->_searcher_class_basename.$name;
			$this->_search_strategies[$name] = new $class;
		}
		return $this->_search_strategies[$name];
	}
	
	/**
	 * Returns user input found in an input field identified by name= $fieldname,
	 * using the ordered search of input fields defined by $search strategy. If
	 * the field is not found returns the $default value. The input is modified
	 * by the $scrub strategy before being returned. 
	 * @param string $fieldname
	 * @param string $scrub
	 * @param mixed $default
	 * @param string $search
	 * @return string
	 */
	public function getUserInput($fieldname, $scrub = 'Default', $default = null, $search = 'Default')
	{
		// Corrections to make this method backward compatible 
		if ($scrub == self::$integer_scrub) {
			$scrub = 'Integer';
		} elseif ($scrub == self::$default_scrub) {
			$scrub = 'Default';
		}
		$searcher = $this->getSearcher($search);
		$scrubber = $this->getScrubber($scrub);
		$value = $searcher->get($fieldname);
		if (is_null($value)) $value = $default;
		if (is_array($value)) {
			for ($i = 0; $i < count($value); ++$i) {
				$value[$i] = $scrubber->scrub($value[$i]);
			}
		} else {
			$value = (is_null($value)) ? null : $scrubber->scrub($value);
		}
		return $value;
	}
	
	public function isAjax()
	{
		if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
			return true;
		}
		if (isset($_GET['ajax']) && $_GET['ajax'] == 1) {
			return true;
		}
		if (isset($_POST['ajax']) && $_POST['ajax'] == 1) {
			return true;
		}
		return false;
	}
	
	/**
	 * Return true if this script is responding to an HTTP POST request
	 * @return boolean
	 */
	public static function IsPost()
	{
		if (array_key_exists('REQUEST_METHOD', $_SERVER) && $_SERVER['REQUEST_METHOD'] == 'POST') {
			return true;
		}
		return false;
	}
	
	/**
	 * Return true if this script was invoked from the shell command line
	 * instead of as an HTTP process.
	 * @return boolean
	 */
	public static function IsCommandLine()
	{
		if (array_key_exists('SHELL', $_SERVER) && array_key_exists('TERM', $_SERVER)) {
			if (!array_key_exists('HTTP_HOST', $_SERVER) && !array_key_exists('REMOTE_ADDR', $_SERVER)) {
				return true;
			}
		}
		return false;
	}
		
	/**
	 * Return the request method of the HTTP request (ex. 'POST' or 'GET') that 
	 * invoked this script or 'CMDLINE' if the script was invoked from a shell 
	 * command
	 * @return string
	 */
	public static function Method()
	{
		if (array_key_exists('SHELL', $_SERVER)) {
			return 'CMDLINE';
		}
		if (array_key_exists('REQUEST_METHOD', $_SERVER)) {
			return $_SERVER['REQUEST_METHOD'];
		}
		return null;
	}
	
	/**
	 * Return the server relative path to the script being called. This method
	 * removes the bootstrap loader.
	 * @return string
	 */
	public static function Phpself()
	{
		return self::GetInstance()->getPhpSelf();
	}
	
	/**
	 * Return the fully qualified domain name of the server this script is being
	 * executed on. For HTTP requests this is the hostname the user used to reach
	 * the server. For scripts this is the primary hostname of the system.
	 * @return string
	 */
	public static function ServerName()
	{
		if (isset($_SERVER['SERVER_NAME'])) {
			$environment = $_SERVER['SERVER_NAME'];
		} else {
			$environment = exec('hostname');
		}
		return $environment;
	}
	
	/**
	 * Deprecated, use instance->getUserInput(). Check the query string and 
	 * POST for user input for a specified field.
	 * @param string $fieldname name of the GET or POST field to check for
	 * @param string $options rules to follow when scrubbing user input
	 * @return string
	 */
	public static function UserInput($fieldname, $scrub_strategy = null)
	{
		return self::GetInstance()->getUserInput($fieldname, $scrub_strategy);
	}
	
}