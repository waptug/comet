<?php


class Ldap_UwPublic
{
	private static $ldap_host = 'directory.washington.edu';
	private static $ldap_port = 398;
	private static $ldap_base = 'ou=People, o=University of Washington, c=US';

	/**
	 * Searches the UW public LDAP for a person using their UW NetID
	 * if a record is found returns an associative array containing
	 * the relevant data fields
	 * @param string $uwnetid
	 * @return array
	 */
	public static function FetchPerson($uwnetid)
	{
		if (strlen($uwnetid) == 0) {
			return false;
		}
		$log = Logger::GetInstance();
		if (!function_exists('ldap_connect')) {
			$log->error('Trying to use LDAP, but PHP LDAP module not installed.');
			return false;
		}
		$cn = ldap_connect(self::$ldap_host);
		if (!$cn) {
			$log->error('LDAP connection to '. self::$ldap_host .' failed. ('. ldap_errno($cn) .') '. ldap_error($cn));
			return false;
		}
		$r = ldap_bind($cn);
		if (!$r) {
			$log->error('LDAP bind to '. self::$ldap_host .' failed. ('. ldap_errno($cn) .') '. ldap_error($cn));
			return false;
		}
		// Search faculty and staff
		$result = ldap_search($cn, 'ou=Faculty and Staff, ' . self::$ldap_base, '(uid='. $uwnetid .')');
		$count = ldap_count_entries($cn, $result);
		if ($count == 0) {
			// Search students
			$result = ldap_search($cn, 'ou=Students, ' . self::$ldap_base, '(uid='. $uwnetid .')');
			$count = ldap_count_entries($cn, $result);
			if ($count == 0) {
				return false;
			}
		}
		$entries = ldap_get_entries($cn, $result);
		// We are assuming UWNetIDs are unique so this should only return one
		// result, we'll use the values in the first (only) result
		$out = array();
		$out['uwnetid']   = $uwnetid;
		$out['firstname'] = ucfirst(strtolower(self::SearchLdapField($entries, 'givenname')));
		$out['lastname']  = ucfirst(strtolower(self::SearchLdapField($entries, 'sn')));
		$out['title']     = self::SearchLdapField($entries, 'title');
		$out['room']      = self::SearchLdapField($entries, 'postaladdress');
		$out['email']     = self::SearchLdapField($entries, 'mail');
		$out['phone']     = self::SearchLdapField($entries, 'telephonenumber', null, 'homephone');
		$out['department'] = self::ParseDept($entries[0]['dn']);
		$out['source'] = 'uw_dir_pub';
		
		return $out;
	}
	
	/**
	 * Search an ldap entry for a specified field. Return the located value
	 * or a default value.
	 *
	 * @param array $entry collection of ldap_entries, the first record is searched
	 * @param string $field name of the field being searched for
	 * @param string $default what to return if the field is not found
	 * @param string $alternate_field a secondary field to search for if the first is not found
	 * @return string
	 */
	private static function SearchLdapField($entry, $field, $default = null, $alternate_field = null)
	{
		// if the entry array has no items bail by returned the default value
		if (!isset($entry[0])) { return $default; }	
		// if the fields we are searching for is not set
		if (!isset($entry[0][$field])) { 
			// check if the alternate is set
			if (is_null($alternate_field) || !isset($entry[0][$alternate_field])) {
				// if neither the search field or alternate are set bail 
				return $default; 
			} else {
				// if we found the alternate field copy that index over to $field
				$field = $alternate_field;
			}
		}
		// if the field doesnt have a first value bail
		if (!isset($entry[0][$field][0])) { return $default; }
		// otherwise we found what we were looking for, return that
		return $entry[0][$field][0];
	}
	
	/**
	 * Search a string in the format of a UW LDAP distinguished name for 
	 * the property that describes a person's department and return that string
	 *
	 * @param string $ldap_dn the DN record from an ldap entry 
	 * @return string
	 */
	private static function ParseDept($ldap_dn)
	{
		// define something to return if parse fails
		$dept = null;
		// parts of dn we know are not the department
		$ignore = array('ou=People', 'ou=Faculty and Staff', 'ou=Students');
		$dnparts = explode(',', $ldap_dn);
		foreach ($dnparts as $chunk) {
			$chunk = trim($chunk);
			// if this is on our ignore list it's not what we are after
			if (in_array($chunk, $ignore)) { continue; }
			// if this doesnt start with ou= it's not what we are after
			if (stripos($chunk, 'ou=') !== 0) { continue; }
			// get rid of the ou= part
			$bits = explode('=', $chunk);
			$dept = $bits[1];
		}
		return $dept;
	}
}