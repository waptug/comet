<?php
/**
 * @package UW_COE_Courses
 */
/**
 * A job is a unit of work that can be called as part of a process. The process
 * object provides the job parameters and logging functionality. The job implements
 * a specific task in its run method. 
 * @author hanisko
 */
namespace Update\Process;

abstract class JobAbstract
{
	/**
	 * The process object running this job and provides job parameters and 
	 * logging functionality.
	 * @var \Update\Process\ProcessAbstract $process
	 */
	public $process;
	
	public function __construct(ProcessAbstract $process)
	{
		$this->process = $process;
	}
	
    abstract public function run();
    
}
