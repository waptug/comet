<?php
/**
 * @package UW_COE_Framework
 */
/**
 * An update process defines a sequential series of distinct update steps
 * that can be called in order, individually, or from a specific step through
 * the end of the process. The process object provides the order of execution,
 * access to parameters, and logging functionality.
 * @author hanisko
 */
namespace Update\Process;

abstract class ProcessAbstract
{
	protected $jobs;
	protected $log_stack;
	protected $haslock = false;
	public $parameters;
	
	public function __construct()
	{
		$this->jobs = $this->getJobs();
		$this->log_stack = array();
		$this->parameters = array();
	}
	
	/**
	 * Add a Logger object that progress, warning, and error messages can be
	 * written to. 
	 * @param Logger_InterfaceLogger $logger
	 */
	public function addLogger(\Logger_LoggerInterface $logger)
	{
		$this->log_stack[] = $logger;
	}

	/**
	 * Tries obtain a MySQL mutex lock of the specified name. Returns whether it was successful or not
	 * @param string $lockname
	 * @return boolean
	 */
	public function getLock($lockname) {
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT GET_LOCK("'.$lockname.'", 1)';  
		$lock = $db->fetchOne($sql);
		if($lock == 0)
			return false;
		return true;			
	}

	public static function isLocked($lockname) {
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT IS_FREE_LOCK("'.$lockname.'")';  
		$lock = $db->fetchOne($sql);
		if($lock == 1)
			return false;
		return true;
	}

	public function hasLock($lockname) {
		return $this->haslock;
	}

	/**
	 * Writes the provided message to any loggers that were provided via addLogger()
	 * @param string $message
	 */
	public function log($message) 
	{
		foreach ($this->log_stack as $logger) {
			$logger->write($message);
		}
	}
	
	/**
	 * Run all defined processes sequentially. Optionally provide the name
	 * of step as a starting point.
	 * @param string $start_from_step
	 * @return boolean
	 */
	public function run($start_from_step = null)
	{
		$started = false;
		foreach ($this->jobs as $name => $jobclass) {
			if (!$started) {
				if (is_null($start_from_step) || $name == $start_from_step) {
					$started = true;
				} else {
					continue;
				}
			}
			$this->runJob($name);
		}
	}

	/**
	 * Run a specific defined step. Returns false if the step failed and if
	 * the step configuration specifies that full process should be halted
	 * on step failure.
	 * @param string $start_from_step
	 * @return boolean
	 */
	public function runJob($name)
	{
		if (!array_key_exists($name, $this->jobs)) {
			throw new \Exception('Job '.$name.' not configured');
		}
		$class = $this->jobs[$name];
		$job = new $class($this);
		$job->run();
	}

	/**
	 * Run all defined processes sequentially. Optionally provide the name
	 * of step as a starting point.
	 * @param string $start_from_step
	 * @return boolean
	 */
	public function runFromJob($name)
	{
		$this->run($name);
	}
	
	/**
	 * Returns an associative array defining the ordered list of Jobs within this 
	 * process. The array contains a label name for the Job and the class that
	 * runs the job.
	 * 
	 * return array(
	 *     'first_job_name'  => '\Update\Person\Job',
	 *     'second_job_name' => '\Update\Course\Job'		
	 * );
	 * 
	 * @return array
	 */
	abstract protected function getJobs();
	
}