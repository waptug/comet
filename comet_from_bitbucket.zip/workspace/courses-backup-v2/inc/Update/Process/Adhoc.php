<?php
/**
 * @package UW_COE_Framework
*/
/**
 * An empty process with a method to add arbitrary jobs
 * @author hanisko
 */
namespace Update\Process;

class Adhoc extends ProcessAbstract
{

	public function addJob($name, $class)
	{
		$this->jobs[$name] = $class;
	}
	
	protected function getJobs()
	{
		return array();
	}

}