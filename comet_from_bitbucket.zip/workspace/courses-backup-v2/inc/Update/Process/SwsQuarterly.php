<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Process that is run as a maintenance routine once after the end of 
 * each quarter. Updates the course list, historical offerings, and
 * cancels offerings that don't have matching UWTS records.
 * @author hanisko
 */
namespace Update\Process;

class SwsQuarterly extends ProcessAbstract
{

	private $dashboard;
	private $timer;
	
	public function __construct()
	{
		parent::__construct();
		// Choose quarters to process
		$this->parameters['quarters'] = new \QuarterIterator(5,-1);
	}

	protected function getJobs()
	{
		return array(
			 'terms'	   => '\Update\Term\Job',
		     'courses'     => '\Update\Course\Job',
		     'uwts'        => '\Update\Uwts\Job',
		     'repetitions' => '\Update\Offering\RepetitionJob',
		     'link'        => '\Update\Offering\LinkJob',
		     'offerings'   => '\Update\Offering\Job',
		     'cancel'      => '\Update\Offering\CancelJob'
		);
	}
	
}