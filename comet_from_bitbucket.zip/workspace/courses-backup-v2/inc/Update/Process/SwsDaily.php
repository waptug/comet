<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Process that is run as a maintenance routine each night to synchronize
 * local plan data with records in UW time schedule using the Student Web
 * Service.
 * @author hanisko
 */
namespace Update\Process;

class SwsDaily extends ProcessAbstract
{

	private $dashboard;
	private $timer;
	const LOCK_NAME = 'swsdaily';
	
	public function __construct()
	{
		parent::__construct();
		$this->dashboard = new \Db_UwtsDashboard();
		// Choose quarters to process
		$this->parameters['quarters'] = new \QuarterIterator(0,0);
		$this->parameters['quarters']->setEndQuarter($this->dashboard->updatetoyear, $this->dashboard->updatetoquarter);
	}

	public function getLock($lockname = self::LOCK_NAME) {
		if(!$this->haslock)
			$this->haslock = parent::getLock($lockname);
		return $this->haslock;
	}

	public function hasLock($lockname = self::LOCK_NAME) {
		return parent::hasLock($lockname);
	}

	public static function isLocked($lockname = self::LOCK_NAME) {
		return parent::isLocked($lockname);
	}
	
	public function run($start_from_step = null)
	{
		// Start timing how long this takes
		$this->timer = new \Timer();
		
		parent::run($start_from_step);

		$this->dashboard->lastupdateduration = $this->timer->getTime();
		$this->dashboard->lastupdate = time();
		$this->dashboard->save();
		$this->log('Complete in '.$this->dashboard->lastupdateduration.' seconds');
	}

	protected function getJobs()
	{
		return array(
		     'people'    => '\Update\Person\Job',
		     'uwts'      => '\Update\Uwts\Job',
		     'link'      => '\Update\Offering\LinkJob',
		     'offerings' => '\Update\Offering\Job',
		     'joint'     => '\Update\JointExternal\Job'
		);
	}
	
}
