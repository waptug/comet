<?php
/**
 * @packagae UW_COE_Framework
 */
/**
 * This class provides core infrastructure for mapping Student Web Service 
 * JSON resources to local system objects
 * @author hanisko
 */
namespace Update;

abstract class FromSwsAbstract
{
	const ERROR_FOUND = 0;
	const ERROR_NOT_FOUND = 1;
	const ERROR_MISSING_DATA = 3;
	
	private static $error_messages = array(
		0 => 'Matching SWS course record found',
		1 => 'Record not found in SWS',
		3 => 'Missing parameters required to search SWS'
	);
	
	/**
	 * Hold the student web service response resulting from the PHP json_decode
	 * @var StdClass $sws
	 */
	protected $sws;
	
	/**
	 * Contains an error code, 0 indicates no error, null indicates data has not
	 * been loaded yet.
	 * @var integer $error
	 */
	protected $error;
	
	/**
	 * Load the Student Web Service data. Return true if a record was found and that
	 * SWS record matches parameters for the specific local Db_Object
	 * @return boolean
	 */
	protected function loadSws()
	{
		if (is_null($this->sws)) {
			$sws = $this->getRestClientSws();
			if (!$sws) {
				$this->error = FromSwsAbstract::ERROR_MISSING_DATA;
				return false;
			}
			if ($sws->recordExists()) {
				$this->sws = $sws->getDataObject();
				$this->error = 0;
			} else {
				$this->error = FromSwsAbstract::ERROR_NOT_FOUND;
			}
		}
		return !($this->error);
	}
	
	/**
	 * Returns a configured RestClient_SwsJson object that can be queried for 
	 * a JSON representation of a Student Web Service resourse
	 * @return RestClient_SwsJson
	 */
	abstract protected function getRestClientSws();

	/**
	 * Returns the interal error code, resulting from the last web service load
	 * attempt. 0 indicates no error, null indicates data has not been loaded yet.
	 * @return integer
	 */
	public function getError()
	{
		return $this->error;
	}

	/**
	 * Returns internal error code as human readable string.
	 * @return string
	 */
	public function getErrorMesage()
	{
		if (array_key_exists($this->error, FromSwsAbstract::$error_messages)) {
			return FromSwsAbstract::$error_messages[$this->error];
		} else {
			return $this->error;
		}
	}
	
}