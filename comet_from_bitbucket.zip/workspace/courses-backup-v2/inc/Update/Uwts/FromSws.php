<?php
/**
 * @packagae UW_COE_Courses
 */
/**
 * This mapper connects fields from the Student Web Service course section resource
 * to local system Db_UwtsOffering objects.
 * @author hanisko
 */
namespace Update\Uwts;

class FromSws extends \Update\FromSwsAbstract
{
	private $_uwts;
	
	private static $_map_sectiontype_to_code = array(
		'lecture'    => 'LC',
		'laboratory' => 'LB',
		'quiz'       => 'QZ',
		'independent study' => 'IS',
		'studio'     => 'ST',
		'clinic'     => 'CL',
		'conference' => 'CO',
		'seminar'    => 'SM',
		'clerkship'  => 'CK',
		'practicum'  => 'PR'
	);
	
	private static $_map_days_to_int = array(
		'Sunday'    => 0,
		'Monday'    => 1,
		'Tuesday'   => 2,
		'Wednesday' => 3,
		'Thursday'  => 4,
		'Friday'    => 5,
		'Saturday'  => 6
	);
	
	public function __construct(\Db_UwtsOffering $uwts)
	{
		$this->_uwts = $uwts;
	}

	protected function getRestClientSws()
	{
		return new \RestClient_CourseSection(
			$this->_uwts->year, 
			$this->_uwts->quarter, 
			$this->_uwts->curriculum, 
			$this->_uwts->courseno,
			$this->_uwts->section
		);
	}
	
	public function updateAll()
	{
		if ($this->loadSws()) {
			
			$this->_uwts->sln = $this->sws->SLN;
			if ($this->sws->SummerTerm) {
				$this->_uwts->summerterm = $this->sws->SummerTerm;
			} else {
				$this->_uwts->summerterm = null;
			}
			if (array_key_exists($this->sws->SectionType, self::$_map_sectiontype_to_code)) {
				$this->_uwts->sectiontype = self::$_map_sectiontype_to_code[$this->sws->SectionType];
			} else {
				$this->_uwts->sectiontype = '??';
			}
			
			if ($this->sws->InstituteName == 'UW PROFESSIONAL AND CONTINUING EDUCATION') {
				$this->_uwts->institution = 'uweo';
			} else {
				$this->_uwts->institution = 'state';
			}
			switch ($this->sws->CreditControl) {
				case 'zero credits':
					$this->_uwts->creditcontrol = 'fixed';
					$this->_uwts->creditmin = 0;
					$this->_uwts->creditmax = null;
					break;
				case 'fixed credit':
					$this->_uwts->creditcontrol = 'fixed';
					$this->_uwts->creditmin = $this->sws->MinimumTermCredit;
					$this->_uwts->creditmax = null;
					break;
				case 'variable credit - min to max credits':
					$this->_uwts->creditcontrol = 'variable';
					$this->_uwts->creditmin = $this->sws->MinimumTermCredit;
					$this->_uwts->creditmax = $this->sws->MaximumTermCredit;
					break;
				case 'variable credit - min or max credits':
					$this->_uwts->creditcontrol = 'minormax';
					$this->_uwts->creditmin = $this->sws->MinimumTermCredit;
					$this->_uwts->creditmax = $this->sws->MaximumTermCredit;
					break;
				case 'variable credit 1 to 25 credits':
				case 'variable credit - 1 to 25 credits':
					$this->_uwts->creditcontrol = 'open';
					$this->_uwts->creditmin = 1;
					$this->_uwts->creditmax = 25;
					break;
				default:
					debug(__METHOD__.' undefined CreditControl value "'.$this->sws->CreditControl.'"');
					$this->_uwts->creditcontrol = null;
					$this->_uwts->creditmin = null;
					$this->_uwts->creditmax = null;
					break;
			}
			if ($this->sws->LimitEstimateEnrollmentIndicator == 'limit') {
				$this->_uwts->enrollmentestimate = null;
				$this->_uwts->enrollmentlimit = $this->sws->LimitEstimateEnrollment;
			} else {
				$this->_uwts->enrollmentestimate = $this->sws->LimitEstimateEnrollment;
				$this->_uwts->enrollmentlimit = null;
			}
			$this->_uwts->enrollmentcurrent = $this->sws->CurrentEnrollment;
			$this->_uwts->studentcredithours = $this->sws->StudentCreditHours;
			switch ($this->sws->GradingSystem) {
				case 'standard': 
					$this->_uwts->gradingsystem = 'standard';
					break;
				case 'credit/no credit':
					$this->_uwts->gradingsystem = 'credit';
					break;
				default:
					$this->_uwts->gradingsystem = null;
					break;
			}
			// withdrawn, suspended, or active
			$this->_uwts->deleteflag = $this->sws->DeleteFlag;
			$this->_uwts->swslastupdate = time();
			
			
			$map = array();
			foreach ($this->sws->Meetings as $meeting) {
				$map[$meeting->MeetingIndex] = array();
				$m = $this->_uwts->importMeeting($meeting->MeetingIndex);
				if (array_key_exists($meeting->MeetingType, self::$_map_sectiontype_to_code)) {
					$m->meetingtype = self::$_map_sectiontype_to_code[$meeting->MeetingType];
				} else {
					$m->meetingtype = '??';
				}
				if ($meeting->DaysOfWeekToBeArranged != true) {
					$daylist = array();
					foreach ($meeting->DaysOfWeek->Days as $day) {
						if (array_key_exists($day->Name, self::$_map_days_to_int)) {
							$daylist[] = self::$_map_days_to_int[$day->Name];
						} 
					}
					$m->setDows($daylist);
					$m->start = $meeting->StartTime;
					$m->end = $meeting->EndTime;
				}
				if ($meeting->BuildingToBeArranged == true || $meeting->Building == '*') {
					$m->building = null;
				} else {
					$m->building = $meeting->Building;
				}
				if ($meeting->RoomToBeArranged == true || $meeting->RoomNumber == '*') {
					$m->room = null;
				} else {
					$m->room = $meeting->RoomNumber;
				}
				foreach ($meeting->Instructors as $instructor) {
					$map[$meeting->MeetingIndex][] = $instructor->Person->RegID;
					if ($instructor->Person->RegID) {
						$s = $this->_uwts->importStaff($meeting->MeetingIndex, $instructor->Person->RegID);
					}
				}
			}
			// clean up meeting and staff records that no longer exist
			foreach ($this->_uwts->staff as $staff) {
				if (!array_key_exists($staff->meetingnumber, $map) || !in_array($staff->regid, $map[$staff->meetingnumber])) {
					$staff->deleteFlag = true;
				}
			}
			foreach ($this->_uwts->meetings as $meeting) {
				if (!array_key_exists($meeting->meetingnumber, $map)) {
					$meeting->deleteFlag = true;
				}
			}
			// handle joint offerings
			$this->_uwts->joint->clear();
			foreach ($this->sws->JointSections as $joint) {
				$this->_uwts->joint->addSwsJointItem($joint);
			}
			
			return true;  // update success
		} else {
			return false; // update failed
		}
	}
	
}