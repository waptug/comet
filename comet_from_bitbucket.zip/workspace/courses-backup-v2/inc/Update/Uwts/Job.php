<?php
/**
 * @packagae UW_COE_Courses
 */
/**
 * This job locates searches the SWS course section search resource for offerings
 * and creates or updates those offerings in the local uwtsoffering data
 * @author hanisko
 */
namespace Update\Uwts;

class Job extends \Update\Process\JobAbstract
{
	const CACHE_FRESH_SECONDS = 86400; // 24 hours ago (60*60*24);
	
	private $cutoff;
	private $search;
	
	public function run()
	{
		$this->process->log('===== UPDATE UWTS OFFERING JOB == '.__METHOD__);
		if (array_key_exists('curriculum', $this->process->parameters)) {
			$curricula = (array) $this->process->parameters['curriculum'];
		} else {
			$curricula = \Db_Curriculum::$curricula;
		}
		$quarters = $this->process->parameters['quarters'];
		if (!$quarters instanceof \QuarterIterator) {
			throw new \Exception('Quarter list required');
		}
		foreach ($quarters as $quarter) {
			foreach ($curricula as $curriculum) {
				$this->runQuarterCurriculum($quarter->year, $quarter->quarter, $curriculum);
			}
		}
	}
	
	/**
	 * Update Db_UwtsOffering records for a given year/quarter and curriculum. Queries
	 * the SWS for a list of sections in the UWTS. For each found section check the
	 * local uwtsoffering records and creates and updates if needed.
	 * @param string $year
	 * @param integer $quarter
	 * @param string $curriculum
	 */
	public function runQuarterCurriculum($year, $quarter, $curriculum)
	{
		$this->process->log('----- Update UWTS offerings for '.$year.'-'.$quarter.' '.$curriculum);
		if (is_null($this->search)) {
			$this->search = new \RestClient_CourseSectionSearch('2012', 2, 'EDUC');
		}
		if (is_null($this->cutoff)) {
			$this->cutoff = time() - self::CACHE_FRESH_SECONDS;
		}
		$this->search->year = $year;
		$this->search->quarter = $quarter;
		$this->search->curriculum = $curriculum;
	
		$results = $this->search->getResults();
	
		foreach ($results as $r) {
			if (strlen($r->SectionID) == 2) {
				$this->process->log('- Skipping quiz section '.$r->Year.' '.$r->Quarter.' '.$r->CurriculumAbbreviation.' '.$r->CourseNumber.' '.$r->SectionID);
				continue;
			}
			$uwts = \Db_UwtsOffering::FetchBySection($r->Year, $r->Quarter, $r->CurriculumAbbreviation, $r->CourseNumber, $r->SectionID);
			if ($uwts->swslastupdate < $this->cutoff) {
				$sws = new FromSws($uwts);
				$sws->updateAll();
				$uwts->save();
				$this->process->log('+ Updated '.eQuarter($uwts->year, $uwts->quarter).' '.$uwts->curriculum.' '.$uwts->courseno.' '.$uwts->section.' ('.$uwts->uwtsofferingid.')');
			} else {
				$this->process->log('- Cache fresh for '.eQuarter($uwts->year, $uwts->quarter).' '.$uwts->curriculum.' '.$uwts->courseno.' '.$uwts->section.' ('.$uwts->uwtsofferingid.')');
			}
		}
		$this->flushStaleCache($curriculum, $year, $quarter);
	}
	
	/**
	 * Remove UWTS caches records from the system that no longer show up in the web
	 * service. Has a 60 hour lag so a record has to be not found in the web service
	 * for more than two days to get deleted locally.
	 * @param string $curriculum
	 * @param string $year
	 * @param integer $quarter
	 */
	private function flushStaleCache($curriculum, $year, $quarter)
	{
		$this->process->log('xxxxx Delete stale records from '.$curriculum.' '.$year.'-'.$quarter);
		$expire = time() - 216000; // 60 hours in seconds
		$db = \DbFactory::GetConnection();
		$filters = array(
			'c.curriculum = '.$db->quote($curriculum),
			'u.year = '.$db->quote($year),
			'u.quarter = '.$quarter,
			'u.swslastupdate < '.$db->quote($expire, \DbConnection::TYPE_DATETIME)
		);
		$where = \DbObject::MakeWhereClause($filters);
		$sql = 'SELECT uwtsofferingid FROM uwtsoffering u INNER JOIN course c ON u.courseid = c.courseid '.$where;
		$deletes = implode(',',$db->fetchColumn($sql));
		if ($deletes) {
			// change uw time schedule status on any offerings link to these delete records
			$unlinked = $db->fetchColumn('SELECT offeringid FROM uwtsoffering WHERE uwtsofferingid IN ('.$deletes.') AND offeringid IS NOT NULL');
			foreach ($unlinked as $offeringid) {
				$plan = new \Db_Offering($offeringid);
                if ($plan->recordExists()) {
					$plan->removeUwtsLink();
				}
			}
			// delete child data from these records
			$db->query('DELETE FROM uwtsstaff WHERE uwtsofferingid IN ('.$deletes.')');
			$db->query('DELETE FROM uwtsmeeting WHERE uwtsofferingid IN ('.$deletes.')');
			// delete cached offering records
			$db->query('DELETE FROM uwtsoffering WHERE uwtsofferingid IN ('.$deletes.')');
		}
	}
	
}
