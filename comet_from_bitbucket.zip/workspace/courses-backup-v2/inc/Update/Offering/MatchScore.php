<?php
/**
 * @package UW_COE_Courses
 */
/**
 * A matching score object evaluates the similarity of a plan record 
 * (Db_Offering object) and a UW time schedule record (Db_UwtsOffering 
 * object) is runs a field by field comparison of the two objects and
 * returns an integer score rating how well the two objects corellate.
 * @author hanisko
 */
namespace Update\Offering;
 
class MatchScore
{
	private static $weights = array(
		'section' => 20,
		'sectiontype' => 10,
		'dows' => 20,
		'start' => 20,
		'end' => 20,
		'nomeetings' => 40,
		'staff' => 20,
		'nostaff' => 20,
		'gradingsystem' => 10,
		'onetoone' => 40
	);
	private $plan;
	private $uwts;
	private $score;
	public $scorelog;
	public $num_plan;
	public $num_uwts;
	
	public function __construct(\Db_Offering $plan, \Db_UwtsOffering $uwts)
	{
		$this->plan = $plan;
		$this->uwts = $uwts;
		$this->num_plan = -2;
		$this->num_uwts = -1;
	}
	
	private function compare()
	{
		$this->score = 0;
		$this->scorelog = array();
		if ($this->plan->section == $this->uwts->section) {
			$this->addScore('section');
		}
		if ($this->plan->sectiontype == $this->uwts->sectiontype) {
			$this->addScore('sectiontype');
		}
		if ($this->plan->gradingsystem == $this->uwts->gradingsystem) {
			$this->addScore('gradingsystem');
		}
		$uwts_staff_list = array();
		foreach ($this->uwts->staff as $staff) {
			$uwts_staff_list[] = $staff->regid;
		}
		if ($uwts_staff_list) {
			foreach ($this->plan->staff as $staff) {
				if (in_array($staff->regid, $uwts_staff_list)) {
					$this->addScore('staff');
				}
			}
		} else { // no staff records in UWTS data
			$instructor_count = 0;
			foreach ($this->plan->staff as $staff) {
				if ($staff->role != 'grader' && $staff->role != 'ta') {
					++$instructor_count;
				}
			}
			if ($instructor_count == 0) $this->addScore('nostaff');
		}
		// check for no meeting match
		if ($this->plan->meetingsToBeArranged() && $this->uwts->meetingsToBeArranged()) {
			$this->addScore('nomeetings');
		} else {
			foreach ($this->plan->meetings as $pm) {
				foreach ($this->uwts->meetings as $um) {
					if ($pm->dows == $um->dows) {
						$this->addScore('dows');
						if ($pm->start == $um->start) {
							$this->addScore('start');
						}
						if ($pm->end == $um->end) {
							$this->addScore('end');
						}
					}
				}
			}
		}
		// check for exactly one record in each system
		if ($this->num_plan == 1 && $this->num_uwts == 1) {
			$this->addScore('onetoone');
		}
	}
	
	private function addScore($category)
	{
		$this->scorelog[] = self::$weights[$category].' : '.$category;
		$this->score += self::$weights[$category];
	}
	
	public function getScore()
	{
		if (is_null($this->score)) {
			$this->compare();
		}
		return $this->score;
	}
	
	public function setNumberSections($num_plan = null, $num_uwts = null)
	{
		$db = \DbFactory::GetConnection();
		if (!is_null($num_plan)) {
			$this->num_plan = $num_plan;
		} else {
			// check for one-to-one match
			$sql = 'SELECT COUNT(o.offeringid) AS qty '
			     . 'FROM offering o '
			     . 'INNER JOIN course c '
			     . 'ON o.courseid = c.courseid '
			     . 'WHERE c.curriculum = '.$db->quote($this->plan->curriculum).' '
			     . 'AND c.courseno = '.$this->plan->courseno.' '
			     . 'AND o.year = '.$db->quote($this->plan->year).' '
			     . 'AND o.quarter = '.$this->plan->quarter;
			$this->num_plan = $db->fetchOne($sql);
		}
		if (!is_null($num_uwts)) {
			$this->num_uwts = $num_uwts;
		} else {
			// don't bother unless number of plan records is 1 
			if ($this->num_plan == 1) {
				$sql = 'SELECT COUNT(o.uwtsofferingid) AS qty '
				     . 'FROM uwtsoffering o '
				     . 'INNER JOIN course c '
				     . 'ON o.courseid = c.courseid '
				     . 'WHERE c.curriculum = '.$db->quote($this->uwts->curriculum).' '
				     . 'AND c.courseno = '.$this->uwts->courseno.' '
				     . 'AND o.year = '.$db->quote($this->uwts->year).' '
				     . 'AND o.quarter = '.$this->uwts->quarter;
				$this->num_uwts = $db->fetchOne($sql);
			}
		}
	}
	
	public function setPlanObject(\Db_Offering $plan)
	{
		$this->plan = $plan;
		$this->score = null;
	}
	
	public function setUwtsObject(\Db_UwtsOffering $uwts)
	{
		$this->uwts = $uwts;
		$this->score = null;
	}
	
}