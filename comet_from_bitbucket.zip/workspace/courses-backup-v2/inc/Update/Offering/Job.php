<?php
/**
 * @packagae UW_COE_Courses
 */
/**
 * This job locates Db_Offering records that are linked to UWTS records and
 * updates the appropriate fields. For current and future quarter those are
 * the read-only fields, for past quarters updates all fields.
 * @author hanisko
 */
namespace Update\Offering;

class Job extends \Update\Process\JobAbstract
{
	/**
	 * @var \Update\Offering\FromUwts $updater
	 */
	private $updater;
	
	public function run()
	{
		$this->process->log('===== UPDATE PLAN OFFERING RECORDS JOB == '.__METHOD__);
		$quarters = $this->process->parameters['quarters'];
		if (!$quarters instanceof \QuarterIterator) {
			throw new \Exception('Quarter list required');
		}
		foreach ($quarters as $quarter) {
			$this->runQuarter($quarter->year, $quarter->quarter);
		}
	}
	
	/**
	 * Update any linked Db_Offering records in the specified quarter.
	 * @param string $year
	 * @param param $quarter
	 */
	public function runQuarter($year, $quarter)
	{
		$this->process->log('----- Update plan Db_Offering records for '.$year.'-'.$quarter);
		if (is_null($this->updater)) $this->updater = new \Update\Offering\FromUwts();
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT uwtsofferingid '
		     . 'FROM uwtsoffering WHERE year = '.$db->quote($year).' '
		     . 'AND quarter = '.(int)$quarter.' '
		     . 'AND offeringid IS NOT NULL';
		$todolist = $db->fetchColumn($sql);
		foreach ($todolist as $uwtsofferingid) {
			$uwts = new \Db_UwtsOffering($uwtsofferingid);
			$plan = new \Db_Offering($uwts->offeringid);
			$this->process->log('. '.$year.'-'.$quarter.' '.$plan->curriculum.' '.$plan->courseno.' '.$plan->section);
			$this->updater->update($uwts, $plan);
		}
	}
	
}
