<?php
/**
 * @packagae UW_COE_Courses
 */
/**
 * This job locates historical Db_Offering records that have no matching UWTS record
 * and marks them as canceled.
 * @author hanisko
 */
namespace Update\Offering;

class CancelJob extends \Update\Process\JobAbstract
{

	public function run()
	{
		$this->process->log('===== CANCEL UNLINKED OFFERING RECORDS JOB == '.__METHOD__);
		$quarters = $this->process->parameters['quarters'];
		if (!$quarters instanceof \QuarterIterator) {
			throw new \Exception('Quarter list required');
		}
		foreach ($quarters as $quarter) {
			$this->runCancelQuarter($quarter->year, $quarter->quarter);
		}
	}

	/**
	 * Searches a quarter for plan records (Db_Offering) that are not linked
	 * to UW time schedule records and sets their status to canceled. This
	 * method does nothing for current or future quarters.
	 * @param string $year
	 * @param integer $quarter
	 */
	public function runCancelQuarter($year, $quarter)
	{
		$current_quarter = \Db_Quarter::FetchCurrentQuarter();
		if ($current_quarter->compareYearQuarter($year, $quarter) >= 0) {
			// dont run this on the current or a future quarter
			$this->process->log('!! CANNOT IMPLY CANCEL ON CURRENT OR FUTURE QUARTER '.$year.'-'.$quarter);
			return;
		}
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT offeringid '
		     . 'FROM offering '
		     . 'WHERE year = '.$db->quote($year).' '
		     . 'AND quarter = '.$quarter.' '
		     . 'AND uwtsstatus in (0,3) '
		     . 'AND status <> \'canceled\'';
		$todo = $db->fetchColumn($sql);
		foreach ($todo as $offeringid) {
			$plan = new \Db_Offering($offeringid);
			$status = new \Offering\Components\Status($plan);
			$status->cancelByUwts();
			$this->process->log('- Cancel implied for historical offeringid '.$offeringid);
		}
	}
	
}
