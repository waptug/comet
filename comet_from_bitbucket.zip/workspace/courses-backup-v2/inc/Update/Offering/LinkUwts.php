<?php
/**
 * @package UW_COE_Courses
 */
/**
 * This class creates a link between a local plan (Db_Offering) record and a
 * UW Time Schedule (Db_UwtsOffering) record
 * @author hanisko
 */
namespace Update\Offering;
 
class LinkUwts
{
	
	/**
	 * Links a cached UWTS record (Db_UwtsOffering) to a local plan record (Db_Offering) 
	 * @param Db_UwtsOffering $uwts
	 * @param Db_Offering $plan
	 * @return boolean
	 */
	public function createLink(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		$r = $plan->changeSection($uwts->section);
		if (!$r) {
			return false;
		}
		// Important to save plan first to make sure it has an offeringid
		$plan->sln = $uwts->sln;
		$plan->sectionstatus = 'V';
		if ($plan->uwtsstatus == 0) { // change not in UWTS
			$plan->uwtsstatus = 1;    // to modified
		}
		$plan->save();
		$uwts->offeringid = $plan->offeringid;
		$uwts->save();
		return true;
	}
	
}