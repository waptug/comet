<?php
/**
 * @packagae UW_COE_Courses
 */
/**
 * This job runs the update method for each repetition rule in the database 
 * to generate future offerings
 */
namespace Update\Offering;

class RepetitionJob extends \Update\Process\JobAbstract
{
    
    public function run()
    {
        $this->process->log('===== UPDATE REPETITION RULES == '.__METHOD__);
        $repetitions = \Db_Repetition::FetchMultiple();
        foreach($repetitions as $repetition) {
            $this->process->log('----- Running update() on Db_Repetition '.$repetition->course->curriculum.' '.$repetition->course->courseno);
            $repetition->update();
        }
    }
    
    
    
}
