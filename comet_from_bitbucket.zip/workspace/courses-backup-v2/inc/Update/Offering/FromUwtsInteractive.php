<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Provides interface for field by field comparison of a Plan record to
 * its linked UWTS record and supports accepting UWTS values field by
 * field.
 * @author hanisko
 */
namespace Update\Offering;

class FromUwtsInteractive
{
	const TEXT_UPTODATE = 'Up to date';
	const TEXT_ACCEPT = 'Accept UWTS';
	const TEXT_DELETE = 'Delete from plan';
	const TEXT_UNCANCEL = 'Change to planned';
	
	private $confirm;
	private $plan;
	private $uwts;
	
	public function __construct(\Db_Offering $plan, \Db_UwtsOffering $uwts)
	{
		$this->plan = $plan;
		$this->uwts = $uwts;
	}
	
	/**
	 * Update the Plan record with the value from the UWTS record for the specified field.
	 * This applies to specific meetings, staff, and joint offering fields. Specific item
	 * identifiers must be passed in $params array.
	 * @param string $property
	 * @param array $params
	 * @throws \Exception
	 */
	public function acceptUwtsValue($property, $params = null)
	{
		switch ($property) {
			case 'sectiontype':
			case 'summerterm':
			case 'enrollmentestimate':
			case 'enrollmentlimit':
			case 'gradingsystem':
			case 'institution':
				if ($this->plan->$property != $this->uwts->$property) {
					$this->plan->$property = $this->uwts->$property;
					$this->plan->save();
				}
				break;
			case 'canceled':
				$this->acceptCanceled();
				break;
			case 'credits':
				$this->acceptCredits();
				break;
			case 'joint':
				$this->acceptJoint($params);
				break;
			case 'meeting':
				$this->acceptMeeting($params);
				break;
			case 'staff':
				$this->acceptStaff($params);
				break;
			default:
				throw new \Exception('Unhandled property type ('.$property.')');
				break;
		}
	}

	/**
	 * Update the Plan record status to 'planned', accepting the UWTS value of
	 * not canceled.
	 * @throws Exception
	 */
	private function acceptCanceled()
	{
		$status = new \Offering\Components\Status($this->plan);
		$status->setStatus('planned');
	}

	/**
	 * Updates the three fields that represent section credits
	 * @throws Exception
	 */
	private function acceptCredits()
	{
		$this->plan->creditcontrol = $this->uwts->creditcontrol;
		$this->plan->creditmin = $this->uwts->creditmin;
		$this->plan->creditmax = $this->uwts->creditmax;
		$this->plan->save();
	}

	/**
	 * Update the Plan record with the value from the UWTS record for a specific
	 * staff record. Expects a 'jointid' in the format 'EDUC-200-A'
	 * @param array $params
	 * @throws Exception
	 */
	private function acceptJoint($params)
	{
		// $params['jointid'] = 'EDUC-200-A';
		$bits = explode('-',$params['jointid']);
		if (count($bits) != 3) {
			throw new \Exception('Not a valid joint offering identifier');
		}
		$uj = $this->uwts->joint->hasJoint($bits[0], $bits[1], $bits[2]);
		if ($uj) { // if this joint record exists in UWTS do an add or update
			$joint = $this->plan->joint->importJoint($bits[0], $bits[1], $bits[2]);
			$this->plan->joint->addJoint($joint);
		} else {
			// otherwise UWTS record did not exist so accept means delete
			$this->plan->joint->removeJointByMatch($bits[0], $bits[1], $bits[2]);
		}
	}

	/**
	 * Update the Plan record with the value from the UWTS record for a specific 
	 * meeting record. Expects a 'meetingnumber' to be defined in $params.
	 * @param array $params
	 * @throws Exception
	 */
	private function acceptMeeting($params)
	{
		$meetingnumber = $params['meetingnumber'];
		
		$um = $this->uwts->getMeetingByNumber($meetingnumber);
		$pm = $this->plan->getMeetingByNumber($meetingnumber);
		
		if ($um) { // if this meeting exists in UWTS do an add or update
			if (!$pm) { // if plan meeting did not already exist, create it
				$pm = new \Db_Meeting(0);
				$pm->offeringid = $this->plan->offeringid;
				$pm->meetingnumber = $meetingnumber;
			}
			$pm->setDays($um->dows);
			$pm->start = $um->start;
			$pm->end = $um->end;
			$pm->building = $um->building;
			$pm->room = $um->room;
			$pm->save();
			$this->plan->meetingsummary = $this->plan->getMeetingSummary(true);
			$this->plan->save();
			$this->plan->meetings->addMeeting($pm);
		} else {
			// otherwise UWTS record did not exist so accept means delete
			if ($pm) {
				$pm->delete();
				$this->plan->meetingsummary = $this->plan->getMeetingSummary(true);
				$this->plan->save();
				$this->plan->meetings->removeMeeting($pm);
			}
		}
	}

	/**
	 * Update the Plan record with the value from the UWTS record for a specific
	 * staff record. Expects a 'meetingnumber' and 'regid' to be defined in $params.
	 * @param array $params
	 * @throws Exception
	 */
	private function acceptStaff($params)
	{
		$meetingnumber = $params['meetingnumber'];
		$regid = $params['regid'];
		
		$us = $this->uwts->getStaffByRegid($meetingnumber, $regid);
		$ps = $this->plan->getStaffByRegid($meetingnumber, $regid);
		if ($us) { // if this staff record exists in UWTS do an add or update
			if (!$ps) { // if plan staff did not already exist, create it
				$ps = new \Db_Staff(0);
				$ps->offeringid = $this->plan->offeringid;
				$ps->meetingnumber = $meetingnumber;
			}
			$ps->personid = $us->personid;
			$ps->role = 'instructor';
			$ps->timesched = 1;
			$ps->save();
			$this->plan->meetings->addStaff($ps);
		} else {
			// otherwise UWTS record did not exist so accept means delete
			if ($ps) {
				$ps->delete();
				$this->plan->meetings->removeStaff($ps);
			}
		}
	}
	
	/**
	 * Returns an associative array list of parameters required to identify a
	 * specific property. This array can be used to build links to the accept
	 * tool.
	 * @param string $property
	 * @param integer $meetingnumber
	 * @param string $regid
	 * @throws Exception
	 * @return array
	 */
	public function getAcceptParams($property, $meetingnumber = null, $regid = null)
	{
		if (is_null($this->confirm)) {
			$this->confirm = new \Confirmation();
		}
		$out = array(
			'o' => $this->plan->offeringid,
			'property' => $property,
			\Confirmation::INPUT_FIELD_NAME => $this->confirm->getCode()
		);
		switch ($property) {
			case 'sectiontype':
			case 'summerterm':
			case 'enrollmentestimate':
			case 'enrollmentlimit':
			case 'gradingsystem':
			case 'institution':
			case 'canceled':
			case 'credits':
			case 'joint':
				break;
			case 'meeting':
				$out['m'] = $meetingnumber;
				break;
			case 'staff':
				$out['m'] = $meetingnumber;
				$out['regid'] = $regid;
				break;
			default:
				throw new \Exception('Unhandled property type ('.$property.')');
				break;
		}
		return $out;
	}

	/**
	 * Returns a string that describes the action of accepting the UWTS value of this
	 * fields. Could be "Accept", "Delete", or do nothing because this field is "Up to
	 * date".
	 * @param string $property
	 * @param integer $meetingnumber
	 * @param string $regid
	 * @throws Exception
	 * @return string
	 */
	public function getAcceptUwtsText($property, $meetingnumber = null, $regid = null)
	{
		switch ($property) {
			case 'sectiontype':
			case 'summerterm':
			case 'enrollmentestimate':
			case 'enrollmentlimit':
			case 'gradingsystem':
			case 'institution':
				if ($this->plan->$property == $this->uwts->$property) {
					return self::TEXT_UPTODATE;
				} else {
					return self::TEXT_ACCEPT;
				}
				break;
			case 'credits':
				if ($this->isUpToDateCredits()) {
					return self::TEXT_UPTODATE;
				} else {
					return self::TEXT_ACCEPT;
				}
				break;
			case 'meeting':
				return $this->getAcceptMeetingText($meetingnumber);
				break;
			case 'staff':
				return $this->getAcceptStaffText($meetingnumber, $regid);
				break;
			case 'canceled':
				return self::TEXT_UNCANCEL;
				break;
			default:
				throw new \Exception('Unhandled property type ('.$property.')');
				break;
		}
	}

	/**
	 * Returns a string that describes the action of accepting the UWTS value of this
	 * meeting field. Could be "Accept", "Delete", or do nothing because this meeting
	 * record is "Up to date".
	 * @param integer $meetingnumber
	 * @return string
	 */
	private function getAcceptMeetingText($meetingnumber)
	{
		$um = $this->uwts->getMeetingByNumber($meetingnumber);
		$pm = $this->plan->getMeetingByNumber($meetingnumber);
		
		if ($um) {
			if ($pm) {
				// both plan and UWTS exist, run comparison
				if ($um->dows != $pm->dows)   return self::TEXT_ACCEPT;
				if ($um->start != $pm->start) return self::TEXT_ACCEPT;
				if ($um->end != $pm->end)     return self::TEXT_ACCEPT;
				return self::TEXT_UPTODATE;
			} else {
				// there is a UWTS record, but no plan record
				return self::TEXT_ACCEPT;
			}
		} elseif ($pm) {
			// there is a plan record, but no UWTS record
			return self::TEXT_DELETE;
		} else {
			// there is neither a plan record, nor a UWTS record
			return self::TEXT_UPTODATE;
		}
	}

	/**
	 * Returns a string that describes the action of accepting the UWTS value of this
	 * staff field. Could be "Accept", "Delete", or do nothing because this staff
	 * record is "Up to date".
	 * @param integer $meetingnumber
	 * @param string $regid
	 * @return string
	 */
	private function getAcceptStaffText($meetingnumber, $regid)
	{
		$us = $this->uwts->getStaffByRegid($meetingnumber, $regid);
		$ps = $this->plan->getStaffByRegid($meetingnumber, $regid);
		
		if ($us) {
			if ($ps) {
				// both plan and UWTS exist
				return self::TEXT_UPTODATE;
			} else {
				// there is a UWTS record, but no plan record
				return self::TEXT_ACCEPT;
			}
		} elseif ($ps) {
			// there is a plan record, but no UWTS record
			return self::TEXT_DELETE;
		} else {
			// there is neither a plan record, nor a UWTS record
			return self::TEXT_UPTODATE;
		}
	}

	/**
	 * Returns an array of stdClass objects that compare the joint offerings between
	 * the Plan and UWTS records and provide values to generate links. The output
	 * objects have the following properties
	 *   $out[]->jointid - string that identifies a specific joint offering
	 *         ->plantext - user readable string that describes current value
	 *         ->uwtstext - user readable string that describes current value
	 *         ->isuptodate - boolean flag saying this meeting needs action to sync
	 *         ->accepttext - text description of action needed to accept the UWTS value
	 * @return array[stdClass]
	 */
	public function getJointComparison()
	{
		$out = array();
		foreach ($this->uwts->joint as $uj) {
			$o = new \stdClass();
			$o->jointid = $uj->curriculum.'-'.$uj->courseno.'-'.$uj->section;
			$o->uwtstext = $uj->curriculum.' '.$uj->courseno.' '.$uj->section;
			$o->plantext = null;
			$o->isuptodate = false;
			$o->accepttext = self::TEXT_ACCEPT;
			$out[$o->jointid] = $o;
		}
		foreach ($this->plan->joint as $pj) {
			$index = $pj->curriculum.'-'.$pj->courseno.'-'.$pj->section;
			if (array_key_exists($index, $out)) {
				$out[$index]->plantext = $pj->curriculum.' '.$pj->courseno.' '.$pj->section;
				$out[$index]->isuptodate = true;
				$out[$index]->accepttext = self::TEXT_UPTODATE;
			} else {
				$o = new \stdClass();
				$o->jointid = $index;
				$o->uwtstext = null;
				$o->plantext = $pj->curriculum.' '.$pj->courseno.' '.$pj->section;
				$o->isuptodate = false;
				$o->accepttext = self::TEXT_DELETE;
				$out[$index] = $o;
			}
		}
		return $out;
	}
	
	/**
	 * Returns an array of stdClass objects that compare the meeting fields between
	 * the Plan and UWTS records and provide values to generate links. The output 
	 * objects have the following properties
	 *   $out[]->meetingnumber - index for this meeting comparison
	 *         ->plantext - user readable string that describes current value
	 *         ->uwtstext - user readable string that describes current value
	 *         ->isuptodate - boolean flag saying this meeting needs action to sync
	 *         ->accepttext - text description of action needed to accept the UWTS value
	 * @return array[stdClass]
	 */
	public function getMeetingComparison()
	{
		$out = array();
		for ($m = 1; $m < 4; ++$m) {
			$o = new \stdClass();
			$o->meetingnumber = $m;
			$um = $this->uwts->getMeetingByNumber($m);
			$pm = $this->plan->getMeetingByNumber($m);
			if ($um) {
				if ($pm) {
					// both plan and UWTS exist
					$o->plantext = e($pm->getUwtsSummary());
					$o->uwtstext = e($um->getUwtsSummary());

					if ($um->dows != $pm->dows || $um->start != $pm->start || $um->end != $pm->end) {
						$o->isuptodate = false;
						$o->accepttext = self::TEXT_ACCEPT;
					} else {
						$o->isuptodate = true;
						$o->accepttext = self::TEXT_UPTODATE;
					}
				} else {
					// there is a UWTS record, but no plan record
					$o->plantext = null;
					$o->uwtstext = e($um->getUwtsSummary());
					$o->isuptodate = false;
					$o->accepttext = self::TEXT_ACCEPT;
				}
			} elseif ($pm) {
				// there is a plan record, but no UWTS record
				$o->plantext = e($pm->getUwtsSummary());
				$o->uwtstext = null;
				$o->isuptodate = false;
				$o->accepttext = self::TEXT_DELETE;
			} else {
				// there is neither a plan record, nor a UWTS record
				continue;
			}
			$out[] = $o;
		}
		return $out;
	}

	/**
	 * Returns an array of stdClass objects that compare the staff fields between
	 * the Plan and UWTS records and provide values to generate links. The output
	 * objects have the following properties
	 *   $out[]->plantext - user readable string that describes current value
	 *         ->uwtstext - user readable string that describes current value
	 *         ->isuptodate - boolean flag saying this staff record needs action to sync
	 *         ->accepttext - text description of action needed to accept the UWTS value
	 * @return array[stdClass]
	 */
	public function getStaffComparison()
	{
		$map = array();
		foreach ($this->uwts->staff as $us) {
			if (!array_key_exists($us->meetingnumber, $map)) {
				$map[$us->meetingnumber] = array();
			}
			if (!array_key_exists($us->regid, $map[$us->meetingnumber])) {
				$map[$us->meetingnumber][$us->regid] = array('plan'=>null,'uwts'=>null);
			}
			$map[$us->meetingnumber][$us->regid]['uwts'] = $us;
		}
		foreach ($this->plan->staff as $ps) {
			// only compare for roles that are entered in UWTS
			if (!in_array($ps->role, \Update\Offering\Field\Staff::$roles_in_uwts)) {
				continue;
			}
			if (!array_key_exists($ps->meetingnumber, $map)) {
				$map[$ps->meetingnumber] = array();
			}
			if (!array_key_exists($ps->regid, $map[$ps->meetingnumber])) {
				$map[$ps->meetingnumber][$ps->regid] = array('plan'=>null,'uwts'=>null);
			}
			$map[$ps->meetingnumber][$ps->regid]['plan'] = $ps;
		}
		$out = array();
		foreach ($map as $m => $stafflist) {
			foreach ($stafflist as $regid => $values) {
				$o = new \stdClass();
				$o->meetingnumber = $m;
				$o->regid = $regid;
				if ($values['plan']) {
					$o->plantext = '('.$m.') '.\View_Person::FirstLast($values['plan']);
				} else {
					$o->plantext = null;
				}
				if ($values['uwts']) {
					$o->uwtstext = '('.$m.') '.\View_Person::FirstLast($values['uwts']);
				} else {
					$o->uwtstext = null;
				}
				if ($values['uwts']) {
					if ($values['plan']) {
						// both plan and UWTS exist
						$o->isuptodate = true;
						$o->accepttext = self::TEXT_UPTODATE;
					} else {
						// there is a UWTS record, but no plan record
						$o->isuptodate = false;
						$o->accepttext = self::TEXT_ACCEPT;
					}
				} elseif ($values['plan']) {
					// there is a plan record, but no UWTS record
					$o->isuptodate = false;
					$o->accepttext = self::TEXT_DELETE;
				} else {
					// there is neither a plan record, nor a UWTS record
					continue;
				}
				$out[] = $o;
			}
		}
		return $out;
	}

	/**
	 * Returns true if the specified property matches in the Plan record and the 
	 * UWTS record. Compares specific meeting (identified by meeting number) and 
	 * specific staff records (identified by meeting number and RegID).
     * @param $property
     * @param $meetingnumber
     * @param $regid
	 * @return boolean
     * @throws \Exception
	 */
	public function isUpToDate($property, $meetingnumber = null, $regid = null)
	{
		switch ($property) {
			case 'sectiontype':
			case 'summerterm':
			case 'gradingsystem':
			case 'institution':
				return ($this->plan->$property == $this->uwts->$property); 
				break;
			case 'credits':
				return $this->isUpToDateCredits($meetingnumber);
				break;
			case 'enrollmentestimate':
			case 'enrollmentlimit':
				return ((int)$this->plan->$property == (int)$this->uwts->$property); 
				break;
			case 'meeting':
				$this->isUpToDateMeeting($meetingnumber);
				break;
			case 'staff':
				$this->isUpToDateStaff($meetingnumber, $regid);
				break;
			case 'canceled':
				return $this->plan->status != 'canceled';
				break;
			default:
				throw new \Exception('Unhandled property type ('.$property.')');
				break;
		}
	}

	/**
	 * Returns true when there is a difference between the value of the UWTS record,
	 * but only when this field's diff policy states that the field's value impacts
	 * the overall uwtsstatus of the offering.
	 * @return boolean
	 */
	public function isUpToDateCredits()
	{
		if ($this->plan->creditcontrol != $this->uwts->creditcontrol) {
			return false;
		}
		if ((int)$this->plan->creditmin != (int)$this->uwts->creditmin) {
			return false;
		}
		if ((int)$this->plan->creditmax != (int)$this->uwts->creditmax) {
			return false;
		}
		return true;
	}
	
	/**
	 * Returns true if the specific meeting (identified by meeting number) has
	 * the same values as the comparable UWTS record.
	 * @return boolean
	 */
	private function isUpToDateMeeting($meetingnumber)
	{
		$um = $this->uwts->getMeetingByNumber($meetingnumber);
		$pm = $this->plan->getMeetingByNumber($meetingnumber);
		
		if ($um) {
			if ($pm) {
				// both plan and UWTS exist, run comparison
				if ($um->dows != $pm->dows)   return false;
				if ($um->start != $pm->start) return false;
				if ($um->end != $pm->end)     return false;
				return true;
			} else {
				// there is a UWTS record, but no plan record
				return false;
			}
		} elseif ($pm) {
			// there is a plan record, but no UWTS record
			return false;
		} else {
			// there is neither a plan record, nor a UWTS record
			return true;
		}
	}

	/**
	 * Returns true if the specific staff records (identified by meeting number
	 * and RegID) has the same values as the comparable UWTS record.
	 * @return boolean
	 */
	private function isUpToDateStaff($meetingnumber, $regid)
	{
		$us = $this->uwts->getStaffByRegid($meetingnumber, $regid);
		$ps = $this->plan->getStaffByRegid($meetingnumber, $regid);
		
		if ($us) {
			if ($ps) {
				// both plan and UWTS exist
				return true;
			} else {
				// there is a UWTS record, but no plan record
				return false;
			}
		} elseif ($ps) {
			// there is a plan record, but no UWTS record
			return false;
		} else {
			// there is neither a plan record, nor a UWTS record
			return true;
		}
	}
	
}
