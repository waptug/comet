<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Contains the logic for updating the Staff fields of a Plan record (Db_Offering) 
 * from a cached UW time schedule record (Db_UwtsOffering)
 * @author hanisko
 */
namespace Update\Offering\Field;
 
class Staff extends FieldAbstract
{
	public static $roles_in_uwts = array('instructor','faculty','adjunct','support');
	
	protected $update_policy = FieldAbstract::UPDATE_ONLY_HISTORICAL;
	protected $diff_policy = FieldAbstract::DIFF_AFFECTS_STATUS;
	protected $fieldname = 'staff';

	/**
	 * Returns true when there is a difference between the value of the UWTS record,
	 * but only when this field's diff policy states that the field's value impacts
	 * the overall uwtsstatus of the offering.
	 * @return boolean
	 */
	public function isDifferent(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		foreach ($plan->staff as $ps) {
			// don't compare the TBD placeholder
			if ($ps->personid == 1) {
				continue;
			}
			// only compare for roles that are entered in UWTS
			if (!in_array($ps->role, self::$roles_in_uwts)) {
				continue; 
			}
			if (!$ps->regid) return true; // planned staff can't be compared to uwts without regid
			$us = $uwts->getStaffByRegid($ps->meetingnumber, $ps->regid);
			if (!$us) {
				return true; // planned staff missing from uwts
			}
		}
		foreach ($uwts->staff as $us) {
			$ps = $plan->getStaffByRegid($us->meetingnumber, $us->regid);
			if (!$ps || !in_array($ps->role, self::$roles_in_uwts)) {
				return true; // uwts staff missing from plan
			}
		}
		return false;
	}
	
	/**
	 * Updates this field in the Plan record with the value in the UWTS record. If
	 * this field is not read only (therefore should only be updated when the record 
	 * is histrorical) this method will return without doing anything.
	 */
	public function updateReadOnly(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		// Accept UWTS staff for Independent Study courses
		if ($plan->sectiontype == 'IS' || $this->update_policy == FieldAbstract::UPDATE_ALWAYS) {
			$this->update($uwts, $plan);
		}
	}
	
	/**
	 * Updates this field in the Plan record with the value in the UWTS record.
	 */
	public function update(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		foreach ($uwts->staff as $us) {
			$ps = $plan->getStaffByRegid($us->meetingnumber, $us->regid);
			if (!$ps) {
				$person = \Db_Person::FetchFromSws($us->regid);
				$ps = new \Db_Staff(0);
				$ps->offeringid = $plan->offeringid;
				$ps->meetingnumber = $us->meetingnumber;
				$ps->personid = $person->personid;
				if ($person->isfaculty) {
					$ps->role = 'faculty';
				} elseif ($person->isadjunct) {
					$ps->role = 'adjunct';
				} else {
					$ps->role = 'instructor';
				}
				$ps->save();
			}
		}
		foreach ($plan->staff as $ps) {
			$us = $uwts->getStaffByRegid($ps->meetingnumber, $ps->regid);
			if (!$us) { // staff exists in plan but not in uwts
				// delete staff from plan if not in UWTS, but only for roles we put in UWTS
				if (in_array($ps->role, self::$roles_in_uwts)) {
					$ps->delete();
				}
			}
		}
	}
	
}
