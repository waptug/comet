<?php
/**
 * @package edu.uw.education.courses
 */
/**
 * Contains the logic for updating the Summerterm field of a Plan record (Db_Offering) 
 * from a cached UW time schedule record (Db_UwtsOffering)
 * @author hanisko
 */
namespace Update\Offering\Field;
 
class SummerTerm extends FieldAbstract
{
	protected $update_policy = FieldAbstract::UPDATE_ONLY_HISTORICAL;
	protected $diff_policy = FieldAbstract::DIFF_AFFECTS_STATUS;
	protected $fieldname = 'summerterm';

    /**
     * Returns true when there is a difference between the value of the UWTS record,
     * but only when this field's diff policy states that the field's value impacts
     * the overall uwtsstatus of the offering.
     * @param \Db_UwtsOffering $uwts
     * @param \Db_Offering $plan
     * @return boolean
     */
    public function isDifferent(\Db_UwtsOffering $uwts, \Db_Offering $plan)
    {
        if ($plan->quarter != 3) {
            // Field is hidden and meaningless except for summer quarter (3)
            return false;
        }
        return parent::isDifferent($uwts, $plan);
    }

}
