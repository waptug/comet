<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Contains the logic for updating the Enrollmentcurrent field of a Plan record (Db_Offering) 
 * from a cached UW time schedule record (Db_UwtsOffering)
 * @author hanisko
 */
namespace Update\Offering\Field;
 
class EnrollmentCurrent extends FieldAbstract
{
	protected $update_policy = FieldAbstract::UPDATE_ALWAYS;
	protected $diff_policy = FieldAbstract::DIFF_DOES_NOT_AFFECT_STATUS;
	protected $fieldname = 'enrollmentcurrent';

	/**
	 * Updates this field in the Plan record with the value in the UWTS record.
	 */
	public function update(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		/* In UWTS data, Enrollment current is populated with same section last year 
		 * when the record is created. Only after an SLN is assigned is the value 
		 * zeroed out and becomes an accurate measure of students enrolled in this
		 * year's course offering.
		 */
		if ($uwts->sln) {
			$plan->enrollmentcurrent = $uwts->enrollmentcurrent;
			if ($plan->course->creditfixed) {
				$plan->studentcredithours = $plan->enrollmentcurrent * $plan->course->creditfixed;
			}
		} else {
			$plan->enrollmentcurrent = 0;
			$plan->studentcredithours = 0;
		}
	}
	
}