<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Contains the logic for updating the credits fields of a Plan record (Db_Offering) 
 * from a cached UW time schedule record (Db_UwtsOffering)
 * @author hanisko
 */
namespace Update\Offering\Field;
 
class Credits extends FieldAbstract
{
	protected $update_policy = FieldAbstract::UPDATE_ONLY_HISTORICAL;
	protected $diff_policy = FieldAbstract::DIFF_AFFECTS_STATUS;
	protected $fieldname = 'creditcontrol';

	/**
	 * Returns true when there is a difference between the value of the UWTS record,
	 * but only when this field's diff policy states that the field's value impacts
	 * the overall uwtsstatus of the offering.
	 * @return boolean
	 */
	public function isDifferent(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		if ($plan->creditcontrol != $uwts->creditcontrol) {
			return true;
		}
		if ((int)$plan->creditmin != (int)$uwts->creditmin) {
			return true;
		}
		if ((int)$plan->creditmax != (int)$uwts->creditmax) {
			return true;
		}
		return false;
	}
	
	/**
	 * Updates this field in the Plan record with the value in the UWTS record.
	 */
	public function update(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		$plan->creditcontrol = $uwts->creditcontrol;
		$plan->creditmin = $uwts->creditmin;
		$plan->creditmax = $uwts->creditmax;
	}
	
}
