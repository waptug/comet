<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Contains the logic for updating the Meeting fields of a Plan record (Db_Offering) 
 * from a cached UW time schedule record (Db_UwtsOffering)
 * @author hanisko
 */
namespace Update\Offering\Field;
 
class Meetings extends FieldAbstract
{
	protected $update_policy = FieldAbstract::UPDATE_ONLY_HISTORICAL;
	protected $diff_policy = FieldAbstract::DIFF_AFFECTS_STATUS;
	protected $fieldname = 'meetings';

	/**
	 * Returns true when there is a difference between the value of the UWTS record,
	 * but only when this field's diff policy states that the field's value impacts
	 * the overall uwtsstatus of the offering.
	 * @return boolean
	 */
	public function isDifferent(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		foreach ($plan->meetings as $pm) {
			$um = $uwts->getMeetingByNumber($pm->meetingnumber);
			if ($um) {
				if ($um->dows != $pm->dows) return true;
				if ($um->start != $pm->start) return true;
				if ($um->end != $pm->end) return true;
			} else {
				return true; // planned meeting missing from uwts
			}
		}
		foreach ($uwts->meetings as $um) {
			$pm = $uwts->getMeetingByNumber($um->meetingnumber);
			if ($pm) {
				if ($pm->dows != $um->dows) return true;
				if ($pm->start != $um->start) return true;
				if ($pm->end != $um->end) return true;
			} else {
				return true; // uwts meeting not in plan
			}
		}
		return false;
	}
	
	/**
	 * Updates this field in the Plan record with the value in the UWTS record. If
	 * this field is not read only (therefore should only be updated when the record 
	 * is histrorical) this method will return without doing anything.
	 */
	public function updateReadOnly(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		foreach ($uwts->meetings as $um) {
			$pm = $plan->getMeetingByNumber($um->meetingnumber);
			if ($pm) {
				$pm->building = $um->building;
				$pm->room = $um->room;
				$pm->save();
			} else {
				$pm = new \Db_Meeting(0);
				$pm->offeringid = $plan->offeringid;
				$pm->meetingnumber = $um->meetingnumber;
				$pm->building = $um->building;
				$pm->room = $um->room;
				$pm->save();
			}
		}
	}
	
	/**
	 * Updates this field in the Plan record with the value in the UWTS record.
	 */
	public function update(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		foreach ($uwts->meetings as $um) {
			$pm = $plan->getMeetingByNumber($um->meetingnumber);
			if (!$pm) {
				$pm = new \Db_Meeting(0);
				$pm->offeringid = $plan->offeringid;
				$pm->meetingnumber = $um->meetingnumber;
			}
			$pm->setDays($um->dows);
			$pm->start = $um->start;
			$pm->end = $um->end;
			$pm->building = $um->building;
			$pm->room = $um->room;
			$pm->save();
		}
		foreach ($plan->meetings as $pm) {
			$um = $uwts->getMeetingByNumber($pm->meetingnumber);
			if (!$um) { // meeting exists in plan but not in uwts
				$pm->delete();
			}
		}
		$plan->meetingsummary = $plan->getMeetingSummary(true);
		$plan->save();
	}
	
}