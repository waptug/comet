<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Contains the logic for updating the Joint offerings of a Plan record (Db_Offering) 
 * from a cached UW time schedule record (Db_UwtsOffering)
 * @author hanisko
 */
namespace Update\Offering\Field;
 
class Joint extends FieldAbstract
{	
	protected $update_policy = FieldAbstract::UPDATE_ONLY_HISTORICAL;
	protected $diff_policy = FieldAbstract::DIFF_AFFECTS_STATUS;
	protected $fieldname = 'joint';

	/**
	 * Returns true when there is a difference between the value of the UWTS record,
	 * but only when this field's diff policy states that the field's value impacts
	 * the overall uwtsstatus of the offering.
	 * @return boolean
	 */
	public function isDifferent(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		foreach ($plan->joint as $js) {
			if (!$uwts->joint->hasJoint($js->curriculum, $js->courseno, $js->section)) {
				return true; // planned joint offering missing from uwts
			}
		}
		foreach ($uwts->joint as $uj) {
			if (!$plan->joint->hasJoint($uj->curriculum, $uj->courseno, $uj->section)) {
				return true; // uwts joint offering missing from plan
			}
		}
		return false;
	}
	
	/**
	 * Updates this field in the Plan record with the value in the UWTS record.
	 */
	public function update(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		foreach ($uwts->joint as $uj) {
			if (!$plan->joint->hasJoint($uj->curriculum, $uj->courseno, $uj->section)) {
				$joint = $plan->joint->importJoint($uj->curriculum, $uj->courseno, $uj->section);
				$joint->save();
				$plan->joint->addJoint($joint);
			}
		}
		foreach ($plan->joint as $js) {
			if (!$uwts->joint->hasJoint($js->curriculum, $js->courseno, $js->section)) {
				// joint record exists in plan, but not in uwts, delete it
				$plan->joint->removeJoint($js);
			}
		}
	}
	
}