<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Contains the logic for updating the Enrollmentcurrent field of a Plan record (Db_Offering) 
 * from a cached UW time schedule record (Db_UwtsOffering)
 * @author hanisko
 */
namespace Update\Offering\Field;
 
class StudentCreditHours extends FieldAbstract
{
	protected $update_policy = FieldAbstract::UPDATE_ALWAYS;
	protected $diff_policy = FieldAbstract::DIFF_DOES_NOT_AFFECT_STATUS;
	protected $fieldname = 'studentcredithours';

	/**
	 * Updates this field in the Plan record with the value in the UWTS record.
	 */
	public function update(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		if ($uwts->sln) {
			$plan->studentcredithours = $uwts->studentcredithours;
		}
	}
	
}