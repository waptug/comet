<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Contains the logic for comparing the status = canceled field in a 
 * Db_Offering record. The link's existence means that the UWTS record
 * exists and is not canceled.
 * @author hanisko
 */
namespace Update\Offering\Field;
 
class Canceled extends FieldAbstract
{
	protected $update_policy = FieldAbstract::UPDATE_ONLY_HISTORICAL;
	protected $diff_policy = FieldAbstract::DIFF_AFFECTS_STATUS;
	protected $fieldname = 'canceled';

	/**
	 * Returns true when there is a difference between the value of the UWTS record,
	 * but only when this field's diff policy states that the field's value impacts
	 * the overall uwtsstatus of the offering.
	 * @return boolean
	 */
	public function isDifferent(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		if ($this->diff_policy == FieldAbstract::DIFF_AFFECTS_STATUS) {
			// the existence of the UWTS record implies it is not canceled, so local plan
			// status of canceled isDifferent
			if ($plan->status == 'canceled') {
				return true;
			}
		}
		return false;
	}

	/**
	 * Updates this field in the Plan record with the value in the UWTS record.
	 */
	public function update(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		// if a linked UWTS record exists, then the plan implicitly is not canceled
		if ($plan->status == 'canceled') {
			$status = new \Offering\Components\Status($plan);
			$status->unCancelByUwts();
		}
	}
	
}