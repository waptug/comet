<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Contains the logic for updating a specific field of a Plan record (Db_Offering) 
 * from a cached UW time schedule record (Db_UwtsOffering)
 * @author hanisko
 */
namespace Update\Offering\Field;
 
abstract class FieldAbstract
{
	const UPDATE_ONLY_HISTORICAL = 0;
	const UPDATE_ALWAYS = 1;
	
	const DIFF_DOES_NOT_AFFECT_STATUS = 0;
	const DIFF_AFFECTS_STATUS = 1;
	
	/**
	 * $update_policy defines whether this is a readonly field that can be safely
	 * updated from UWTS at any time (ALWAYS) or if this is an active planning field that
	 * should only be updated when the record is HISTORICAL
	 * @var integer
	 */
	protected $update_policy = FieldAbstract::UPDATE_ONLY_HISTORICAL;
	
	/**
	 * $diff_policy defines whether a difference in values in this field between 
	 * Plan and UWTS indicates that the offering record as a whole should be flagged
	 * as modified in UW time schedule
	 * @var integer $diff_policy
	 */
	protected $diff_policy = FieldAbstract::DIFF_AFFECTS_STATUS;
	protected $fieldname;
	
	/**
	 * Returns true when there is a difference between the value of the UWTS record,
	 * but only when this field's diff policy states that the field's value impacts 
	 * the overall uwtsstatus of the offering.
     * @param \Db_UwtsOffering $uwts
     * @param \Db_Offering $plan
	 * @return boolean
	 */
	public function isDifferent(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		if ($this->diff_policy == FieldAbstract::DIFF_AFFECTS_STATUS) {
			$fieldname = $this->fieldname;
			if ($plan->$fieldname != $uwts->$fieldname) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Updates this field in the Plan record with the value in the UWTS record. If
	 * this field is not read only (therefore should only be updated when the record 
	 * is histrorical) this method will return without doing anything.
     * @param \Db_UwtsOffering $uwts
     * @param \Db_Offering $plan
     */
	public function updateReadOnly(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		if ($this->update_policy == FieldAbstract::UPDATE_ALWAYS) {
			$this->update($uwts, $plan);
		}
	}

	/**
	 * Updates this field in the Plan record with the value in the UWTS record.
     * @param \Db_UwtsOffering $uwts
     * @param \Db_Offering $plan
	 */
	public function update(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		$fieldname = $this->fieldname;
		$plan->$fieldname = $uwts->$fieldname;
	}
	
}