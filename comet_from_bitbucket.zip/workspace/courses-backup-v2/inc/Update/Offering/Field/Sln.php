<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Contains the logic for updating the SLN field of a Plan record (Db_Offering) 
 * from a cached UW time schedule record (Db_UwtsOffering)
 * @author hanisko
 */
namespace Update\Offering\Field;
 
class Sln extends FieldAbstract
{
	protected $update_policy = FieldAbstract::UPDATE_ALWAYS;
	protected $diff_policy = FieldAbstract::DIFF_DOES_NOT_AFFECT_STATUS;
	protected $fieldname = 'sln';
		
}