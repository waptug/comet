<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Contains the logic for updating the Gradingsystem field of a Plan record (Db_Offering) 
 * from a cached UW time schedule record (Db_UwtsOffering)
 * @author hanisko
 */
namespace Update\Offering\Field;
 
class GradingSystem extends FieldAbstract
{
	protected $update_policy = FieldAbstract::UPDATE_ONLY_HISTORICAL;
	protected $diff_policy = FieldAbstract::DIFF_AFFECTS_STATUS;
	protected $fieldname = 'gradingsystem';
		
}