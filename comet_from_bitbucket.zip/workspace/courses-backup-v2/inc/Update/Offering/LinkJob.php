<?php
/**
 * @package UW_COE_Courses
 */
/**
 * This class calculates the matching of plan records (Db_Offering records) to 
 * UW Time Schedule (UWTS) (Db_UwtsOffering) records.
 * @author hanisko
 */
namespace Update\Offering;
 
class LinkJob extends \Update\Process\JobAbstract
{
	/**
	 * @var \Update\Offering\LinkUwts $linker
	 */
	private $linker;
	
	/**
	 * @var \Update\Offering\FromUwts $updater
	 */
	private $updater;
	
	public function run()
	{
		$this->process->log('===== LINK PLAN TO UWTS JOB == '.__METHOD__);
		$quarters = $this->process->parameters['quarters'];
		if (!$quarters instanceof \QuarterIterator) {
			throw new \Exception('Quarter list required');
		}
		foreach ($quarters as $quarter) {
			$this->runQuarter($quarter->year, $quarter->quarter);
		}
	}
	
	/**
	 * Process unlinked plan records and unlinked UWTS records for a specific
	 * academic quarter. Attempt to find matching record and store the link.
	 * @param string $year
	 * @param integer $quarter
	 */
	public function runQuarter($year, $quarter)
	{
		$this->process->log('----- Linking UWTS and Plan for '.$year.'-'.$quarter);
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT o.offeringid '
		     . 'FROM offering o '
		     . 'LEFT OUTER JOIN uwtsoffering u '
		     . 'ON o.offeringid = u.offeringid '
		     . 'WHERE u.offeringid IS NULL '
		     . 'AND o.year = '.$db->quote($year).' '
		     . 'AND o.quarter = '.$quarter;
		$unmatched_offeringids = $db->fetchColumn($sql);
		foreach ($unmatched_offeringids as $offeringid) {
			$plan = new \Db_Offering($offeringid);
			$this->matchPlan($plan);
		}
		$sql = 'SELECT uwtsofferingid '
		     . 'FROM uwtsoffering '
		     . 'WHERE offeringid IS NULL '
		     . 'AND year = '.$db->quote($year).' '
		     . 'AND quarter = '.$quarter;
		$unmatched_offeringids = $db->fetchColumn($sql);
		foreach ($unmatched_offeringids as $uwtsofferingid) {
			$uwts = new \Db_UwtsOffering($uwtsofferingid);
			$this->matchUwts($uwts);
		}
	}
	
	/**
	 * Attempt to match a local plan record (Db_Offering) to the UWTS data via
	 * SLN or verified section id. Creates link by storing offeringid on the 
	 * UwtsOffering record and logs the process.
	 * @param \Db_Offering $plan
	 * @throws \Exception
	 */
	public function matchPlan(\Db_Offering $plan)
	{
		// Match on SLNs
		if ($plan->sln) {
			$uwts = \Db_UwtsOffering::FetchBySLN($plan->year, $plan->quarter, $plan->sln);
			if ($uwts) {
				if ($plan->section != $uwts->section) {
					$this->log(\Db_UwtsMatchingLog::ERROR_SLN_MATCH_SECTION_MISMATCH, $uwts, $plan);
					throw new \Exception('Plan ('.$plan->offeringid.') and UWTS ('.$uwts->uwtsofferingid.') with same SLN have different sections');
				}
				if ($uwts->offeringid && $uwts->offeringid != $plan->offeringid) {
                    $this->log(\Db_UwtsMatchingLog::ERROR_SLN_MATCH_LINKED_TO_OTHER, $uwts, $plan);
                    $orphanedoffering = new \Db_Offering($uwts->offeringid);
                    $orphanedoffering->uwtsstatus = 4; //Potential Duplicate Section
                    $orphanedoffering->save();
				}
				$uwts->offeringid = $plan->offeringid;
				$uwts->save();
				$this->log(\Db_UwtsMatchingLog::LINKED_ON_SLN, $uwts, $plan);
				return;
			}
		}
		// Match on Verified section id
		if ($plan->sectionstatus == 'V') {
			$uwts = \Db_UwtsOffering::FetchBySection($plan->year, $plan->quarter, $plan->curriculum, $plan->courseno, $plan->section);
			if ($uwts->recordExists()) {
				if ($uwts->offeringid && $uwts->offeringid != $plan->offeringid) {
                    $this->log(\Db_UwtsMatchingLog::ERROR_VERIFIED_SECTION_LINKED_TO_OTHER, $uwts, $plan);
                    $orphanedoffering = new \Db_Offering($uwts->offeringid);
                    $orphanedoffering->uwtsstatus = 4; //Potential Duplicate Section
                    $orphanedoffering->save();
				}
				$uwts->offeringid = $plan->offeringid;
				$uwts->save();
				$this->log(\Db_UwtsMatchingLog::LINKED_ON_VERIFIED_SECTION, $uwts, $plan);
				return;
			}
		}
		if ($plan->status == 'canceled') {
			$this->log(\Db_UwtsMatchingLog::NO_LINK_PLAN_CANCELED, null, $plan);
		} else {
			$this->log(\Db_UwtsMatchingLog::NO_LINK_ON_SLN_OR_VERIFIED_SECTION, null, $plan);
		}
		$plan->uwtsstatus = 0; // Not entered
		$plan->save();
	}

	/**
	 * Attempt to match a UWTS record (Db_UwtsOffering) to a local plan record 
	 * (Db_Offering) by matching section letter and scoring similarity of the 
	 * records. Creates link by storing offeringid on the UwtsOffering record 
	 * and logs the process. If needed creates a new record. 
	 * @param \Db_UwtsOffering $uwts
	 * @throws \Exception
	 */
	public function matchUwts(\Db_UwtsOffering $uwts)
	{
		// check for a match on a section
		$plan = \Db_Offering::FetchMatchBySection($uwts->year, $uwts->quarter, $uwts->curriculum, $uwts->courseno, $uwts->section);
		if (!$plan->recordExists()) {
			// how many potential matches are there
			$possible = $uwts->fetchMatchingOfferingids();
			if (count($possible) == 0) {
				// safe to add, we know there is no section collision and there are no candidate records
				// this might be matched to
				$plan = \Db_Offering::Create($uwts->year, $uwts->quarter, $uwts->courseid, $uwts->section);
				$this->createLink($uwts, $plan);
				if (is_null($this->updater)) $this->updater = new \Update\Offering\FromUwts();
				$this->updater->updateAll($uwts, $plan);
				\Db_ActivityLog_Uwtsnewoffering::Write($plan->offeringid);
				$this->log(\Db_UwtsMatchingLog::LINKED_NEW_OFFERING, $uwts, $plan);
				return;
			} else {
				$this->log(\Db_UwtsMatchingLog::NO_LINK_MULTIPLE_POSSIBLE, $uwts, null);
				return;
			}
		}
		// found match on section, score similarity of records
		$compare = new MatchScore($plan, $uwts);
		$score = $compare->getScore();
		if ($score >= 70) {
			$uwts->offeringid = $plan->offeringid;
			$uwts->save();
			$plan->uwtsstatus = 1; // Up to date in UWTS
			$plan->save();
			$this->log(\Db_UwtsMatchingLog::LINKED_ON_SECTION_AND_SCORE, $uwts, $plan, $score);
		} else {
			$this->log(\Db_UwtsMatchingLog::NO_LINK_MATCH_SCORE_LOW, $uwts, $plan, $score);
			$plan->uwtsstatus = 0; // Not entered
			$plan->save();
		}
	}

	/**
	 * Store progress in linking log. Optionally write progess to standard output
	 * @param integer $message_code see constants from DB_UwtsMatchingLog
	 * @param Db_UwtsOffering $uwts
	 * @param Db_Offering $plan
	 * @param integer $score
	 */
	private function log($message_code, $uwts = null, $plan = null, $score = null)
	{
		$dblog = \Db_UwtsMatchingLog::Write($message_code, $uwts, $plan, $score);
		if ($uwts instanceof \Db_UwtsOffering) {
			$this->process->log($dblog->getSummary($uwts));
		} else {
			$this->process->log($dblog->getSummary($plan));
		} 
	}
	
	/**
	 * Links a cached UWTS record (Db_UwtsOffering) to a local plan record (Db_Offering) 
	 * @param Db_UwtsOffering $uwts
	 * @param Db_Offering $plan
	 * @return boolean
	 */
	public function createLink(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		if (is_null($this->linker)) {
			$this->linker = new LinkUwts();
		}
		return $this->linker->createLink($uwts, $plan);
	}
	
}
