<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Contains the logic for automated updating of a Plan record (Db_Offering) 
 * from a cached UW time schedule record (Db_UwtsOffering).
 * @author hanisko
 */
namespace Update\Offering;
 
class FromUwts
{
	private $curr_quarter;
	private $config;
	private $fieldupdaters;
	
	public function __construct()
	{
		$this->curr_quarter = \Db_Quarter::FetchCurrentQuarter();
		$this->config = $this->getConfig();
		$this->fieldupdaters = array();
	}

    /**
     * Returns an array list of the field identifiers that differ
     * @param \Db_UwtsOffering $uwts
     * @param \Db_Offering $plan
     * @throws \Exception
     * @return array
     */
    public function getDiffFields(\Db_UwtsOffering $uwts, \Db_Offering $plan)
    {
        if ($uwts->offeringid != $plan->offeringid) {
            throw new \Exception('Cannot update Plan record from UWTS record that is not linked');
        }
        $out = array();
        foreach ($this->config as $field => $class) {
            $updater = $this->getUpdater($field);
            if ($updater->isDifferent($uwts, $plan)) {
                $out[] = $field;
            }
        }
        return $out;
    }

	/**
	 * Compare records and update the plan where appropriate. Chooses the 
	 * appropriate update level based on time frame of record quarters.
     * @param \Db_UwtsOffering $uwts
     * @param \Db_Offering $plan
	 */
	public function update(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		if ($this->curr_quarter->compareYearQuarter($uwts->year, $uwts->quarter) < 0) {
			// this record happened in a quarter before the current one
			$this->updateAll($uwts, $plan);
		} else {
			// current or future quarter
			$this->updateReadOnly($uwts, $plan);
		}
	}
	
	/**
	 * Update the read-only fields in the Plan record with the data in the
	 * UWTS record.
	 * @param \Db_UwtsOffering $uwts
	 * @param \Db_Offering $plan
     * @throws \Exception
	 */
	public function updateReadOnly(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		if ($uwts->offeringid != $plan->offeringid) {
			throw new \Exception('Cannot update Plan record from UWTS record that is not linked');
		}
		$differs = false;
		foreach ($this->config as $field => $class) {
			$updater = $this->getUpdater($field);
			$updater->updateReadOnly($uwts, $plan);
			$differs = ($differs || $updater->isDifferent($uwts, $plan));
		}
		if ($differs) {
			$plan->uwtsstatus = 1; // 1 - in UWTS but different field values
		} else {
			$plan->uwtsstatus = 2; // 2 - in UWTS and fields match
		}
		//debug('Updated READ-ONLY fields for '.$plan->year.'-'.$plan->quarter.' '.$plan->curriculum.', uwtsstatus = '.$plan->uwtsstatus);
		$plan->save();
	}

	/**
	 * Update all fields in the Plan record with the data in the UWTS record.
     * @param \Db_UwtsOffering $uwts
     * @param \Db_Offering $plan
     * @throws \Exception
	 */
	public function updateAll(\Db_UwtsOffering $uwts, \Db_Offering $plan)
	{
		if ($uwts->offeringid != $plan->offeringid) {
			throw new \Exception('Cannot update Plan record from UWTS record that is not linked');
		}
		foreach ($this->config as $field => $class) {
			$updater = $this->getUpdater($field);
			$updater->update($uwts, $plan);
		}
		$plan->meetingsummary = $plan->getMeetingSummary(true);
		$plan->uwtsstatus = 2; // 2 - in UWTS and fields match
		//debug('Updated ALL fields for '.$plan->year.'-'.$plan->quarter.' '.$plan->curriculum.', uwtsstatus = 2');
		$plan->save();
	}
	
	/**
	 * Returns a field updater object for the specified field
	 * @param string $field
	 * @return \Update\Offering\Field\FieldAbstract
	 */
	protected function getUpdater($field)
	{
		if (!array_key_exists($field, $this->fieldupdaters)) {
			$class = $this->config[$field];
			$this->fieldupdaters[$field] = new $class();
		}
		return $this->fieldupdaters[$field];
	}
	
	/**
	 * Returns an array mapping of offering fields to their appropriate
	 * field updater class
	 * @return array
	 */
	protected function getConfig()
	{
		return array(
			'sln'                => '\Update\Offering\Field\Sln',
			'summerterm'         => '\Update\Offering\Field\SummerTerm',
			'sectiontype'        => '\Update\Offering\Field\SectionType',
			'institution'        => '\Update\Offering\Field\Institution',
			'credits'            => '\Update\Offering\Field\Credits',
			'enrollmentcurrent'  => '\Update\Offering\Field\EnrollmentCurrent',
			'enrollmentestimate' => '\Update\Offering\Field\EnrollmentEstimate',
			'enrollmentlimit'    => '\Update\Offering\Field\EnrollmentLimit',
			'gradingsystem'      => '\Update\Offering\Field\GradingSystem',
			'meetings'           => '\Update\Offering\Field\Meetings',
			'staff'              => '\Update\Offering\Field\Staff',
			'canceled'           => '\Update\Offering\Field\Canceled',
			'joint'              => '\Update\Offering\Field\Joint',
			'studentcredithours' => '\Update\Offering\Field\StudentCreditHours'
		);
	}
	
}