<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Contains the logic for updating an offering record to keep it sync'd with
 * its joint sections.
 * @author hanisko
 */
namespace Update\Offering;

class FromJoint
{
	
	/**
	 * Update all fields in a joint offering with values from a linked source
	 * offering.
	 * @param Db_Offering $source
	 * @param Db_Offering $target
	 */
	public function updateAll(\Db_Offering $source, \Db_Offering $target)
	{
		$target->summerterm = $source->summerterm;
		$target->funding = ($target->funding) ? $target->funding : $source->funding;
		$target->gradingsystem = ($source->gradingsystem) ? $source->gradingsystem : 'standard';
		$target->sectiontype = ($source->sectiontype) ? $source->sectiontype : 'LC';
		$target->creditcontrol = $source->creditcontrol;
		$target->creditmin = $source->creditmin;
		$target->creditmax = $source->creditmax;
		// meetings
		foreach ($source->meetings as $s_meeting) {
			$t_meeting = $target->getMeetingByNumber($s_meeting->meetingnumber);
			if (!$t_meeting) {
				$t_meeting = new \Db_Meeting(0);
				$t_meeting->offeringid = $target->offeringid;
				$t_meeting->meetingnumber = $s_meeting->meetingnumber;
			}
			$t_meeting->setDays($s_meeting->dows);
			$t_meeting->start = $s_meeting->start;
			$t_meeting->end = $s_meeting->end;
			$t_meeting->building = $s_meeting->building;
			$t_meeting->room = $s_meeting->room;
			$t_meeting->save();
		}
		foreach ($target->meetings as $t_meeting) {
			$s_meeting = $source->getMeetingByNumber($t_meeting->meetingnumber);
			if (!$s_meeting) { // meeting exists in target but not in source
				$t_meeting->delete();
			}
		}
		$target->meetingsummary = $target->getMeetingSummary(true);
		$target->save();
		// staff
		foreach ($source->staff as $s_staff) {
			$t_staff = $target->meetings->locateStaff($s_staff->meetingnumber, $s_staff->personid);
			if (!$t_staff) {
				$t_staff = new \Db_Staff(0);
				$t_staff->offeringid = $target->offeringid;
				$t_staff->meetingnumber = $s_staff->meetingnumber;
				$t_staff->personid = $s_staff->personid;
				$t_staff->role = $s_staff->role;
				$t_staff->timesched = $s_staff->timesched;
				$t_staff->save();
				$target->meetings->addStaff($t_staff);
			}
		}
		foreach ($target->staff as $t_staff) {
			$s_staff = $source->meetings->locateStaff($t_staff->meetingnumber, $t_staff->personid);
			if (!$s_staff) { // staff exists in target but not in source
				$t_staff->delete();
				$target->meetings->removeStaff($t_staff);
			}
		}
	}
	
}