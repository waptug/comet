<?php
/**
 * @packagae UW_COE_Courses
 */
/**
 * This mapper connects fields from the Student Web Service course section resource
 * to local system Db_JointExternal object.
 * @author hanisko
 */
namespace Update\JointExternal;

class FromSws extends \Update\FromSwsAbstract
{
	private $joint;
	private $quarter;
	private $year;
	
	public function __construct(\Db_JointExternal $joint)
	{
		$this->joint = $joint;
	}

	protected function getRestClientSws()
	{
		return new \RestClient_CourseSection(
			$this->joint->year, 
			$this->joint->quarter, 
			$this->joint->curriculum, 
			$this->joint->courseno,
			$this->joint->section
		);
	}
	
	public function updateAll()
	{
		if ($this->loadSws()) {

			$this->joint->enrollmentcurrent = $this->sws->CurrentEnrollment;
			if ($this->sws->LimitEstimateEnrollmentIndicator == 'limit') {
				$this->joint->enrollmentestimate = null;
				$this->joint->enrollmentlimit = $this->sws->LimitEstimateEnrollment;
			} else {
				$this->joint->enrollmentestimate = $this->sws->LimitEstimateEnrollment;
				$this->joint->enrollmentlimit = null;
			}
			$this->joint->uwts_curriculum_abbrev = $this->sws->Curriculum->TimeScheduleLinkAbbreviation;
			
			return true;  // update success
		} else {
			return false; // update failed
		}
	}
	
}