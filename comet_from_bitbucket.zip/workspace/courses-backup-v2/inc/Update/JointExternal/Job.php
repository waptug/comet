<?php
/**
 * @packagae UW_COE_Courses
 */
/**
 * This job locates Db_JointExternal records and updates them from the SWS
 * course section resource
 * @author hanisko
 */
namespace Update\JointExternal;

class Job extends \Update\Process\JobAbstract
{
	
	public function run()
	{
		$this->process->log('===== UPDATE EXTERNAL JOINT SECTIONS JOB == '.__METHOD__);
		$quarters = $this->process->parameters['quarters'];
		if (!$quarters instanceof \QuarterIterator) {
			throw new \Exception('Quarter list required');
		}
		foreach ($quarters as $quarter) {
			$this->runQuarter($quarter->year, $quarter->quarter);
		}
	}
	
	/**
	 * Update Db_JointExternal records for a given year/quarter. Queries local database
	 * for external joint sections. For each found section updates enrollment fields.
	 * @param string $year
	 * @param integer $quarter
	 */
	public function runQuarter($year, $quarter)
	{
		$this->process->log('----- Update external joint sections for '.$year.'-'.$quarter);
		
		$db = \DbFactory::GetConnection();
		$sql = 'SELECT * '
		     . 'FROM jointexternal '
		     . 'WHERE year = '.$db->quote($year).' '
		     . 'AND quarter = '.$quarter;
		$results = $db->fetchAssoc($sql);
		foreach ($results as $row) {
			$joint = new \Db_JointExternal($row['jointexternalid'], false);
			$joint->init($row);
			$sws = new FromSws($joint);
			$sws->updateAll();
			$joint->save();
		}
	}
	
}
