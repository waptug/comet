<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Contains the logic for merging one or more tag records into a target
 * tag record
 * @author hanisko
 */
namespace Update\Tag;

class Merge
{
	private $target;
	private $mergeTags;
	
	public function __construct($targetTagId, $mergeIds)
	{
		$this->target = new \Db_Tag($targetTagId);
		$this->mergeTags = array();
		foreach ($mergeIds as $tagid) {
			$tagid = (int) $tagid;
			if ($tagid && $tagid != $this->target->tagid) {
				$tag = new \Db_Tag($tagid);
				if ($tag->recordExists()) {
					$this->mergeTags[] = $tag;
				}
			}
		}
	}
	
	public function getTarget()
	{
		return $this->target;
	}
	
	public function getMergeTags()
	{
		return $this->mergeTags;
	}
	
	public function doMerge()
	{
		if (!$this->target->recordExists()) {
			return;
		}
		$db = \DbFactory::GetConnection();
		foreach ($this->mergeTags as $merge) {
			$target_has = $db->fetchColumn('SELECT courseid FROM tagcourse WHERE tagid = '.$this->target->tagid);
			$merge_has = $db->fetchColumn('SELECT courseid FROM tagcourse WHERE tagid = '.$merge->tagid);
			foreach ($merge_has as $courseid) {
				if (!in_array($courseid, $target_has)) {
					$sql = 'UPDATE tagcourse '
					     . 'SET tagid = '.$this->target->tagid.' '
					     . 'WHERE tagid = '.$merge->tagid.' '
					     . 'AND courseid = '.$courseid;
					$db->query($sql);
				}
			}
			$merge->delete();
		}
	}
	
}