<?php
/**
 * @packagae UW_COE_Courses
 */
/**
 * This mapper connects fields from the Student Web Service term resource
 * to local system Db_Quarter objects.
 */
namespace Update\Term;

class FromSws extends \Update\FromSwsAbstract
{
	private $_year;
	private $_quarter;

	private static $_map_quarter_to_int = array(
		'winter' => 1,
		'spring' => 2,
		'summer' => 3,
		'autumn' => 4
	);

	public function __construct($year, $quarter)
	{
		$this->_year = $year;
		$this->_quarter = $quarter;
	}

	protected function getRestClientSws()
	{
		return new \RestClient_Term($this->_year, $this->_quarter);
	}

	public function update(\Db_Quarter $quarter)
	{
		if ($this->loadSws()) {
				
			$date_parser = new \Parser_Date();
			$quarter->description = \Db_Quarter::BuildDefaultDescription($quarter->year, $quarter->quarter);
			$quarter->start = $date_parser->getValue($this->sws->FirstDay);
			$quarter->end = $date_parser->getValue($this->sws->LastFinalExamDay);
			$quarter->swslastupdate = time();

			return true;  // update success
				
		} else {
			return false; // update failed
		}
	}

	/**
	 * Creates a new course record and updates the record from the SWS course resource
	 * @param integer $year
	 * @param integer $quarter
	 * @return Db_Course
	 */
	public static function CreateQuarter($year, $qtr)
	{
		$quarter = new \Db_Quarter(9999, 4); //pass arbitrary quarter
		$quarter->year = $year;
		$quarter->quarter = $qtr;
		$sws = new self($quarter->year, $quarter->quarter);
		$sws->update($quarter);
		$quarter->save();
		return $quarter;
	}

}