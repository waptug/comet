<?php
/**
 * @packagae UW_COE_Courses
 */
/**
 * This mapper connects fields from the Student Web Service person resource
 * to local system Db_Quarter objects.
 */
namespace Update\Term;

class Job extends \Update\Process\JobAbstract
{
	const CACHE_FRESH_SECONDS = 86400; // 24 hours ago (60*60*24);
	
	private $cutoff;
	
	public function run()
	{
		$this->process->log('===== UPDATE QUARTER RECORDS JOB == '.__METHOD__);
		
		//to get future quarters, a new QuarterIterator needs to be made rather than using the one on the process
		$quarters = new \QuarterIterator(0, 4*4); //always do 4 years into the future
		
		foreach ($quarters as $quarter) {
			$this->runQuarter($quarter->year, $quarter->quarter);
		}
	}
	
	/**
	 * Update quarter table for a given quarter. Queries the SWS for quarter details
	 * For each course found creates the record if needed and updates the fields. 
	 * @param string $year
	 * @param integer $quarter
	 */
	public function runQuarter($year, $qtr)
	{
		$this->process->log('----- Begin updating quarter '.$year.'-'.$qtr);
	
		if (is_null($this->cutoff)) {
			$this->cutoff = time() - self::CACHE_FRESH_SECONDS;
		}
		$quarter = new \Db_Quarter((int)$year, (int)$qtr);

		if($quarter->recordExists()) {
			if ($quarter->swslastupdate < $this->cutoff) {
				$sws = new FromSws($year, $qtr);
				$sws->update($quarter);
				$quarter->save();
				$this->process->log('* Updated '.$year.'-'.$qtr);
			} else {
				$this->process->log('- Cache fresh for '.$year.'-'.$qtr);
			}
		
		} else {
			// no existing year/quarter combination
			$quarter = FromSws::CreateQuarter($year, $qtr);
			$this->process->log('+ Created new quarter record '.$year.'-'.$qtr);
		}
	}
	
}
