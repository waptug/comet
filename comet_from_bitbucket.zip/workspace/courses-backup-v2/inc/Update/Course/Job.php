<?php
/**
 * @packagae UW_COE_Courses
 */
/**
 * This mapper connects fields from the Student Web Service person resource
 * to local system Db_Person objects.
 * @author hanisko
 */
namespace Update\Course;

class Job extends \Update\Process\JobAbstract
{
	const CACHE_FRESH_SECONDS = 86400; // 24 hours ago (60*60*24);
	
	private $cutoff;
	private $search;
	
	public function run()
	{
		$this->process->log('===== UPDATE COURSE RECORDS JOB == '.__METHOD__);
		if (array_key_exists('curriculum', $this->process->parameters)) {
			$curricula = (array) $this->process->parameters['curriculum'];
		} else {
			$curricula = \Db_Curriculum::$curricula;
		}
		$quarters = $this->process->parameters['quarters'];
		if (!$quarters instanceof \QuarterIterator) {
			throw new \Exception('Quarter list required');
		}
		foreach ($quarters as $quarter) {
			foreach ($curricula as $curriculum) {
				$this->runQuarterCurriculum($quarter->year, $quarter->quarter, $curriculum);
			}
		}
	}
	
	/**
	 * Update course table for a given curriculum. Queries the SWS for a list of
	 * courses in the UWTS. For each course found creates the record if needed and
	 * updates the fields. A year/quarter context is required since course numbers
	 * can be used for multiple courses over time.
	 * @param string $year
	 * @param integer $quarter
	 * @param string $curriculum
	 */
	public function runQuarterCurriculum($year, $quarter, $curriculum)
	{
		$this->process->log('----- Begin updating course records for '.$year.'-'.$quarter.' '.$curriculum);
		if (is_null($this->search)) $this->search = new \RestClient_CourseSearch('2012', 2, 'EDUC');
		$this->search->year = $year;
		$this->search->quarter = $quarter;
		$this->search->curriculum = $curriculum;
	
		$results = $this->search->getResults();
	
		if (is_null($this->cutoff)) {
			$this->cutoff = time() - self::CACHE_FRESH_SECONDS;
		}
	
		foreach ($results as $r) {
			$courseids = \Db_Course::FetchCourseids($r->CurriculumAbbreviation, $r->CourseNumber);
			if ($courseids) {
				// found existing courses with this curriculum/courseno
				foreach ($courseids as $courseid) { // update each course record i.e. wildcard titles
					$course = new \Db_Course($courseid);
					// only update this record if its valid range includes focus quarter
					if ($course->isValidForQuarter($year, $quarter)) {
						if ($course->swslastupdate < $this->cutoff) {
							$sws = new FromSws($r->CurriculumAbbreviation, $r->CourseNumber, $r->Year, $r->Quarter);
							$sws->update($course);
							$course->save();
							$this->process->log('* Updated '.$course->curriculum.' '.$course->courseno);
						} else {
							$this->process->log('- Cache fresh for '.$course->curriculum.' '.$course->courseno);
						}
					} else {
						$this->process->log('! '.$course->curriculum.' '.$course->courseno.' only valid '.$course->firstquarter.' through '.$course->lastquarter);
					}
				}
			} else {
				// no existing courses with this curriculum/courseno
				$course = FromSws::CreateCourse($r->CurriculumAbbreviation, $r->CourseNumber, $year, $quarter);
				$this->process->log('+ Created new course record for '.$course->curriculum.' '.$course->courseno);
			}
		}
	}
	
}
