<?php
/**
 * @packagae UW_COE_Courses
 */
/**
 * This mapper connects fields from the Student Web Service course resource
 * to local system Db_Offering objects.
 * @author hanisko
 */
namespace Update\Course;

class FromSws extends \Update\FromSwsAbstract
{
	private $_curriculum;
	private $_courseno;
	private $_year;
	private $_quarter;

	private static $_map_quarter_to_int = array(
		'winter' => 1,
		'spring' => 2,
		'summer' => 3,
		'autumn' => 4
	);

	public function __construct($curriculum, $courseno, $year = null, $quarter = null)
	{
		if (is_null($year) || is_null($quarter)) {
			$current_quarter = \Db_Quarter::FetchCurrentQuarter();
			$year = $current_quarter->year;
			$quarter = $current_quarter->quarter;
		}
		$this->_curriculum = $curriculum;
		$this->_courseno = $courseno;
		$this->_year = $year;
		$this->_quarter = $quarter;
	}

	protected function getRestClientSws()
	{
		return new \RestClient_Course($this->_year, $this->_quarter, $this->_curriculum, $this->_courseno);
	}

	public function update(\Db_Course $course)
	{
		if ($this->loadSws()) {
				
			$title_parser = new \Parser_Title();
			$course->title = $title_parser->getValue($this->sws->CourseTitleLong);
			$course->shorttitle = $this->sws->CourseTitle;
			$course->description = $this->sws->CourseDescription;
			switch ($this->sws->CreditControl) {
				case 'zero credits':
					$course->coursecreditcontrol = 'fixed';
					$course->coursecreditmin = 0;
					$course->coursecreditmax = null;
					break;
				case 'fixed credit':
					$course->coursecreditcontrol = 'fixed';
					$course->coursecreditmin = $this->sws->MinimumTermCredit;
					$course->coursecreditmax = null;
					break;
				case 'variable credit - min to max credits':
					$course->coursecreditcontrol = 'variable';
					$course->coursecreditmin = $this->sws->MinimumTermCredit;
					$course->coursecreditmax = $this->sws->MaximumTermCredit;
					break;
				case 'variable credit - min or max credits':
					$course->coursecreditcontrol = 'minormax';
					$course->coursecreditmin = $this->sws->MinimumTermCredit;
					$course->coursecreditmax = $this->sws->MaximumTermCredit;
					break;
				case 'variable credit 1 to 25 credits':
				case 'variable credit - 1 to 25 credits':
					$course->coursecreditcontrol = 'open';
					$course->coursecreditmin = 1;
					$course->coursecreditmax = 25;
					break;
				default:
					debug(__METHOD__.' undefined CreditControl value "'.$this->sws->CreditControl.'"');
					$course->coursecreditcontrol = null;
					$course->coursecreditmin = null;
					$course->coursecreditmax = null;
					break;
			}
			$course->creditrepeatmax = $this->sws->MaximumCredit;
			$general_educations = array();
			foreach(\Db_Course::$general_education_flags as $abbr => $name) {
				$xml_name = str_replace(array(" ",","), "", $name);
				if($this->sws->GeneralEducationRequirements->{$xml_name} == true)
					$general_educations[] = $abbr;
			}
			if(count($general_educations))
				$course->general_education = implode(",",$general_educations);
			/*$course->writing = $this->sws->GeneralEducationRequirements->Writing;
			$course->qsr = $this->sws->GeneralEducationRequirements->QuantitativeAndSymbolicReasoning;
			$course->indivsociety = $this->sws->GeneralEducationRequirements->IndividualsAndSocieties;*/
			$course->firstquarter = $this->getQuarterCode($this->sws->FirstEffectiveTerm);
			$course->lastquarter = $this->getQuarterCode($this->sws->LastEffectiveTerm);
			$course->swslastupdate = time();

			return true;  // update success
				
		} else {
			return false; // update failed
		}
	}

	protected function getQuarterCode($quarter)
	{
		if (array_key_exists($quarter->Quarter, self::$_map_quarter_to_int)) {
			$q = self::$_map_quarter_to_int[$quarter->Quarter];
		} else {
			$q = 0;
		}
		return $quarter->Year.'-'.$q;
	}

	/**
	 * Creates a new course record and updates the record from the SWS course resource
	 * @param string $curriculum
	 * @param integer $courseno
	 * @param integer $year
	 * @param integer $quarter
	 * @return Db_Course
	 */
	public static function CreateCourse($curriculum, $courseno, $year, $quarter)
	{
		$course = new \Db_Course(0);
		$course->curriculum = $curriculum;
		$course->courseno = $courseno;
		$sws = new self($course->curriculum, $course->courseno, $year, $quarter);
		$sws->update($course);
		$course->save();
		return $course;
	}

}