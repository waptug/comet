<?php
/**
 * @packagae UW_COE_Courses
 */
/**
 * This job locates local Db_Person records that are missing a RegID value and
 * attempts to locate them in SWS person resource, then updates any empty fields.
 * @author hanisko
 */
namespace Update\Person;

class Job extends \Update\Process\JobAbstract
{
	
	public function run()
	{
		$this->process->log('===== UPDATE PEOPLE JOB == '.__METHOD__);
		$db = \DbFactory::GetConnection();
		$todolist = $db->fetchColumn('SELECT personid FROM person WHERE regid IS NULL');
		foreach ($todolist as $personid) {
			$person = new \Db_Person($personid);
			$sws = new FromSws($person);
			$r = $sws->updateEmptyFields();
			if ($r) {
				$person->save();
				$this->process->log('+ Set '.\View_Person::FirstLast($person).' regid to '.$person->regid);
			} else {
				$this->process->log('X '.\View_Person::FirstLast($person).' not found in service ('.$person->ein.','.$person->uwnetid.')');
			}
		}
	}
	
}
