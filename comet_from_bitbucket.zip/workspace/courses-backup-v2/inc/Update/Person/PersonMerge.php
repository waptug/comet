<?php
/**
 * @package edu.uw.education.courses
 */
/** 
 * Merges two redundant Db_Person records into one
 * @author hanisko
 */

namespace Update\Person;

use DbFactory;
use Db_Person;

class PersonMerge
{
    protected $properties = array(
        'lastname',
        'uwnetid',
        'ein',
        'facultysequence',
        'regid',
        'email',
        'phone',
        'area',
        'faculty_rouid',
        'isfaculty',
        'isadjunct',
        'isstudentstaff',
        'issupport',
        'workflow',
    );

    protected $linked_tables = array(
        'staff',
        'personorgunit',
        'uwtsstaff'
    );

    /**
     * Delete $merge record and relate any child records to $keep
     * If $keep has empty values, use the $merge values
     * @param Db_Person $keep
     * @param Db_Person $merge
     * @throws \Exception
     */
    public function merge(Db_Person $keep, Db_Person $merge)
    {
        $db = DbFactory::GetConnection();
        foreach ($this->properties as $property) {
            if (!$keep->$property && $merge->$property) $keep->$property = $merge->$property;
        }
        // use the shortest not empty firstname to eliminate middle names and initials
        if ($merge->firstname && strlen($merge->firstname) < strlen($keep->firstname)) {
            $keep->firstname = $merge->firstname;
        }
        $keep->save();
        foreach ($this->linked_tables as $table) {
            $db->query('UPDATE `'.$table.'` SET personid = '.$keep->personid.' WHERE personid = '.$merge->personid);
        }
        // have to dig into JSON values for repetition records
        $sql = 'SELECT repetitionid, staffjson '
             . 'FROM repetition '
             . 'WHERE staffjson LIKE \'%"personid":'.$merge->personid.',%\' '
             . 'OR staffjson LIKE \'%"personid":'.$merge->personid.'}%\'';
        $repetition = $db->fetchPairs($sql);
        foreach ($repetition as $repetitionid => $staffjson) {
            $old = '"personid":'.$merge->personid;
            $new = '"personid":'.$keep->personid;
            $staffjson = str_replace($old.',', $new.',', $staffjson);
            $staffjson = str_replace($old.'}', $new.'}', $staffjson);
            $db->query('UPDATE repetition SET staffjson = '.$db->quote($staffjson).' WHERE repetitionid = '.$repetitionid);
        }
        $merge->delete();
    }

}
