<?php
/**
 * @packagae UW_COE_Courses
 */
/**
 * This mapper connects fields from the Student Web Service person resource
 * to local system Db_Person objects.
 * @author hanisko
 */
namespace Update\Person;

class FromSws extends \Update\FromSwsAbstract
{
	private $_person;
	
	public function __construct(\Db_Person $person)
	{
		$this->_person = $person;
	}

	protected function getRestClientSws()
	{
		if ($this->_person->regid) {
			return new \RestClient_Person($this->_person->regid);
		}
		$sws_search = new \RestClient_PersonSearch($this->_person);
		$regid = $sws_search->findRegid();
		if ($regid) {
			return new \RestClient_Person($regid);
		}
		return null;
	}
	
	/**
	 * Update all available fields on the Db_Person record with data from the 
	 * student web service person resource. Returns true if an SWS record was
	 * located and update successful.
	 * @return boolean
	 */
	public function updateAll()
	{
		if ($this->loadSws()) {
			
			$this->_person->regid = $this->sws->RegID;
			$this->_person->ein = $this->sws->EmployeeID;
			$this->_person->uwnetid = $this->sws->UWNetID;
			$this->_person->lastname = ucwords(strtolower($this->sws->LastName));
			$this->_person->firstname = ucwords(strtolower($this->sws->FirstName));
			if ($this->_person->uwnetid && !$this->_person->email) {
				$this->_person->email = $this->_person->uwnetid.'@uw.edu';
			}
			return true;  // update sucess
			
		} else {
			return false; // update failed
		}
	}

	/**
	 * Update fields on the Db_Person record with data from the student web service 
	 * person resource. Updates all identifying fields, other fields (e.g. name) are
	 * only updated if the local record is blank. Returns true if an SWS record was
	 * located and update successful.
	 * @return boolean
	 */
	public function updateEmptyFields()
	{
		if ($this->loadSws()) {
			
			$this->_person->regid = $this->sws->RegID;
			$this->_person->ein = $this->sws->EmployeeID;
			$this->_person->uwnetid = $this->sws->UWNetID;
			if (!$this->_person->lastname) {
				$this->_person->lastname = ucwords(strtolower($this->sws->LastName));
			}
			if (!$this->_person->firstname) {
				$this->_person->firstname = ucwords(strtolower($this->sws->FirstName));
			}
			if ($this->_person->uwnetid && !$this->_person->email) {
				$this->_person->email = $this->_person->uwnetid.'@uw.edu';
			}
			return true;  // update sucess
			
		} else {
			return false; // update failed
		}
	}
	
}