<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Provides a mechanism for iterating through Db_Quarter objects. Allows
 * the definition of a start and end quarter and provids each quarter in
 * sequence to the PHP foreach operator.
 * @author hanisko
 */
 
class QuarterIterator implements Iterator 
{
	private $_quarter;
	private $_startYear;
	private $_startQtr;
	private $_endYear;
	private $_endQtr;
	private $_currentYear;
	private $_currentQtr;
	
	public function __construct($quarters_past = 0, $quarters_future = 0)
	{
		$this->setRange($quarters_past, $quarters_future);
	}
	
	/**
	 * Returns an associative array of quarter YYYY-Q codes and descriptions that
	 * can be used as an FormElement->valuelist
	 * @return array
	 */
	public function getSelectOptions()
	{
		$out = array();
		foreach ($this as $q) {
			$out[$q->year.'-'.$q->quarter] = eQuarter($q->year,$q->quarter);
		}
		return $out;
	}
	
	public function setRange($quarters_past, $quarters_future)
	{
		$current_quarter = Db_Quarter::FetchCurrentQuarter();
		if ((string)$quarters_past == 'ALL') {
			$db = DbFactory::GetConnection();
			$row = $db->fetchRow('SELECT DISTINCT year, quarter FROM offering ORDER BY year, quarter');
			$this->_startYear = $row['year'];
			$this->_startQtr = $row['quarter'];
		} else {
			$quarters_past = (int)$quarters_past;
			$this->_startYear = $current_quarter->year - (int)($quarters_past / 4);
			$this->_startQtr = $current_quarter->quarter - ($quarters_past % 4);
			if ($this->_startQtr < 1) {
				$this->_startQtr = $this->_startQtr + 4;
				$this->_startYear = $this->_startYear - 1;
			}
		}
		if ((string)$quarters_future == 'ALL') {
			$db = DbFactory::GetConnection();
			$row = $db->fetchRow('SELECT DISTINCT year, quarter FROM offering ORDER BY year DESC, quarter DESC');
			$this->_endYear = $row['year'];
			$this->_endQtr = $row['quarter'];
		} else {
			$this->_endYear = $current_quarter->year + (int)($quarters_future / 4);
			$this->_endQtr = $current_quarter->quarter + ($quarters_future % 4);
			if ($this->_endQtr > 4) {
				$this->_endQtr = $this->_endQtr - 4;
				$this->_endYear = $this->_endYear + 1;
			}
		}
	}
	
	public function setStartQuarter($year, $quarter)
	{
		$this->rewind();
		$this->_startYear = $this->validYear($year);
		$this->_startQtr = $this->validQuarter($quarter);
	}
	
	public function setEndQuarter($year, $quarter)
	{
		$this->rewind();
		$this->_endYear = $this->validYear($year);
		$this->_endQtr = $this->validQuarter($quarter);
	}
	
	private function validYear($year)
	{
		$year = (int)$year;
		if ($year < 1700 || $year > 2500) {
			throw new Exception('Year '.$year.' is out of range');
		}
		return $year;
	}
	
	private function validQuarter($qtr)
	{
		$qtr = (int)$qtr;
		if ($qtr < 1 || $qtr > 4) {
			throw new Exception('Quarter '.$qtr.' is out of range');
		}
		return $qtr;
	}
	
	private function getQuarterObject($year, $qtr)
	{
		if (is_null($this->_quarter)) {
			$this->_quarter = new Db_Quarter($year, $qtr, false);
			return $this->_quarter;
		} else {
			$this->_quarter->year = $year;
			$this->_quarter->quarter = $qtr;
		}
		return $this->_quarter;
	} 
	
	/**
	 * Iterator::current � Return the current element
	 * @return Db_Quarter
	 */
	public function current()
	{
		return $this->getQuarterObject($this->_currentYear, $this->_currentQtr);
	}
	
	/**
	 * Iterator::key � Return the key of the current element
	 * @return scalar
	 */
	public function key()
	{
		return $this->_currentYear.'-'.$this->_currentQtr;
	}

	/**
	 * Iterator::next � Move forward to next element
	 * @return void
	 */
	public function next()
	{
		++$this->_currentQtr;
		if ($this->_currentQtr > 4) {
			$this->_currentYear = $this->_currentYear + 1;
			$this->_currentQtr = $this->_currentQtr - 4;
		}
	}

	/**
	 * Iterator::rewind � Rewind the Iterator to the first element
	 * @return void
	 */
	public function rewind()
	{
		$this->_currentYear = $this->_startYear;
		$this->_currentQtr = $this->_startQtr;
	}

	/**
	 * Iterator::valid � Checks if current position is valid
	 * @return boolean
	 */
	public function valid()
	{
		if ($this->_currentYear > $this->_endYear || ($this->_currentYear == $this->_endYear && $this->_currentQtr > $this->_endQtr)) {
			return false;
		}
		return true;
	}
	
}