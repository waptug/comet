<?php
/**
 * Store application messages short term for retrieval during
 * next page view.
 * @author Paul Hanisko
 * @package UW_COE_Techsupport
 */

class AppMessage
{
	// Give this a unique name so it does not collide with other
	// apps on the server
	private static $_fieldname = 'tk_app_redirect_message';
	
	/**
	 * Check the session for an application message and return it. Unset
	 * that session variable so the message does not repeat.
	 *
	 * @return string
	 */
	public static function Fetch()
	{
		$message = '';
		if (isset($_SESSION[self::$_fieldname])) {
			$message = $_SESSION[self::$_fieldname];
			unset($_SESSION[self::$_fieldname]);
		}
		return $message;
	}
	
	/**
	 * Store an application message in the session to be read and
	 * presented in another script.
	 *
	 * @param string $message
	 */
	public static function Store($message)
	{
		$_SESSION[self::$_fieldname] = $message;
	}

}