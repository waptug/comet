<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Adds functionality to upload and download attachment files for 
 * Db_Syllabus objects
 * @author hanisko
 */

class Attachment_Syllabus extends Attachment_AttachmentAbstract
{

	protected function initStorageStrategy()
	{
		$s = new Attachment_StorageStrategy_LocalFile($this);
		$attachment_config = Config::GetConfig('attachment');
		$s->setLocalBasePath($attachment_config->syllabus_path);
		return $s;
	}

	protected function initDeliveryStrategy()
	{
		return new Attachment_DeliveryStrategy_Binary($this);
	}

}