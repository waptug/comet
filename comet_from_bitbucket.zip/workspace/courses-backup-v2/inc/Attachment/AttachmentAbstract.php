<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Encapsulates methods for binary files that can be uploaded by
 * clients and later retrieved.
 * @author hanisko
 */

abstract class Attachment_AttachmentAbstract
{
	/**
	 * Provides methods for storing and retrieving files from server side
	 * repository such as the local file system
	 * @var Attachment_StorageStrategy_StorageStrategyAbstract
	 */
	public $storage;
	
	/**
	 * Provides method for delivering a file handle stream to the client
	 * @var Attachment_DeliveryStrategy_DeliveryStrategyAbstract
	 */
	public $delivery;
	
	/**
	 * Provides access to attachment metadata
	 * @var Attachment_MetadataInterface
	 */
	public $metadata;
	
	public function __construct($metadata)
	{
		if (!$metadata instanceof Attachment_MetadataInterface) {
			throw new Exception('Attachment_AttachmentAbstract::__construct() requires instance of Attachment_MetadataInterface');
		}
		$this->metadata = $metadata;
		$this->delivery = $this->initDeliveryStrategy();
		$this->storage = $this->initStorageStrategy();
	}
	
	public function __get($name)
	{
		return $this->metadata->getValue($name);
	}
	
	public function __set($name, $value)
	{
		return $this->metadata->getValue($name, $value);
	}
	
	/**
	 * Transmit the contents of the attachment to the client
	 */
	public function sendContents()
	{
		$this->delivery->sendContents($this->storage->getFileHandle());
	}
	
	/**
	 * Store the uploaded file associated with the form input field with
	 * the name= attibute of $input_name
	 * later retrieval
	 * @param string $input_name
	 */
	public function store($input_name)
	{
		if (!array_key_exists($input_name, $_FILES)) {
			Logger::GetInstance()->error('No file input field named "'.$input_name.'" exists');
			return false;
		}
		if ($_FILES[$input_name]['error'] > 0) {
			Logger::GetInstance()->error('File upload error '.$_FILES[$input_name]['error'].' for field named "'.$input_name.'"');
			return false;
		}
		$handle = fopen($_FILES[$input_name]['tmp_name'], 'r');
		$this->storage->store($handle);
		$this->metadata->save();
		return true;
	}
	
	/**
	 * Return a filename to name the file when it is downloaded by a client
	 * @return string
	 */
	public function getClientFilename()
	{
		$this->metadata->getClientFilename();
	}

	/**
	 * Deletes the stored attachment and its metadata from the server
	 * @return resource $handle
	 */
	public function delete()
	{
		$this->storage->delete();
		$this->metadata->delete();
	}
	
	/**
	 * Provide a Attachment_StorageStrategy_Abstract implementation that 
	 * will support the specific attachment type. Assign an instance of
	 * Attachment_StorageStrategy_Abstract to $this->_storage_strategy
	 * @return Attachment_StorageStrategy_StorageStrategyAbstract
	 */
	abstract protected function initStorageStrategy();

	/**
	 * Provide a Attachment_DeliveryStrategy_Abstract implementation that
	 * will support the specific attachment type. Assign an instance of
	 * Attachment_DeliveryStrategy_Abstract to $this->_delivery_strategy
	 * @return Attachment_DeliveryStrategy_DeliveryStrategyAbstract
	 */
	abstract protected function initDeliveryStrategy();
	
}