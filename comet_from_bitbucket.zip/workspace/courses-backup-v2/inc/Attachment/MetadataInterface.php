<?php
/**
 * @package UW_COE_Framework
 */
/**
 * An interface for objects that can be used as a metadata repository
 * for Attachment objects.
 * @author hanisko
 */

interface Attachment_MetadataInterface
{

	/**
	 * Write the metadata to a persistent store
	 */
	public function save();

	/**
	 * Delete the metadata associated with an attachment
	 */
	public function delete();

	/**
	 * Return the http Mime Type of the file attachment
	 * @return string
	 */
	public function getMimetype();

	/**
	 * Return an arbitrary property value stored in the metadata and 
	 * identified by $name
	 * @return string
	 */
	public function getValue($name);

	/**
	 * Set an arbitrary property value stored in the metadata and
	 * identified by $name to $value
	 * @return string
	 */
	public function setValue($name, $value);

	/**
	 * Return a unique primary key identifier that refers to this 
	 * metadata (and by extension this attachment)
	 * @return string
	 */
	public function getId();
	
	/**
	 * Return a filename to name the file when it is downloaded by a client
	 * @return string
	 */
	public function getClientFilename();
	
	/**
	 * Return a filename to name to use when storing the file in the server
	 * side store. Storage filename must be unique (at least, within the
	 * getStoreagePath()) or stored files may be overwritten.
	 * @return string
	 */
	public function getStorageFilename();
	
	/**
	 * Returns a path (e.g. subdirectory that specifies where a server side
	 * file should be stored. getStoreagePath() +  getStorageFilename() should
	 * return unique values or stored files may be overwritten.
	 * @return string
	 */
	public function getStoragePath();
	
}
