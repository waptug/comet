<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Encapsulates methods for delivering binary files to a client
 * @author hanisko
 */

class Attachment_DeliveryStrategy_Binary extends Attachment_DeliveryStrategy_DeliveryStrategyAbstract
{

	/**
	 * Transmits the file contents from a file $handle resource 
	 * to the client
	 * @param resource $handle
	 */
	public function sendContents($handle)
	{
		header('Pragma: public');
		header('Expires: 0');
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Cache-Control: public');
		header('Content-Description: File Transfer');
		header('Content-Type:'.$this->attachment->metadata->getMimetype());
		header('Content-Disposition: attachment; filename="'.$this->attachment->metadata->getClientFilename().'"');
		header('Content-Transfer-Encoding: binary');
		$filesize = $this->attachment->storage->getFilesize();
		if ($filesize) {
			header('Content-Length: '.$filesize);
		}
		fpassthru($handle);
	}
	
}