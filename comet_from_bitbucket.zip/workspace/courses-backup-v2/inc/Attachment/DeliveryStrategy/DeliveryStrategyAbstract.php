<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Encapsulates methods for delivering binary files to a client
 * @author hanisko
 */

abstract class Attachment_DeliveryStrategy_DeliveryStrategyAbstract
{
	/**
	 * Reference to the attachment parent object
	 * @var Attachment_AttachmentAbstract
	 */
	protected $attachment;
	
	public function __construct(Attachment_AttachmentAbstract $attachment)
	{
		$this->attachment = $attachment;	
	}
	
	/**
	 * Transmits the file contents from a file $handle resource 
	 * to the client
	 * @param resource $handle
	 */
	abstract public function sendContents($handle);
	
}