<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Encapsulates methods for storing and retrieving uploaded binary
 * files
 * @author hanisko
 */

class Attachment_StorageStrategy_LocalFile extends Attachment_StorageStrategy_StorageStrategyAbstract
{
	private $local_file_path = '';
	
	/**
	 * Returns an absolute path to the file on a local disk.
	 * @return string
	 */
	public function getFilename()
	{
		$path = realpath($this->getLocalBasePath().'/'.$this->attachment->metadata->getStoragePath());
		if (!$path) {
			throw new Exception('Invalid directory configured to store files');
		}
		return $path.'/'.$this->attachment->metadata->getStorageFilename();
	}

	/**
	 * Write the contents of the PHP file handle resource $handle
	 * to the store
	 */
	public function store($handle)
	{
		$r = file_put_contents($this->getFilename(), $handle);
		if ($r === false) {
			throw new Exception('Could not store '.$this->getFilename());
		}
	}

	/**
	 * Delete the server side file from storage
	 */
	public function delete()
	{
		unlink($this->getFilename());
	}

	/**
	 * Return a PHP resource pointer file handle that has reference to the
	 * binary contents of the attachment file
	 * @return resource
	 */
	public function getFileHandle()
	{
		return fopen($this->getFilename(), 'r');
	}

	/**
	 * Return a filename to name the file when it is downloaded by a client
	 * @return string
	 */
	public function getFilesize()
	{
		return filesize($this->getFilename());
	}
	
	/**
	 * Returns a local file system directory that these attachments should
	 * be stored in.
	 * @return string
	 */
	public function getLocalBasePath()
	{
		return $this->local_file_path;
	}
	
	/**
	 * Set the local file system directory that these attachments should
	 * be stored in.
	 * @param string $filepath
	 */
	public function setLocalBasePath($filepath)
	{
		$this->local_file_path = $filepath;
	}
	
}