<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Encapsulates methods for storing and retrieving uploaded binary
 * files
 * @author hanisko
 */

class Attachment_StorageStrategy_LocalTest extends Attachment_StorageStrategy_LocalFile
{
	
	/**
	 * Returns a local file system directory that these attachments should
	 * be stored in.
	 * @return string
	 */
	public function getLocalBasePath() 
	{
		return '/backup/uploads/courses/syllabus';
	}
	
}
