<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Encapsulates methods for storing and retrieving uploaded binary
 * files
 * @author hanisko
 */

abstract class Attachment_StorageStrategy_StorageStrategyAbstract
{
	/**
	 * Reference to the attachment parent object
	 * @var Attachment_AttachmentAbstract
	 */
	protected $attachment;
	
	public function __construct(Attachment_AttachmentAbstract $attachment)
	{
		$this->attachment = $attachment;	
	}
	
	abstract public function store($filehandle);

	/**
	 * Delete the server side file from storage
	 */
	abstract public function delete();

	/**
	 * Return a PHP resource pointer file handle that has reference to the
	 * binary contents of the attachment file
	 * @return resource
	 */
	abstract public function getFileHandle();

	/**
	 * Return a filename to name the file when it is downloaded by a client
	 * @return string
	 */
	abstract public function getFilesize();
	
}