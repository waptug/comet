<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Basic autoload strategy that self registers with the PHP spl_autoload engine
 * @author hanisko
 */

class Autoloader
{
	private $basedir;
	
	public function __construct($basedir) 
	{
		$this->basedir = $basedir;
		spl_autoload_register(array($this, 'loader'));
	}
	
	public function loader($classname) 
	{
		$classname = str_replace('\\', DIRECTORY_SEPARATOR, $classname);
		$classname = str_replace('_', DIRECTORY_SEPARATOR, $classname);
		include $this->basedir . DIRECTORY_SEPARATOR . $classname . '.php';
    }

}