<?php
/**
 * Supports conversion of input into standardized formats. Cleans
 * and translates input. Can be used to support import of data
 * from external feeds into a database.
 * @author Paul
 */

abstract class Parser
{
	
	/**
	 * Return the processed value based on the input provided scrubbed
	 * and converted to local format
	 * @params string $input raw data to be parsed and scrubbed for a value in the expected format
	 * @return mixed
	 */
	abstract public function getValue($input);
	
}