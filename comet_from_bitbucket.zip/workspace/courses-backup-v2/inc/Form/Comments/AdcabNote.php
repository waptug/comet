<?php
/**
 * @package UW_COE_Courses
 */

class Form_Comments_AdcabNote extends Form
{
	private $discussion;
	private $offering;
	
	public static $statuses = array(
		'planned'  => 'Planned, will be submitted to UW Time Schedule',
		'hold'     => 'Temporary hold, will not be scheduled until resolved',
		'canceled' => 'Canceled'
	);
	
	public function __construct(Db_AdcabNote $discussion, Db_Offering $offering)
	{
		$this->comment = new FormElement_Textarea('comment', 'Comment', $discussion->comment);
		$this->comment->rows = 6;
		$this->status = new FormElement_Select('status', 'Set status of this course offering', $offering->status);
		$this->status->valuelist = self::$statuses;
		/*
		$this->notetype = new FormElement_Select('notetype', 'Note type', $discussion->notetype);
		$this->notetype->valuelist = Db_AdcabNote::$types;
		$this->notetype->helptext = 'Help categorize your comment for reporting and discussion';
		*/
		$this->discussion = $discussion;
		$this->offering = $offering;
	}
	
	public function process()
	{
		$this->comment->getUserInput();
		
		if ($this->comment->isEmpty()) {
			$this->comment->error = 'Can\'t post an empty comment';
		}
		
		
		$this->status->getUserInput();
		if (!$this->status->valueInList()) {
		$this->status->value = $this->offering->status;
		}
		
		/*
		$this->notetype->getUserInput();
		if (!$this->notetype->valueInList()) {
			$this->notetype->value = 'logistic';
		}
		*/
				
		if ($this->hasErrors()) {
			return false;
		}
		
		$this->discussion->comment = $this->comment->value;
		//$this->discussion->notetype = $this->notetype->value;
		$this->discussion->notetype = 'fiscal';
		$this->discussion->offeringid = $this->offering->offeringid;
		// Canceled offerings bypass AdCab discussion so resolve immediately
		if ($this->status->value == 'canceled') {
			$this->discussion->resolved = true;
		}
		$this->discussion->save();
		
		$status = new \Offering\Components\Status($this->offering);
		$status->setStatus($this->status->value);
		
		return true;
	}
	
}