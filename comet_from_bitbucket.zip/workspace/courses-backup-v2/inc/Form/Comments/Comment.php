<?php
/**
 * @package edu.uw.education.courses
 */
/**
 * Form for creating and editing comment records
 * @author hanisko
 */

class Form_Comments_Comment extends Form
{
    protected $comment;
    protected $offering;

    public function __construct(Db_Comment $comment, Db_Offering $offering)
    {
        $this->commenttext = new FormElement_Textarea('commenttext', 'Comment', $comment->comment);
        $this->commenttext->rows = 6;
        $applies_value = ($comment->courseid) ? 1 : 0;
        $this->appliesto = new FormElement_Select('appliesto', 'Applies to', $applies_value);
        $this->appliesto->valuelist = array(
            0 => 'Only '.eQuarter($offering->year, $offering->quarter).' '.$offering->curriculum.' '.$offering->courseno.' '.$offering->section,
            1 => 'All '.$offering->curriculum.' '.$offering->courseno.', any quarter, any section'
        );
        $this->comment = $comment;
        $this->offering = $offering;
    }

    public function process()
    {
        $this->commenttext->getUserInput();
        $this->appliesto->getUserInput(Request::$integer_scrub);

        if ($this->commenttext->isEmpty()) {
            $this->commenttext->error = 'Can\'t post an empty comment';
        }
        if (!$this->appliesto->valueInList()) {
            $this->appliesto->value = 0;
        }

        if ($this->hasErrors()) {
            return false;
        }

        $this->comment->comment = $this->commenttext->value;
        if ($this->appliesto->value) {
            // appliesto = 1 = Course
            $this->comment->courseid = $this->offering->courseid;
        } else {
            // appliesto = 0 = Offering
            $this->comment->offeringid = $this->offering->offeringid;
        }
        if ($this->comment->recordExists()) {
            $this->comment->edited_on = time();
            $this->comment->edited_personid = User::GetLoggedInUser()->personid;
        } else {
            $this->comment->created_on = time();
            $this->comment->created_personid = User::GetLoggedInUser()->personid;
        }
        $this->comment->save();
        return true;
    }

}
