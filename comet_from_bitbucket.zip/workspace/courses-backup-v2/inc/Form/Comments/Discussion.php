<?php


class Form_Comments_Discussion extends Form
{
	private $discussion;
	private $offering;
	
	public function __construct(Db_Discussion $discussion, Db_Offering $offering)
	{
		$this->comment = new FormElement_Textarea('comment', 'Comment', $discussion->comment);
		$this->comment->rows = 6;
		$applies_valuelist = array(
			0 => 'Only this offering',
			1 => 'All '.$offering->curriculum.' '.$offering->courseno.', all sections, all quarters'
		);
		$applies_value = ($discussion->courseid) ? 1 : 0;
		$this->appliesto = new FormElement_Select('appliesto', 'Applies to', $applies_value);
		$this->appliesto->valuelist = $applies_valuelist;
		$this->discussion = $discussion;
		$this->offering = $offering;
	}
	
	public function process()
	{
		$this->comment->getUserInput();
		$this->appliesto->getUserInput(Request::$integer_scrub);
		
		if ($this->comment->isEmpty()) {
			$this->comment->error = 'Can\'t post an empty comment';
		}
		
		if (!$this->appliesto->valueInList()) {
			$this->appliesto->value = 0;
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$this->discussion->comment = $this->comment->value;
		if ($this->appliesto->value) {
			// appliesto = 1 = Course
			$this->discussion->courseid = $this->offering->courseid;
		} else {
			// appliesto = 0 = Offering
			$this->discussion->offeringid = $this->offering->offeringid;
		}
		$this->discussion->save();
		
		$this->offering->makePlanned('status was set');
		
		return true;
	}
	
}
