<?php
/**
 * @package UW_COE_Courses
 */

class Form_Comments_AdcabNoteReply extends Form
{
	private $adcabnote;
	private $offering;
	
	public function __construct(Db_AdcabNote $adcabnote, Db_Offering $offering)
	{
		$this->comment = new FormElement_Textarea('comment', 'Comment', $adcabnote->comment);
		$this->comment->rows = 6;
		$this->adcabnote = $adcabnote;
		$this->offering = $offering;
	}
	
	public function process()
	{
		$this->comment->getUserInput();
		
		if ($this->comment->isEmpty()) {
			$this->comment->error = 'Can\'t post an empty comment';
		}
				
		if ($this->hasErrors()) {
			return false;
		}
		
		$this->adcabnote->comment = $this->comment->value;
		$this->adcabnote->save();
		
		return true;
	}
	
}