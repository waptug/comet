<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Administrative tool to moderate comments
 * @author hanisko
 */

class Form_Comments_AdcabNoteModerate extends Form
{
	private $discussion;
	
	public function __construct(Db_AdcabNote $discussion)
	{
		$this->comment = new FormElement_Textarea('comment', 'Comment', $discussion->comment);
		$this->comment->rows = 6;
		$this->resolved = new FormElement_Select('resolved', 'Resolved', $discussion->resolved);
		$this->resolved->valuelist = array('Not resolved', 'Resolved');
		$this->discussion = $discussion;
	}
	
	public function process()
	{
		$action = Request::UserInput('action');
		if ($action == 'Delete') {
			$this->discussion->delete();
			return true;
		}
		
		$this->comment->getUserInput();
		if ($this->comment->isEmpty()) {
			$this->comment->error = 'Can\'t post an empty comment';
		}
		
		$this->resolved->getUserInput();
		if (!$this->resolved->valueInList()) {
			$this->resolved->value = 0;
		}
				
		if ($this->hasErrors()) {
			return false;
		}
		
		$this->discussion->comment = $this->comment->value;
		$this->discussion->resolved = $this->resolved->value;
		$this->discussion->save();
		
		return true;
	}
	
}