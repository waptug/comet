<?php
/**
 * @package UW_COE_Courses
 */

class Form_Comments_AdcabNoteResolve extends Form
{
	private $adcabnote;
	private $resolve;
	
	public function __construct(Db_AdcabNote $resolve, Db_AdcabNote $adcabnote, Db_Offering $offering)
	{
		$this->comment = new FormElement_Textarea('comment', 'Resolution', $adcabnote->comment);
		$this->comment->rows = 6;
		$this->status = new FormElement_Select('status', 'Set status of this course offering', $offering->status);
		$this->status->valuelist = Form_Comments_AdcabNote::$statuses;
		$this->adcabnote = $adcabnote;
		$this->resolve = $resolve;
		$this->offering = $offering;
	}
	
	public function process()
	{
		$this->comment->getUserInput();
		
		if ($this->comment->isEmpty()) {
			$this->comment->error = 'Can\'t post an empty comment';
		}
		
		$this->status->getUserInput();
		
		if (!$this->status->valueInList()) {
			$this->status->value = $this->offering->status;
		}
				
		if ($this->hasErrors()) {
			return false;
		}
		
		$this->adcabnote->comment = $this->comment->value;
		$this->adcabnote->save();
		
		$this->resolve->resolved = true;
		$this->resolve->save();

		$status = new \Offering\Components\Status($this->offering);
		$status->setStatus($this->status->value);
		
		return true;
	}
	
}