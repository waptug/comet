<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to set room needs for a course offering.
 * @author hanisko
 */

class Form_Room_Comment extends Form
{
	private $roomcomment;
	private $offering;
	
	public function __construct(Db_RoomComment $roomcomment, Db_Offering $offering)
	{
		$this->comment = new FormElement_Textarea('comment', 'Comment', $roomcomment->comment);
		$this->comment->rows = 6;
		$this->roomcomment = $roomcomment;
		$this->offering = $offering;
	}
	
	public function process()
	{
		$this->comment->getUserInput();
		
		if ($this->comment->isEmpty()) {
			$this->comment->error = 'Cannot post an empty comment';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$before = new \Offering\Snapshot\RoomRequest($this->offering->offeringid);
		
		$this->roomcomment->comment = $this->comment->value;
		$this->roomcomment->offeringid = $this->offering->offeringid;
		$this->roomcomment->save();

		$after = new \Offering\Snapshot\RoomRequest($this->offering->offeringid);
		$after->logChanges($before, $this->offering->roomneed);
		
		return true;
	}
	
}