<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to set room needs for a course offering.
 * @author hanisko
 */

class Form_Room_Needs extends Form
{
	private $offering;
	
	public function __construct(Db_Offering $offering)
	{
		$this->roompref1 = new FormElement_Text('roompref1', 'First preference', $offering->roomneed->roompref1);
		$this->roompref1->helptext = 'Building (optional room number) of first preference';
		$this->roompref2 = new FormElement_Text('roompref2', 'Second preference', $offering->roomneed->roompref2);
		$this->roompref2->helptext = 'Building (optional room number) of second preference';
		$this->roompref3 = new FormElement_Text('roompref3', 'Third preference', $offering->roomneed->roompref3);
		$this->roompref3->helptext = 'Building (optional room number) of third preference';
		$this->roomfeatures = new FormElement_Checkbox('roomfeatures', '', $offering->roomneed->roomfeatures);
		$this->roomfeatures->valuelist = Db_RoomNeed::$features;
		
		$this->offering = $offering;
	}
	
	public function process()
	{
		$this->roompref1->getUserInput();
		$this->roompref2->getUserInput();
		$this->roompref3->getUserInput();
		$this->roomfeatures->getUserInput();
		
		if (!$this->roomfeatures->valueInList()) {
			$this->roomfeatures->error = 'Choose only values from this list';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$before = new\Offering\Snapshot\RoomRequest($this->offering->offeringid);
		
		$this->offering->roomneed->roompref1 = $this->roompref1->value;
		$this->offering->roomneed->roompref2 = $this->roompref2->value;
		$this->offering->roomneed->roompref3 = $this->roompref3->value;
		$this->offering->roomneed->roomfeatures = $this->roomfeatures->value;
		$this->offering->roomneed->save();

		$after = new \Offering\Snapshot\RoomRequest($this->offering->offeringid);
		$after->logChanges($before, $this->offering->roomneed);
		
		return true;
	}
	
}