<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Change Request form that process input for adding a resolution message to 
 * a change request
 * @author hanisko
 */
 
class Form_Change_Resolve extends Form
{
	private $change;
	
	public static $resolve_options = array(
		''        => '(Not yet resolved)',
		'updated' => 'Updated - the plan has been updated with this change',
		'closed'  => 'Closed - no further action will be taken on this change',
		'uwts'    => 'Sent to UWTS - this changes has beeen submitted to UW Time Schedule'
	);

	public function __construct(Db_ChangeMessage $change)
	{
		if (!$change->offeringid) { throw new Exception(__CLASS__.' requires that offeringid is set'); }
		if (!$change->parent_changeid) { throw new Exception(__CLASS__.' requires that parent_changeid is set'); }
		
		$this->behalfof = new FormElement_Select('behalfof', 'On behalf of', $change->author_personid);
		$this->behalfof->valuelist = Db_Person::FetchIndex();
		$this->behalfof->addDefault('(myself)');
		$this->behalfof->helptext = 'If you are recording a reply for someone else (e.g. pasting an email) choose the person to be listed as the author here';
		
		$this->resolve = new FormElement_Select('resolve', 'Resolution', $change->resolution);
		$this->resolve->valuelist = self::$resolve_options;

		$this->message = new FormElement_Textarea('message', 'Reply message', $change->message);
		$this->message->rows = 5;
		
		$this->change = $change;
	}
	
	public function process()
	{
		$this->behalfof->getUserInput('Integer');
		$this->message->getUserInput();
		$this->resolve->getUserInput();
		
		if (!$this->behalfof->valueInList()) {
			$this->behalfof->error = 'Choose a value from this list';
		}
		
		if (!$this->resolve->valueInList()) {
			$this->resolve->error = 'Choose a value from this list';
			$this->resolve->value = null;
		}
		
		if ($this->hasErrors()) {
			return false;
		}

		$this->change->setAuthorFields(User::GetLoggedInUser()->personid, $this->behalfof->value);
		$this->change->resolution = ($this->resolve->value) ? $this->resolve->value : null;
		$this->change->message = $this->message->value;
		$this->change->save();
		
		return true;	
	}
	
}