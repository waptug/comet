<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Change Request form that process input for creating an Ask For Approval
 * @author hanisko
 */
 
class Form_Change_AskForApproval extends Form
{
	private $change;
	
	public function __construct(Db_ChangeMessage $change)
	{
		if (!$change->offeringid) { throw new Exception(__CLASS__.' requires that offeringid is set'); }
		if (!$change->parent_changeid) { throw new Exception(__CLASS__.' requires that parent_changeid is set'); }

		$this->ask = new FormElement_Select('ask', 'Ask for approval', $change->ask_personid);
		$this->ask->valuelist = Db_Person::FetchIndex();
		
		$this->message = new FormElement_Textarea('message', 'Ask message (optional)', $change->message);
		$this->message->rows = 5;
		
		$this->change = $change;
	}
	
	public function process()
	{
		$this->ask->getUserInput('Integer');
		$this->message->getUserInput();

		if (!$this->ask->valueInList()) {
			$this->ask->error = 'Choose a value from this list';
		}
		
		if ($this->hasErrors()) {
			return false;
		}

		$this->change->ask_personid = $this->ask->value;
		$this->change->message = ($this->message->value) ? $this->message->value : null;
		$this->change->save();
		
		return true;	
	}
	
}