<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Change Request form that process input for creating a new Change Request
 * @author hanisko
 */
 
class Form_Change_NewRequest extends Form
{
	private $change;
	
	public function __construct(Db_ChangeMessage $change)
	{
		if (!$change->offeringid) { throw new Exception(__CLASS__.' requires that offeringid is set'); }
		
		$this->behalfof = new FormElement_Select('behalfof', 'On behalf of', $change->author_personid);
		$this->behalfof->valuelist = Db_Person::FetchIndex();
		$this->behalfof->addDefault('(myself)');
		$this->behalfof->helptext = 'If you are recording a change item for someone else (e.g. pasting an email) choose the person to be listed as the author here';
		
		$this->message = new FormElement_Textarea('message', 'Change requested', $change->message);
		$this->message->rows = 5;
		
		$this->change = $change;
	}
	
	public function process()
	{
		$this->behalfof->getUserInput('Integer');
		$this->message->getUserInput();
		
		if (!$this->behalfof->valueInList()) {
			$this->behalfof->error = 'Choose a value from this list';
		}
		
		if ($this->message->isEmpty()) {
			$this->message->error = 'Cannot submit an empty change request';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$this->change->setAuthorFields(User::GetLoggedInUser()->personid, $this->behalfof->value);
		$this->change->message = $this->message->value;
		$this->change->save();
		
		return true;	
	}
	
}