<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Change Request form that process input for creating a Response to an
 * ask for approval
 * @author hanisko
 */
 
class Form_Change_RespondToAsk extends Form
{
	private $ask;
	private $response;
	public static $response_options = array(
		'approve' => 'Approve the requested change',
		'decline' => 'Decline the requested change',
		'defer'   => 'Defer'
	);
	
	public function __construct(Db_ChangeMessage $ask, Db_ChangeMessage $response)
	{
		if (!$response->offeringid) { throw new Exception(__CLASS__.' requires that offeringid is set'); }
		if (!$response->parent_changeid) { throw new Exception(__CLASS__.' requires that parent_changeid is set'); }
		
		$this->behalfof = new FormElement_Readonly('behalfof', 'On behalf of', View_Person::FirstLast($ask->ask_personid));
		$this->behalfof->helptext = 'You are recording this response on behalf of the person that was asked for approval.';
		
		$this->responseinput = new FormElement_Select('response', 'Response', $response->response);
		$this->responseinput->valuelist = self::$response_options;
		
		$this->message = new FormElement_Textarea('message', 'Reply message', $response->message);
		$this->message->rows = 5;
		
		$this->ask = $ask;
		$this->response = $response;
	}
	
	public function process()
	{
		$this->responseinput->getUserInput();
		$this->message->getUserInput();
		
		if (!$this->responseinput->valueInList()) {
			$this->responseinput->error = 'Choose a value from this list';
		}
		
		if ($this->hasErrors()) {
			return false;
		}

		$this->response->setAuthorFields(User::GetLoggedInUser()->personid, $this->ask->ask_personid);
		$this->response->response = $this->responseinput->value;
		$this->response->message = ($this->message->value) ? $this->message->value : null;
		$this->response->save();
		
		$this->ask->setResponse($this->response);
		$this->ask->save();
		
		return true;	
	}
	
}