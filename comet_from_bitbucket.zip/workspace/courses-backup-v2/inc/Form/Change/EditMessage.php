<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Change Request form that process input for creating a new Change Request
 * @author hanisko
 */
 
class Form_Change_EditMessage extends Form
{
	private $change;
	
	public function __construct(Db_ChangeMessage $change)
	{
		if (!$change->offeringid) { throw new Exception(__CLASS__.' requires that offeringid is set'); }

		$person_options = Db_Person::FetchIndex();
		
		$this->behalfof = new FormElement_Select('behalfof', 'On behalf of', $change->author_personid);
		$this->behalfof->valuelist = $person_options;
		$this->behalfof->addDefault('(myself)');
		$this->behalfof->helptext = 'If you are recording a reply for someone else (e.g. pasting an email) choose the person to be listed as the author here';

		$this->ask = new FormElement_Select('ask', 'Ask for approval', $change->ask_personid);
		$this->ask->valuelist = $person_options;
		
		$this->responseinput = new FormElement_Select('response', 'Response', $change->response);
		$this->responseinput->valuelist = Form_Change_RespondToAsk::$response_options;

		$this->resolve = new FormElement_Select('resolve', 'Resolution', $change->resolution);
		$this->resolve->valuelist = Form_Change_Resolve::$resolve_options;
		
		$this->message = new FormElement_Textarea('message', 'Change requested', $change->message);
		$this->message->rows = 5;
		
		$this->change = $change;
	}
	
	public function process()
	{
		$this->behalfof->getUserInput('Integer');
		$this->ask->getUserInput('Integer');
		$this->message->getUserInput();
		$this->resolve->getUserInput();
		
		if ($this->message->isEmpty()) {
			$this->message->error = 'Message cannot be empty';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$user = User::GetLoggedInUser();
		
		if ($this->change->canBehalf($user)) {
			$this->change->setAuthorFields($user->personid, $this->behalfof->value);
		}
		if ($this->change->canEdit($user)) {
			$this->change->message = $this->message->value;
			$this->change->resolution = ($this->resolve->value) ? $this->resolve->value : null;
			$this->change->ask_personid = $this->ask->value;
			$this->change->message_edit_personid = User::GetLoggedInUser()->personid;
			$this->change->message_edit_date = time();
		}
		
		$this->change->save();
		
		return true;	
	}
	
}