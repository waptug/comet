<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Create, edit, delete staff from repetition rules
 * @author hanisko
 */

class Form_Repetition_Staff extends Form
{
	private $repetition;
	private $_index; 
	
	public function __construct(Db_Repetition $repetition, $index)
	{
		if ($index == 0) {
			$this->_index = $repetition->getNextStaffIndex();
		} else {
			$this->_index = $index;
		}
		// create a new record record
		if (!array_key_exists($index, $repetition->staff) || !$repetition->staff[$this->_index] instanceof \Offering\Repetition\Staff) {
			$repetition->staff[$this->_index] = new \Offering\Repetition\Staff();
			$repetition->staff[$this->_index]->repetitionindex = $this->_index;
		}
		// get a reference to the record we are editing
		$staff = $repetition->staff[$this->_index];
		$this->role = new FormElement_Select('role', 'Role', $staff->role);
		$this->role->valuelist = Db_Staff::getRoles();
		$this->faculty = new FormElement_Select('faculty', 'Faculty', $staff->personid);
		$this->faculty->valuelist = Db_Person::FetchIndex('isfaculty = 1');
		$this->faculty->addDefault('(To be determined)', 1);
		$this->student = new FormElement_Select('student', 'TA/Grader', $staff->personid);
		$this->student->valuelist = Db_Person::FetchIndex('isstudentstaff = 1');
		$this->student->addDefault('(To be determined)', 1);
		$this->adjunct = new FormElement_Select('adjunct', 'Adjunct', $staff->personid);
		$this->adjunct->valuelist = Db_Person::FetchIndex('isadjunct = 1');
		$this->adjunct->addDefault('(To be determined)', 1);
		$this->buyoutreason = new FormElement_Select('buyoutreason', 'Buyout reason', $staff->buyoutreason);
		$this->buyoutreason->valuelist = Db_Staff::$buyout_reasons;
		$this->timesched = new FormElement_Select('timesched', 'Show in UW Time Schedule', $staff->timesched);
		$this->timesched->valuelist = array( '0' => 'No', '1' => 'Yes' );
		$this->timesched->helptext = 'Only one instructor can be listed per meeting in the UW Time Schedule. If you set this value to Yes, all other staff for this meeting will be set to No.';
		
		$this->repetition = $repetition;
	}
	
	public function getIndex()
	{
		return $this->_index;
	}
	
	public function process()
	{
		$action = Request::UserInput('action');
		if ($action == 'Delete') {
			unset($this->repetition->staff[$this->_index]);
			$this->repetition->save();
			$this->repetition->updateStaff();
			return true;
		}

		$this->role->getUserInput();
		$this->faculty->getUserInput(Request::$integer_scrub);
		$this->adjunct->getUserInput(Request::$integer_scrub);
		$this->buyoutreason->getUserInput(Request::$integer_scrub);
		$this->student->getUserInput(Request::$integer_scrub);
		$this->timesched->getUserInput(Request::$integer_scrub);
		
		if (!$this->role->valueInList()) {
			$this->role->error = 'Select a value from this list';
		}
		if (!$this->faculty->valueInList()) {
			$this->faculty->error = 'Select a value from this list';
		}
		if (!$this->adjunct->valueInList()) {
			$this->adjunct->error = 'Select a value from this list';
		}
		if (!$this->buyoutreason->valueInList()) {
			$this->buyoutreason->error = 'Select a value from this list';
		}
		if (!$this->student->valueInList()) {
			$this->student->error = 'Select a value from this list';
		}

		if (!$this->timesched->valueInList()) {
			$this->timesched->value = 0;
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$this->repetition->staff[$this->_index]->role = $this->role->value;
		$this->repetition->staff[$this->_index]->timesched = $this->timesched->value;
		if ($this->role->value == 'faculty') {
			$this->repetition->staff[$this->_index]->personid = $this->faculty->value;
			$this->repetition->staff[$this->_index]->buyoutreason = null;
		} elseif ($this->role->value == 'adjunct') {
			$this->repetition->staff[$this->_index]->personid = $this->adjunct->value;
			$this->repetition->staff[$this->_index]->buyoutreason = null;
		} elseif ($this->role->value == 'buyout') {
			$this->repetition->staff[$this->_index]->personid = $this->faculty->value;
			$this->repetition->staff[$this->_index]->buyoutreason = $this->buyoutreason->value;
		} else {
			$this->repetition->staff[$this->_index]->personid = $this->student->value;
			$this->repetition->staff[$this->_index]->buyoutreason = null;
		}
		$this->repetition->save();
		
		$this->repetition->updateStaff();
		
		return true;
	}
	
}
