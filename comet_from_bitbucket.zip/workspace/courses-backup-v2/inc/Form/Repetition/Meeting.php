<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Create, edit, delete meetings from repetition rules
 * @author hanisko
 */

class Form_Repetition_Meeting extends Form
{
	public static $dow = array(
		'Sunday',
		'Monday',
		'Tuesday',
		'Wednesday',
		'Thursday',
		'Friday',
		'Saturday'
	);
	
	private $repetition;
	private $_index; 
	
	public function __construct(Db_Repetition $repetition, $index)
	{
		$this->_index = $index;
		$existing_meetings = count($repetition->meetings);
		// find a safe meeting index
		if ($this->_index == 0) {
			// create a new meeting
			$this->_index = $existing_meetings;
		} else {
			$this->_index = $this->_index - 1;
			if ($this->_index < 0) $this->_index = 0;
			if ($this->_index > $existing_meetings) $this->_index = $existing_meetings;
			if ($this->_index > 2) $this->_index = 2;
		}
		// create a new meeting record
		if ($this->_index >= $existing_meetings || !$repetition->meetings[$this->_index] instanceof \Offering\Repetition\Meeting) {
			$repetition->meetings[$this->_index] = new \Offering\Repetition\Meeting();
		}
		// get a reference to the meeting we are editing
		$meeting = $repetition->meetings[$this->_index];
		$this->daylist = new FormElement_Checkbox('daylist', 'Days of Week', $meeting->daylist);
		$this->daylist->valuelist = self::$dow;
		$this->starttime = new FormElement_Text('starttime', 'Start Time', eTime($meeting->start));
		$this->starttime->helptext = 'Enter time as H:MM AM/PM. Example: 9:00 AM';
		$this->starttime->class = 'timedata';
		$this->endtime = new FormElement_Text('endtime', 'End Time', eTime($meeting->end));
		$this->endtime->helptext = 'Enter time as H:MM AM/PM. Example: 4:50 PM';
		$this->endtime->class = 'timedata';

		$this->repetition = $repetition;
	}
	
	public function process()
	{
		$action = Request::UserInput('action');
		if ($action == 'Delete') {
			unset($this->repetition->meetings[$this->_index]);
			$this->repetition->save();
			$this->repetition->updateMeetings();
			return true;
		}
		
		$this->daylist->getUserInput(Request::$integer_scrub);
		$this->starttime->getUserInput();
		$this->endtime->getUserInput();
		
		if (!$this->daylist->valueInList()) {
			$this->daylist->error = 'Select a day from this list';
		}
		
		if ($this->starttime->isEmpty()) {
			$this->starttime->error = 'Meeting start time is required';
		}
		$start = new Time($this->starttime->value);
		if (!$start->isValid) {
			$this->starttime->error = 'Not a valid time input use H:MM AM/PM';
		}
		
		if ($this->endtime->isEmpty()) {
			$this->endtime->error = 'Meeting end time is required';
		}
		$end = new Time($this->endtime->value);
		if (!$end->isValid) {
			$this->endtime->error = 'Not a valid time input use H:MM AM/PM';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$this->repetition->meetings[$this->_index]->daylist = $this->daylist->value;
		$this->repetition->meetings[$this->_index]->start = $start->getDbTime();
		$this->repetition->meetings[$this->_index]->end = $end->getDbTime();
		$this->repetition->save();
		
		$this->repetition->updateMeetings();
		
		return true;
	}
	
}