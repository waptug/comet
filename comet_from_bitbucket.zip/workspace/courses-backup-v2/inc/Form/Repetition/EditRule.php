<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Create a new course repetition rule in the system. Also creates the
 * relevant expected offering records when the rule is created.
 * @author hanisko
 */

class Form_Repetition_EditRule extends Form
{
	public $safeofferingid;
	private $repetition;
		
	public function __construct(Db_Repetition $repetition)
	{
		if (!$repetition->firstyear) $repetition->firstyear = date('Y') + 1;
		if (!$repetition->sections) $repetition->sections = 1;
		
		$this->firstyear = new FormElement_Text('firstyear', 'First year', $repetition->firstyear);
		$this->firstyear->helptext = 'First year in which this rule should create course offerings.';
		$this->firstyear->class = 'number';
		$this->yearfreq = new FormElement_Select('yearfreq', 'Year frequency', $repetition->yearfreq);
		$this->yearfreq->valuelist = Db_Repetition::$frequencies;
		$this->yearfreq->helptext = 'How often this rule repeats, starting from the first year.';
		$this->quarter = new FormElement_Select('quarter', 'Quarters', $repetition->quarter);
		$this->quarter->valuelist = Db_Repetition::$quarters;
		$this->quarter->helptext = 'Which quarters, during a selected year, course offerings will be created';
		$this->sections = new FormElement_Text('sections', 'Number of sections', $repetition->sections);
		$this->sections->helptext = 'The number of sections to create in each quarter that matches this rule';
		$this->sections->class = 'number';
		$this->sectionpref = new FormElement_Text('sectionpre', 'Section preference', $repetition->sectionpref);
		$this->sectionpref->helptext = 'The section letters you prefer to use for this course\'s offerings. Leave blank for first available.';
		$this->summerterm = new FormElement_Select('summerterm', 'Summer term', $repetition->summerterm);
		$this->summerterm->valuelist = Db_Offering::$summerterms;
		$this->sectiontype = new FormElement_Select('sectiontype', 'Section Type', $repetition->sectiontype);
		$this->sectiontype->valuelist = Db_Offering::$sectiontypes;
		$this->gradingsystem = new FormElement_Select('gradingsystem', 'Grading system', $repetition->gradingsystem);
		$this->gradingsystem->valuelist = Db_Offering::$gradingsystems;
		$this->institution = new FormElement_Select('institution', 'Offered through', $repetition->institution);
		$this->institution->valuelist = Db_Offering::$institutions;
		
		$this->repetition = $repetition;
	}
	
	public function process()
	{
		$this->firstyear->getUserInput(Request::$integer_scrub);
		$this->yearfreq->getUserInput(Request::$integer_scrub);
		$this->quarter->getUserInput(Request::$integer_scrub);
		$this->sections->getUserInput(Request::$integer_scrub);
		$this->sectionpref->getUserInput();
		$this->summerterm->getUserInput();
		$this->sectiontype->getUserInput();
		$this->gradingsystem->getUserInput();
		$this->institution->getUserInput();
		
		if ($this->firstyear->value < 2000 || $this->firstyear->value > 2050) {
			$this->firstyear->error = 'Must be a 4 digit year value';
		}
		if (!$this->yearfreq->valueInList()) {
			$this->yearfreq->error = 'Choose a value from this list';
		}
		if (!$this->quarter->valueInList()) {
			$this->quarter->error = 'Choose a value from this list';
		}
		if ($this->sections->value < 1 || $this->sections->value > 26) {
			$this->sections->error = 'Must be a number value between 1 and 26';
		}
		if ($this->sectionpref->value) {
			$sections = array();
			$characters = str_split(strtoupper($this->sectionpref->value));
			foreach ($characters as $c) {
				$ascii_code = ord($c);
				if ($ascii_code >= 65 && $ascii_code <= 90) {
					$sections[] = $c;
				}
			}
			$this->sectionpref->value = implode(',', $sections);
		}
		if (!$this->summerterm->valueInList()) {
			$this->summerterm->value = '';
		}
		if (!$this->sectiontype->valueInList()) {
			$this->sectiontype->error = 'Choose a value from the list';
		}
		if (!$this->gradingsystem->valueInList()) {
			$this->gradingsystem->value = 1;
		}
		if (!$this->institution->valueInList()) {
			$this->institution->value = 'state';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
				
		$this->repetition->firstyear = $this->firstyear->value;
		$this->repetition->yearfreq = $this->yearfreq->value;
		$this->repetition->quarter = $this->quarter->value;
		$this->repetition->sections = $this->sections->value;
		$this->repetition->sectionpref = $this->sectionpref->value;
		$this->repetition->summerterm = $this->summerterm->value;
		$this->repetition->sectiontype = $this->sectiontype->value;
		$this->repetition->gradingsystem = $this->gradingsystem->value;
		$this->repetition->institution = $this->institution->value;
		$this->repetition->save();
		
		// Update offerings for the current version of this rule
		$this->repetition->update();
		
		return true;
	}
	
}