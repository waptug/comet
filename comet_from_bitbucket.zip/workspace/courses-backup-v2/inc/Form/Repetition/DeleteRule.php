<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Delete a course repetition rule from the system. Also deletes
 * the relevant expected offering records when the rule is deleted.
 * @author hanisko
 */

class Form_Repetition_DeleteRule extends Form
{
	private $repetition;
		
	public function __construct(Db_Repetition $repetition)
	{	
		$this->deleteall = new FormElement_Select('deleteall', 'Delete offerings', 1);
		$this->deleteall->valuelist = array(
			0 => 'Delete the rule, but keep course offerings in the system',
			1 => 'Delete the rule and delete expected course offerings that match the rule'
		);
		$this->deleteall->helptext = 'Set whether to delete or keep the course offerings listed above.';
		
		$this->repetition = $repetition;
	}
	
	public function process()
	{
		$this->deleteall->getUserInput(Request::$integer_scrub);
		
		if (!$this->deleteall->valueInList()) {
			$this->yearfreq->error = 'Choose a value from this list';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
				
		// If deleteall flag is set delete the course offerings with "expected" status
		// that match this rule
		if ($this->deleteall->value) {
			$this->repetition->deleteOfferings();
		}
		
		// Delete the rule itself
		$this->repetition->delete();
		
		return true;
	}
	
}