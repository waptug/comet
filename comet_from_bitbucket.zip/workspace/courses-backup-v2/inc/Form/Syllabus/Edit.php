<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Upload a syllabus attachement and set metadata
 * @author hanisko
 */
 
class Form_Syllabus_Edit extends Form
{
	
	/**
	 * Course offering this syllabus is being attached to
	 * @var Db_Offering
	 */
	private $offering;
	
	public function __construct(Db_Offering $offering)
	{
		$this->upload = new FormElement_File('upload', 'Upload new syllabus');
		$this->upload->size = '40';
		$this->offering = $offering;
	}
	
	public function process()
	{
		$action = Request::UserInput('action');
		if ($action == 'Delete') {
			if ($this->offering->syllabus instanceof Db_Syllabus) {
				$attachment = new Attachment_Syllabus($this->offering->syllabus);
				$attachment->delete();
			}
			return true;
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$syllabus = new Db_Syllabus($this->offering->syllabusid);
		$syllabus->setOffering($this->offering);
		$syllabus->uploadedby = User::GetLoggedInUser()->uwnetid;
		$syllabus->uploadedon = time();
		$syllabus->extension = strtolower(substr(strrchr($_FILES['upload']['name'],'.'),1));
		$syllabus->mimetype = Attachment_MimeType::GetMimeType($syllabus->extension);
		$syllabus->save();
		
		$attachment = new Attachment_Syllabus($syllabus);
		$r = $attachment->store('upload');
		if (!$r) {
			$this->upload->error = 'Problem storing uploaded file';
			$syllabus->delete();
			return false;
		}
		
		$this->offering->syllabusid = $syllabus->syllabusid;
		$this->offering->save();
		
		return true;
	}
	
}