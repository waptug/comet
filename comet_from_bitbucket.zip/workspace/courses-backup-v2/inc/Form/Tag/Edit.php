<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Create or edit a Db_Tag record
 * @author hanisko
 */

class Form_Tag_Edit extends Form
{
	private $tag;
	
	public function __construct(Db_Tag $tag)
	{
		$this->name = new FormElement_Text('name', 'Name', $tag->name);
		$this->tag = $tag;
	}
	
	public function process()
	{
		$this->name->getUserInput();
		
		if ($this->name->isEmpty()) {
			$this->name->error = 'Tag name cannot be blank';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$this->tag->name = $this->name->value;
		$this->tag->save();
		
		return true;
	}
	
}