<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Delete a tag record from the system
 * @author hanisko
 */

class Form_Tag_Delete extends Form
{
	private $tag;
	
	public function __construct(Db_Tag $tag)
	{
		$this->name = new FormElement_Readonly('name', 'Name', $tag->name);
		$this->tag = $tag;
	}
	
	public function process()
	{	
		// @TODO should we remove individually from course records and log change?
		// Db_ActivityLog_Tagremove::Write($course, $this->tag);
		$this->tag->delete();
		return true;
	}
	
}