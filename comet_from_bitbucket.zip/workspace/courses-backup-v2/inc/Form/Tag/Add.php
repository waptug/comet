<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Add a tag to a course record
 * @author hanisko
 */

class Form_Tag_Add extends Form
{
	private $offering;
	
	public function __construct(Db_Offering $offering)
	{
		$this->offering = $offering;
		$this->tag = new FormElement_Select('tag', 'Tag');
		$this->tag->valuelist = Db_Tag::FetchIndex();
	}
	
	public function process()
	{
		$this->tag->getUserInput();
		
		if (!$this->tag->valueInList()) {
			$this->tag->error = 'Choose a value from the list';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$tag = new Db_Tag($this->tag->value);
		$tag->addToCourse($this->offering->course);
		
		Db_ActivityLog_Tagadd::Write($this->offering->course, $tag);
		
		return true;
	}
	
}