<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Remove a tag from a course record
 * @author hanisko
 */

class Form_Tag_Remove extends Form
{
	private $offering;
	private $tag;
	
	public function __construct(Db_Offering $offering, Db_Tag $tag)
	{
		$this->offering = $offering;
		$this->tag = $tag;
	}
	
	public function process()
	{	
		$this->tag->removeFromCourse($this->offering->course);
		Db_ActivityLog_Tagremove::Write($this->offering->course, $this->tag);
		return true;
	}
	
}