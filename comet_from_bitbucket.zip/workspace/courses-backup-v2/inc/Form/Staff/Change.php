<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Form for changing the assigned person within a Db_Staff record.
 * Does not allow the user to modify staff role within the offering.
 * @author Paul Hanisko
 */

class Form_Staff_Change extends Form_Staff_Abstract
{
	

}