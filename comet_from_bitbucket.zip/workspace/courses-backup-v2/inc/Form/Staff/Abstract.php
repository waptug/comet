<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Insert or Update a Db_Staff database record.
 */

abstract class Form_Staff_Abstract extends Form
{
	const DELETE_BUTTON_TEXT = 'Delete';
		
	protected $staff;

	public function __construct(Db_Staff $staff)
	{
		switch ($staff->role) {
			case 'faculty':
			case 'buyout':
				$filter = 'isfaculty = 1';
				break;
			case 'adjunct':
				$filter = 'isadjunct = 1';
				break;
			case 'instructor':
				$filter = 'isfaculty = 1 OR isadjunct = 1';
				break;
			case 'ta':
			case 'grader':
				$filter = 'isstudentstaff = 1';
				break;
			case 'support':
				$filter = 'issupport = 1';
				break;
			default:
				throw new Exception('Invalid staff role '.$staff->role);
		}
		$this->person = new FormElement_Select('person', 'Person', $staff->personid);
		$this->person->valuelist = Db_Person::FetchIndex($filter);
		$this->person->addDefault('(To be determined)', 1);
		$this->buyoutreason = new FormElement_Select('reason', 'Buy out reason', $staff->buyoutreason);
		$this->buyoutreason->valuelist = Db_Staff::$buyout_reasons;
		$this->buyoutfor = new FormElement_Select('buyoutfor', 'Buy out for', $staff->getBuyoutPersonid());
		$this->buyoutfor->helptext = 'If this adjunct is for a faculty buy out, specify the faculty being replaced';
		$this->buyoutfor->valuelist = Db_Person::FetchIndex('isfaculty = 1');
		$this->buyoutfor->addDefault('(no faculty buy out)', 0);
		$this->meetingnumber = new FormElement_Select('meetingnumber', 'Meeting number', $staff->meetingnumber);
		$this->meetingnumber->valuelist = Db_Meeting::FetchMeetingNumberIndex('offeringid = '.$staff->offeringid);
		$this->meetingnumber->helptext = 'Associate this staff with a specific meeting';
		
		$this->staff = $staff;
	}
	
	/**
	 * Check if we have enough data to process this request without ever
	 * showing the user the form.
	 * @return boolean
	 */
	public function preProcess()
	{
		$personid = Request::UserInput('person', Request::$integer_scrub);
		if ($personid && $this->staff->role != 'adjunct') {
			return true;
		} else {
			// if the staff being added is an adjunct, we need to ask for a reason
			return false;
		}
	}
	
	public function process()
	{
		$action = Request::UserInput('action');
		if ($action == self::DELETE_BUTTON_TEXT) {
			return $this->delete();
		}
		
		$this->person->getUserInput(Request::$integer_scrub);
		$this->buyoutreason->getUserInput(Request::$integer_scrub);
		$this->buyoutfor->getUserInput(Request::$integer_scrub);
		$this->meetingnumber->getUserInput(Request::$integer_scrub);
		
		if (!$this->person->valueInList()) {
			$this->person->error = 'Choose a value from the list';
		}
		if (!$this->meetingnumber->valueInList()) {
			$this->meetingnumber->value = 1;
		}
		
		if ($this->staff->role == 'adjunct') {
			if (!$this->buyoutfor->valueInList() || $this->buyoutfor->value == 0) {
				$this->buyoutfor->value = null;
			} else {
				if (!$this->buyoutreason->valueInList()) {
					$this->buyoutreason->error = 'Choose a value from the list';
				}
			}
		}
		
		if ($this->staff->role == 'buyout') {
			if (!$this->buyoutreason->valueInList()) {
				$this->buyoutreason->error = 'Choose a value from the list';
			}
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		// Check that user input does not conflict with other records
		if (!$this->checkConflicts()) {
			$this->person->error = 'Selecting this person conflicts with another existing staff record for this offering. Go back and delete the conflicting record';
			return false;
		}
		
		// watch this offering for changes
		$offering = new Db_Offering($this->staff->offeringid);
		$offering->changemanager->snapshot();
		
		// if we are changing the person record on an existing staff record, unmap the existing person
		// @TODO this is really messy, this logic does not belong here
		if ($this->staff->recordExists() && $this->person->value != $this->staff->personid) {
			$offering->meetings->removeStaff($this->staff);
		}
		
		// $this->staff expected to have offeringid and role set by child class
		$this->staff->meetingnumber = $this->meetingnumber->value;
		$this->staff->personid = $this->person->value;
		if ($this->staff->role == 'buyout') {
			$this->staff->meetingnumber = 1;
			$this->staff->timesched = 0;
			$this->staff->buyoutreason = $this->buyoutreason->value;
			$this->staff->save();
		}
		$this->staff->save();
		$offering->meetings->addStaff($this->staff);
		
		// create a second record for faculty buyout
		if ($this->buyoutfor->value) {
			$buyout = Db_Staff::ImportStaff($this->staff->offeringid, 1, $this->buyoutfor->value);
			$buyout->role = 'buyout';
			$buyout->timesched = 0;
			$buyout->buyoutreason = $this->buyoutreason->value;
			$buyout->save();
			$offering->meetings->addStaff($buyout);
		}

		// process any changes
		$offering->changemanager->processChanges();
		
		return true;
	}
	
	/**
	 * Verify that the changes to this record are safe to make. Cleans up
	 * conflicting data. Returns true if it is safe to continue to save
	 * this record.
	 * @return boolean
	 */
	protected function checkConflicts()
	{
		if ($this->staff->personid == $this->person->value) {
			// don't have to check if we are not changing assigned person
			return true;
		}
		// Test for record collision, this would happen if user tries to pick a person
		// for this staff record that is already assigned to this course offering
		$filters = array(
			'offeringid = '.$this->staff->offeringid,
			'meetingnumber = '.$this->staff->meetingnumber,
			'personid = '.$this->person->value,
			'personid <> 1'
		);
		$other = Db_Staff::FetchMultiple($filters);
		if (count($other)) {
			// if the target staff is already assigned, this record can be deleted
			$this->staff->delete();
			// use the $other, containing the user selected person, as the current record
			$this->staff = $other[0];
		}
		return true;
	}
	
	/**
	 * Deletes existing staff from an offering record. This process may trigger
	 * a revision.
	 * @return boolean 
	 */
	protected function delete()
	{
		// watch this offering for changes
		$offering = new Db_Offering($this->staff->offeringid);
		$offering->changemanager->snapshot();
		
		$this->staff->delete();
		$offering->meetings->removeStaff($this->staff);

		// process any changes
		$offering->changemanager->processChanges();
		
		return true;
	}

}