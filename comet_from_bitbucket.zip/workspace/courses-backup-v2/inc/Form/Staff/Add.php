<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Add a staff record to a course offering.
 * @author Paul Hanisko
 */

class Form_Staff_Add extends Form_Staff_Abstract
{

	public function __construct(Db_Offering $offering, $role)
	{
		$this->staff = new Db_Staff(0);
		$this->staff->offeringid = $offering->offeringid;
		$this->staff->personid = Request::UserInput('p', Request::$integer_scrub);
		$this->staff->role = $role;
		parent::__construct($this->staff);
	}

}