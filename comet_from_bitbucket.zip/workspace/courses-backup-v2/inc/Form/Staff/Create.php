<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Form for adding entirely new Db_Staff records to the database.
 * Creates a Db_Person record and then the Db_Staff association.
 * 
 * @author Paul Hanisko
 */

class Form_Staff_Create extends Form
{
	public $person;
	private $role;
	
	public function __construct($role)
	{
		$this->firstname = new FormElement_Text('firstname', 'First name');
		$this->lastname = new FormElement_Text('lastname', 'Last name');
		$this->lastname->required = true;
		$this->uwnetid = new FormElement_Text('uwnetid', 'UW NetID');
		$this->ein = new FormElement_Text('ein', 'UW Employee ID Number');
		$this->email = new FormElement_Text('email', 'Email');
		$this->phone = new FormElement_Text('phone', 'Phone');
		$this->role = $role;
	}
	
	public function process()
	{
		$this->firstname->getUserInput();
		$this->lastname->getUserInput();
		$this->uwnetid->getUserInput();
		$this->ein->getUserInput();
		$this->email->getUserInput();
		$this->phone->getUserInput();
		
		if ($this->lastname->isEmpty()) {
			$this->lastname->error = 'Last name is required.';
		}
	
		if ($this->hasErrors()) {
			return false;
		}
		
		// Try to locate an existing person record before creating a new one
		$this->person = Db_Person::FetchByUwnetid($this->uwnetid->value);
		if (!$this->person->recordExists() && $this->ein->value) {
			$this->person = Db_Person::FetchByEin($this->ein->value);
		}
		
		$this->person->firstname = $this->firstname->value;
		$this->person->lastname = $this->lastname->value;
		$this->person->ein = $this->ein->value;
		$this->person->email = $this->email->value;
		$this->person->phone = $this->phone->value;
		
		if (!$this->person->recordExists()) {
			$this->person->source = User::GetLoggedInUser()->uwnetid;
		}
		if (!$this->person->email && $this->person->uwnetid) {
			$this->person->email = $this->person->uwnetid.'@uw.edu';
		}
		switch ($this->role) {
			case 'faculty':
				$this->person->isfaculty = true;
				break;
			case 'adjunct':
				$this->person->isadjunct = true;
				break;
			case 'grader':
			case 'ta':
				$this->person->isstudentstaff = true;
				break;
			default:
				break;
		}
		$this->person->save();
		
		
		return true;
	}

}