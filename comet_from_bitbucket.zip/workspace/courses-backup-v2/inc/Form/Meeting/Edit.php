<?php
/**
 * @package UW_COE_Framework
 */
/**
 * Allow the entry of a course offering's meetings in a single
 * input.
 * @author hanisko
 */

class Form_Meeting_Edit extends Form
{
	public static $dow = array(
		'Sunday',
		'Monday',
		'Tuesday',
		'Wednesday',
		'Thursday',
		'Friday',
		'Saturday'
	);
	
	private $meeting; 
	
	public function __construct(Db_Meeting $meeting)
	{
		$this->daylist = new FormElement_Checkbox('daylist', 'Days of Week', $meeting->daylist);
		$this->daylist->valuelist = self::$dow;
		$this->starttime = new FormElement_Text('starttime', 'Start Time', eTime($meeting->start));
		$this->starttime->helptext = 'Enter time as H:MM AM/PM. Example: 9:00 AM';
		$this->starttime->class = 'timedata';
		$this->endtime = new FormElement_Text('endtime', 'End Time', eTime($meeting->end));
		$this->endtime->helptext = 'Enter time as H:MM AM/PM. Example: 4:50 PM';
		$this->endtime->class = 'timedata';
		
		$this->meeting = $meeting;
	}
	
	public function process()
	{
		$action = Request::UserInput('action');
		if ($action == 'Delete') {
			$this->delete();
			return true;
		}
		
		$this->daylist->getUserInput(Request::$integer_scrub);
		$this->starttime->getUserInput();
		$this->endtime->getUserInput();
		
		if (!$this->daylist->valueInList()) {
			$this->daylist->error = 'Select a day from this list';
		}
		
		if ($this->starttime->isEmpty()) {
			$this->starttime->error = 'Meeting start time is required';
		}
		$start = new Time($this->starttime->value);
		if (!$start->isValid) {
			$this->starttime->error = 'Not a valid time input use H:MM AM/PM';
		}
		
		if ($this->endtime->isEmpty()) {
			$this->endtime->error = 'Meeting end time is required';
		}
		$end = new Time($this->endtime->value);
		if (!$end->isValid) {
			$this->endtime->error = 'Not a valid time input use H:MM AM/PM';
		}
		
		if ($this->hasErrors()) {
			return false;
		}

		// watch this offering for changes
		$offering = new Db_Offering($this->meeting->offeringid);
		$offering->changemanager->snapshot();
		
		$this->meeting->daylist = $this->daylist->value;
		$this->meeting->start = $start->getDbTime();
		$this->meeting->end = $end->getDbTime();
		$this->meeting->save();
		
		$offering->meetingsummary = $offering->getMeetingSummary(true);
		$offering->save();

		// process any changes
		$offering->changemanager->processChanges();
		
		return true;
	}
	
	/**
	 * Delete the meeting an run updates on the offering object
	 */
	protected function delete()
	{
		$offering = new Db_Offering($this->meeting->offeringid);

		// watch this offering for changes
		$offering->changemanager->snapshot();
		
		$this->meeting->delete();
		
		$offering->meetingsummary = $offering->getMeetingSummary(true);
		$offering->save();

		// process any changes
		$offering->changemanager->processChanges();
	}
	
}
