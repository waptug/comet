<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Change the values of the 'update through' quarter in the database which signifies the end date
 * of the automated update process
 */

class Form_Uwts_ChangeUpdateThroughQuarter extends Form
{
	private $uwtsdashboard;
	
	public function __construct(Db_UwtsDashboard $uwtsdashboard)
	{

		if($uwtsdashboard->updatetoyear && $uwtsdashboard->updatetoquarter)
			$selected = (string)$uwtsdashboard->updatetoyear.'-'.(string)$uwtsdashboard->updatetoquarter;
		else {
			$current = Db_Quarter::FetchCurrentQuarter();
			$selected = (string)$current->year.'-'.(string)$current->quarter;
		} 
		$this->yearquarter = new FormElement_Select('yearquarter', 'Year and quarter', $selected);
		$quarters = new \QuarterIterator(6, 'ALL');
		$this->yearquarter->valuelist = $quarters->getSelectOptions();
		
		$this->uwtsdashboard = $uwtsdashboard;
	}
	
	public function process()
	{
		$this->yearquarter->getUserInput();

		if (!$this->yearquarter->valueInList()) {
			$this->curriculum->error = 'Choose a value from this list';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		list($year, $quarter) = explode('-',$this->yearquarter->value);
		$this->uwtsdashboard->updatetoyear = $year;
		$this->uwtsdashboard->updatetoquarter = $quarter;
		$this->uwtsdashboard->quarterupdatedby = User::GetLoggedInUser()->uwnetid;
		$this->uwtsdashboard->quarterupdatedat = time();
		
		$this->uwtsdashboard->save();
		
		return true;
	}

}
