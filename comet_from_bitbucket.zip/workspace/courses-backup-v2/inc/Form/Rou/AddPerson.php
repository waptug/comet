<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Add a system person as an Administrator for an ROU. ROUs are the 
 * groups within the college responsible for scheduling and staffing 
 * course offerings.
 * @author hanisko
 */

class Form_Rou_AddPerson extends Form
{
	protected $rou;

	public function __construct(Db_Rou $rou, $personid = null)
	{
		$this->addperson = new FormElement_Select('addperson', 'ROU Academic support team');
		$this->addperson->valuelist = Db_Person::FetchIndex();
		if ($personid) $this->addperson->value = $personid;
		
		$this->rou = $rou;
	}
	
	public function process()
	{
		$this->addperson->getUserInput('Integer');

		if (!$this->addperson->valueInList()) {
			$this->addperson->error = 'Choose a value from the list';
		}
		
		$person = Db_Person::Get($this->addperson->value);
		
		if (!$person->recordExists()) {
			$this->addperson->error = 'Choose a value from the list';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$this->rou->addPerson($person);
		$this->rou->save();
		
		// Make sure the admin person is authorized to use system
		$auth = new Db_Auth($person->uwnetid);
		// don't downgrade existing permission
		if ($auth->role != 'super') {
			$auth->role = 'admin';
		}
		if ($auth->uwnetid) $auth->save();
		
		return true;
	}

}
