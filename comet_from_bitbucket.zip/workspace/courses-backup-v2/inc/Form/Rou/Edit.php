<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Create or edit a responsible organizational unit. ROUs are the 
 * groups within the college responsible for scheduling and staffing 
 * course offerings.
 * @author hanisko
 */

class Form_Rou_Edit extends Form
{
	protected $rou;

	public function __construct(Db_Rou $rou, $personid = null)
	{
		$this->rouname = new FormElement_Text('rouname', 'ROU Name', $rou->rou_name);
		$this->approver = new FormElement_Select('approver', 'Approver', $rou->approver_personid);
		$this->approver->valuelist = Db_Person::FetchIndex();
		if ($personid) $this->approver->value = $personid;
		$this->parent = new FormElement_Select('parent', 'Parent ROU', $rou->parent_rouid);
		$this->parent->valuelist = Db_Rou::FetchIndex('parent_rouid = 0');
		$this->parent->addDefault('(No parent)');
		$this->description = new FormElement_Textarea('description', 'Description', $rou->description);
		$this->description->helptext = 'This will be displayed to faculty when they click an ROU on the offering detail screen';
		
		$this->rou = $rou;
	}
	
	public function process()
	{
		$this->rouname->getUserInput();
		$this->approver->getUserInput('Integer');
		$this->parent->getUserInput('Integer');
		$this->description->getUserInput();

		if ($this->rouname->isEmpty()) {
			$this->rouname->error = 'ROU must have a name';
		}
		if (!$this->approver->valueInList()) {
			$this->approver->error = 'Choose a value from the list';
		}
		if (!$this->parent->valueInList()) {
			$this->parent->error = 'Choose a value from the list';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$this->rou->rou_name = $this->rouname->value;
		$this->rou->approver_personid = $this->approver->value;
		$this->rou->parent_rouid = $this->parent->value;
		$this->rou->description = $this->description->value;
		$this->rou->save();
		
		// Make sure the approver person is authorized to use system
		$auth = new Db_Auth($this->rou->getApprover()->uwnetid);
		// don't downgrade existing permission
		if ($auth->role != 'super') {
			$auth->role = 'admin';
		}
		if ($auth->uwnetid) $auth->save();
		
		return true;
	}

}
