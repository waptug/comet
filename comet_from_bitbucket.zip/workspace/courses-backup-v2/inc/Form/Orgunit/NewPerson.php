<?php
/**
 * Form for adding entirely new Db_Person records as members of an
 * organizational unit. Creates a Db_Person record, a Db_Auth record
 * and then the Db_PersonOrgunit association.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Form_Orgunit_NewPerson extends Form
{
	protected $orgunit;

	public function __construct(Db_OrgUnit $orgunit)
	{
		$this->firstname = new FormElement_Text('firstname', 'First name');
		$this->lastname = new FormElement_Text('lastname', 'Last name');
		$this->lastname->required = true;
		$this->uwnetid = new FormElement_Text('uwnetid', 'UW NetID');
		$this->uwnetid->required = true;
		$this->ein = new FormElement_Text('ein', 'UW Employee ID Number');
		$this->email = new FormElement_Text('email', 'Email');
		$this->phone = new FormElement_Text('phone', 'Phone');
		$this->orgunit = $orgunit;
	}
	
	public function process()
	{
		$this->firstname->getUserInput();
		$this->lastname->getUserInput();
		$this->uwnetid->getUserInput();
		$this->ein->getUserInput();
		$this->email->getUserInput();
		$this->phone->getUserInput();
		
		if ($this->lastname->isEmpty()) {
			$this->lastname->error = 'Last name is required.';
		}
		if ($this->uwnetid->isEmpty()) {
			$this->uwnetid->error = 'UW NetID is required. This person must log into system.';
		}
	
		if ($this->hasErrors()) {
			return false;
		}
		
		// Step 1: Create person
		// Try to locate an existing person record before creating a new one
		$person = Db_Person::FetchByUwnetid($this->uwnetid->value);
		if (!$person->recordExists() && $this->ein->value) {
			$person = Db_Person::FetchByEin($this->ein->value);
			$person->uwnetid = $this->uwnetid->value;
		}
		
		$person->firstname = $this->firstname->value;
		$person->lastname = $this->lastname->value;
		$person->ein = $this->ein->value;
		$person->email = $this->email->value;
		$person->phone = $this->phone->value;
		
		if (!$person->recordExists()) {
			$person->source = User::GetLoggedInUser()->uwnetid;
		}
		if (!$person->email && $person->uwnetid) {
			$person->email = $person->uwnetid.'@uw.edu';
		}
		$person->save();
		
		// Step 2: Create authorization
		$auth = new Db_Auth($this->uwnetid->value);
		// don't downgrade existing permission
		if ($auth->role != 'super') {
			$auth->role = 'user';
		}
		$auth->save();
		
		// Step 3: Add to organizational unit
		$po = new Db_PersonOrgunit($person->personid, $this->orgunit->orgunitid);
		$po->save();
		
		return true;
	}

}