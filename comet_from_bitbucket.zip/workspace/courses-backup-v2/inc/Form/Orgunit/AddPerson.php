<?php
/**
 * Add a user to an orgunit group
 *
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Form_Orgunit_AddPerson extends Form
{
	protected $orgunit;

	public function __construct(Db_OrgUnit $orgunit)
	{
		$filter = 'uwnetid IS NOT NULL';
		$this->person = new FormElement_Select('person', 'Person');
		$this->person->valuelist = Db_Person::FetchIndex($filter);
		
		$this->orgunit = $orgunit;
	}
	
	public function process()
	{
		$this->person->getUserInput(Request::$integer_scrub);
		
		if (!$this->person->valueInList()) {
			$this->person->error = 'Choose a value from the list';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$person = new Db_Person($this->person->value);
		
		// Step 1: Make sure this person is authorized
		$auth = new Db_Auth($person->uwnetid);
		// don't downgrade existing permission
		if ($auth->role != 'super') {
			$auth->role = 'user';
		}
		$auth->save();
		
		// Step 2: Add to organizational unit
		$po = new Db_PersonOrgunit($this->person->value, $this->orgunit->orgunitid);
		$po->save();
		
		return true;
	}

}