<?php
/**
 * Select a quarter to create course offerings in the builder.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Form_Builder_Settings extends Form
{
	private $builder;
	
	public function __construct()
	{
		$this->builder = Builder::GetInstance();
		if (!$this->builder->year) {
			$this->builder->year = date('Y');
		}
		if (!$this->builder->quarter) {
			$this->builder->quarter = 4;
		}
		if (!$this->builder->curriculum) {
			$this->builder->curriculum = 'ALL';
		}
		$this->quarter = new FormElement_Select('quarter', 'Quarter', $this->builder->year.'-'.$this->builder->quarter);
		$this->quarter->valuelist = Db_Quarter::FetchIndex();
		$this->curriculum = new FormElement_Select('curriculum', 'Curriculum', $this->builder->curriculum);
		$this->curriculum->valuelist = Db_Curriculum::FetchIndex(true);
		$this->curriculum->helptext = 'Show only courses matching the specified course curriculum abbreviation';
		$this->responsible = new FormElement_Select('responsible', 'Responsible area', $this->builder->responsible);
		$this->responsible->valuelist = Db_OrgUnit::$dept_org_units;
		$this->responsible->addDefault('(any area)');
		$this->responsible->helptext = 'Show only courses that specified area is repsonsible for scheduling and staffing';
	}
	
	public function process()
	{
		$this->quarter->getUserInput();
		$this->curriculum->getUserInput();
		$this->responsible->getUserInput();
		
		if (!$this->quarter->valueInList()) {
			$this->quarter->error = 'Choose a value from the list';
		}
		if (!$this->curriculum->valueInList()) {
			$this->curriculum->error = 'Choose a value from the list';
		}
		if (!$this->responsible->valueInList()) {
			$this->responsible->error = 'Choose a value from the list';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		list($year, $qtr) = explode('-', $this->quarter->value);
		$this->builder->year = $year;
		$this->builder->quarter = $qtr;
		if ($this->curriculum->value == 'ALL') {
			$this->builder->curriculum = null;
		} else {
			$this->builder->curriculum = $this->curriculum->value;
		}
		if ($this->responsible->value == '') {
			$this->builder->responsible = null;
		} else {
			$this->builder->responsible = $this->responsible->value;
		}
		
		return true;
	}

}