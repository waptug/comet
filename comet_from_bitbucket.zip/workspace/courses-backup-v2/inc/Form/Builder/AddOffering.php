<?php
/**
 * Select an existing course record. This form provides selection tools
 * for existing course records and feeds into the create offering tool.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Form_Builder_AddOffering extends Form
{
	private $builder;
	public $duplicate_error = false;
	
	public function __construct()
	{
		$this->builder = Builder::GetInstance();
		$course_filter = null;
		if ($this->builder->curriculum) {
			$course_filter = 'curriculum = '.DbFactory::GetConnection()->quote($this->builder->curriculum);
		}
		$this->course = new FormElement_Select('course', 'Course');
		$this->course->valuelist = Db_Course::FetchIndex($course_filter);
		$this->course->addDefault('(none selected)');
		$this->section = new FormElement_Select('section', 'Section');
		$this->section->valuelist = Db_Offering::FetchSectionIndex();
		$this->section->addDefault('(next available)');
		$this->summerterm = new FormElement_Select('summerterm', 'Summer term', $offering->summerterm);
		$this->summerterm->valuelist = Db_Offering::$summerterms;
		$this->sectiontype = new FormElement_Select('sectiontype', 'Section Type');
		$this->sectiontype->valuelist = Db_Offering::$sectiontypes;
	}
	
	public function process()
	{
		$this->course->getUserInput(Request::$integer_scrub);
		$this->section->getUserInput();
		$this->summerterm->getUserInput();
		$this->sectiontype->getUserInput();
	
		if (!$this->course->valueInList() || $this->course->isEmpty()) {
			$this->course->error = 'Choose a course from this list';
		}
		if (!$this->section->valueInList()) {
			$this->section->error = 'Choose a value from the list';
		}
		if (!$this->summerterm->valueInList()) {
			$this->summerterm->value = '';
		}
		if (!$this->sectiontype->valueInList()) {
			$this->sectiontype->error = 'Choose a value from the list';
		}
	
		if ($this->hasErrors()) {
			return false;
		}
		
		$offering = Db_Offering::Create($this->builder->year, $this->builder->quarter, $this->course->value, $this->section->value);
		if (!$offering) {
			$this->section->error = 'This course, quarter, and section already exist in the system. Choose a new section or go to the existing course offering.';
			$this->duplicate_error = true;
			return false;
		}
		if ($this->offering->quarter == 3 && $this->summerterm->value) {
			$this->offering->summerterm = $this->summerterm->value;
		} else {
			$this->offering->summerterm = null;
		}
		$offering->sectiontype = $this->sectiontype->value;
		$offering->save();
		
		Db_ActivityLog_Entered::Write($offering->offeringid);
		
		return true;
	}

}