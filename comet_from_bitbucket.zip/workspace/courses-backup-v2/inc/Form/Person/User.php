<?php
/**
 * Edit a person record with added field for modifying system user role
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Form_Person_User extends Form_Person_Person
{
	
	public function __construct(Db_Person $person)
	{
		parent::__construct($person);
		if ($person->auth) {
			$role = $person->auth->role;
		} else {
			$role = 'noauth';
		}
		$this->approle = new FormElement_Select('approle', 'Application User Role', $role);
		$this->approle->valuelist = Db_Auth::$roles;
	}
	
	public function process()
	{
		$this->approle->getUserInput();

		if (!$this->approle->valueInList()) {
			$this->approle->error = 'Choose a value from this list';
		}
		
		if (!parent::process()) {
			return false;
		}
		
		$this->person->saveUser($this->approle->value);
		
		return true;
	}

}