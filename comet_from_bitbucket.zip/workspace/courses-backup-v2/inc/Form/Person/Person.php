<?php
/**
 * Form for editing Db_Person records in the database.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Form_Person_Person extends Form
{
	const SWS_UPDATE_BUTTON = 'Update from UW';
	protected $person;
	
	public $swsMessage;
	
	public function __construct(Db_Person $person)
	{
		$yesno = array('1' => 'Yes', '0' => 'No');
		$this->firstname = new FormElement_Text('firstname', 'First name', $person->firstname);
		$this->lastname = new FormElement_Text('lastname', 'Last name', $person->lastname);
		$this->lastname->required = true;
		$this->uwnetid = new FormElement_Text('uwnetid', 'UW NetID', $person->uwnetid);
		$this->uwnetid->helptext = 'UW web login name';
		$this->ein = new FormElement_Text('ein', 'UW Employee ID Number', $person->ein);
		$this->facultysequence = new FormElement_Text('facultysequence', 'Faculty Sequence Number', $person->facultysequence);
		$this->facultysequence->helptext = 'Identifier students use to register for independent studies';
		$this->email = new FormElement_Text('email', 'Email', $person->email);
		$this->email->helptext = 'Leave blank to use UW NetID email address';
		$this->phone = new FormElement_Text('phone', 'Phone', $person->phone);
		$this->isfaculty = new FormElement_Select('isfaculty', 'Is Faculty', (int) $person->isfaculty);
		$this->isfaculty->valuelist = $yesno;
		$this->isfaculty->helptext = 'Can this person be assigned to course offerings as UW Faculty';
		$this->isadjunct = new FormElement_Select('isadjunct', 'Is Adjunct', (int) $person->isadjunct);
		$this->isadjunct->valuelist = $yesno;
		$this->isadjunct->helptext = 'Can this person be assigned to course offerings as an Adjunct Instructor';
		$this->isstudentstaff = new FormElement_Select('isstudentstaff', 'Is Student-Staff', (int) $person->isstudentstaff);
		$this->isstudentstaff->valuelist = $yesno;
		$this->isstudentstaff->helptext = 'Can this person be assigned to course offerings as a TA or Grader';
		$this->area = new FormElement_Select('area', 'Affiliated with', $person->area);
		$this->area->valuelist = Db_Person::$areas;
		$this->area->helptext = 'For faculty only, associate dean this faculty is affiliated with';
		
		$this->person = $person;
	}
	
	public function process()
	{
		$this->firstname->getUserInput();
		$this->lastname->getUserInput();
		$this->uwnetid->getUserInput();
		$this->ein->getUserInput();
		$this->email->getUserInput();
		$this->phone->getUserInput();
		$this->isfaculty->getUserInput();
		$this->isadjunct->getUserInput();
		$this->isstudentstaff->getUserInput();
		$this->area->getUserInput();
		$this->facultysequence->getUserInput();
		
		$action = UserInput::get('action');
		if ($action == self::SWS_UPDATE_BUTTON) {
			$this->person->uwnetid = $this->uwnetid->value;
			$this->person->ein = $this->ein->value;
			$sws = new \Update\Person\FromSws($this->person);
			if ($sws->updateAll()) {
				$this->firstname->value = $this->person->firstname;
				$this->lastname->value = $this->person->lastname;
				$this->uwnetid->value = $this->person->uwnetid;
				$this->ein->value = $this->person->ein;
				$this->email->value = $this->person->email;
				$this->swsMessage = 'Found person in UW person resource, verify the following updates and click Save';
				return false;
			} else {
				$this->swsMessage = 'No matching person record was located in the SWS person resources';
				return false;
			}
		}
		
		if ($this->lastname->isEmpty()) {
			$this->lastname->error = 'Last name is required.';
		}
		if (!$this->isfaculty->valueInList()) {
			$this->isfaculty->value = false;
		}
		if (!$this->isadjunct->valueInList()) {
			$this->isadjunct->value = false;
		}
		if (!$this->isstudentstaff->valueInList()) {
			$this->isstudentstaff->value = false;
		}
	
		if ($this->hasErrors()) {
			return false;
		}
		
		if (!$this->person->recordExists()) {
			// Try to match EIN before creating new record
			if ($this->ein->value) {
				$found = Db_Person::FetchByEin($this->ein->value);
				if ($found->recordExists()) {
					$this->person = $found;
				}
			}
			// Try to match UWNetID before creating new record
			if ($this->uwnetid->value) {
				$found = Db_Person::FetchByUwnetid($this->uwnetid->value);
				if ($found->recordExists()) {
					$this->person = $found;
				}
			}
		}
		
		$this->person->firstname = $this->firstname->value;
		$this->person->lastname = $this->lastname->value;
		$this->person->uwnetid = $this->uwnetid->value;
		$this->person->ein = $this->ein->value;
		$this->person->email = $this->email->value;
		$this->person->phone = $this->phone->value;
		$this->person->isfaculty = $this->isfaculty->value;
		$this->person->isadjunct = $this->isadjunct->value;
		$this->person->isstudentstaff = $this->isstudentstaff->value;
		$this->person->area = $this->area->value;
		$this->person->facultysequence = $this->facultysequence->value;
		
		if (!$this->person->recordExists()) {
			$this->person->source = 'admin';
		}
		if (!$this->person->email && $this->person->uwnetid) {
			$this->person->email = $this->person->uwnetid.'@uw.edu';
		}
		$this->person->save();
		
		return true;
	}

}