<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to edit course records in the database. Still clarifying
 * what makes sense to edit locally so initially limited fields e
 * exposed here.
 * @author hanisko
 */

class Form_Course_Responsible extends Form
{
	private $course;
	
	public function __construct(Db_Course $course)
	{
		$this->rou = new FormElement_Select('rou', 'Responsible organizational unit', $course->rouid);
		$report = new \Reports\Rous();
		$this->rou->valuelist = $report->getSelectOptions();
		
		$this->course = $course;
	}
	
	public function process()
	{
		$this->rou->getUserInput();
		
		if (!$this->rou->valueInList()) {
			$this->rou->error = 'Choose a value from this list';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$this->course->rouid = $this->rou->value;
		$this->course->save();
		
		return true;
	}

}