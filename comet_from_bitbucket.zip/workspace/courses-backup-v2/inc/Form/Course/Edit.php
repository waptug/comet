<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Edit a Db_Course record. (Caution that this value is automatically overwritten
 * by matching values in the SWS.)
 * @author hanisko
 */

class Form_Course_Edit extends Form
{
	private $course;
	private static $yesorno = array('No', 'Yes');
	private static $creditcontrols = array(
		'fixed'    => 'Fixed',
		'open'     => 'Variable (1 to 25)',
		'variable' => 'Variable X to Y',
		'minormax' => 'Variable X to Y',
		'zero'     => 'Zero credit'
	);
	private static $curriculums = array(
		'ECFS'  => 'ECFS',
		'EDC&I' => 'EDC&I',
		'EDPSY' => 'EDPSY',
		'EDLPS' => 'EDLPS',
		'EDSPE' => 'EDSPE',
		'EDTEP' => 'EDTEP',
		'EDUC'  => 'EDUC',
	);
	
	public function __construct(Db_Course $course)
	{
		$this->curriculum = new FormElement_Select('curriculum', 'Curriculum', $course->curriculum);
		$this->curriculum->valuelist = self::$curriculums;
		$this->courseno = new FormElement_Text('courseno', 'Course number', $course->courseno);
		$this->title = new FormElement_Text('title', 'Full title', $course->title);
		$this->shorttitle = new FormElement_Text('shorttitle', 'Short title', $course->shorttitle);
		$this->wildcardtitle = new FormElement_Text('wildcardtitle', 'Wildcard title', $course->wildcardtitle);
		$this->creditcontrol = new FormElement_Radio('creditcontrol', 'Credit control', $course->coursecreditcontrol);
		$this->creditcontrol->valuelist = self::$creditcontrols;
		$this->fixed = new FormElement_Text('fixed', 'Fixed credits', $course->coursecreditmin);
		$this->varmin = new FormElement_Text('varmin', 'Variable minimum', $course->coursecreditmin);
		$this->varmax = new FormElement_Text('varmax', 'Variable maximum', $course->coursecreditmax);
		$this->ormin = new FormElement_Text('ormin', 'Or minimum', $course->coursecreditmin);
		$this->ormax = new FormElement_Text('ormax', 'Or maximum', $course->coursecreditmax);
		$this->general_education = new FormElement_Checkbox('general_education', 'General Education Requirements', explode(',',$course->general_education));
		$this->general_education->valuelist = Db_Course::$general_education_flags;
		$this->rou = new FormElement_Select('rou', 'Responsible organizational unit', $course->rouid);
		$report = new \Reports\Rous();
		$this->rou->valuelist = $report->getSelectOptions();
		$this->course = $course;
	}
	
	public function process()
	{
		$this->curriculum->getUserInput();
		$this->courseno->getUserInput('Integer');
		$this->title->getUserInput();
		$this->shorttitle->getUserInput();
		$this->wildcardtitle->getUserInput();
		$this->creditcontrol->getUserInput();
		$this->fixed->getUserInput('Integer');
		$this->varmin->getUserInput('Integer');
		$this->varmax->getUserInput('Integer');
		$this->ormin->getUserInput('Integer');
		$this->ormax->getUserInput('Integer');
		$this->general_education->getUserInput();
		$this->rou->getUserInput();

		if (!$this->curriculum->valueInList()) {
			$this->curriculum->error = 'Choose a value from this list';
		}
		if ($this->courseno->value < 100 || $this->courseno->value > 999) {
			$this->courseno->error = 'Must be a number between 100 and 999';
		}
		if ($this->title->isEmpty()) {
			$this->title->error = 'Course title is required';
		}
		if (!$this->creditcontrol->valueInList()) {
			$this->creditcontrol->error = 'Choose a value from this list';
		}
		if (!$this->general_education->valueInList()) {
			$this->general_education->error = 'Choose a value from this list';
		}
		if (!$this->rou->valueInList()) {
			$this->rou->error = 'Choose a value from this list';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$this->course->curriculum = $this->curriculum->value;
		$this->course->courseno = $this->courseno->value;
		$this->course->title = $this->title->value;
		$this->course->shorttitle = $this->shorttitle->value;
		$this->course->wildcardtitle = $this->wildcardtitle->value;
		$this->course->general_education = implode(",",$this->general_education->value);
		$this->course->rouid = $this->rou->value;
		
		switch ($this->creditcontrol->value) {
			case 'fixed':
				$this->course->coursecreditcontrol = 'fixed';
				$this->course->coursecreditmin = $this->fixed->value;
				$this->course->coursecreditmax = null;
				break;
			case 'zero':
				$this->course->coursecreditcontrol = 'fixed';
				$this->course->coursecreditmin = 0;
				$this->course->coursecreditmax = null;
				break;
			case 'open':
				$this->course->coursecreditcontrol = 'open';
				$this->course->coursecreditmin = 1;
				$this->course->coursecreditmax = 25;
				break;
			case 'variable':
				$this->course->coursecreditcontrol = 'variable';
				$this->course->coursecreditmin = $this->varmin->value;
				$this->course->coursecreditmax = $this->varmax->value;
				break;
			case 'minormax':
				$this->course->coursecreditcontrol = 'minormax';
				$this->course->coursecreditmin = $this->ormin->value;
				$this->course->coursecreditmax = $this->ormax->value;
				break;
			default:
				break;
		}
		
		$this->course->save();
		
		return true;
	}

}
