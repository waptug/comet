<?php
/**
 * Select an existing course record. This form provides selection tools
 * for existing course records and feeds into the create offering tool.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Form_Offering_ChooseCourse extends Form
{
	public $courseid;
	
	public function __construct($curriculum)
	{
		$course_filter = null;
		if ($curriculum) {
			$course_filter = 'curriculum = '.DbFactory::GetConnection()->quote($curriculum);
		}
		$this->course = new FormElement_Select('course', 'Course');
		$this->course->valuelist = Db_Course::FetchIndex($course_filter);
		$this->course->addDefault('(none selected)');
	}
	
	public function process()
	{
		$this->course->getUserInput(Request::$integer_scrub);
		
		if (!$this->course->valueInList()) {
			$this->course->error = 'Choose a course from this list';
		}
	
		if ($this->hasErrors()) {
			return false;
		}
		
		$this->courseid = $this->course->value;
		
		return true;
	}

}