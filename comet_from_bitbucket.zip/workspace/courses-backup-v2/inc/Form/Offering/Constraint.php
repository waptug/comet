<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Allows user to create and edit Constraint records. Constraints are text
 * messages that describe known issues when scheduling or changes course
 * offerings.
 * @author hanisko
 */
 
class Form_Offering_Constraint extends Form
{
	private $constraint;
	private $offering;
	
	public function __construct(Db_Constraint $constraint, Db_Offering $offering)
	{
		$this->appliesto = new FormElement_Select('appliesto', 'Applies to');
		$this->appliesto->valuelist = array(
				'Any '.$offering->curriculum.' '.$offering->courseno.' '.$offering->wildcardtitle,
				'Only this section');
		$this->appliesto->helptext = 'Constraints can apply to the course in general (for wildcard courses only sections of that wildcard title) or to one specific course offering (section).';
		if ($constraint->offeringid) $this->appliesto->value = 1;
		
		$this->contact = new FormElement_Select('contact', 'Contact', $constraint->contact_personid);
		$this->contact->valuelist = Db_Person::FetchIndex();
		$this->contact->helptext = 'Contact is the person who can answer questions about this constraint or give approval for related changes.';
		if (!$this->contact->value) {
			$this->contact->value = User::GetLoggedInUser()->personid;
		}
		
		$this->message = new FormElement_Textarea('message', 'Description', $constraint->message);
		$this->message->rows = 5;
		
		$this->constraint = $constraint;
		$this->offering = $offering;
	}
	
	public function process()
	{
		$this->appliesto->getUserInput('Integer');
		$this->contact->getUserInput('Integer');
		$this->message->getUserInput();
		
		if (!$this->appliesto->valueInList()) {
			$this->appliesto->error = 'Choose a value from this list';
		}
		if (!$this->contact->valueInList()) {
			$this->contact->error = 'Choose a value from this list';
		}
		if ($this->message->isEmpty()) {
			$this->message->error = 'A description of the constraint is required';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		if ($this->appliesto->value == 0) {
			$this->constraint->courseid = $this->offering->courseid;
			$this->constraint->offeringid = null;
		} else {
			$this->constraint->courseid = null;
			$this->constraint->offeringid = $this->offering->offeringid;
		}
		$this->constraint->contact_personid = $this->contact->value;
		$this->constraint->message = $this->message->value;
		if ($this->constraint->recordExists()) {
			$this->constraint->message_edit_personid = User::GetLoggedInUser()->personid;
			$this->constraint->message_edit_date = time();
		} else {
			$this->constraint->entered_date = time();
			$this->constraint->entered_personid = User::GetLoggedInUser()->personid;
		}
		$this->constraint->save();
		
		
		return true;
	}
	
}