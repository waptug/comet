<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Record instructor approval (or removal of approval) of a course offering
 * @author hanisko
 */

class Form_Offering_InstructorApproval extends Form
{
	protected $offering;
	
	public function __construct(Db_Offering $offering)
	{
		$this->approval = new FormElement_Text('approval', '');
		$this->offering = $offering;
	}
	
	public function process()
	{
		$this->approval->getUserInput();
		
		if ($this->hasErrors()) {
			return false;
		}

		$log = new Db_ActivityLog_Instructorapproval(0,false);
		$log->offeringid = $this->offering->offeringid;
		if ($this->approval->value == 'removed') {
			$this->offering->instructorapproval = false;
			$log->data->approval = 'removed';
		} else {
			$this->offering->instructorapproval = true;
			$log->data->approval = 'added';
		}
		$log->save();
		$this->offering->instructorapproval_logid = $log->logid;
		$this->offering->save();
		
		return true;	
	}
	
}
