<?php
/**
 * Create a new course offering record and attach a workflow
 * to it.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Form_Offering_Create extends Form
{
	public $offering;
	public $duplicate_error;
	
	public function __construct(Db_Offering $offering)
	{
		$this->course = new FormElement_Readonly('course', 'Course', $offering->course->summaryname);
		$this->year = new FormElement_Select('year', 'Year', self::GetSelectedYear($offering->year));
		$this->year->valuelist = self::GetYears();
		$this->quarter = new FormElement_Select('quarter', 'Quarter', $offering->quarter);
		$this->quarter->valuelist = Db_Offering::$quarters;
		$this->section = new FormElement_Select('section', 'Section', $offering->section);
		$this->section->valuelist = Db_Offering::FetchSectionIndex($offering);
		$this->section->addDefault('(next available)');
		$this->summerterm = new FormElement_Select('summerterm', 'Summer term', $offering->summerterm);
		$this->summerterm->valuelist = Db_Offering::$summerterms;
		$this->sectiontype = new FormElement_Select('type', 'Section Type', $offering->type);
		$this->sectiontype->valuelist = Db_Offering::$sectiontypes;
		$this->gradingsystem = new FormElement_Select('gradingsystem', 'Grading system', $offering->gradingsystem);
		$this->gradingsystem->valuelist = Db_Offering::$gradingsystems;
		$this->funding = new FormElement_Select('funding', 'Funding type', $offering->funding);
		$this->funding->valuelist = Db_Offering::$fundingtypes;
		
		$this->offering = $offering;
	}
	
	public function process()
	{
		$this->year->getUserInput(Request::$integer_scrub);
		$this->quarter->getUserInput(Request::$integer_scrub);
		$this->section->getUserInput();
		$this->summerterm->getUserInput();
		$this->sectiontype->getUserInput();
		$this->gradingsystem->getUserInput();
		$this->funding->getUserInput();
		
		if (!$this->year->valueInList()) {
			$this->year->error = 'Choose a value from the list';
		}
		if (!$this->quarter->valueInList()) {
			$this->quarter->error = 'Choose a value from the list';
		}
		if (!$this->section->valueInList()) {
			$this->section->error = 'Choose a value from the list';
		}
		if (!$this->summerterm->valueInList()) {
			$this->summerterm->value = '';
		}
		if (!$this->sectiontype->valueInList()) {
			$this->sectiontype->error = 'Choose a value from the list';
		}
		if (!$this->gradingsystem->valueInList()) {
			$this->gradingsystem->error = 'Choose a value from the list';
		}
		if (!$this->funding->valueInList()) {
			$this->funding->value = 'St';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$offering = Db_Offering::Create($this->year->value, $this->quarter->value, $this->offering->courseid, $this->section->value);
		if (!$offering) {
			$this->section->error = 'This course, quarter, and section already exist in the system. Choose a new section or go to the existing course offering.';
			$this->duplicate_error = true;
			return false;
		}
		if ($offering->quarter == 3 && $this->summerterm->value) {
			$this->offering->summerterm = $this->summerterm->value;
		} else {
			$this->offering->summerterm = null;
		}
		$offering->sectiontype = $this->sectiontype->value;
		$offering->gradingsystem = $this->gradingsystem->value;
		$offering->funding = $this->funding->value;
		$offering->save();
		
		$this->offering = $offering;
		
		Db_ActivityLog_Entered::Write($this->offering->offeringid);
		
		return true;
	}
	
	/**
	 * Create a list of years to choose from to populate a select list
	 * @param integer $include_year make sure the specified year is a value in the list
	 * @return array
	 */
	public static function GetYears($include_year = null)
	{
		$start = date('Y') - 3;
		$end = $start + 6;
		$out = array();
		for ($y = $start; $y <= $end; ++$y) {
			$out[$y] = $y;
		}
		if (!is_null($include_year)) {
			if (!in_array($include_year, $out)) {
				array_unshift($out, $include_year);
			}
		}
		return $out;
	}
	
	/**
	 * Pick a likely year as a default value. Use the set year if the value
	 * existed.
	 * @param integer $year
	 * @return integer
	 */
	public static function GetSelectedYear($year)
	{
		if ($year) {
			return $year;
		} else {
			return date('Y') + 1;
		}
	}

}