<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Tool to create joint section records.
 * @author hanisko
 */
 
class Form_Offering_Joint extends Form
{
	private $offering;
	
	public function __construct(Db_Offering $offering)
	{
		$this->sectionstring = new FormElement_Text('sectionstring', 'Joint section');
		$this->sectionstring->helptext = 'Enter curriculum abbreviation, course number, and section letter of the joint section';
		$this->sectionstring->placeholder = 'example: EDUC 500 A';
		$this->confirmnew = new FormElement_Checkbox('confirmnew', 'Confirm new offering');
		$this->confirmnew->valuelist = array('1' => 'Check to create a new offering record');
		
		$this->offering = $offering;
	}
	
	public function process()
	{
		$this->sectionstring->getUserInput();
		$this->confirmnew->getUserInput('Integer');
		
		$parser = new Parser_CourseNumber();
		$r = $parser->getValue($this->sectionstring->value);
		
		if (!$parser->curriculum || !$parser->courseno) {
			$this->sectionstring->error = 'Not a valid curriculum abbreviation and course number';
		}
		if (!$parser->section) {
			$this->sectionstring->error = 'Not a valid section letter';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$joint = $this->offering->joint->importJoint($parser->curriculum, $parser->courseno, $parser->section);
		
		if ($joint instanceof Db_Offering) {
			// ask for confirmation before creating a section
			if (!$joint->recordExists()) {
				if (!$this->confirmnew->value || $this->confirmnew->value[0] != 1) {
					$this->confirmnew->error = 'This course offering does not exist. Check "confirm new offering" box to create it now.';
					return false;
				} else {
					// copy all values from master, not just the normal joint sync
					$joint->save();
				}
			}
		}
		
		// watch this offering for changes
		$this->offering->changemanager->snapshot();
		
		$this->offering->joint->addJoint($joint);

		// process any changes
		$this->offering->changemanager->processChanges();
		
		return true;	
	}
	
}