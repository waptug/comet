<?php
/**
 * Create a new course offering record and attach a workflow
 * to it.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Form_Offering_VerifySection extends Form
{
	public $offering;
	public $error_description;
	
	public function __construct(Db_Offering $offering)
	{
		$this->section = new FormElement_Text('section', 'Section', '');
		$this->section->class = 'number';
		$this->section->helptext = 'Enter the section letter assign by the UW time schedule';
		
		$this->offering = $offering;
	}
	
	public function process()
	{
		$this->section->getUserInput();
		
		if ($this->hasErrors()) {
			return false;
		}
		
		$r = $this->offering->changeSection($this->section->value);
		if (!$r) {
			$this->error_description = 'Couldn\'t change section id to '.$this->section->value.'. '.$this->offering->getChangeSectionError()->message;
			return false;
		}
		$this->offering->sectionstatus = 'V'; // verified
		$this->offering->save();
		
		Db_ActivityLog_Verifysection::Write($this->offering->offeringid, $this->offering->section);
		
		return true;
	}

}