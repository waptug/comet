<?php
/**
 * @package UW_COE_Courses
 */

class Form_Offering_Cancel extends Form
{
	private $offering;
	
	public function __construct(Db_Offering $offering)
	{
		$this->comment = new FormElement_Textarea('comment', 'Comment');
		$this->comment->rows = 6;
		$this->offering = $offering;
	}
	
	public function process()
	{
		$this->comment->getUserInput();
		
		if ($this->comment->isEmpty()) {
			$this->comment->error = 'Reason for cancel is required';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		/*
		 * @TODO need place to store cancel comments
		$discussion = new Db_AdcabNote(0);
		$discussion->comment = $this->comment->value;
		$discussion->notetype = 'fiscal';
		$discussion->offeringid = $this->offering->offeringid;
		$discussion->resolved = true;
		$discussion->save();
		*/
		// watch this offering for changes
		$this->offering->changemanager->snapshot();
		
		$status = new \Offering\Components\Status($this->offering);
		$status->setStatus('canceled');

		// process any changes
		$this->offering->changemanager->processChanges();
		
		return true;
	}
	
}