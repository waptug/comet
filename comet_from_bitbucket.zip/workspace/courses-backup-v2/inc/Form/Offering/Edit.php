<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to edit course offering records in the database. Still clarifying
 * what makes sense to edit locally so initially limited fields exposed here.
 * @author hanisko
 */

class Form_Offering_Edit extends Form
{
	private $offering;
	
	public function __construct(Db_Offering $offering)
	{
		$this->offering = $offering;
		$this->section = new FormElement_Select('section', 'Section', $offering->section);
		$this->section->valuelist = Db_Offering::FetchSectionIndex($offering);
		$this->sectionro = new FormElement_Readonly('section', 'Section', $offering->section);
		$this->sectionro->helptext = 'Section ID is locked because this record is linked to a section in the UW time schedule.';
		$this->summerterm = new FormElement_Select('summerterm', 'Summer term', $offering->summerterm);
		$this->summerterm->valuelist = Db_Offering::$summerterms;
		$this->sectiontype = new FormElement_Select('sectiontype', 'Section Type', $offering->sectiontype);
		$this->sectiontype->valuelist = Db_Offering::$sectiontypes;
		$this->gradingsystem = new FormElement_Select('gradingsystem', 'Grading system', $offering->gradingsystem);
		$this->gradingsystem->valuelist = Db_Offering::$gradingsystems;
		$this->institution = new FormElement_Select('institution', 'Offered through', $offering->institution);
		$this->institution->valuelist = Db_Offering::$institutions;
	}
	
	public function process()
	{
		$this->section->getUserInput();
		$this->summerterm->getUserInput();
		$this->sectiontype->getUserInput();
		$this->gradingsystem->getUserInput();
		$this->institution->getUserInput();

		if (!$this->section->valueInList()) {
			$this->section->error = 'Choose a value from the list';
		}
		if (!$this->summerterm->valueInList()) {
			$this->summerterm->value = '';
		}
		if (!$this->sectiontype->valueInList()) {
			$this->sectiontype->error = 'Choose a value from the list';
		}
		if (!$this->gradingsystem->valueInList()) {
			$this->gradingsystem->error = 'Choose a value from the list';
		}
		if (!$this->institution->valueInList()) {
			$this->institution->value = 'state';
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		// watch this offering for changes
		$this->offering->changemanager->snapshot();
		
		if (!$this->offering->isSectionLocked()) {
			$this->offering->section = $this->section->value;
		}
		if ($this->offering->quarter == 3 && $this->summerterm->value) {
			$this->offering->summerterm = $this->summerterm->value;
		} else {
			$this->offering->summerterm = null;
		}
		$this->offering->sectiontype = $this->sectiontype->value;
		$this->offering->gradingsystem = $this->gradingsystem->value;
		$this->offering->institution = $this->institution->value;
		
		$this->offering->save();
		
		// process any changes
		$this->offering->changemanager->processChanges();
		
		return true;
	}

}