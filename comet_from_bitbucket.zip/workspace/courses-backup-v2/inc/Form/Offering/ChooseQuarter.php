<?php
/**
 * Select an quarter with existing course offering records. Optionally
 * limits quarter query to a specific curriculum. This form feeds into 
 * show schedule tool.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Form_Offering_ChooseQuarter extends Form
{
	public $year;
	public $quarter;
	
	public function __construct()
	{
		$this->yearquarter = new FormElement_Select('yearquarter', 'Quarter');
		$quarters = new \QuarterIterator(0, 15);
		$this->yearquarter->valuelist = $quarters->getSelectOptions();
	}
	
	public function process()
	{
		$this->yearquarter->getUserInput();
		
		if (!$this->yearquarter->valueInList()) {
			$this->yearquarter->error = 'Choose a quarter from this list';
		}
	
		if ($this->hasErrors()) {
			return false;
		}
		
		list($this->year, $this->quarter) = explode('-',$this->yearquarter->value); 
		
		return true;
	}

}