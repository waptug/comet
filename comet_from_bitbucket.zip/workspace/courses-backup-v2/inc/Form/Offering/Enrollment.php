<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Interface to edit course offering enrollment and student credit hour
 * fields.
 * @author Paul Hanisko
 */


class Form_Offering_Enrollment extends Form
{
	private $offering;
	
	public function __construct(Db_Offering $offering)
	{
		$this->offering = $offering;
		$this->enrollmentestimate = new FormElement_Text('enrollmentestimate', 'Enrollment estimate', (int)$offering->enrollmentestimate);
		$this->enrollmentestimate->class = 'number';
		$this->enrollmentlimit = new FormElement_Text('enrollmentlimit', 'Enrollment limit', (int)$offering->enrollmentlimit);
		$this->enrollmentlimit->class = 'number';
		$this->enrollmentlimit->helptext = 'Enter an estimate OR a limit';
		$this->creditdescription = new FormElement_Readonly('creditdescription', 'Course credit description', $offering->course->getCreditDescription());
		$this->creditestimate = new FormElement_Text('creditestimate', 'Credit average', (int)$offering->course->creditestimate);
		$this->creditestimate->class = 'number';
		$this->creditestimate->helptext = 'For variable credit courses, enter an estimated average credits that system will use to estimate SCH';
	}
	
	public function process()
	{
		$this->enrollmentestimate->getUserInput(Request::$integer_scrub);
		$this->enrollmentlimit->getUserInput(Request::$integer_scrub);
		$this->creditestimate->getUserInput(Request::$integer_scrub);
		
		if ($this->hasErrors()) {
			return false;
		}

		// watch this offering for changes
		$this->offering->changemanager->snapshot();

		$this->offering->course->creditestimate = $this->creditestimate->value;
		$this->offering->course->save();
		
		$this->offering->enrollmentestimate = $this->enrollmentestimate->value;
		$this->offering->enrollmentlimit = $this->enrollmentlimit->value;
		$this->offering->save();

		// process any changes
		$this->offering->changemanager->processChanges();
		
		return true;
	}

}