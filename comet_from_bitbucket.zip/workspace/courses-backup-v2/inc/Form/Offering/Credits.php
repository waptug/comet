<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Edit offering specific credits
 * @author hanisko
 */

class Form_Offering_Credits extends Form
{
	private $offering;
	
	private static $creditcontrols = array(
		'fixed'    => 'Fixed',
		'open'     => 'Variable (1 to 25)',
		'variable' => 'Variable X to Y',
		'minormax' => 'Variable X to Y',
		'zero'     => 'Zero credit'				
	);
	
	public function __construct(Db_Offering $offering)
	{
		$this->offering = $offering;
		$this->creditcontrol = new FormElement_Radio('creditcontrol', 'Credit control');
		$this->creditcontrol->valuelist = self::$creditcontrols;
		$this->fixed = new FormElement_Text('fixed', 'Fixed credits');
		$this->varmin = new FormElement_Text('varmin', 'Variable minimum');
		$this->varmax = new FormElement_Text('varmax', 'Variable maximum');
		$this->ormin = new FormElement_Text('ormin', 'Or minimum');
		$this->ormax = new FormElement_Text('ormax', 'Or maximum');
		
		switch ($offering->creditcontrol) {
			case 'fixed':
				if ($offering->creditmin == 0) {
					$this->creditcontrol->value = 'zero';
				} else {
					$this->creditcontrol->value = 'fixed';
					$this->fixed->value = $offering->creditmin;
				}
				break;
			case 'open':
				$this->creditcontrol->value = 'open';
				break;
			case 'variable':
				$this->creditcontrol->value = 'variable';
				$this->varmin->value = $offering->creditmin;
				$this->varmax->value = $offering->creditmax;
				break;
			case 'minormax':
				$this->creditcontrol->value = 'minormax';
				$this->ormin->value = $offering->creditmin;
				$this->ormax->value = $offering->creditmax;
				break;
			default:
				break;
		}
	}
	
	public function process()
	{
		$this->creditcontrol->getUserInput();
		$this->fixed->getUserInput('Integer');
		$this->varmin->getUserInput('Integer');
		$this->varmax->getUserInput('Integer');
		$this->ormin->getUserInput('Integer');
		$this->ormax->getUserInput('Integer');

		if (!$this->creditcontrol->valueInList()) {
			$this->creditcontrol->error = 'Choose a value from the list';
		}
		if ($this->creditcontrol->value == 'variable') {
			if ($this->varmax->value <= $this->varmin->value) {
				$this->varmax->error = 'Max credits must be larger than min credits';
			}
		}
		if ($this->creditcontrol->value == 'minormax') {
			if ($this->ormax->value <= $this->ormin->value) {
				$this->ormax->error = 'Max credits must be larger than min credits';
			}
		}
		
		if ($this->hasErrors()) {
			return false;
		}
		
		// watch this offering for changes
		$this->offering->changemanager->snapshot();
		
		switch ($this->creditcontrol->value) {
			case 'fixed':
				$this->offering->creditcontrol = 'fixed';
				$this->offering->creditmin = $this->fixed->value;
				$this->offering->creditmax = null;
				break;
			case 'zero':
				$this->offering->creditcontrol = 'fixed';
				$this->offering->creditmin = 0;
				$this->offering->creditmax = null;
				break;
			case 'open':
				$this->offering->creditcontrol = 'open';
				$this->offering->creditmin = 1;
				$this->offering->creditmax = 25;
				break;
			case 'variable':
				$this->offering->creditcontrol = 'variable';
				$this->offering->creditmin = $this->varmin->value;
				$this->offering->creditmax = $this->varmax->value;
				break;
			case 'minormax':
				$this->offering->creditcontrol = 'minormax';
				$this->offering->creditmin = $this->ormin->value;
				$this->offering->creditmax = $this->ormax->value;
				break;
			default:
				break;
		}
		
		$this->offering->save();
		
		// process any changes
		$this->offering->changemanager->processChanges();
		
		return true;
	}

}