<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Make edits to the Wildcard Title associated with courses and 
 * course offerings.
 * @author hanisko
 */
 
class Form_Offering_Wildcard extends Form
{
	private $offering;
	
	private static $actions = array(
		'choose' => 'Choose from existing wildcard titles',
		'remove' => 'Remove wildcard title from this offering',	
		'create' => 'Create a new wildcard title for this offering'	
	);
	
	public function __construct(Db_Offering $offering)
	{
		$this->wildcard = new FormElement_Select('wildcard', 'Choose', $offering->course->courseid);
		$this->wildcard->valuelist = Db_Course::FetchWildcardtitles($offering);
		$this->action = new FormElement_Select('action', 'Action');
		$this->action->valuelist = self::$actions;
		if ($offering->wildcardtitle) {
			$this->action->value = 'remove';
		} elseif (count($this->wildcard->valuelist) == 0) {
			$this->action->value = 'create';
		} else {
			$this->action->value = 'choose';
		}
		$this->newtitle = new FormElement_Text('newtitle', 'New title');
		$this->newtitle->helptext = 'Create a new wildcard title which will be applied only to this offering';
		$this->offering = $offering;
	}
	
	public function process()
	{
		$this->action->getUserInput();
		$this->wildcard->getUserInput(Request::$integer_scrub);
		$this->newtitle->getUserInput();

		if (!$this->action->valueInList()) {
			$this->action->error = 'Choose an option from the list.';
			return false;
		}
		
		if ($this->action->value == 'choose') {
			
			// action == 'choose'
			if (!$this->wildcard->valueInList()) {
				$this->wildcard->error = 'Choose an option from the list.';
				return false;
			}
			$this->offering->courseid = $this->wildcard->value;
			$this->offering->save();
			
		} elseif ($this->action->value == 'create') {
			
			// action == 'create'
			if ($this->newtitle->isEmpty()) {
				$this->newtitle->error = 'New title is required for this action';
				return false;
			}
			$course = $this->offering->course->getClone();
			$course->wildcardtitle = $this->newtitle->value;
			$course->save();
			$this->offering->courseid = $course->courseid;
			
		} else {
			
			// action == 'remove'
			$basecourse = $this->offering->course->fetchBaseCourse();
			$this->offering->courseid = $basecourse->courseid;
			
		}

		$this->offering->save();
		
		// Reload to get updated course info
		$this->offering = new Db_Offering($this->offering->offeringid);
		Db_ActivityLog_Wildcardtitle::Write($this->offering->offeringid, $this->offering->course->wildcardtitle);
		
		return true;
	}
	
}