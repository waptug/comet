<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Form to collect report parameters
 * @author hanisko
 */

use \Reports\CoursesAbstract;
use \Reports\Constants as RC;

class Form_Report_Parameters extends Form
{
	private $report;
	
	public function __construct(CoursesAbstract $report)
	{
		$this->year = new FormElement_Select('y', 'Year', $report->getValue('year'));
		$this->year->valuelist = self::YearOptions();
		$this->quarter = new FormElement_Select('q', 'Quarter', $report->getValue('quarter'));
		$this->quarter->valuelist = array(
			0 => 'Academic year',
			4 => 'Autumn',
			1 => 'Winter',
			2 => 'Spring',
			3 => 'Summer'		
		);
		$this->curriculum = new FormElement_Select('c', 'Curriculum', $report->getValue('curriculum'));
		$this->curriculum->valuelist = Db_Curriculum::$curricula;
		$this->curriculum->addDefault('(All curricula)');
		$this->responsible = new FormElement_Rou('rou', 'Responsible', $report->getValue('rou'));
		$this->institution = new FormElement_Select('institution', 'Offered through', $report->getValue('institution'));
		$this->institution->valuelist = \Reports\Params\Institution::$filters;
		$this->tag = new FormElement_Select('t', 'Has tag');
		$this->tag->valuelist = Db_Tag::FetchIndex();
		$this->tag->addDefault('(any/none)');
		if (!is_null($tag = $report->getParam('tag')->getTag())) {
			$this->tag->value = $tag->tagid;
		}
		$this->canceled = new FormElement_Select('canceled', 'Canceled', $report->getValue('canceled'));
		$this->canceled->valuelist = array(
			RC::SHOW_NOT  => 'Not canceled',
			RC::SHOW_ONLY => 'Only canceled',
			RC::SHOW_ALL  => 'All offerings'	
		);
		$this->classroom = new FormElement_Select('classroom', 'Section types', $report->getValue('classroom'));
		$this->classroom->valuelist = array(
			RC::SHOW_ONLY => 'Lecture and seminar',
			RC::SHOW_NOT  => 'Not lecture or seminar',
			RC::SHOW_ALL  => 'All section types'	
		);
		$this->enrollmentfield = new FormElement_Select('enrollmentfield', 'Enrollment field', $report->getValue('enrollmentfield'));
		$this->enrollmentfield->valuelist = array(
			RC::ENROLLMENT_FIELD_EXPECTED => 'Expected enrollment',
			RC::ENROLLMENT_FIELD_ACTUAL   => 'Actual enrollment'	
		);
		$this->lessthan = new FormElement_Text('lessthan', 'Enrollment less than', $report->getValue('lessthan'));
		$this->lessthan->class = 'number';
		$this->greaterthan = new FormElement_Text('greaterthan', 'Enrollment greater than', $report->getValue('greaterthan'));
		$this->greaterthan->class = 'number';
		if ($this->greaterthan->value < 0) { $this->greaterthan->value = null; }
		
		$this->report = $report;
	}
	
	public function process()
	{
		if ($this->hasErrors()) {
			return false;
		}	
		
		return true;
	}
	
	/**
	 * Provides an associative array list of year values, with the year represented as 
	 * both the index and the value.
	 * @param integer $min
	 * @param integer $max
	 * @return array
	 */
	public static function YearOptions($min = null, $max = null)
	{
		if (!$min) {
			$db = DbFactory::GetConnection();
			$min = $db->fetchOne('SELECT MIN(year) FROM offering');
		}
		if (!$max) {
			$max = date('Y') + 2;
		}
		$out = array();
		for ($year = $min; $year <= $max; ++$year) {
			$out[$year] = $year;
		}
		return $out;
	}
	
}
