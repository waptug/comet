<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Testing an include system for defining SQL statements in separate files.
 * @author hanisko
 */

return <<<_END_OF_SQL

SELECT * FROM offering
WHERE year = '2013' AND quarter = 1

_END_OF_SQL;
