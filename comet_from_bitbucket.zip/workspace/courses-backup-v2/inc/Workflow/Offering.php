<?php
/**
 * This workflow sub-class represents the full review and approval
 * process of a course offering.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class Workflow_Offering extends Workflow_Abstract
{
	protected $offering;
	
	public function __construct(Db_Offering $offering)
	{
		$this->offering = $offering;
		$json = file_get_contents('/www/courses/config/workflow/offering.json');
		$config = json_decode($json);
		if (is_null($config)) {
			throw new Exception('Failed to read JSON config file. json_last_error() = '.json_last_error());
		}
		parent::__construct($config);
	}
	
	/**
	 * Load all existing steps from the persistant store into memory
	 * ($this->step_index) with completed steps first, open steps second
	 * and then chronological order.
	 */
	protected function loadSteps()
	{
		$this->steps_index = Db_WorkflowStep::FetchMultiple('offeringid = '.$this->offering->offeringid);	
	}
	
	/**
	 * Returns an open (not complete) Db_WorkflowStep of the the specified
	 * type. If the steptype does not already exist in the datastore a new
	 * (unsaved) object is created.
	 * @param string $steptype
	 * @param boolean $search_datastore
	 * @return Db_WorkflowStep
	 */
	protected function getOpenStep($steptype, $search_datastore = true)
	{
		if ($search_datastore) {
			return Db_WorkflowStep::FetchOpenStep($this->offering->offeringid, $steptype);	
		} else {
			$out = new Db_WorkflowStep(0, false);
			$out->offeringid = $this->offering->offeringid;
			$out->workflowtype = 'offering';
			$out->steptype = $steptype;
			return $out;
		}
	}
	
	/**
	 * Returns the database id of the organizational unit (Db_OrgUnit) that is
	 * responsible for completing the specified step type.
	 * @param string $steptype
	 * @return integer
	 */
	protected function getResponsible($steptype)
	{
		if (!property_exists($this->config->steps, $steptype)) {
			return null;
		}
		if (!property_exists($this->config->steps->$steptype, 'responsible')) {
			return null;
		}
		if (property_exists($this->config->steps->$steptype->responsible, 'id')) {
			if (property_exists($this->config->responsibleids, (string)$this->config->steps->$steptype->responsible->id)) {
				$index = (string)$this->config->steps->$steptype->responsible->id;
				return (int)$this->config->responsibleids->$index;
			} else {
				return (int)$this->config->steps->$steptype->responsible->id;
			}
		}
		if (property_exists($this->config->steps->$steptype->responsible, 'modifier')) {
			if (!$this->offering->orgunitid) {
				return null;
			}
			if (property_exists($this->config->responsibleids, (string)$this->config->steps->$steptype->responsible->modifier)) {
				$index = (string)$this->config->steps->$steptype->responsible->modifier;
				$modifier = (int)$this->config->responsibleids->$index;
			} else {
				$modifier = (int)$this->config->steps->$steptype->responsible->modifier;
			}
			return $this->offering->orgunitid + $modifier;
		}
		return null;
	}
	
}