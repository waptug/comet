<?php
/**
 * Defines a series of Workflow Steps that govern review and approval 
 * of an institutional record. For example review and approval of a 
 * course offering and its support staff.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Framework
 */

abstract class Workflow_Abstract
{
	/**
	 * This workflow's configuration read in from a JSON file in an
	 * object representation 
	 * @var stdClass
	 */
	protected $config;
	
	/**
	 * Registry of each workflow status name as the index and true/false 
	 * indicating whether this status is complete
	 * @var array
	 */
	protected $status_complete;
	
	/**
	 * Status name of the current status of this workflow
	 * @var string
	 */
	protected $status_current;
	
	/**
	 * Mapping of status names to the related steps. Status names are
	 * the indices and an array of step names as the value
	 * @var array
	 */
	protected $status_steps;
	
	/**
	 * Array list of Db_WorkflowStep objects representing all completed, 
	 * open, and expected steps
	 * @var array
	 */
	protected $steps_index;
	
	/**
	 * Array list of Db_WorkflowStep objects representing the current
	 * open steps.
	 * @var array
	 */
	protected $steps_current;
	
	/**
	 * Maps steps by step type to an index in the $steps_index array. The
	 * top index of this array is a step type the value is another array
	 * with 'open' and 'complete' indices containing the relevant index to
	 * a step in $steps_index. Only 'open' or 'complete' should have a value,
	 * not both.
	 *   $steps_state = array()
	 *   $steps_state['proposed']['open'] = null;
	 *   $steps_state['proposed']['completed'] = 1;
	 *   $steps_state['fiscal']['open'] = null;
	 *   $steps_state['fiscal']['completed'] = 2;
	 *   $steps_state['academic']['open'] = 3;
	 *   $steps_state['academic']['completed'] = null;
	 * @var array
	 */
	protected $steps_state;
	
	public function __construct($config)
	{
		$this->config = $config;
		// initalize internal registers
		$this->status_complete = array();
		$this->status_current = array();
		$this->status_steps = array();
		$this->steps_current = array();
		$this->steps_index = array();
		$this->steps_state = array();
		$found_status = false;
		// create a list of step types related to this workflow
		foreach ($this->config->statuses as $statusname) {
			// check if this status has sub-steps defined
			if (property_exists($config->statussteps, $statusname)) {
				$this->status_steps[$statusname] = array();
				foreach ($config->statussteps->$statusname as $steptype) {
					// create a state container for each step type
					$this->steps_state[$steptype] = array( 'open' => null, 'complete' => null );
					$this->status_steps[$statusname][] = $steptype;
				}
			} else {
				// otherwise expect a single step matching the status name
				$this->steps_state[$statusname] = array( 'open' => null, 'complete' => null );
				$this->status_steps[$statusname] = array($statusname);
			}
		}
		// load complete and open steps from the database
		$this->loadSteps();
		// map the locations of open and complete steps by step type
		foreach ($this->steps_index as $index => $step) {
			// give loaded steps a reference to the workflow config
			$step->setConfig($this->config);
			// steps that need to be revisited are neither complete nor open, just part of the history
			if (!$step->revisit) {
				// if this step is an expected part of the workflow it gets mapped
				if (array_key_exists($step->steptype, $this->steps_state)) {
					if ($step->completed) {
						$this->steps_state[$step->steptype]['complete'] = $index;
					} else {
						$this->steps_state[$step->steptype]['open'] = $index;
					}
				} else {
					// steptypes that are not part of the workflow can represent 
					// the current status of the workflow
					if ($step->completed) {
						$this->status_current = $step->steptype;
					}
				}
			}
		}
		// loop through statuses: calculate current status
		foreach ($this->config->statuses as $statusname) {
			// start by assuming it is complete
			$this->status_complete[$statusname] = true;
			foreach ($this->status_steps[$statusname] as $steptype) {
				// if any step within this status is not complete, the status is not complete
				if (!$this->steps_state[$steptype]['complete']) {
					$this->status_complete[$statusname] = false;
					// if the step is not complete, there needs to be an open version of it
					if (!$this->steps_state[$steptype]['open']) {
						$s = $this->getOpenStep($steptype);
						$s->responsible = $this->getResponsible($steptype);
						$s->setConfig($this->config);
						$this->steps_index[] = $s;
						$this->steps_state[$steptype]['open'] = count($this->steps_index) - 1;
					}
				}
			}
			// if still searching for a current status
			if (!$found_status) {
				// if we located an open status
				if ($this->status_complete[$statusname] == false) {
					// stop searching in future iterations
					$found_status = true;
					// create a reference to the current steps
					foreach ($this->status_steps[$statusname] as $steptype) {
						if (!is_null($this->steps_state[$steptype]['open'])) {
							$this->steps_current[] = $this->steps_index[$this->steps_state[$steptype]['open']];
						}
					} 
				} else {
					// otherwise this status is complete and is a candidate for
					// the current status
					$this->status_current = $statusname;
				}
			}
		}
	}
	
	/**
	 * Complete the specified step type within this workflow.
	 * @param string $steptype
	 * @param string $uwnetid
	 */
	public function complete($steptype, $uwnetid = 'system')
	{
		// Completed the identified step
		$now = time();
		$complete = Db_WorkflowStep::FetchOpenStep($this->offering->offeringid, $steptype);
		$complete->workflowtype = $this->getWorkflowType();
		if (!$complete->started) $complete->started = $now;
		$complete->result = true;
		$complete->completed = $now;
		$complete->completedby = $uwnetid;
		$complete->save();
		// Find the first status in the series that is not yet complete
		foreach ($this->statuses as $status) {
			// verify if this status is complete
			if (!$status->isComplete()) {
				// once we find a status that is not complete, create it's step records
				$status->createSteps();
				// once we find and create an open step, we can stop
				break;
			} else {
				// if this is a complete status item make it the overall workflow status
				$this->status = $status->getStatusName();
			}
		}
		// if there is not completed step that is part of this workflow, use the 
		// most recent completed step in the database
		if (!$this->status) {
			$this->status = Db_WorkflowStep::GetLastComplete($this->offering->offeringid, false);
		}
		// Store the workflow overall status name in the offering
		$this->offering->status = $this->status;
		$this->offering->save();
	}
	
	
	/**
	 * Returns an array of Db_WorkflowStep objects that are currently open.
	 * @return array
	 */
	public function getCurrentSteps()
	{
		return $this->steps_current;
	}
	
	/**
	 * Return an array list of Db_WorkflowStep objects in chronological order
	 * includes completed, open, and expected steps.
	 * @return array
	 */
	public function getSteps()
	{
		return $this->steps_index;
	}
	
	/**
	 * Returns the status of the workflow. This is defined as the complete status
	 * immediately preceding the first incompleted status.
	 * @return string
	 */
	public function getStatus()
	{
		return $this->status_current;
	}
	
	/**
	 * Returns true if the specified status name is complete
	 * @param string $statusname
	 * @return boolean
	 */
	public function isStatusComplete($statusname)
	{
		if (array_key_exists($statusname, $this->status_complete)) {
			return $this->status_complete[$statusname];
		} else {
			return null;
		}
	}
	
	/**
	 * Returns true if the specified step name is complete
	 * @param string $steptype
	 * @return boolean
	 */
	public function isStepComplete($steptype)
	{
		return (!is_null($this->steps_state[$steptype]['complete']));
	}
	
	/*
	public function getStatus()
	{
		if (is_null($this->status)) {
			// Find the first status in the series that is not yet complete
			foreach ($this->statuses as $status) {
				// verify if this status is complete
				if ($status->isComplete()) {
					// if this is a complete status item may be the overall workflow status
					$this->status = $status->getStatusName();
				} else {
					// once we find an incomplete status item, stop, the previously set status is our answer
					break;
				}
			}
		}
		return $this->status;
	} 
	*/
	
	/**
	 * Load all existing steps from the persistant store into memory
	 * ($this->step_index) with completed steps first, open steps second
	 * and then chronological order. 
	 */
	abstract protected function loadSteps();
	
	/**
	 * Returns an open (not complete) Db_WorkflowStep of the the specified
	 * type. If the steptype does not already exist in the datastore a new
	 * (unsaved) object is created.
	 * @param string $steptype
	 * @param boolean $search_datastore
	 * @return Db_WorkflowStep
	 */
	abstract protected function getOpenStep($steptype, $search_datastore = true);	
	
	/**
	 * Returns the database id of the organizational unit (Db_OrgUnit) that is
	 * responsible for completing the specified step type.
	 * @param string $steptype
	 * @return integer
	 */
	abstract protected function getResponsible($steptype);	
	
	public function debug()
	{
		echo 'Status complete list' . PHP_EOL;
		print_r($this->status_complete);
		echo PHP_EOL . PHP_EOL;
		
		echo 'Current status' . PHP_EOL;
		echo $this->getStatus();
		echo PHP_EOL . PHP_EOL;
		
		echo 'Map status to steps' . PHP_EOL;
		print_r($this->status_steps);
		echo PHP_EOL . PHP_EOL;
		
		echo 'Steps state map' . PHP_EOL;
		print_r($this->steps_state);
		echo PHP_EOL . PHP_EOL;
		
		echo 'All steps chronologically' . PHP_EOL;
		foreach ($this->getSteps() as $step) {
			echo ' + '.$step->steptype.' R:'.$step->responsible.' '.$step->getResultName().' '.$step->getDescription()."\n";
		}
		echo PHP_EOL . PHP_EOL;
		
		echo 'Current steps' . PHP_EOL;
		foreach ($this->getCurrentSteps() as $step) {
			echo ' * '.$step->steptype.' '.$step->completed.' R:'.$step->responsible."\n";
		}
		echo PHP_EOL . PHP_EOL;
	}

}
