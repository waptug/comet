<?php
/**
 * @package UW_COE_Framework
 */
/**
 * An HTML Anchor tag <a> (aka link). Allows for systematic building of links and
 * multiple rendering with variations in text and parameters.
 * @author hanisko
 */

class Html_Anchor
{
	public $path;
	public $params;
	public $linktext;
	
	private $_attribs;
	
	public function __construct($path = '/', $params = null)
	{
		$this->_attribs = array();
		$this->path = $path;
		if (is_array($params)) {
			$this->params = $params;
		} else {
			$this->params = array();
		}
	}
	
	public function __get($name)
	{
		if (isset($this->_attribs[$name])) {
			return $this->_attribs[$name];
		} else {
			return null;
		}
	}

	public function __set($name, $value)
	{
		$this->_attribs[$name] = $value;
	}
	
	public function getHtml($linktext = null, $extra_params = null)
	{
		if (!is_null($linktext)) {
			$this->linktext = $linktext;
		}
		$attributes = array();
		foreach ($this->_attribs as $name => $value) {
			$attributes[] = e($name).'="'.e($value).'"';
		}
		if (!array_key_exists('href', $this->_attribs)) {
			$attributes[] = 'href="'.buildUrl($this->path, $this->params, $extra_params).'"';
		}
		return '<a '.implode(' ',$attributes).'>'.$this->linktext.'</a>';
	}
	
}