<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Access UW Person data from the Student Web Service
 * @author hanisko
 */

class RestClient_PersonSearch extends RestClient_SwsJson
{
	private $_person;
	
	private static $search_fields = array(
		'ein'       => 'employee_id',	
		'systemkey' => 'student_system_key',	
		'uwnetid'   => 'net_id'
	);
	
	public function __construct(Db_Person $person)
	{
		parent::__construct();
		$this->_person = $person;
	}
	
	public function findRegid()
	{
		foreach (RestClient_PersonSearch::$search_fields as $property => $url_param) {
			if ($this->_person->$property) {
				$this->exec($this->_sws_config->url.'/person.json?'.$url_param.'='.$this->_person->$property);
				$this->_data = json_decode($this->getResponse());
				if (property_exists($this->_data, 'TotalCount') && $this->_data->TotalCount == 1) {
					return $this->_data->Persons[0]->RegID;
				}
			}
		}
		return null;
	}
	
}

