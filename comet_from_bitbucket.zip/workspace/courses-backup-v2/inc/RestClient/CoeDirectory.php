<?php
/**
 * Provides access to person information in the College of Education
 * website directory.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Courses
 */

class RestClient_CoeDirectory extends RestClient
{
	private static $_instance;
	private $baseurl;
	public static $lasthttpstatus = 0;

	/**
	 * Get an existing instance of this class or create a new one if we
	 * need to.
	 */
	public static function GetInstance($options=null)
	{
		if (is_null(self::$_instance)) {
			self::$_instance = new RestClient_CoeDirectory($options);
		}
		return self::$_instance;
	}

	/**
	 * Returns the literal XML responses from the service.
	 * 
	 * @param string $url
	 * @return string
	 */
	public static function FetchRawResponse($url)
	{
		// Get an instance of this class
		$c = self::GetInstance();
		$c->exec($url);
		self::$lasthttpstatus = $c->httpcode;
	
		return $c->getResponse();
	}
	
	/**
	 * Lookup a person in the College of Eduation directory service based
	 * on UWNetID. Returns the matched person as a Cache_Person object or
	 * null if no match was found.
	 *
	 * @return object Cache_Person
	 */
	public static function FetchPerson($uwnetid)
	{
		$uwnetid_lookup = Config::GetConfig('uwnetid_lookup');
		$uwnetid = rawurldecode($uwnetid);
		$c = self::GetInstance();
		$response = self::FetchRawResponse($uwnetid_lookup->url . $uwnetid);
	
		try {
			// parse the response into a SimpleXML object
			$xml = new SimpleXMLElement($response);
		}
		catch (Exception $e) {
			Logger::GetInstance()->debug("Couldn't parse XML from College of Education service - \n" . $response);
			throw $e;
		}
		
		if ($xml->status->code != 200) {
			return null;
		}
		
		$out = array();
		$out['uwnetid'] = (string) $xml->uwnetid;
		$out['firstname'] = (string) $xml->first_name;
		$out['lastname'] = (string) $xml->last_name;
		$out['classification'] = strtolower((string) $xml->appointment_type);
		$out['room'] = (string) $xml->office;
		$out['phone'] = (string) $xml->phone;
		$out['mailstop'] = (string) $xml->mailstop;
		$out['source'] = 'coe_dir';
		
		return $out;
	}
	
}