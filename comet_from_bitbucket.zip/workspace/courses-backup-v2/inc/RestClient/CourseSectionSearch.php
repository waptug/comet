<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Access lists of UW Course section records from the Student Web Service
 * @author hanisko
 */

class RestClient_CourseSectionSearch extends RestClient_SwsJson
{
	// https://ws.admin.washington.edu/student/v5/section.json?year=2012&quarter=spring&curriculum_abbreviation=EDUC&course_number=&reg_id=&search_by=Instructor&include_secondaries=&page_size=10&page_start=1
	private $_params;
	
	public function __construct($year, $quarter, $curriculum, $courseno = null)
	{
		parent::__construct();
		$this->_params['year'] = $year;
		$this->setQuarter($quarter);
		$this->_params['curriculum'] = $curriculum;
		$this->_params['courseno'] = $courseno;
	}
	
	public function __get($name)
	{
		if (array_key_exists($name, $this->_params)) {
			return $this->_params[$name];
		} else {
			return null;
		}
	}
	
	public function __set($name, $value)
	{
		switch($name) {
			case 'quarter':
				$this->setQuarter($value);
				break;
			default:
				$this->_params[$name] = $value;
				break;
		}
	}
	
	public function getResults()
	{
		$params = array(
			'year' => $this->year,
			'quarter' => $this->quarter,
			'curriculum_abbreviation' => $this->curriculum
		);
		if (!is_null($this->courseno)) {
			$params['course_number'] = $this->courseno;
		}
		$escaped = array();
		foreach ($params as $key => $value) {
			$escaped[] = urlencode($key).'='.urlencode($value);
		}
		$this->_resourceurl = $this->_sws_config->url.'/section.json?'.implode('&',$escaped);
		$this->load();
		return $this->_data->Sections;
	}
	
	protected function setQuarter($quarter)
	{
		if (is_numeric($quarter)) {
			$quarter = (int)$quarter;
			$quarter = RestClient_SwsJson::IntToQuarter($quarter);
		}
		if (in_array($quarter, RestClient_SwsJson::$sws_quarter_names)) {
			$this->_params['quarter'] = $quarter;
		} else {
			throw new Exception('Not a valid quarter identifier '.$quarter);
		}
	}

}
