<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Access UW Course data from the Student Web Service
 * @author hanisko
 */

class RestClient_Course extends RestClient_SwsJson
{

	public function __construct($year, $quarter, $curriculum, $courseno)
	{
		parent::__construct();
		$this->_resourceurl = $this->_sws_config->url . '/course/'.$year.','.$quarter.','.rawurlencode($curriculum).','.$courseno.'.json';
	}

}
