<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Access UW Course offering data from the Student Web Service
 * @author hanisko
 */

class RestClient_CourseSection extends RestClient_SwsJson
{
	
	public function __construct($year, $quarter, $curriculum, $courseno, $section)
	{
		parent::__construct();
		$quarter = RestClient_SwsJson::IntToQuarter($quarter);
		//  https://ws.admin.washington.edu/student/v5/course/2012,winter,EDC%26I,505/C
		$this->_resourceurl = $this->_sws_config->url . '/course/'.$year.','.$quarter.','.rawurlencode($curriculum).','.$courseno.'/'.$section.'.json';
	}

}
