<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Access UW Person data from the Student Web Service
 * @author hanisko
 */

class RestClient_Person extends RestClient_SwsJson
{
	
	public function __construct($regid)
	{
		parent::__construct();
		// https://ws.admin.washington.edu/student/v5/person/8068A6E64E1011D983A980176710D768
		$this->_resourceurl = $this->_sws_config->url . '/person/'.$regid.'.json';
	}
	
}

