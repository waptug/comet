<?php
/**
 * @package UW_COE_Framework
 */
/**
 * This abstract class provides methods for interacting with the UW Student
 * Web Service and retrieving JSON representations.
 * @author hanisko
 */
 
class RestClient_SwsJson extends RestClient
{
	private static $not_found_codes = array(400, 404);
	private static $error_codes = array(500);
	
	public static $sws_quarter_names = array(
		1 => 'winter',
		2 => 'spring',
		3 => 'summer',
		4 => 'autumn'
	);
	
	protected $_sws_config;
	protected $_resourceurl;
	protected $_data;
	protected $_statuscode;
	
	public function __construct()
	{
		$this->_sws_config = Config::GetConfig('sws');
		parent::__construct();
		$this->setCertFile($this->_sws_config->authcert);
		$this->setKeyFile($this->_sws_config->keyfile);
	}
	
	/**
	 * Writes the content of the StdClass data object to standard output.
	 */
	public function debug()
	{
		echo __CLASS__." debug output\n";
		echo $this->_resourceurl."\n";
		if (is_null($this->_data)) {
			$this->load();
		}
		if ($this->_statuscode == '404') {
			echo "Not found.\n";
		} else {
			print_r($this->_data);
		}
	}
	
	/**
	 * Returns the StdClass data object containing the data returned by the 
	 * SWS resources.
	 * @return StdClass
	 */
	public function getDataObject()
	{
		if (is_null($this->_data)) {
			$this->load();
		}
		return $this->_data;
	}
	
	/**
	 * Returns the numeric HTTP status code of the last query or null if no query
	 * was executed through this instance
	 * @return integer
	 */
	public function getStatusCode()
	{
		return $this->_statuscode;
	}
	
	/**
	 * Executes the HTTP request against the web service and converts the JSON reponse
	 * to a PHP StdClass structure. Stores an HTTP response status code.
	 */
	public function load()
	{
		$this->exec($this->_resourceurl);
		$this->_data = json_decode($this->getResponse());
		if (is_null($this->_data)) {
			debug(__METHOD__.'Response from '.$this->_resourceurl.PHP_EOL.$this->getResponse());
			throw new Exception('Could not parse JSON response');
		}
		if (property_exists ($this->_data, 'StatusCode')) {
			if (in_array($this->_data->StatusCode, RestClient_SwsJson::$not_found_codes)) {
				$this->_statuscode = 404;
			} elseif (in_array($this->_data->StatusCode, RestClient_SwsJson::$error_codes)) {
				$this->_statuscode = 500;
			} else {
				$this->_statuscode = $this->_data->StatusCode;
			}
		} else {
			$this->_statuscode = 200;
		}
	}
	
	/**
	 * Executes load if needed and returns true if the requested SWS resources was found.
	 * @return boolean
	 */
	public function recordExists()
	{
		if (is_null($this->_data)) {
			$this->load();
		}
		return ($this->_statuscode == 200);
	}
	
	/**
	 * Convert a string quarter value (used by the SWS) to an integer quarter
	 * value (used by the local system)
	 * @param string $quarter
	 * @return integer
	 */
	protected static function QuarterToInt($quarter)
	{
		$quarter = strtolower($quarter);
		switch ($quarter)
		{
			case 1:
			case 'winter':
				$q = 1;
				break;
			case 2:
			case 'spring':
				$q = 2;
				break;
			case 3:
			case 'summer':
				$q = 3;
				break;
			case 4:
			case 'fall':
			case 'autumn':
				$q = 4;
				break;
			default:
				return null;
				break;
		}
		return $q;
	}

	/**
	 * Convert an integer quarter value (used by the local system) to a string 
	 * quarter value (used by the SWS)  
	 * @param integer $q
	 * @return string
	 */
	protected static function IntToQuarter($q)
	{
		if (in_array($q, RestClient_SwsJson::$sws_quarter_names)) {
			return $q;
		}
		$q = (int) $q;
		if ($q > 0 && $q < 5) {
			return RestClient_SwsJson::$sws_quarter_names[$q];
		} else {
			return null;
		}
	}
	
}