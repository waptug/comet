<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Access UW Term data from the Student Web Service
 */

class RestClient_Term extends RestClient_SwsJson
{

	public function __construct($year, $quarter)
	{
		parent::__construct();
		$this->_resourceurl = $this->_sws_config->url . '/term/'.$year.','.$quarter.'.json';
	}

}
