<?php
/**
 * @package UW_COE_Courses
 */
/**
 * Access lists of UW Course records from the Student Web Service
 * @author hanisko
 */

class RestClient_CourseSearch extends RestClient_SwsJson
{
	const SEARCH_PAGE_SIZE = 200;
	
	// https://ws.admin.washington.edu/student/v5/course.json?year=2012&quarter=summer&curriculum_abbreviation=EDLPS&page_size=200
	private $_params;
	
	public function __construct($year, $quarter, $curriculum)
	{
		parent::__construct();
		$this->_params['year'] = $year;
		$this->setQuarter($quarter);
		$this->_params['curriculum'] = $curriculum;
		$this->_params['page_size'] = self::SEARCH_PAGE_SIZE;
		$this->_params['future_terms'] = 2; // Need this to catch new courses
	}
	
	public function __get($name)
	{
		if (array_key_exists($name, $this->_params)) {
			return $this->_params[$name];
		} else {
			return null;
		}
	}
	
	public function __set($name, $value)
	{
		switch($name) {
			case 'quarter':
				$this->setQuarter($value);
				break;
			default:
				$this->_params[$name] = $value;
				break;
		}
	}
	
	public function getResults()
	{
		$params = array(
			'year' => $this->year,
			'quarter' => $this->quarter,
			'curriculum_abbreviation' => $this->curriculum,
			'page_size' => $this->page_size,
			'future_terms' => $this->future_terms
		);
		$escaped = array();
		foreach ($params as $key => $value) {
			$escaped[] = urlencode($key).'='.urlencode($value);
		}
		$this->_resourceurl = $this->_sws_config->url.'/course.json?'.implode('&',$escaped);
		$this->load();
		if ($this->_data->TotalCount > self::SEARCH_PAGE_SIZE) {
			throw new Exception('Too many search results for a single response');
		}
		return $this->_data->Courses;
	}
	
	protected function setQuarter($quarter)
	{
		if (is_numeric($quarter)) {
			$quarter = (int)$quarter;
			$quarter = RestClient_SwsJson::IntToQuarter($quarter);
		}
		if (in_array($quarter, RestClient_SwsJson::$sws_quarter_names)) {
			$this->_params['quarter'] = $quarter;
		} else {
			throw new Exception('Not a valid quarter identifier '.$quarter);
		}
	}

}
