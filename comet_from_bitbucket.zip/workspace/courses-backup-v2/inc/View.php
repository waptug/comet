<?php
/**
 * View classes hold display and formatting related settings for a
 * given piece of data. They implement a render function which outputs
 * an HTML fragment representing the piece of data.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Framework
 */


abstract class View
{
	protected $_template_dir;
	
	public $template;
	    
    /**
     * Returns the base directory from which data type display templates 
     * should be included.
     * @return string
     */
    protected function getTemplateDir()
    {
    	if (is_null($this->_template_dir)) {
    		$this->_template_dir = dirname(dirname(__FILE__)).'/views';
    	}
    	return $this->_template_dir;
    }
    
    /**
     * Sets the base directory from which data type display templates 
     * should be included.
     * @return string
     */
    protected function setTemplateDir($directory)
    {
    	$this->_template_dir = $directory;
    }
    
    /**
     * Returns the value wrapped in the specified HTML $element. $value should be
     * HTML escaped before passing to this method. $element is name only, do not 
     * include angle brackets. $attributes can be represented as a string (which 
     * will be included literally) or as an array (whose index => value pairs will 
     * receive HTML escaping)
     * @param string $element HTML element that can contain data, element only, no angle brackets
     * @param mixed $attributes
     * @return string
     */
    protected function wrap($value, $element, $attributes)
    {
    	if (!$attributes) {
    		$start = '<'.$element.'>';
    	} elseif (!is_array($attributes)) {
    		$start = '<'.$element.' '.$attributes.'>';
    	} else {
			$attr = array();
			foreach ($attributes as $k => $v) {
				$attr[] = e($k).'="'.e($v).'"';
			}
			$start = '<'.$element.' '.implode(' ',$attr).'>';
    	}
    	return $start.$value.'</'.$element.'>';
    }
    
}