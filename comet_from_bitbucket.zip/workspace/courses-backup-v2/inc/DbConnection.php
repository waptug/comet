<?php
/**
 * A wrapper for the mysqli database connection object. Provides error 
 * checking, logging, quoting routines and conversion of results into 
 * common PHP data structures.
 * 
 * @author Paul Hanisko
 * @package UW_COE_Framework
 */
class DbConnection
{
	private static $_registry = array();
	
	const TYPE_CHAR      = 0;
	const TYPE_DATETIME  = 1;
	const TYPE_BOOLEAN   = 2;
	const TYPE_INT       = 3;
	const TYPE_NUMERIC   = 4;
	const TYPE_TIMESTAMP = 1;
	
	// If QUERY_TIMER is true all queries will be timed
	const QUERY_TIMER = false; //true;
	// If a query takes longer than QUERY_SLOW seconds it will be logged
	const QUERY_SLOW = 0; //0.01;
	
	private $_params;
	private $_connection;
	public $lastquery = '';
	public $error = false;
	public $errno = false;
		
	/**
	 * Create a new instance. Accessible only through the GetInstance()
	 * static method.
	 */
	public function __construct($params)
	{
		if(is_object($params)) $params = (array)$params;
		$this->_params = $params;
		$this->_connection = false;
	}
	
	public static function GetInstance($name = 'courses')
	{
		return DbFactory::GetConnection($name);
	}
	
	/**
	 *  Returns an open MySQLi connection object. Make the connection lazy, 
	 *  only open it when we are actually ready to use it.
	 *  
	 *  @return object 
	 */
	private function getConnection()
	{
		if (!$this->_connection) {
			
			$dbhost = $this->_params['host'];
			$dbuser = $this->_params['username'];
			$dbpass = $this->_params['password'];
			$dbname = $this->_params['dbname'];
		
			if (self::QUERY_TIMER) {
				$timer = new Timer();
			}
			
			$c = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
		
			if (self::QUERY_TIMER) {
				$msecs = $timer->getTime();
				if ($msecs > self::QUERY_SLOW) {
					Logger::GetInstance()->debug('Took '. $msecs .' seconds to open a database connection');
				}
			}
			
			if (mysqli_connect_errno()) {
				
				Logger::GetInstance()->debug('Failed opening database connection ' . mysqli_connect_error());
				throw new Exception('System error connecting to database');
			}
			$this->_connection = $c;
		}
		return $this->_connection;
	}
	
	private function tquery($sql)
	{
		$db = $this->getConnection();
		if (self::QUERY_TIMER) {
				$timer = new Timer();
		}
		$result = $db->query($sql);
		if (self::QUERY_TIMER) {
			$msecs = $timer->getTime();
			if ($msecs > self::QUERY_SLOW) {
				Logger::GetInstance()->dbError('Database query took '. $msecs .' seconds.', $sql);
			}
		}
		
		if (!$result) {
			// MySQL Error
			$this->error = $db->error;
			$this->errno = $db->errno;
			Logger::GetInstance()->dbError('MySQL Error ('. $db->errno .') '. $db->error, $sql);
			throw new Exception('Application error');
		}
		return $result;
	}
	
	/**
	 * Escape a value and wrap it in quotes appropriate to its data type for safe 
	 * inclusion in an SQL statement.
	 *
	 * @param mixed $value the value to escape and quote
	 * @param string $type the column type to escape and quote for
	 * @return string
	 */
	function quote($value, $type = 'text')
	{
		$type = strtolower($type);
		
		// if the value provided is null in return the db null literal
		if (is_null($value)) { return 'null'; }
		
		$quote = '\'';
		$quoted = '';
		
		switch ($type) {
			case self::TYPE_TIMESTAMP:
			case 'date':
			case 'time':
			case 'datetime':
				if (!is_int($value)) { $value = strtotime($value); }
				if ($value == 0) {
					$quoted = $quote . '00-00-00 00:00:00' . $quote;
				} else {
					$quoted = $quote . date('Y-m-d H:i:s', $value) . $quote;
				}
				break;
			case 'year':
				$value = (int) $value;
				$quoted = $quote . $value . $quote;
				break;
			case self::TYPE_INT:
			case 'int':
				$quoted = (int) $value;
				break;
			case self::TYPE_NUMERIC:
			case 'numeric':
			case 'number':
			case 'float':
			case 'double':
				$quoted = (float) $value;
				break;
			case self::TYPE_BOOLEAN:
			case 'bool':
			case 'boolean':
				$quoted = ($value) ? 1 : 0;
				break;
			case self::TYPE_CHAR:
			case 'string':
			case 'char':
			case 'varchar':
			case 'text':
			default: // treat unknown data types as string values
				$db = $this->getConnection();
				$quoted = $quote . $db->real_escape_string($value) . $quote;
				break;
		}
		return $quoted;
	}
	
	/**
	 * Replace a question mark character (?) in an SQL statement with 
	 * the escaped and quoted version of the supplied value.
	 * 
	 * @param string $sql SQL statement with one ? place holder 
	 * @param string $value value to quote and insert into SQL
	 * @param int $value type of data being quoted
	 * @return string
	 */
	public function quoteInto($sql, $value, $datatype = self::TYPE_CHAR)
	{
		$value = $this->quote($value, $datatype);
		return str_replace('?', $value, $sql);
	}
	
	/**
	 * Run a query that does not return data. E.G. an INSERT or UPDATE
	 *
	 * @param string $sql sql statement to execute
	 * @param string $location where this was called from (for logging)
	 */
	public function query($sql) 
	{
		$this->lastquery = $sql;
		
		// run the query against the database
		$this->tquery($sql);
	}
	
	/**
	 * Get the last auto incremented ID value generated by the database. Utilizes
	 * MySQLs last_insert_id function which insures that the ID returned is 
	 * connection specific.
	 *
	 * @param string $location where this was called from (for logging)
	 * @return int
	 */
	public function getLastInsertId()
	{
		$sql = 'SELECT LAST_INSERT_ID()';
		return $this->fetchOne($sql);
	}
	
	/**
	 * Fetch an array of associative arrays from a database query. The outer
	 * array is a list of rows returned. The inner arrays are associative
	 * arrays with the column names as indicies. If no results match returns
	 * an empty array.
	 *
	 * @param string $sql an SQL select statement
	 * @return array
	 */
	public function fetchAssoc($sql) 
	{
		$this->lastquery = $sql;
		
		// run the query against the database
		$result = $this->tquery($sql);
		
		$out = array();
				
		for ($i = 0; $i < $result->num_rows; ++$i) {
			$out[] = $result->fetch_assoc();
		}
		
		$result->free();
		
		return $out;
	}
	
	/**
	 * Fetch the contents of two columns into an associative array where
	 * the first column becomes the index and the second column the value.
	 * If no results match returns an empty array.
	 * 
	 * @param string $sql an SQL select statement
	 * @return array
	 */
	public function fetchPairs($sql) 
	{
		$this->lastquery = $sql;
		
		// run the query against the database
		$result = $this->tquery($sql);
		
		$out = array();
		
		for ($i = 0; $i < $result->num_rows; ++$i) {
			$row = $result->fetch_row();
			$out[$row[0]] = $row[1];
		}
		
		$result->free();
		
		return $out;
	}
	
	/**
	 * Fetch the contents of a single column into a simple numerically
	 * indexed array. Regardless of query provided only the values in the first
	 * column are returned. If no results match returns an empty array.
	 *
	 * @param string $sql an SQL select statement
	 * @return array
	 */
	public function fetchColumn($sql) 
	{
		$this->lastquery = $sql;
		
		// run the query against the database
		$result = $this->tquery($sql);
		
		$out = array();
		
		for ($i = 0; $i < $result->num_rows; ++$i) {
			$row = $result->fetch_row();
			$out[] = $row[0];
		}
		
		$result->free();
		
		return $out;
	}

	/**
	 * Fetch an array of associative arrays from a database query. The outer
	 * array is a list of rows returned. The inner arrays are associative
	 * arrays with the column names as indicies. If no results match returns
	 * an empty array.
	 * 
	 * The outer array will have indices based on the values of the column(s) 
	 * specified by the $key_column_name. This argument can be a string for a
	 * single column or an array for a complex key. Complex key values will
	 * be concatenated with "-" hyphen separators by default.
	 *
	 * @param string $sql an SQL select statement
	 * @param mixed $key_column_name name of column(s) who's values will be used as array index
	 * @param mixed $separator character other than "-" to use to separate pk values
	 * @return array
	 */
	public function fetchIndexed($sql, $key_column_name, $separator = '-') 
	{
		// run the query against the database
		$result = $this->tquery($sql);
		
		$out = array();
	
		if (is_array($key_column_name)) {
			for ($i = 0; $i < $result->num_rows; ++$i) {
				$row = $result->fetch_assoc();
				$index = array();
				foreach ($key_column_name as $key) {
					$index[] = $row[$key];
				}
				$out[implode($separator, $index)] = $row;
			}
		} else {
			for ($i = 0; $i < $result->num_rows; ++$i) {
				$row = $result->fetch_assoc();
				$out[$row[$key_column_name]] = $row;
			}
		}	
		
		$result->free();
		
		return $out;
	}
	
	/**
	 * Fetch a single scalar value from a database query. Regardless of
	 * results of query only the first column of the first record will
	 * be returned. If no results match returns null.
	 *
	 * @param string $sql an SQL select statement
	 * @return string
	 */
	public function fetchOne($sql) 
	{
		$this->lastquery = $sql;
		
		// run the query against the database
		$result = $this->tquery($sql);
		
		// if we didn't match any rows send null back
		if ($result->num_rows == 0) {
			return null;
		}
		
		$row = $result->fetch_row();
		$out = $row[0];
		$result->free();
		
		return $out;
	}
	
	/**
	 * Fetch a single row from a database query and return it as an associative
	 * array. Regardless of results of query only the first record will be 
	 * returned. If no results match returns null.
	 *
	 * @param string $sql an SQL select statement
	 * @return array
	 */
	public function fetchRow($sql) 
	{
		$this->lastquery = $sql;
		
		// run the query against the database
		$result = $this->tquery($sql);
		
		if ($result->num_rows == 0) {
			return null;
		}
		
		$out = $result->fetch_assoc();
		$result->free();
		
		return $out;
	}
	
	/**
	 * Expose the MySQLi prepared statement factory. Returns a prepared statement
	 * object.
	 *
	 * @param string $sql_statement SQL query with optional ? data placeholders
	 * @return object
	 */
	public function prepare($sql_statement)
	{
		$db = $this->getConnection();
		return $db->prepare($sql_statement);
	}
	
}